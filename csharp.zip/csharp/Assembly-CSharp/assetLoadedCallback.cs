﻿using System;

// Token: 0x020000F9 RID: 249
// (Invoke) Token: 0x06000642 RID: 1602
public delegate void assetLoadedCallback(OvrAvatarAsset asset);
