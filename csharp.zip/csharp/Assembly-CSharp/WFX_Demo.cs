﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000015 RID: 21
public class WFX_Demo : MonoBehaviour
{
	// Token: 0x06000058 RID: 88 RVA: 0x00003748 File Offset: 0x00001948
	private void OnMouseDown()
	{
		RaycastHit raycastHit = default(RaycastHit);
		if (base.GetComponent<Collider>().Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out raycastHit, 9999f))
		{
			GameObject gameObject = this.spawnParticle();
			if (!gameObject.name.StartsWith("WFX_MF"))
			{
				gameObject.transform.position = raycastHit.point + gameObject.transform.position;
			}
		}
	}

	// Token: 0x06000059 RID: 89 RVA: 0x000037BC File Offset: 0x000019BC
	public GameObject spawnParticle()
	{
		GameObject gameObject = Object.Instantiate<GameObject>(this.ParticleExamples[this.exampleIndex]);
		if (gameObject.name.StartsWith("WFX_MF"))
		{
			gameObject.transform.parent = this.ParticleExamples[this.exampleIndex].transform.parent;
			gameObject.transform.localPosition = this.ParticleExamples[this.exampleIndex].transform.localPosition;
			gameObject.transform.localRotation = this.ParticleExamples[this.exampleIndex].transform.localRotation;
		}
		else if (gameObject.name.Contains("Hole"))
		{
			gameObject.transform.parent = this.bulletholes.transform;
		}
		this.SetActiveCrossVersions(gameObject, true);
		return gameObject;
	}

	// Token: 0x0600005A RID: 90 RVA: 0x00003888 File Offset: 0x00001A88
	private void SetActiveCrossVersions(GameObject obj, bool active)
	{
		obj.SetActive(active);
		for (int i = 0; i < obj.transform.childCount; i++)
		{
			obj.transform.GetChild(i).gameObject.SetActive(active);
		}
	}

	// Token: 0x0600005B RID: 91 RVA: 0x000038CC File Offset: 0x00001ACC
	private void OnGUI()
	{
		GUILayout.BeginArea(new Rect(5f, 20f, (float)(Screen.width - 10), 60f));
		GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
		GUILayout.Label("Effect: " + this.ParticleExamples[this.exampleIndex].name, new GUILayoutOption[]
		{
			GUILayout.Width(280f)
		});
		if (GUILayout.Button("<", new GUILayoutOption[]
		{
			GUILayout.Width(30f)
		}))
		{
			this.prevParticle();
		}
		if (GUILayout.Button(">", new GUILayoutOption[]
		{
			GUILayout.Width(30f)
		}))
		{
			this.nextParticle();
		}
		GUILayout.FlexibleSpace();
		GUILayout.Label("Click on the ground to spawn the selected effect", Array.Empty<GUILayoutOption>());
		GUILayout.FlexibleSpace();
		if (GUILayout.Button(this.rotateCam ? "Pause Camera" : "Rotate Camera", new GUILayoutOption[]
		{
			GUILayout.Width(110f)
		}))
		{
			this.rotateCam = !this.rotateCam;
		}
		if (GUILayout.Button(base.GetComponent<Renderer>().enabled ? "Hide Ground" : "Show Ground", new GUILayoutOption[]
		{
			GUILayout.Width(90f)
		}))
		{
			base.GetComponent<Renderer>().enabled = !base.GetComponent<Renderer>().enabled;
		}
		if (GUILayout.Button(this.slowMo ? "Normal Speed" : "Slow Motion", new GUILayoutOption[]
		{
			GUILayout.Width(100f)
		}))
		{
			this.slowMo = !this.slowMo;
			if (this.slowMo)
			{
				Time.timeScale = 0.33f;
			}
			else
			{
				Time.timeScale = 1f;
			}
		}
		GUILayout.EndHorizontal();
		GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
		GUILayout.Label("Ground texture: " + this.groundTextureStr, new GUILayoutOption[]
		{
			GUILayout.Width(160f)
		});
		if (GUILayout.Button("<", new GUILayoutOption[]
		{
			GUILayout.Width(30f)
		}))
		{
			this.prevTexture();
		}
		if (GUILayout.Button(">", new GUILayoutOption[]
		{
			GUILayout.Width(30f)
		}))
		{
			this.nextTexture();
		}
		GUILayout.EndHorizontal();
		GUILayout.EndArea();
		if (this.m4.GetComponent<Renderer>().enabled)
		{
			GUILayout.BeginArea(new Rect(5f, (float)(Screen.height - 100), (float)(Screen.width - 10), 90f));
			this.rotate_m4 = GUILayout.Toggle(this.rotate_m4, "AutoRotate Weapon", new GUILayoutOption[]
			{
				GUILayout.Width(250f)
			});
			GUI.enabled = !this.rotate_m4;
			float num = this.m4.transform.localEulerAngles.x;
			num = ((num > 90f) ? (num - 180f) : num);
			float num2 = this.m4.transform.localEulerAngles.y;
			float num3 = this.m4.transform.localEulerAngles.z;
			num = GUILayout.HorizontalSlider(num, 0f, 179f, new GUILayoutOption[]
			{
				GUILayout.Width(256f)
			});
			num2 = GUILayout.HorizontalSlider(num2, 0f, 359f, new GUILayoutOption[]
			{
				GUILayout.Width(256f)
			});
			num3 = GUILayout.HorizontalSlider(num3, 0f, 359f, new GUILayoutOption[]
			{
				GUILayout.Width(256f)
			});
			if (GUI.changed)
			{
				if (num > 90f)
				{
					num += 180f;
				}
				this.m4.transform.localEulerAngles = new Vector3(num, num2, num3);
				Debug.Log(num);
			}
			GUILayout.EndArea();
		}
	}

	// Token: 0x0600005C RID: 92 RVA: 0x00003C7D File Offset: 0x00001E7D
	private IEnumerator RandomSpawnsCoroutine()
	{
		for (;;)
		{
			GameObject gameObject = this.spawnParticle();
			if (this.orderedSpawns)
			{
				gameObject.transform.position = base.transform.position + new Vector3(this.order, gameObject.transform.position.y, 0f);
				this.order -= this.step;
				if (this.order < -this.range)
				{
					this.order = this.range;
				}
			}
			else
			{
				gameObject.transform.position = base.transform.position + new Vector3(Random.Range(-this.range, this.range), 0f, Random.Range(-this.range, this.range)) + new Vector3(0f, gameObject.transform.position.y, 0f);
			}
			yield return new WaitForSeconds(float.Parse(this.randomSpawnsDelay));
		}
		yield break;
	}

	// Token: 0x0600005D RID: 93 RVA: 0x00003C8C File Offset: 0x00001E8C
	private void Update()
	{
		if (Input.GetKeyDown(KeyCode.LeftArrow))
		{
			this.prevParticle();
		}
		else if (Input.GetKeyDown(KeyCode.RightArrow))
		{
			this.nextParticle();
		}
		if (this.rotateCam)
		{
			Camera.main.transform.RotateAround(Vector3.zero, Vector3.up, this.cameraSpeed * Time.deltaTime);
		}
		if (this.rotate_m4)
		{
			this.m4.transform.Rotate(new Vector3(0f, 40f, 0f) * Time.deltaTime, Space.World);
		}
	}

	// Token: 0x0600005E RID: 94 RVA: 0x00003D24 File Offset: 0x00001F24
	private void prevTexture()
	{
		int num = this.groundTextures.IndexOf(this.groundTextureStr);
		num--;
		if (num < 0)
		{
			num = this.groundTextures.Count - 1;
		}
		this.groundTextureStr = this.groundTextures[num];
		this.selectMaterial();
	}

	// Token: 0x0600005F RID: 95 RVA: 0x00003D74 File Offset: 0x00001F74
	private void nextTexture()
	{
		int num = this.groundTextures.IndexOf(this.groundTextureStr);
		num++;
		if (num >= this.groundTextures.Count)
		{
			num = 0;
		}
		this.groundTextureStr = this.groundTextures[num];
		this.selectMaterial();
	}

	// Token: 0x06000060 RID: 96 RVA: 0x00003DC0 File Offset: 0x00001FC0
	private void selectMaterial()
	{
		string a = this.groundTextureStr;
		if (a == "Concrete")
		{
			base.GetComponent<Renderer>().material = this.concrete;
			this.walls.transform.GetChild(0).GetComponent<Renderer>().material = this.concreteWall;
			this.walls.transform.GetChild(1).GetComponent<Renderer>().material = this.concreteWall;
			return;
		}
		if (a == "Wood")
		{
			base.GetComponent<Renderer>().material = this.wood;
			this.walls.transform.GetChild(0).GetComponent<Renderer>().material = this.woodWall;
			this.walls.transform.GetChild(1).GetComponent<Renderer>().material = this.woodWall;
			return;
		}
		if (a == "Metal")
		{
			base.GetComponent<Renderer>().material = this.metal;
			this.walls.transform.GetChild(0).GetComponent<Renderer>().material = this.metalWall;
			this.walls.transform.GetChild(1).GetComponent<Renderer>().material = this.metalWall;
			return;
		}
		if (!(a == "Checker"))
		{
			return;
		}
		base.GetComponent<Renderer>().material = this.checker;
		this.walls.transform.GetChild(0).GetComponent<Renderer>().material = this.checkerWall;
		this.walls.transform.GetChild(1).GetComponent<Renderer>().material = this.checkerWall;
	}

	// Token: 0x06000061 RID: 97 RVA: 0x00003F5E File Offset: 0x0000215E
	private void prevParticle()
	{
		this.exampleIndex--;
		if (this.exampleIndex < 0)
		{
			this.exampleIndex = this.ParticleExamples.Length - 1;
		}
		this.showHideStuff();
	}

	// Token: 0x06000062 RID: 98 RVA: 0x00003F8D File Offset: 0x0000218D
	private void nextParticle()
	{
		this.exampleIndex++;
		if (this.exampleIndex >= this.ParticleExamples.Length)
		{
			this.exampleIndex = 0;
		}
		this.showHideStuff();
	}

	// Token: 0x06000063 RID: 99 RVA: 0x00003FBC File Offset: 0x000021BC
	private void showHideStuff()
	{
		if (this.ParticleExamples[this.exampleIndex].name.StartsWith("WFX_MF Spr"))
		{
			this.m4.GetComponent<Renderer>().enabled = true;
		}
		else
		{
			this.m4.GetComponent<Renderer>().enabled = false;
		}
		if (this.ParticleExamples[this.exampleIndex].name.StartsWith("WFX_MF FPS"))
		{
			this.m4fps.GetComponent<Renderer>().enabled = true;
		}
		else
		{
			this.m4fps.GetComponent<Renderer>().enabled = false;
		}
		if (this.ParticleExamples[this.exampleIndex].name.StartsWith("WFX_BImpact"))
		{
			this.SetActiveCrossVersions(this.walls, true);
			Renderer[] componentsInChildren = this.bulletholes.GetComponentsInChildren<Renderer>();
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].enabled = true;
			}
		}
		else
		{
			this.SetActiveCrossVersions(this.walls, false);
			Renderer[] componentsInChildren = this.bulletholes.GetComponentsInChildren<Renderer>();
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].enabled = false;
			}
		}
		if (this.ParticleExamples[this.exampleIndex].name.Contains("Wood"))
		{
			this.groundTextureStr = "Wood";
			this.selectMaterial();
			return;
		}
		if (this.ParticleExamples[this.exampleIndex].name.Contains("Concrete"))
		{
			this.groundTextureStr = "Concrete";
			this.selectMaterial();
			return;
		}
		if (this.ParticleExamples[this.exampleIndex].name.Contains("Metal"))
		{
			this.groundTextureStr = "Metal";
			this.selectMaterial();
			return;
		}
		if (this.ParticleExamples[this.exampleIndex].name.Contains("Dirt") || this.ParticleExamples[this.exampleIndex].name.Contains("Sand") || this.ParticleExamples[this.exampleIndex].name.Contains("SoftBody"))
		{
			this.groundTextureStr = "Checker";
			this.selectMaterial();
			return;
		}
		if (this.ParticleExamples[this.exampleIndex].name == "WFX_Explosion")
		{
			this.groundTextureStr = "Checker";
			this.selectMaterial();
		}
	}

	// Token: 0x04000047 RID: 71
	public float cameraSpeed = 10f;

	// Token: 0x04000048 RID: 72
	public bool orderedSpawns = true;

	// Token: 0x04000049 RID: 73
	public float step = 1f;

	// Token: 0x0400004A RID: 74
	public float range = 5f;

	// Token: 0x0400004B RID: 75
	private float order = -5f;

	// Token: 0x0400004C RID: 76
	public GameObject walls;

	// Token: 0x0400004D RID: 77
	public GameObject bulletholes;

	// Token: 0x0400004E RID: 78
	public GameObject[] ParticleExamples;

	// Token: 0x0400004F RID: 79
	private int exampleIndex;

	// Token: 0x04000050 RID: 80
	private string randomSpawnsDelay = "0.5";

	// Token: 0x04000051 RID: 81
	private bool randomSpawns;

	// Token: 0x04000052 RID: 82
	private bool slowMo;

	// Token: 0x04000053 RID: 83
	private bool rotateCam = true;

	// Token: 0x04000054 RID: 84
	public Material wood;

	// Token: 0x04000055 RID: 85
	public Material concrete;

	// Token: 0x04000056 RID: 86
	public Material metal;

	// Token: 0x04000057 RID: 87
	public Material checker;

	// Token: 0x04000058 RID: 88
	public Material woodWall;

	// Token: 0x04000059 RID: 89
	public Material concreteWall;

	// Token: 0x0400005A RID: 90
	public Material metalWall;

	// Token: 0x0400005B RID: 91
	public Material checkerWall;

	// Token: 0x0400005C RID: 92
	private string groundTextureStr = "Checker";

	// Token: 0x0400005D RID: 93
	private List<string> groundTextures = new List<string>(new string[]
	{
		"Concrete",
		"Wood",
		"Metal",
		"Checker"
	});

	// Token: 0x0400005E RID: 94
	public GameObject m4;

	// Token: 0x0400005F RID: 95
	public GameObject m4fps;

	// Token: 0x04000060 RID: 96
	private bool rotate_m4 = true;
}
