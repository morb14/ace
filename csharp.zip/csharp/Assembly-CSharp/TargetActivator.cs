﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200005E RID: 94
public class TargetActivator : MonoBehaviour
{
	// Token: 0x06000384 RID: 900 RVA: 0x00017659 File Offset: 0x00015859
	private void Start()
	{
		if (this.targetInfo == null && base.GetComponent<TargetInfo>())
		{
			this.targetInfo = base.GetComponent<TargetInfo>();
		}
		base.Invoke("InitiateLinks", 0.2f);
	}

	// Token: 0x06000385 RID: 901 RVA: 0x00017694 File Offset: 0x00015894
	private void InitiateLinks()
	{
		ActiveTarget[] array = Object.FindObjectsOfType<ActiveTarget>();
		if (array.Length != 0)
		{
			foreach (ActiveTarget activeTarget in array)
			{
				MonoBehaviour.print(activeTarget);
				MonoBehaviour.print(activeTarget.targetInfo);
				MonoBehaviour.print(activeTarget.targetInfo.linkID.Length);
				if (activeTarget.targetInfo.linkID != null && this.targetInfo.ContainsID(activeTarget.DetermineInstanceID()))
				{
					MonoBehaviour.print(activeTarget.DetermineInstanceID());
					this.Link(activeTarget, false);
					activeTarget.Link(this, Object.FindObjectOfType<StagePlanner>().linkLineMaterial, false);
				}
			}
		}
	}

	// Token: 0x06000386 RID: 902 RVA: 0x00017734 File Offset: 0x00015934
	public bool Linked()
	{
		return this.activeTargetList.Count > 0;
	}

	// Token: 0x06000387 RID: 903 RVA: 0x00017747 File Offset: 0x00015947
	public void Link(ActiveTarget target, bool manual = false)
	{
		if (this.targetInfo.instanceID == 0)
		{
			this.targetInfo.instanceID = this.targetInfo.gameObject.GetInstanceID();
		}
		this.activeTargetList.Add(target);
		if (manual)
		{
			this.UpdateActiveTargetID();
		}
	}

	// Token: 0x06000388 RID: 904 RVA: 0x00017786 File Offset: 0x00015986
	public int DetermineInstanceID()
	{
		if (this.targetInfo.instanceID != 0)
		{
			return this.targetInfo.instanceID;
		}
		return base.gameObject.GetInstanceID();
	}

	// Token: 0x06000389 RID: 905 RVA: 0x000177AC File Offset: 0x000159AC
	public void Unlink(ActiveTarget target)
	{
		this.activeTargetList.Remove(target);
		this.UpdateActiveTargetID();
	}

	// Token: 0x0600038A RID: 906 RVA: 0x000177C4 File Offset: 0x000159C4
	public void Activate()
	{
		foreach (ActiveTarget activeTarget in this.activeTargets)
		{
			if (activeTarget != null)
			{
				activeTarget.Activate();
			}
		}
		foreach (ActiveTarget activeTarget2 in this.activeTargetList)
		{
			if (activeTarget2 != null)
			{
				activeTarget2.Activate();
			}
			else
			{
				this.activeTargetList.Remove(activeTarget2);
			}
		}
	}

	// Token: 0x0600038B RID: 907 RVA: 0x0001785C File Offset: 0x00015A5C
	private void UpdateActiveTargetID()
	{
		this.activeTargetIDs.Clear();
		foreach (ActiveTarget activeTarget in this.activeTargetList)
		{
			this.activeTargetIDs.Add(activeTarget.DetermineInstanceID());
		}
		this.targetInfo.linkID = this.activeTargetIDs.ToArray();
	}

	// Token: 0x0600038C RID: 908 RVA: 0x000178DC File Offset: 0x00015ADC
	private void OnDestroy()
	{
		foreach (ActiveTarget activeTarget in this.activeTargetList)
		{
			if (activeTarget != null)
			{
				activeTarget.Unlink(this);
			}
			else
			{
				this.activeTargetList.Remove(activeTarget);
			}
		}
	}

	// Token: 0x0400044B RID: 1099
	[SerializeField]
	public ActiveTarget[] activeTargets;

	// Token: 0x0400044C RID: 1100
	public bool linked;

	// Token: 0x0400044D RID: 1101
	[SerializeField]
	private LineRenderer lr;

	// Token: 0x0400044E RID: 1102
	[SerializeField]
	public TargetInfo targetInfo;

	// Token: 0x0400044F RID: 1103
	private List<int> activeTargetIDs = new List<int>();

	// Token: 0x04000450 RID: 1104
	public List<ActiveTarget> activeTargetList = new List<ActiveTarget>();

	// Token: 0x020001D3 RID: 467
	public enum ActivatorType
	{
		// Token: 0x04000DCC RID: 3532
		None,
		// Token: 0x04000DCD RID: 3533
		Sender,
		// Token: 0x04000DCE RID: 3534
		Receiver
	}
}
