﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000110 RID: 272
[Serializable]
public class OVRLipSyncSequence : ScriptableObject
{
	// Token: 0x060006F0 RID: 1776 RVA: 0x0002C5F8 File Offset: 0x0002A7F8
	public OVRLipSync.Frame GetFrameAtTime(float time)
	{
		OVRLipSync.Frame result = null;
		if (time < this.length && this.entries.Count > 0)
		{
			float num = time / this.length;
			result = this.entries[(int)((float)this.entries.Count * num)];
		}
		return result;
	}

	// Token: 0x0400091D RID: 2333
	public List<OVRLipSync.Frame> entries = new List<OVRLipSync.Frame>();

	// Token: 0x0400091E RID: 2334
	public float length;
}
