﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x0200005A RID: 90
public class StagePlannerTargetDeck : MonoBehaviour
{
	// Token: 0x0400043A RID: 1082
	[SerializeField]
	public Transform deckSpin;

	// Token: 0x0400043B RID: 1083
	[SerializeField]
	public GameObject[] spheres;

	// Token: 0x0400043C RID: 1084
	[SerializeField]
	public TextMeshPro distanceTMP;

	// Token: 0x0400043D RID: 1085
	[SerializeField]
	public TextMeshPro targetTypeTMP;
}
