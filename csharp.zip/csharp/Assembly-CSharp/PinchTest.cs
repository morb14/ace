﻿using System;
using UnityEngine;

// Token: 0x02000087 RID: 135
public class PinchTest : MonoBehaviour
{
	// Token: 0x060004C6 RID: 1222 RVA: 0x00003297 File Offset: 0x00001497
	private void Start()
	{
	}

	// Token: 0x060004C7 RID: 1223 RVA: 0x0001FCAE File Offset: 0x0001DEAE
	private void Update()
	{
		this.PinchCheck();
	}

	// Token: 0x060004C8 RID: 1224 RVA: 0x0001FCB6 File Offset: 0x0001DEB6
	private void PinchCheck()
	{
		if (this.leftHand.GetFingerIsPinching(OVRHand.HandFinger.Index))
		{
			MonoBehaviour.print("LEFT INDEX PINCHING");
		}
		if (this.rightHand.GetFingerIsPinching(OVRHand.HandFinger.Index))
		{
			MonoBehaviour.print("RIGHT INDEX PINCHING");
		}
	}

	// Token: 0x0400060F RID: 1551
	[SerializeField]
	public OVRHand leftHand;

	// Token: 0x04000610 RID: 1552
	[SerializeField]
	public OVRHand rightHand;

	// Token: 0x04000611 RID: 1553
	private Transform rightIndexTip;
}
