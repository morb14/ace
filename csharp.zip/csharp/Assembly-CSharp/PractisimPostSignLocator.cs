﻿using System;
using UnityEngine;

// Token: 0x0200007D RID: 125
public class PractisimPostSignLocator : MonoBehaviour
{
	// Token: 0x06000484 RID: 1156 RVA: 0x0001E3C7 File Offset: 0x0001C5C7
	private void Start()
	{
		base.transform.position = new Vector3(3.768f, -0.13f, -3.276f);
		base.transform.eulerAngles = new Vector3(0f, -28f, 0f);
	}
}
