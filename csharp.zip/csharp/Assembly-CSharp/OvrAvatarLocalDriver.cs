﻿using System;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x020000B4 RID: 180
public class OvrAvatarLocalDriver : OvrAvatarDriver
{
	// Token: 0x060005F7 RID: 1527 RVA: 0x00026F5C File Offset: 0x0002515C
	private OvrAvatarDriver.ControllerPose GetMalibuControllerPose(OVRInput.Controller controller)
	{
		ovrAvatarButton ovrAvatarButton = (ovrAvatarButton)0;
		if (OVRInput.Get(OVRInput.Button.PrimaryIndexTrigger, controller))
		{
			ovrAvatarButton |= ovrAvatarButton.One;
		}
		return new OvrAvatarDriver.ControllerPose
		{
			buttons = ovrAvatarButton,
			touches = (OVRInput.Get(OVRInput.Touch.PrimaryTouchpad, OVRInput.Controller.Active) ? ovrAvatarTouch.One : ((ovrAvatarTouch)0)),
			joystickPosition = OVRInput.Get(OVRInput.Axis2D.PrimaryTouchpad, controller),
			indexTrigger = 0f,
			handTrigger = 0f,
			isActive = ((OVRInput.GetActiveController() & controller) > OVRInput.Controller.None)
		};
	}

	// Token: 0x060005F8 RID: 1528 RVA: 0x00026FE0 File Offset: 0x000251E0
	private OvrAvatarDriver.ControllerPose GetControllerPose(OVRInput.Controller controller)
	{
		ovrAvatarButton ovrAvatarButton = (ovrAvatarButton)0;
		if (OVRInput.Get(OVRInput.Button.One, controller))
		{
			ovrAvatarButton |= ovrAvatarButton.One;
		}
		if (OVRInput.Get(OVRInput.Button.Two, controller))
		{
			ovrAvatarButton |= ovrAvatarButton.Two;
		}
		if (OVRInput.Get(OVRInput.Button.Start, controller))
		{
			ovrAvatarButton |= ovrAvatarButton.Three;
		}
		if (OVRInput.Get(OVRInput.Button.PrimaryThumbstick, controller))
		{
			ovrAvatarButton |= ovrAvatarButton.Joystick;
		}
		ovrAvatarTouch ovrAvatarTouch = (ovrAvatarTouch)0;
		if (OVRInput.Get(OVRInput.Touch.One, controller))
		{
			ovrAvatarTouch |= ovrAvatarTouch.One;
		}
		if (OVRInput.Get(OVRInput.Touch.Two, controller))
		{
			ovrAvatarTouch |= ovrAvatarTouch.Two;
		}
		if (OVRInput.Get(OVRInput.Touch.PrimaryThumbstick, controller))
		{
			ovrAvatarTouch |= ovrAvatarTouch.Joystick;
		}
		if (OVRInput.Get(OVRInput.Touch.PrimaryThumbRest, controller))
		{
			ovrAvatarTouch |= ovrAvatarTouch.ThumbRest;
		}
		if (OVRInput.Get(OVRInput.Touch.PrimaryIndexTrigger, controller))
		{
			ovrAvatarTouch |= ovrAvatarTouch.Index;
		}
		if (!OVRInput.Get(OVRInput.NearTouch.PrimaryIndexTrigger, controller))
		{
			ovrAvatarTouch |= ovrAvatarTouch.Pointing;
		}
		if (!OVRInput.Get(OVRInput.NearTouch.PrimaryThumbButtons, controller))
		{
			ovrAvatarTouch |= ovrAvatarTouch.ThumbUp;
		}
		return new OvrAvatarDriver.ControllerPose
		{
			buttons = ovrAvatarButton,
			touches = ovrAvatarTouch,
			joystickPosition = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, controller),
			indexTrigger = OVRInput.Get(OVRInput.Axis1D.PrimaryIndexTrigger, controller),
			handTrigger = OVRInput.Get(OVRInput.Axis1D.PrimaryHandTrigger, controller),
			isActive = ((OVRInput.GetActiveController() & controller) > OVRInput.Controller.None)
		};
	}

	// Token: 0x060005F9 RID: 1529 RVA: 0x000270F0 File Offset: 0x000252F0
	private void CalculateCurrentPose()
	{
		OVRNodeStateProperties.GetNodeStatePropertyVector3(XRNode.CenterEye, NodeStatePropertyType.Position, OVRPlugin.Node.EyeCenter, OVRPlugin.Step.Render, out this.centerEyePosition);
		OVRNodeStateProperties.GetNodeStatePropertyQuaternion(XRNode.CenterEye, NodeStatePropertyType.Orientation, OVRPlugin.Node.EyeCenter, OVRPlugin.Step.Render, out this.centerEyeRotation);
		if (OvrAvatarDriver.GetIsTrackedRemote())
		{
			this.CurrentPose = new OvrAvatarDriver.PoseFrame
			{
				voiceAmplitude = this.voiceAmplitude,
				headPosition = this.centerEyePosition,
				headRotation = this.centerEyeRotation,
				handLeftPosition = OVRInput.GetLocalControllerPosition(OVRInput.Controller.LTrackedRemote),
				handLeftRotation = OVRInput.GetLocalControllerRotation(OVRInput.Controller.LTrackedRemote),
				handRightPosition = OVRInput.GetLocalControllerPosition(OVRInput.Controller.RTrackedRemote),
				handRightRotation = OVRInput.GetLocalControllerRotation(OVRInput.Controller.RTrackedRemote),
				controllerLeftPose = this.GetMalibuControllerPose(OVRInput.Controller.LTrackedRemote),
				controllerRightPose = this.GetMalibuControllerPose(OVRInput.Controller.RTrackedRemote)
			};
			return;
		}
		this.CurrentPose = new OvrAvatarDriver.PoseFrame
		{
			voiceAmplitude = this.voiceAmplitude,
			headPosition = this.centerEyePosition,
			headRotation = this.centerEyeRotation,
			handLeftPosition = OVRInput.GetLocalControllerPosition(OVRInput.Controller.LTouch),
			handLeftRotation = OVRInput.GetLocalControllerRotation(OVRInput.Controller.LTouch),
			handRightPosition = OVRInput.GetLocalControllerPosition(OVRInput.Controller.RTouch),
			handRightRotation = OVRInput.GetLocalControllerRotation(OVRInput.Controller.RTouch),
			controllerLeftPose = this.GetControllerPose(OVRInput.Controller.LTouch),
			controllerRightPose = this.GetControllerPose(OVRInput.Controller.RTouch)
		};
	}

	// Token: 0x060005FA RID: 1530 RVA: 0x0002724C File Offset: 0x0002544C
	public override void UpdateTransforms(IntPtr sdkAvatar)
	{
		this.CalculateCurrentPose();
		base.UpdateTransformsFromPose(sdkAvatar);
	}

	// Token: 0x0400072A RID: 1834
	private Vector3 centerEyePosition = Vector3.zero;

	// Token: 0x0400072B RID: 1835
	private Quaternion centerEyeRotation = Quaternion.identity;

	// Token: 0x0400072C RID: 1836
	private float voiceAmplitude;
}
