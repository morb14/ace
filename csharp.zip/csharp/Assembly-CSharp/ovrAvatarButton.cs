﻿using System;

// Token: 0x020000CA RID: 202
[Flags]
public enum ovrAvatarButton
{
	// Token: 0x040007C9 RID: 1993
	One = 1,
	// Token: 0x040007CA RID: 1994
	Two = 2,
	// Token: 0x040007CB RID: 1995
	Three = 4,
	// Token: 0x040007CC RID: 1996
	Joystick = 8
}
