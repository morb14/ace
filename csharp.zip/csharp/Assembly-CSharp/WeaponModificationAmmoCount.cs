﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000098 RID: 152
public class WeaponModificationAmmoCount : MonoBehaviour
{
	// Token: 0x06000519 RID: 1305 RVA: 0x00021038 File Offset: 0x0001F238
	private void Start()
	{
		if (this.weaponModificationButton.ButtonType() != AccessoryManager.AccessoryType.Magazine)
		{
			base.gameObject.SetActive(false);
			this.ammoAdjustmentButtons.SetActive(false);
		}
		else
		{
			this.ammoCount.enabled = true;
			this.ammoAdjustmentButtons.SetActive(true);
		}
		GameEvents.current.onWeaponModified += this.OnWeaponModified;
	}

	// Token: 0x0600051A RID: 1306 RVA: 0x0002109B File Offset: 0x0001F29B
	private void OnEnable()
	{
		this.OnWeaponModified();
	}

	// Token: 0x0600051B RID: 1307 RVA: 0x000210A4 File Offset: 0x0001F2A4
	private void OnWeaponModified()
	{
		if (Object.FindObjectOfType<WeaponController>())
		{
			int currentCapacity = Object.FindObjectOfType<WeaponController>().GetCurrentCapacity();
			if (currentCapacity == 9999)
			{
				this.ammoCount.text = "INF";
				return;
			}
			this.ammoCount.text = currentCapacity.ToString();
		}
	}

	// Token: 0x0600051C RID: 1308 RVA: 0x000210F3 File Offset: 0x0001F2F3
	private void OnDestroy()
	{
		GameEvents.current.onWeaponModified -= this.OnWeaponModified;
	}

	// Token: 0x04000657 RID: 1623
	[SerializeField]
	private WeaponModificationButton weaponModificationButton;

	// Token: 0x04000658 RID: 1624
	[SerializeField]
	private TMP_Text ammoCount;

	// Token: 0x04000659 RID: 1625
	[SerializeField]
	private GameObject ammoAdjustmentButtons;
}
