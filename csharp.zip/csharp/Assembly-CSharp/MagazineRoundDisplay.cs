﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200003B RID: 59
public class MagazineRoundDisplay : MonoBehaviour
{
	// Token: 0x060001F9 RID: 505 RVA: 0x0000AEDC File Offset: 0x000090DC
	private void Start()
	{
		this.characterControllerLayer = LayerMask.NameToLayer("CharacterController");
		this.gameManager = Object.FindObjectOfType<GameManager>();
		if (this.magRounds != null)
		{
			foreach (object obj in this.magRounds.GetComponentInChildren<Transform>())
			{
				Transform transform = (Transform)obj;
				if (!(transform.gameObject == this.magRounds))
				{
					this.rounds.Add(transform);
				}
			}
		}
		if (!this.droppedMag)
		{
			this.UpdateBlendShapes(this.rounds.Count);
		}
		GameEvents.current.onShotFired += this.ShotFired;
	}

	// Token: 0x060001FA RID: 506 RVA: 0x0000AFAC File Offset: 0x000091AC
	private void UpdateBlendShapes(int count)
	{
		if (this.spring == null)
		{
			return;
		}
		int count2 = this.rounds.Count;
		int num = this.spring.sharedMesh.blendShapeCount * 100;
		float num2 = (float)count / (float)this.rounds.Count * (float)num;
		bool flag = false;
		for (int i = 0; i < this.spring.sharedMesh.blendShapeCount; i++)
		{
			if (flag)
			{
				this.spring.SetBlendShapeWeight(i, 0f);
			}
			else if (num2 >= 100f)
			{
				this.spring.SetBlendShapeWeight(i, 100f);
				num2 -= 100f;
			}
			else
			{
				this.spring.SetBlendShapeWeight(i, num2);
				flag = true;
			}
		}
	}

	// Token: 0x060001FB RID: 507 RVA: 0x0000B060 File Offset: 0x00009260
	public void SetMaterial(Material material)
	{
		if (this.currentMagMaterial != material)
		{
			foreach (MeshRenderer meshRenderer in this.magRounds.GetComponentsInChildren<MeshRenderer>())
			{
				Material[] materials = meshRenderer.materials;
				materials[0] = material;
				materials[1] = meshRenderer.materials[1];
				meshRenderer.materials = materials;
			}
		}
		this.currentMagMaterial = material;
	}

	// Token: 0x060001FC RID: 508 RVA: 0x0000B0C0 File Offset: 0x000092C0
	private void ShotFired()
	{
		if (base.transform.parent == null)
		{
			return;
		}
		if (base.transform.root.gameObject.layer == this.characterControllerLayer && this.shotsFired < this.rounds.Count)
		{
			this.shotsFired++;
			int num = this.rounds.Count - this.shotsFired;
			this.rounds[num].gameObject.SetActive(false);
			this.UpdateBlendShapes(num);
		}
	}

	// Token: 0x060001FD RID: 509 RVA: 0x0000B150 File Offset: 0x00009350
	public void Reset()
	{
		this.shotsFired = 0;
		this.droppedMag = false;
		foreach (Transform transform in this.rounds)
		{
			transform.gameObject.SetActive(true);
		}
		this.UpdateBlendShapes(this.rounds.Count);
	}

	// Token: 0x060001FE RID: 510 RVA: 0x0000B1C8 File Offset: 0x000093C8
	public void SetCount(int count)
	{
		foreach (Transform transform in this.rounds)
		{
			if (this.rounds.IndexOf(transform) >= count)
			{
				transform.gameObject.SetActive(false);
			}
			else
			{
				transform.gameObject.SetActive(true);
			}
		}
		this.droppedMag = true;
		this.UpdateBlendShapes(count);
		MonoBehaviour.print("floor mag count " + count);
	}

	// Token: 0x060001FF RID: 511 RVA: 0x0000B260 File Offset: 0x00009460
	private void OnDestroy()
	{
		GameEvents.current.onShotFired -= this.ShotFired;
	}

	// Token: 0x040001AE RID: 430
	[SerializeField]
	public GameObject magRounds;

	// Token: 0x040001AF RID: 431
	[SerializeField]
	private SkinnedMeshRenderer spring;

	// Token: 0x040001B0 RID: 432
	private SkinnedMeshRenderer meshRenderer;

	// Token: 0x040001B1 RID: 433
	public List<Transform> rounds = new List<Transform>();

	// Token: 0x040001B2 RID: 434
	private GameManager gameManager;

	// Token: 0x040001B3 RID: 435
	private WeaponController weaponController;

	// Token: 0x040001B4 RID: 436
	private int characterControllerLayer;

	// Token: 0x040001B5 RID: 437
	private int shotsFired;

	// Token: 0x040001B6 RID: 438
	private Material currentMagMaterial;

	// Token: 0x040001B7 RID: 439
	private bool droppedMag;
}
