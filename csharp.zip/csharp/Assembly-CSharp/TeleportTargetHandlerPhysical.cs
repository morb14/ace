﻿using System;
using UnityEngine;

// Token: 0x0200012C RID: 300
public class TeleportTargetHandlerPhysical : TeleportTargetHandler
{
	// Token: 0x060007BF RID: 1983 RVA: 0x0002F93C File Offset: 0x0002DB3C
	protected override bool ConsiderTeleport(Vector3 start, ref Vector3 end)
	{
		if (base.LocomotionTeleport.AimCollisionTest(start, end, this.AimCollisionLayerMask, out this.AimData.TargetHitInfo))
		{
			Vector3 normalized = (end - start).normalized;
			end = start + normalized * this.AimData.TargetHitInfo.distance;
			return true;
		}
		return false;
	}
}
