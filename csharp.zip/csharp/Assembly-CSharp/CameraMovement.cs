﻿using System;
using UnityEngine;

// Token: 0x02000026 RID: 38
public class CameraMovement : MonoBehaviour
{
	// Token: 0x060000B6 RID: 182 RVA: 0x00005B0C File Offset: 0x00003D0C
	private void Start()
	{
		if (this.toBeDisabled.Length != 0)
		{
			GameObject[] array = this.toBeDisabled;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].SetActive(false);
			}
		}
		if (Object.FindObjectOfType<Results>())
		{
			Object.FindObjectOfType<Results>().gameObject.SetActive(false);
		}
		this.speed /= 1000f;
	}

	// Token: 0x060000B7 RID: 183 RVA: 0x00005B70 File Offset: 0x00003D70
	private void Update()
	{
		float x;
		if (this.reverseDirection)
		{
			x = -this.speed;
		}
		else
		{
			x = this.speed;
		}
		if (this.type == CameraMovement.CameraMovementType.Crab)
		{
			base.transform.Translate(x, 0f, 0f);
		}
	}

	// Token: 0x040000B5 RID: 181
	[SerializeField]
	private float speed = 1f;

	// Token: 0x040000B6 RID: 182
	[SerializeField]
	private CameraMovement.CameraMovementType type;

	// Token: 0x040000B7 RID: 183
	[SerializeField]
	private bool reverseDirection;

	// Token: 0x040000B8 RID: 184
	[SerializeField]
	private GameObject[] toBeDisabled;

	// Token: 0x020001AF RID: 431
	public enum CameraMovementType
	{
		// Token: 0x04000D10 RID: 3344
		Crab,
		// Token: 0x04000D11 RID: 3345
		Pan
	}
}
