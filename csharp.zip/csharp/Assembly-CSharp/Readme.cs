﻿using System;
using UnityEngine;

// Token: 0x0200014B RID: 331
public class Readme : ScriptableObject
{
	// Token: 0x04000A95 RID: 2709
	public Texture2D icon;

	// Token: 0x04000A96 RID: 2710
	public string title;

	// Token: 0x04000A97 RID: 2711
	public Readme.Section[] sections;

	// Token: 0x04000A98 RID: 2712
	public bool loadedLayout;

	// Token: 0x0200023A RID: 570
	[Serializable]
	public class Section
	{
		// Token: 0x04000FB1 RID: 4017
		public string heading;

		// Token: 0x04000FB2 RID: 4018
		public string text;

		// Token: 0x04000FB3 RID: 4019
		public string linkText;

		// Token: 0x04000FB4 RID: 4020
		public string url;
	}
}
