﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000099 RID: 153
public class ZeroingDisplay : MonoBehaviour
{
	// Token: 0x0600051E RID: 1310 RVA: 0x0002110C File Offset: 0x0001F30C
	private void Start()
	{
		this.defaultScale = this.hitOne.transform.localScale;
		foreach (ZeroingTargetButton item in this.zeroingPanels.GetComponentsInChildren<ZeroingTargetButton>())
		{
			this.buttons.Add(item);
		}
	}

	// Token: 0x0600051F RID: 1311 RVA: 0x0002115C File Offset: 0x0001F35C
	public void UpdateShotPosition(Vector3 shotPosition, ZeroingTargetButton zeroingTargetButton)
	{
		this.hitOne.transform.localScale = new Vector3(this.defaultScale.x * 1.4f, this.defaultScale.y * 1.4f, this.defaultScale.z * 1.4f);
		this.hitOne.SetActive(true);
		this.hitOne.transform.localPosition = shotPosition;
		this.UpdateButton(zeroingTargetButton);
		base.Invoke("Rescale", 0.1f);
	}

	// Token: 0x06000520 RID: 1312 RVA: 0x000211E8 File Offset: 0x0001F3E8
	private void UpdateButton(ZeroingTargetButton zeroingTargetButton)
	{
		if (this.currentHitButton != zeroingTargetButton)
		{
			foreach (ZeroingTargetButton zeroingTargetButton2 in this.buttons)
			{
				zeroingTargetButton2.UpdateMaterial();
			}
			zeroingTargetButton.Hit();
			this.currentHitButton = zeroingTargetButton;
		}
	}

	// Token: 0x06000521 RID: 1313 RVA: 0x00021254 File Offset: 0x0001F454
	private void Rescale()
	{
		this.hitOne.transform.localScale = this.defaultScale;
	}

	// Token: 0x0400065A RID: 1626
	[SerializeField]
	private GameObject hitOne;

	// Token: 0x0400065B RID: 1627
	[SerializeField]
	private GameObject hitTwo;

	// Token: 0x0400065C RID: 1628
	[SerializeField]
	private GameObject hitThree;

	// Token: 0x0400065D RID: 1629
	[SerializeField]
	private Transform targetTransform;

	// Token: 0x0400065E RID: 1630
	[SerializeField]
	private GameObject zeroingPanels;

	// Token: 0x0400065F RID: 1631
	private List<ZeroingTargetButton> buttons = new List<ZeroingTargetButton>();

	// Token: 0x04000660 RID: 1632
	private ZeroingTargetButton currentHitButton;

	// Token: 0x04000661 RID: 1633
	private Vector3 defaultScale;
}
