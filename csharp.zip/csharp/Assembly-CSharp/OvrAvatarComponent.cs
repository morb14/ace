﻿using System;
using System.Collections.Generic;
using Oculus.Avatar;
using UnityEngine;

// Token: 0x020000B1 RID: 177
public class OvrAvatarComponent : MonoBehaviour
{
	// Token: 0x060005E8 RID: 1512 RVA: 0x000265C8 File Offset: 0x000247C8
	public void SetOvrAvatarOwner(OvrAvatar ovrAvatarOwner)
	{
		this.owner = ovrAvatarOwner;
	}

	// Token: 0x060005E9 RID: 1513 RVA: 0x000265D4 File Offset: 0x000247D4
	public void UpdateAvatar(IntPtr nativeComponent)
	{
		CAPI.ovrAvatarComponent_Get(nativeComponent, false, ref this.nativeAvatarComponent);
		OvrAvatar.ConvertTransform(this.nativeAvatarComponent.transform, base.transform);
		uint num = 0U;
		while (num < this.nativeAvatarComponent.renderPartCount && (long)this.RenderParts.Count > (long)((ulong)num))
		{
			OvrAvatarRenderComponent ovrAvatarRenderComponent = this.RenderParts[(int)num];
			IntPtr renderPart = OvrAvatar.GetRenderPart(this.nativeAvatarComponent, num);
			switch (CAPI.ovrAvatarRenderPart_GetType(renderPart))
			{
			case ovrAvatarRenderPartType.SkinnedMeshRender:
				((OvrAvatarSkinnedMeshRenderComponent)ovrAvatarRenderComponent).UpdateSkinnedMeshRender(this, this.owner, renderPart);
				break;
			case ovrAvatarRenderPartType.SkinnedMeshRenderPBS:
				((OvrAvatarSkinnedMeshRenderPBSComponent)ovrAvatarRenderComponent).UpdateSkinnedMeshRenderPBS(this.owner, renderPart, ovrAvatarRenderComponent.mesh.sharedMaterial);
				break;
			case ovrAvatarRenderPartType.SkinnedMeshRenderPBS_V2:
				((OvrAvatarSkinnedMeshPBSV2RenderComponent)ovrAvatarRenderComponent).UpdateSkinnedMeshRender(this, this.owner, renderPart);
				break;
			}
			num += 1U;
		}
	}

	// Token: 0x060005EA RID: 1514 RVA: 0x000266B4 File Offset: 0x000248B4
	protected void UpdateActive(OvrAvatar avatar, ovrAvatarVisibilityFlags mask)
	{
		bool flag = avatar.ShowFirstPerson && (mask & ovrAvatarVisibilityFlags.FirstPerson) > (ovrAvatarVisibilityFlags)0;
		flag |= (avatar.ShowThirdPerson && (mask & ovrAvatarVisibilityFlags.ThirdPerson) > (ovrAvatarVisibilityFlags)0);
		base.gameObject.SetActive(flag);
	}

	// Token: 0x060005EB RID: 1515 RVA: 0x000266F4 File Offset: 0x000248F4
	public void UpdateAvatarMaterial(Material mat, ovrAvatarMaterialState matState)
	{
		mat.SetColor("_BaseColor", matState.baseColor);
		mat.SetInt("_BaseMaskType", (int)matState.baseMaskType);
		mat.SetVector("_BaseMaskParameters", matState.baseMaskParameters);
		mat.SetVector("_BaseMaskAxis", matState.baseMaskAxis);
		if (matState.alphaMaskTextureID != 0UL)
		{
			mat.SetTexture("_AlphaMask", OvrAvatarComponent.GetLoadedTexture(matState.alphaMaskTextureID));
			mat.SetTextureScale("_AlphaMask", new Vector2(matState.alphaMaskScaleOffset.x, matState.alphaMaskScaleOffset.y));
			mat.SetTextureOffset("_AlphaMask", new Vector2(matState.alphaMaskScaleOffset.z, matState.alphaMaskScaleOffset.w));
		}
		if (matState.normalMapTextureID != 0UL)
		{
			mat.EnableKeyword("NORMAL_MAP_ON");
			mat.SetTexture("_NormalMap", OvrAvatarComponent.GetLoadedTexture(matState.normalMapTextureID));
			mat.SetTextureScale("_NormalMap", new Vector2(matState.normalMapScaleOffset.x, matState.normalMapScaleOffset.y));
			mat.SetTextureOffset("_NormalMap", new Vector2(matState.normalMapScaleOffset.z, matState.normalMapScaleOffset.w));
		}
		if (matState.parallaxMapTextureID != 0UL)
		{
			mat.SetTexture("_ParallaxMap", OvrAvatarComponent.GetLoadedTexture(matState.parallaxMapTextureID));
			mat.SetTextureScale("_ParallaxMap", new Vector2(matState.parallaxMapScaleOffset.x, matState.parallaxMapScaleOffset.y));
			mat.SetTextureOffset("_ParallaxMap", new Vector2(matState.parallaxMapScaleOffset.z, matState.parallaxMapScaleOffset.w));
		}
		if (matState.roughnessMapTextureID != 0UL)
		{
			mat.EnableKeyword("ROUGHNESS_ON");
			mat.SetTexture("_RoughnessMap", OvrAvatarComponent.GetLoadedTexture(matState.roughnessMapTextureID));
			mat.SetTextureScale("_RoughnessMap", new Vector2(matState.roughnessMapScaleOffset.x, matState.roughnessMapScaleOffset.y));
			mat.SetTextureOffset("_RoughnessMap", new Vector2(matState.roughnessMapScaleOffset.z, matState.roughnessMapScaleOffset.w));
		}
		mat.EnableKeyword(OvrAvatarComponent.LayerKeywords[(int)matState.layerCount]);
		for (ulong num = 0UL; num < (ulong)matState.layerCount; num += 1UL)
		{
			checked
			{
				ovrAvatarMaterialLayerState ovrAvatarMaterialLayerState = matState.layers[(int)((IntPtr)num)];
				mat.SetInt(OvrAvatarComponent.LayerSampleModeParameters[(int)((IntPtr)num)], (int)ovrAvatarMaterialLayerState.sampleMode);
				mat.SetInt(OvrAvatarComponent.LayerBlendModeParameters[(int)((IntPtr)num)], (int)ovrAvatarMaterialLayerState.blendMode);
				mat.SetInt(OvrAvatarComponent.LayerMaskTypeParameters[(int)((IntPtr)num)], (int)ovrAvatarMaterialLayerState.maskType);
				mat.SetColor(OvrAvatarComponent.LayerColorParameters[(int)((IntPtr)num)], ovrAvatarMaterialLayerState.layerColor);
				if (ovrAvatarMaterialLayerState.sampleMode != ovrAvatarMaterialLayerSampleMode.Color)
				{
					string name = OvrAvatarComponent.LayerSurfaceParameters[(int)((IntPtr)num)];
					mat.SetTexture(name, OvrAvatarComponent.GetLoadedTexture(ovrAvatarMaterialLayerState.sampleTexture));
					mat.SetTextureScale(name, new Vector2(ovrAvatarMaterialLayerState.sampleScaleOffset.x, ovrAvatarMaterialLayerState.sampleScaleOffset.y));
					mat.SetTextureOffset(name, new Vector2(ovrAvatarMaterialLayerState.sampleScaleOffset.z, ovrAvatarMaterialLayerState.sampleScaleOffset.w));
				}
				if (ovrAvatarMaterialLayerState.sampleMode == ovrAvatarMaterialLayerSampleMode.Parallax)
				{
					mat.EnableKeyword("PARALLAX_ON");
				}
				mat.SetColor(OvrAvatarComponent.LayerSampleParametersParameters[(int)((IntPtr)num)], ovrAvatarMaterialLayerState.sampleParameters);
				mat.SetColor(OvrAvatarComponent.LayerMaskParametersParameters[(int)((IntPtr)num)], ovrAvatarMaterialLayerState.maskParameters);
				mat.SetColor(OvrAvatarComponent.LayerMaskAxisParameters[(int)((IntPtr)num)], ovrAvatarMaterialLayerState.maskAxis);
			}
		}
		this.materialStates[mat] = matState;
	}

	// Token: 0x060005EC RID: 1516 RVA: 0x00026A6C File Offset: 0x00024C6C
	public static Texture2D GetLoadedTexture(ulong assetId)
	{
		OvrAvatarAssetTexture ovrAvatarAssetTexture = (OvrAvatarAssetTexture)OvrAvatarSDKManager.Instance.GetAsset(assetId);
		if (ovrAvatarAssetTexture == null)
		{
			return null;
		}
		return ovrAvatarAssetTexture.texture;
	}

	// Token: 0x04000718 RID: 1816
	public static readonly string[] LayerKeywords = new string[]
	{
		"LAYERS_0",
		"LAYERS_1",
		"LAYERS_2",
		"LAYERS_3",
		"LAYERS_4",
		"LAYERS_5",
		"LAYERS_6",
		"LAYERS_7",
		"LAYERS_8"
	};

	// Token: 0x04000719 RID: 1817
	public static readonly string[] LayerSampleModeParameters = new string[]
	{
		"_LayerSampleMode0",
		"_LayerSampleMode1",
		"_LayerSampleMode2",
		"_LayerSampleMode3",
		"_LayerSampleMode4",
		"_LayerSampleMode5",
		"_LayerSampleMode6",
		"_LayerSampleMode7"
	};

	// Token: 0x0400071A RID: 1818
	public static readonly string[] LayerBlendModeParameters = new string[]
	{
		"_LayerBlendMode0",
		"_LayerBlendMode1",
		"_LayerBlendMode2",
		"_LayerBlendMode3",
		"_LayerBlendMode4",
		"_LayerBlendMode5",
		"_LayerBlendMode6",
		"_LayerBlendMode7"
	};

	// Token: 0x0400071B RID: 1819
	public static readonly string[] LayerMaskTypeParameters = new string[]
	{
		"_LayerMaskType0",
		"_LayerMaskType1",
		"_LayerMaskType2",
		"_LayerMaskType3",
		"_LayerMaskType4",
		"_LayerMaskType5",
		"_LayerMaskType6",
		"_LayerMaskType7"
	};

	// Token: 0x0400071C RID: 1820
	public static readonly string[] LayerColorParameters = new string[]
	{
		"_LayerColor0",
		"_LayerColor1",
		"_LayerColor2",
		"_LayerColor3",
		"_LayerColor4",
		"_LayerColor5",
		"_LayerColor6",
		"_LayerColor7"
	};

	// Token: 0x0400071D RID: 1821
	public static readonly string[] LayerSurfaceParameters = new string[]
	{
		"_LayerSurface0",
		"_LayerSurface1",
		"_LayerSurface2",
		"_LayerSurface3",
		"_LayerSurface4",
		"_LayerSurface5",
		"_LayerSurface6",
		"_LayerSurface7"
	};

	// Token: 0x0400071E RID: 1822
	public static readonly string[] LayerSampleParametersParameters = new string[]
	{
		"_LayerSampleParameters0",
		"_LayerSampleParameters1",
		"_LayerSampleParameters2",
		"_LayerSampleParameters3",
		"_LayerSampleParameters4",
		"_LayerSampleParameters5",
		"_LayerSampleParameters6",
		"_LayerSampleParameters7"
	};

	// Token: 0x0400071F RID: 1823
	public static readonly string[] LayerMaskParametersParameters = new string[]
	{
		"_LayerMaskParameters0",
		"_LayerMaskParameters1",
		"_LayerMaskParameters2",
		"_LayerMaskParameters3",
		"_LayerMaskParameters4",
		"_LayerMaskParameters5",
		"_LayerMaskParameters6",
		"_LayerMaskParameters7"
	};

	// Token: 0x04000720 RID: 1824
	public static readonly string[] LayerMaskAxisParameters = new string[]
	{
		"_LayerMaskAxis0",
		"_LayerMaskAxis1",
		"_LayerMaskAxis2",
		"_LayerMaskAxis3",
		"_LayerMaskAxis4",
		"_LayerMaskAxis5",
		"_LayerMaskAxis6",
		"_LayerMaskAxis7"
	};

	// Token: 0x04000721 RID: 1825
	private Dictionary<Material, ovrAvatarMaterialState> materialStates = new Dictionary<Material, ovrAvatarMaterialState>();

	// Token: 0x04000722 RID: 1826
	public List<OvrAvatarRenderComponent> RenderParts = new List<OvrAvatarRenderComponent>();

	// Token: 0x04000723 RID: 1827
	protected OvrAvatar owner;

	// Token: 0x04000724 RID: 1828
	protected ovrAvatarComponent nativeAvatarComponent;
}
