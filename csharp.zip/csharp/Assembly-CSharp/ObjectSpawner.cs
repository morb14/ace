﻿using System;
using UnityEngine;

// Token: 0x02000041 RID: 65
public class ObjectSpawner : MonoBehaviour
{
	// Token: 0x0600021D RID: 541 RVA: 0x0000BD9A File Offset: 0x00009F9A
	private void Start()
	{
		base.Invoke("DisableRenderer", Time.deltaTime);
		this.materialAssigner.SwitchMaterial(false, null);
	}

	// Token: 0x0600021E RID: 542 RVA: 0x0000BDB9 File Offset: 0x00009FB9
	private void DisableRenderer()
	{
		this.thisRenderer.enabled = false;
	}

	// Token: 0x0600021F RID: 543 RVA: 0x0000BDC8 File Offset: 0x00009FC8
	public void SpawnIndicator()
	{
		this.spawnerIndicator = Object.Instantiate<GameObject>(this.objectToSpawn, Vector3.zero, Quaternion.identity);
		Renderer[] componentsInChildren = this.spawnerIndicator.GetComponentsInChildren<Renderer>(true);
		for (int i = 0; i < componentsInChildren.Length; i++)
		{
			componentsInChildren[i].gameObject.layer = LayerMask.GetMask(new string[]
			{
				"Default"
			});
		}
		Collider[] componentsInChildren2 = this.spawnerIndicator.GetComponentsInChildren<Collider>(true);
		for (int i = 0; i < componentsInChildren2.Length; i++)
		{
			Object.Destroy(componentsInChildren2[i]);
		}
		PaperTarget[] componentsInChildren3 = this.spawnerIndicator.GetComponentsInChildren<PaperTarget>(true);
		for (int i = 0; i < componentsInChildren3.Length; i++)
		{
			Object.Destroy(componentsInChildren3[i]);
		}
		componentsInChildren2 = this.spawnerIndicator.GetComponentsInChildren<Collider>(true);
		for (int i = 0; i < componentsInChildren2.Length; i++)
		{
			Object.Destroy(componentsInChildren2[i]);
		}
		TargetDetach[] componentsInChildren4 = this.spawnerIndicator.GetComponentsInChildren<TargetDetach>(true);
		for (int i = 0; i < componentsInChildren4.Length; i++)
		{
			Object.Destroy(componentsInChildren4[i]);
		}
		HingeJoint[] componentsInChildren5 = this.spawnerIndicator.GetComponentsInChildren<HingeJoint>(true);
		for (int i = 0; i < componentsInChildren5.Length; i++)
		{
			Object.Destroy(componentsInChildren5[i]);
		}
		FixedJoint[] componentsInChildren6 = this.spawnerIndicator.GetComponentsInChildren<FixedJoint>(true);
		for (int i = 0; i < componentsInChildren6.Length; i++)
		{
			Object.Destroy(componentsInChildren6[i]);
		}
		Rigidbody[] componentsInChildren7 = this.spawnerIndicator.GetComponentsInChildren<Rigidbody>(true);
		for (int i = 0; i < componentsInChildren7.Length; i++)
		{
			Object.Destroy(componentsInChildren7[i]);
		}
		SteelTarget[] componentsInChildren8 = this.spawnerIndicator.GetComponentsInChildren<SteelTarget>(true);
		for (int i = 0; i < componentsInChildren8.Length; i++)
		{
			Object.Destroy(componentsInChildren8[i]);
		}
		TexasReset[] componentsInChildren9 = this.spawnerIndicator.GetComponentsInChildren<TexasReset>(true);
		for (int i = 0; i < componentsInChildren9.Length; i++)
		{
			Object.Destroy(componentsInChildren9[i]);
		}
		OtherTarget[] componentsInChildren10 = this.spawnerIndicator.GetComponentsInChildren<OtherTarget>(true);
		for (int i = 0; i < componentsInChildren10.Length; i++)
		{
			Object.Destroy(componentsInChildren10[i]);
		}
		SpawnOneOnly[] componentsInChildren11 = this.spawnerIndicator.GetComponentsInChildren<SpawnOneOnly>(true);
		for (int i = 0; i < componentsInChildren11.Length; i++)
		{
			Object.Destroy(componentsInChildren11[i]);
		}
		this.spawnerIndicator.AddComponent<MaterialReplacer>();
		this.spawnerIndicator.GetComponent<MaterialReplacer>().SwitchMaterial(this.blueprintMaterial);
		this.spawnerIndicator.SetActive(false);
		this.indicatorSpawned = true;
	}

	// Token: 0x06000220 RID: 544 RVA: 0x0000BFFC File Offset: 0x0000A1FC
	public void Adjusting(bool adjusting)
	{
		if (adjusting)
		{
			if (this.spawnerIndicator != null)
			{
				this.spawnerIndicator.GetComponent<MaterialReplacer>().SwitchMaterial(this.adjustBluePrint);
				return;
			}
		}
		else if (this.spawnerIndicator != null)
		{
			this.spawnerIndicator.GetComponent<MaterialReplacer>().SwitchMaterial(this.blueprintMaterial);
		}
	}

	// Token: 0x06000221 RID: 545 RVA: 0x0000C055 File Offset: 0x0000A255
	private void OnDestroy()
	{
		Object.Destroy(this.spawnerIndicator);
	}

	// Token: 0x040001E7 RID: 487
	[SerializeField]
	public GameObject objectToSpawn;

	// Token: 0x040001E8 RID: 488
	[SerializeField]
	public Transform offset;

	// Token: 0x040001E9 RID: 489
	[SerializeField]
	private Renderer thisRenderer;

	// Token: 0x040001EA RID: 490
	[SerializeField]
	public MaterialAssigner materialAssigner;

	// Token: 0x040001EB RID: 491
	[SerializeField]
	public Material blueprintMaterial;

	// Token: 0x040001EC RID: 492
	[SerializeField]
	public Material adjustBluePrint;

	// Token: 0x040001ED RID: 493
	[SerializeField]
	public AudioClip spawnSoundEffect;

	// Token: 0x040001EE RID: 494
	[Header("Adjustability")]
	[SerializeField]
	public bool adjustFineTune;

	// Token: 0x040001EF RID: 495
	[SerializeField]
	public bool adjustHeight;

	// Token: 0x040001F0 RID: 496
	[SerializeField]
	public bool adjustPitch;

	// Token: 0x040001F1 RID: 497
	[SerializeField]
	public bool adjustRoll;

	// Token: 0x040001F2 RID: 498
	[SerializeField]
	public bool adjustYaw;

	// Token: 0x040001F3 RID: 499
	[SerializeField]
	public bool flippable;

	// Token: 0x040001F4 RID: 500
	public GameObject spawnerIndicator;

	// Token: 0x040001F5 RID: 501
	private Material[] materials;

	// Token: 0x040001F6 RID: 502
	public bool indicatorSpawned;

	// Token: 0x040001F7 RID: 503
	public bool flipped;
}
