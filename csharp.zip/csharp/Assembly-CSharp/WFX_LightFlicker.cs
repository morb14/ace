﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x0200001D RID: 29
[RequireComponent(typeof(Light))]
public class WFX_LightFlicker : MonoBehaviour
{
	// Token: 0x06000089 RID: 137 RVA: 0x000051D8 File Offset: 0x000033D8
	private void Start()
	{
		this.timer = this.time;
		base.StartCoroutine("Flicker");
	}

	// Token: 0x0600008A RID: 138 RVA: 0x000051F2 File Offset: 0x000033F2
	private IEnumerator Flicker()
	{
		for (;;)
		{
			base.GetComponent<Light>().enabled = !base.GetComponent<Light>().enabled;
			do
			{
				this.timer -= Time.deltaTime;
				yield return null;
			}
			while (this.timer > 0f);
			this.timer = this.time;
		}
		yield break;
	}

	// Token: 0x04000097 RID: 151
	public float time = 0.05f;

	// Token: 0x04000098 RID: 152
	private float timer;
}
