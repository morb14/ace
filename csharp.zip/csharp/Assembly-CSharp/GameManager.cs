﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x0200002C RID: 44
public class GameManager : MonoBehaviour
{
	// Token: 0x06000180 RID: 384 RVA: 0x00008348 File Offset: 0x00006548
	private void Awake()
	{
		this.soundManager = base.GetComponent<SoundManager>();
		if (!Object.FindObjectOfType<OVRPlayerController>())
		{
			this.SpawnRig(null);
		}
		SceneManager.sceneLoaded += this.OnSceneLoaded;
	}

	// Token: 0x06000181 RID: 385 RVA: 0x0000837A File Offset: 0x0000657A
	public void PassMessage(string message, bool errorNoise = false)
	{
		this.broadcastMessage = message;
		if (errorNoise)
		{
			this.soundManager.Play(this.soundManager.UIerror);
		}
	}

	// Token: 0x06000182 RID: 386 RVA: 0x0000839C File Offset: 0x0000659C
	public GameObject ActiveHandObject()
	{
		if (this.handObjectLeft.activeSelf && this.handObjectRight.activeSelf)
		{
			return null;
		}
		if (this.handObjectLeft.activeSelf)
		{
			return this.handObjectLeft;
		}
		if (this.handObjectRight.activeSelf)
		{
			return this.handObjectRight;
		}
		return null;
	}

	// Token: 0x06000183 RID: 387 RVA: 0x000083F0 File Offset: 0x000065F0
	private void SpawnDefaultWeapon()
	{
		if (SceneManager.GetActiveScene().buildIndex == 0 || this.spawnedRig.GetComponentInChildren<WeaponController>() || Object.FindObjectOfType<SceneSettings>().noDefaultWeapon)
		{
			return;
		}
		GameObject gameObject = Object.Instantiate<GameObject>(this.defaultWeapon, this.spawnedRig.transform);
		Transform transform = this.spawnedRig.transform.Find("TestingHolsterPosition");
		if (transform != null)
		{
			gameObject.transform.position = transform.position;
			gameObject.transform.rotation = transform.rotation;
			gameObject.GetComponent<Rigidbody>().isKinematic = true;
			gameObject.GetComponent<Rigidbody>().useGravity = false;
		}
	}

	// Token: 0x06000184 RID: 388 RVA: 0x0000849C File Offset: 0x0000669C
	private void SpawnRig(GameObject rig = null)
	{
		if (rig == null)
		{
			this.spawnedRig = Object.Instantiate<GameObject>(this.playerRig, Vector3.zero, Quaternion.identity);
			Object.DontDestroyOnLoad(this.spawnedRig);
		}
		else
		{
			this.spawnedRig = Object.Instantiate<GameObject>(rig, Vector3.zero, Quaternion.identity);
		}
		this.GetHandObjects();
		Object.FindObjectOfType<SceneSettings>().MovePlayerToStartPos(this.spawnedRig);
	}

	// Token: 0x06000185 RID: 389 RVA: 0x00008508 File Offset: 0x00006708
	private void GetHandObjects()
	{
		foreach (OVRGrabber ovrgrabber in this.spawnedRig.GetComponentsInChildren<OVRGrabber>())
		{
			if (ovrgrabber.controllerType == OVRInput.Controller.LTouch)
			{
				this.handObjectLeft = ovrgrabber.gameObject;
			}
			if (ovrgrabber.controllerType == OVRInput.Controller.RTouch)
			{
				this.handObjectRight = ovrgrabber.gameObject;
			}
		}
	}

	// Token: 0x06000186 RID: 390 RVA: 0x0000855D File Offset: 0x0000675D
	public SceneSettings GetSceneSettings()
	{
		return base.GetComponentInParent<SceneSettings>();
	}

	// Token: 0x06000187 RID: 391 RVA: 0x00008568 File Offset: 0x00006768
	private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
	{
		if (!Object.FindObjectOfType<OVRPlayerController>())
		{
			this.SpawnRig(null);
		}
		if (Object.FindObjectOfType<SceneSettings>())
		{
			this.currentScene = Object.FindObjectOfType<SceneSettings>();
			if (this.currentScene.rigOverride && this.currentScene.rigToOverride != null)
			{
				MonoBehaviour.print("ON SCENELOAD RIGS CHECK, NUKING ALL RIGS");
				OVRPlayerController[] array = Object.FindObjectsOfType<OVRPlayerController>();
				for (int i = 0; i < array.Length; i++)
				{
					Object.Destroy(array[i].gameObject);
				}
				base.Invoke("DelayedSpawnRig", 0.2f);
			}
		}
	}

	// Token: 0x06000188 RID: 392 RVA: 0x000085FA File Offset: 0x000067FA
	private void DelayedSpawnRig()
	{
		this.SpawnRig(Object.FindObjectOfType<SceneSettings>().rigToOverride);
	}

	// Token: 0x06000189 RID: 393 RVA: 0x0000860C File Offset: 0x0000680C
	public GameObject Player()
	{
		return this.spawnedRig;
	}

	// Token: 0x0600018A RID: 394 RVA: 0x00008614 File Offset: 0x00006814
	public void TextBlock(int sceneIndex)
	{
		if (!this.indexList.Contains(sceneIndex))
		{
			this.indexList.Add(sceneIndex);
		}
	}

	// Token: 0x0600018B RID: 395 RVA: 0x00008630 File Offset: 0x00006830
	public bool TextCheck(int sceneIndex)
	{
		return this.indexList.Contains(sceneIndex);
	}

	// Token: 0x0600018C RID: 396 RVA: 0x00008643 File Offset: 0x00006843
	private void OnDestroy()
	{
		SceneManager.sceneLoaded -= this.OnSceneLoaded;
	}

	// Token: 0x0400011E RID: 286
	[SerializeField]
	public GameObject playerRig;

	// Token: 0x0400011F RID: 287
	[SerializeField]
	public GameObject handObjectLeft;

	// Token: 0x04000120 RID: 288
	[SerializeField]
	public GameObject handObjectRight;

	// Token: 0x04000121 RID: 289
	[SerializeField]
	private GameObject defaultWeapon;

	// Token: 0x04000122 RID: 290
	[SerializeField]
	public GameObject holsteredWeapon;

	// Token: 0x04000123 RID: 291
	[SerializeField]
	public GameObject stagePlannerObject;

	// Token: 0x04000124 RID: 292
	public string broadcastMessage;

	// Token: 0x04000125 RID: 293
	private List<int> indexList = new List<int>();

	// Token: 0x04000126 RID: 294
	private Transform playerRigTransform;

	// Token: 0x04000127 RID: 295
	private GameObject spawnedRig;

	// Token: 0x04000128 RID: 296
	private SoundManager soundManager;

	// Token: 0x04000129 RID: 297
	public SceneSettings currentScene;
}
