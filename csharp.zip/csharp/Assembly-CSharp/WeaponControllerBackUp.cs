﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000054 RID: 84
public class WeaponControllerBackUp : MonoBehaviour
{
	// Token: 0x06000322 RID: 802 RVA: 0x000141D4 File Offset: 0x000123D4
	private void Start()
	{
		this.controlManager = Object.FindObjectOfType<ControlManager>();
		this.hapticManager = Object.FindObjectOfType<HapticManager>();
		this.triggerReset = true;
		this.audioSource = base.gameObject.AddComponent<AudioSource>();
		this.audioSource.spatialBlend = 1f;
		this.lastPos = Vector3.zero;
		if (this.currentAmmo == 0)
		{
			this.currentAmmo = this.magazineCapacity + 1;
			this.status = WeaponControllerBackUp.WeaponStatus.Loaded;
		}
		if (this.animator == null)
		{
			this.animator = base.GetComponentInChildren<Animator>();
		}
		this.hasMagazine = true;
		this.canShoot = true;
	}

	// Token: 0x06000323 RID: 803 RVA: 0x0001426F File Offset: 0x0001246F
	public string WeaponID()
	{
		return this.weaponID;
	}

	// Token: 0x06000324 RID: 804 RVA: 0x00014277 File Offset: 0x00012477
	private void Update()
	{
		if (!this.holstered)
		{
			this.TapDetection();
			this.InputControl();
		}
	}

	// Token: 0x06000325 RID: 805 RVA: 0x0001428D File Offset: 0x0001248D
	private void InputControl()
	{
		this.TriggerControl();
		this.EjectMagazine();
		this.SlideAction();
		this.SafetyLever();
	}

	// Token: 0x06000326 RID: 806 RVA: 0x000142A7 File Offset: 0x000124A7
	public WeaponControllerBackUp.WeaponStatus CheckCondition()
	{
		return this.status;
	}

	// Token: 0x06000327 RID: 807 RVA: 0x000142B0 File Offset: 0x000124B0
	private void SafetyLever()
	{
		Vector2 vector = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, this.controlManager.controller);
		if (this.hammerDrop)
		{
			return;
		}
		if (vector.x > 0.9f && !this.safetyOn)
		{
			this.animator.SetTrigger("SafetyOn");
			this.safetyOn = true;
			return;
		}
		if (vector.x < -0.8f && this.safetyOn)
		{
			this.animator.SetTrigger("SafetyOff");
			this.safetyOn = false;
		}
	}

	// Token: 0x06000328 RID: 808 RVA: 0x00014334 File Offset: 0x00012534
	private void SlideActionType(bool lockSlide, bool returnSlide, bool reduceAmmo)
	{
		this.audioSource.PlayOneShot(this.audioSlideRelease);
		if (lockSlide)
		{
			this.animator.SetTrigger("SlideCycleLast");
			this.status = WeaponControllerBackUp.WeaponStatus.SlideLockedBack;
		}
		if (returnSlide)
		{
			this.animator.SetTrigger("SlideRelease");
		}
		if (!lockSlide)
		{
		}
		if (reduceAmmo)
		{
			this.currentAmmo--;
			this.roundEjection.Emit(this.roundEjection.transform.position, this.roundEjection.transform.forward * 3f, 1f, 2f, Color.white);
		}
	}

	// Token: 0x06000329 RID: 809 RVA: 0x000143E0 File Offset: 0x000125E0
	private void SlideAction()
	{
		Vector2 vector = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, this.controlManager.controller);
		if (vector.y < 0f && (double)vector.x > -0.2 && (double)vector.x < 0.2)
		{
			MonoBehaviour.print("JOYSTICK PULL " + Mathf.Abs(vector.y));
			this.animator.SetFloat("JoyStickPull", Mathf.Abs(vector.y));
			if (vector.y < -0.8f && !this.slideActionPerformed)
			{
				this.slideActionPerformed = true;
				if (this.status == WeaponControllerBackUp.WeaponStatus.SlideLockedBack || this.status == WeaponControllerBackUp.WeaponStatus.LoadedSlideLockedBack || this.status == WeaponControllerBackUp.WeaponStatus.EmptySlideLockedBack)
				{
					if (this.currentAmmo > 1)
					{
						this.SlideActionType(false, true, false);
						this.status = WeaponControllerBackUp.WeaponStatus.Loaded;
						this.canShoot = true;
						return;
					}
					this.SlideActionType(false, true, false);
					GameEvents.current.ChamberEmpty();
					this.status = WeaponControllerBackUp.WeaponStatus.Empty;
					return;
				}
				else if (this.hasMagazine)
				{
					if (this.status == WeaponControllerBackUp.WeaponStatus.Loaded)
					{
						if (this.currentAmmo > 1)
						{
							this.SlideActionType(false, false, true);
						}
						if (this.currentAmmo == 1)
						{
							this.SlideActionType(true, false, true);
							this.status = WeaponControllerBackUp.WeaponStatus.SlideLockedBack;
							this.canShoot = false;
						}
					}
					else if (this.status == WeaponControllerBackUp.WeaponStatus.LoadedEmptyChamber)
					{
						this.SlideActionType(false, false, false);
						this.canShoot = true;
						this.status = WeaponControllerBackUp.WeaponStatus.Loaded;
					}
					else if (this.status == WeaponControllerBackUp.WeaponStatus.Empty)
					{
						this.SlideActionType(true, false, false);
					}
				}
				else if (!this.hasMagazine)
				{
					if (this.status == WeaponControllerBackUp.WeaponStatus.EmptyRoundInChamber)
					{
						this.SlideActionType(false, false, true);
						this.status = WeaponControllerBackUp.WeaponStatus.Empty;
						GameEvents.current.GunEmpty();
						this.currentAmmo = 0;
					}
					if (this.status == WeaponControllerBackUp.WeaponStatus.Empty)
					{
						GameEvents.current.GunEmpty();
						this.SlideActionType(false, false, false);
					}
				}
			}
			this.hammerDrop = false;
			if (this.slideActionPerformed && vector.y > -0.1f)
			{
				this.slideActionPerformed = false;
			}
		}
	}

	// Token: 0x0600032A RID: 810 RVA: 0x000145DC File Offset: 0x000127DC
	private void EjectMagazine()
	{
		if (OVRInput.GetDown(OVRInput.Button.One, this.controlManager.controller) && this.hasMagazine)
		{
			MonoBehaviour.print("Mag released, current mag in queue " + this.magazineQueue.Count);
			if (this.magazineQueue.Count < this.maxMagazine)
			{
				GameObject gameObject = Object.Instantiate<GameObject>(this.magazineToBeEjected, this.magazineToBeDisabled.transform.position, this.magazineToBeDisabled.transform.rotation);
				gameObject.AddComponent<BoxCollider>();
				gameObject.layer = LayerMask.NameToLayer("GrabColliders");
				gameObject.AddComponent<Rigidbody>();
				gameObject.GetComponent<Rigidbody>().AddForce(this.magazineEjectionDirection.forward * 2f, ForceMode.Impulse);
				this.magazineQueue.Enqueue(gameObject);
			}
			else
			{
				GameObject gameObject2 = this.magazineQueue.Dequeue();
				gameObject2.transform.position = this.magazineToBeDisabled.transform.position;
				gameObject2.transform.rotation = this.magazineToBeDisabled.transform.rotation;
				gameObject2.GetComponent<Rigidbody>().velocity = Vector3.zero;
				gameObject2.GetComponent<Rigidbody>().AddForce(this.magazineEjectionDirection.forward * 2f, ForceMode.Impulse);
				this.magazineQueue.Enqueue(gameObject2);
			}
			this.magazineToBeDisabled.SetActive(false);
			this.audioSource.PlayOneShot(this.audioMagazineEject);
			this.hasMagazine = false;
			if (this.currentAmmo > 0)
			{
				this.currentAmmo = 1;
				this.status = WeaponControllerBackUp.WeaponStatus.EmptyRoundInChamber;
				return;
			}
			if (this.status != WeaponControllerBackUp.WeaponStatus.SlideLockedBack)
			{
				this.status = WeaponControllerBackUp.WeaponStatus.Empty;
			}
		}
	}

	// Token: 0x0600032B RID: 811 RVA: 0x00014780 File Offset: 0x00012980
	private void TapDetection()
	{
		if (Vector3.Distance(base.transform.position, this.lastPos) > this.detectionThreshold && !this.hasMagazine && !this.ignoreReload)
		{
			this.magazineToBeDisabled.SetActive(true);
			if (this.currentAmmo >= 1)
			{
				this.currentAmmo = this.magazineCapacity + 1;
				this.status = WeaponControllerBackUp.WeaponStatus.Loaded;
			}
			else
			{
				this.currentAmmo = this.magazineCapacity;
				if (this.status == WeaponControllerBackUp.WeaponStatus.SlideLockedBack)
				{
					this.status = WeaponControllerBackUp.WeaponStatus.LoadedSlideLockedBack;
				}
				else
				{
					this.status = WeaponControllerBackUp.WeaponStatus.LoadedEmptyChamber;
					this.canShoot = false;
				}
			}
			this.audioSource.PlayOneShot(this.audioMagazineInsert);
			this.hasMagazine = true;
		}
		this.lastPos = base.transform.position;
	}

	// Token: 0x0600032C RID: 812 RVA: 0x00014840 File Offset: 0x00012A40
	private void TriggerControl()
	{
		float num = OVRInput.Get(OVRInput.Axis1D.PrimaryIndexTrigger, this.controlManager.controller);
		this.animator.SetFloat("TriggerPull", num);
		if (num >= this.triggerWallPosition && this.triggerReset)
		{
			this.Fire();
			this.triggerReset = false;
		}
		if (num <= this.triggerResetPosition && !this.triggerReset)
		{
			this.triggerReset = true;
			if (this.canShoot)
			{
				this.audioSource.PlayOneShot(this.audioTriggerReset);
				this.hapticManager.VibrateStandard(0.8f, 0.4f, 0.05f, this.controlManager.controller);
			}
		}
	}

	// Token: 0x0600032D RID: 813 RVA: 0x000148E4 File Offset: 0x00012AE4
	private void Fire()
	{
		if (!this.hammerDrop)
		{
			if (this.status == WeaponControllerBackUp.WeaponStatus.SlideLockedBack || this.status == WeaponControllerBackUp.WeaponStatus.LoadedSlideLockedBack)
			{
				return;
			}
			if (this.currentAmmo <= 0 || this.status == WeaponControllerBackUp.WeaponStatus.LoadedEmptyChamber)
			{
				this.animator.SetTrigger("HammerDrop");
				MonoBehaviour.print("hammer drop");
				this.audioSource.PlayOneShot(this.audioFireEmpty);
				this.hammerDrop = true;
				if (this.currentAmmo <= 0)
				{
					GameEvents.current.GunEmpty();
				}
			}
		}
		if (this.canShoot && this.triggerReset)
		{
			if (this.currentAmmo > 0)
			{
				this.SpawnProjectile();
				if (this.currentAmmo == 1 && this.hasMagazine)
				{
					this.animator.SetTrigger("FireLast");
					this.status = WeaponControllerBackUp.WeaponStatus.SlideLockedBack;
					this.canShoot = false;
				}
				else if (this.currentAmmo == 1 && !this.hasMagazine)
				{
					this.animator.SetTrigger("Fire");
					this.status = WeaponControllerBackUp.WeaponStatus.Empty;
					this.canShoot = false;
				}
				else
				{
					this.animator.SetTrigger("Fire");
				}
				if (this.currentAmmo == 1)
				{
					MonoBehaviour.print("fire");
				}
				this.currentAmmo--;
				return;
			}
			MonoBehaviour.print("OUT OF AMMO");
		}
	}

	// Token: 0x0600032E RID: 814 RVA: 0x00014A2C File Offset: 0x00012C2C
	private void SpawnProjectile()
	{
		this.shellEjection.Emit(this.shellEjection.transform.position, this.shellEjection.transform.forward * 3f, 1f, 2f, Color.white);
		Object.Instantiate<GameObject>(this.projectilePrefab, this.muzzlePosition.position, this.muzzlePosition.rotation);
		this.hapticManager.VibrateStandard(0.1f, 0.8f, 0.12f, this.controlManager.controller);
		Object.Instantiate<ParticleSystem>(this.muzzleFlash, this.muzzlePosition.position, this.muzzlePosition.rotation);
		AudioSource.PlayClipAtPoint(this.audioFire, this.muzzlePosition.position);
		GameEvents.current.ShotFired();
	}

	// Token: 0x0600032F RID: 815 RVA: 0x00014B0B File Offset: 0x00012D0B
	public void Holster()
	{
		this.holstered = true;
	}

	// Token: 0x06000330 RID: 816 RVA: 0x00014B14 File Offset: 0x00012D14
	public void Unholster()
	{
		this.holstered = false;
		if (this.ignoreReload)
		{
			base.Invoke("DisableIgnoreReload", 0.5f);
		}
	}

	// Token: 0x06000331 RID: 817 RVA: 0x00014B35 File Offset: 0x00012D35
	private void DisableIgnoreReload()
	{
		this.ignoreReload = false;
	}

	// Token: 0x06000332 RID: 818 RVA: 0x00014B40 File Offset: 0x00012D40
	public void EmptyGun()
	{
		this.animator.SetTrigger("HammerDrop");
		this.hasMagazine = false;
		this.magazineToBeDisabled.SetActive(false);
		this.currentAmmo = 0;
		this.ignoreReload = true;
		this.hammerDrop = true;
		this.status = WeaponControllerBackUp.WeaponStatus.Empty;
	}

	// Token: 0x040003A9 RID: 937
	[SerializeField]
	private string weaponID;

	// Token: 0x040003AA RID: 938
	[SerializeField]
	public WeaponControllerBackUp.WeaponStatus status;

	// Token: 0x040003AB RID: 939
	[SerializeField]
	private Animator animator;

	// Token: 0x040003AC RID: 940
	[SerializeField]
	private int magazineCapacity;

	// Token: 0x040003AD RID: 941
	[SerializeField]
	private int currentAmmo;

	// Token: 0x040003AE RID: 942
	[SerializeField]
	private float timeToDeleteOldMagazine = 5f;

	// Token: 0x040003AF RID: 943
	[SerializeField]
	private float detectionThreshold;

	// Token: 0x040003B0 RID: 944
	[SerializeField]
	private GameObject projectilePrefab;

	// Token: 0x040003B1 RID: 945
	[SerializeField]
	private GameObject magazineToBeEjected;

	// Token: 0x040003B2 RID: 946
	[SerializeField]
	private GameObject magazineToBeDisabled;

	// Token: 0x040003B3 RID: 947
	[SerializeField]
	private GameObject magazineToBeInstantiated;

	// Token: 0x040003B4 RID: 948
	[SerializeField]
	private Transform muzzlePosition;

	// Token: 0x040003B5 RID: 949
	[SerializeField]
	private Transform magazineEjectionDirection;

	// Token: 0x040003B6 RID: 950
	[SerializeField]
	private Transform shellEjectPosition;

	// Token: 0x040003B7 RID: 951
	[SerializeField]
	private AudioClip audioFire;

	// Token: 0x040003B8 RID: 952
	[SerializeField]
	private AudioClip audioFireEmpty;

	// Token: 0x040003B9 RID: 953
	[SerializeField]
	private AudioClip audioTriggerReset;

	// Token: 0x040003BA RID: 954
	[SerializeField]
	private AudioClip audioMagazineEject;

	// Token: 0x040003BB RID: 955
	[SerializeField]
	private AudioClip audioMagazineInsert;

	// Token: 0x040003BC RID: 956
	[SerializeField]
	private AudioClip audioSlideRelease;

	// Token: 0x040003BD RID: 957
	[SerializeField]
	private ParticleSystem shellEjection;

	// Token: 0x040003BE RID: 958
	[SerializeField]
	private ParticleSystem roundEjection;

	// Token: 0x040003BF RID: 959
	[SerializeField]
	private ParticleSystem muzzleFlash;

	// Token: 0x040003C0 RID: 960
	[SerializeField]
	private float triggerResetPosition;

	// Token: 0x040003C1 RID: 961
	[SerializeField]
	private float triggerWallPosition;

	// Token: 0x040003C2 RID: 962
	[SerializeField]
	private int maxMagazine = 3;

	// Token: 0x040003C3 RID: 963
	[SerializeField]
	private bool hasSafety;

	// Token: 0x040003C4 RID: 964
	private bool hasMagazine;

	// Token: 0x040003C5 RID: 965
	private bool canShoot;

	// Token: 0x040003C6 RID: 966
	private bool triggerReset;

	// Token: 0x040003C7 RID: 967
	private bool holstered;

	// Token: 0x040003C8 RID: 968
	private bool ignoreReload;

	// Token: 0x040003C9 RID: 969
	private bool hammerDrop;

	// Token: 0x040003CA RID: 970
	private bool safetyOn;

	// Token: 0x040003CB RID: 971
	private bool slideActionPerformed;

	// Token: 0x040003CC RID: 972
	private Vector3 lastPos;

	// Token: 0x040003CD RID: 973
	private ControlManager controlManager;

	// Token: 0x040003CE RID: 974
	private OVRInput.Controller controller;

	// Token: 0x040003CF RID: 975
	private HapticManager hapticManager;

	// Token: 0x040003D0 RID: 976
	private AudioSource audioSource;

	// Token: 0x040003D1 RID: 977
	private Queue<GameObject> magazineQueue = new Queue<GameObject>();

	// Token: 0x020001D0 RID: 464
	public enum WeaponStatus
	{
		// Token: 0x04000DBB RID: 3515
		Empty,
		// Token: 0x04000DBC RID: 3516
		LoadedEmptyChamber,
		// Token: 0x04000DBD RID: 3517
		LoadedSlideLockedBack,
		// Token: 0x04000DBE RID: 3518
		EmptyRoundInChamber,
		// Token: 0x04000DBF RID: 3519
		EmptySlideLockedBack,
		// Token: 0x04000DC0 RID: 3520
		SlideLockedBack,
		// Token: 0x04000DC1 RID: 3521
		Loaded
	}
}
