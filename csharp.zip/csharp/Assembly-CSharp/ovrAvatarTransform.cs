﻿using System;
using UnityEngine;

// Token: 0x020000C9 RID: 201
public struct ovrAvatarTransform
{
	// Token: 0x040007C5 RID: 1989
	public Vector3 position;

	// Token: 0x040007C6 RID: 1990
	public Quaternion orientation;

	// Token: 0x040007C7 RID: 1991
	public Vector3 scale;
}
