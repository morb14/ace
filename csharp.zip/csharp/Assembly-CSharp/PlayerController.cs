﻿using System;
using Oculus.Platform;
using UnityEngine;

// Token: 0x020000A3 RID: 163
public class PlayerController : SocialPlatformManager
{
	// Token: 0x06000568 RID: 1384 RVA: 0x000227C0 File Offset: 0x000209C0
	public override void Awake()
	{
		base.Awake();
		this.cameraRig = this.localPlayerHead.gameObject;
	}

	// Token: 0x06000569 RID: 1385 RVA: 0x000227D9 File Offset: 0x000209D9
	public override void Start()
	{
		base.Start();
		this.spyCamera.enabled = false;
	}

	// Token: 0x0600056A RID: 1386 RVA: 0x000227ED File Offset: 0x000209ED
	public override void Update()
	{
		base.Update();
		this.checkInput();
	}

	// Token: 0x0600056B RID: 1387 RVA: 0x000227FC File Offset: 0x000209FC
	private void checkInput()
	{
		if (UnityEngine.Application.platform == RuntimePlatform.Android)
		{
			if (OVRInput.GetDown(OVRInput.Button.Back, OVRInput.Controller.Active))
			{
				Rooms.LaunchInvitableUserFlow(this.roomManager.roomID);
			}
			if (OVRInput.GetDown(OVRInput.Button.PrimaryTouchpad, OVRInput.Controller.Active))
			{
				this.ToggleCamera();
			}
			if (OVRInput.GetDown(OVRInput.Button.PrimaryIndexTrigger, OVRInput.Controller.Active))
			{
				this.ToggleUI();
				return;
			}
		}
		else
		{
			if (OVRInput.GetDown(OVRInput.Button.Three, OVRInput.Controller.Active))
			{
				Rooms.LaunchInvitableUserFlow(this.roomManager.roomID);
			}
			if (OVRInput.GetDown(OVRInput.Button.Four, OVRInput.Controller.Active))
			{
				this.ToggleCamera();
			}
			if (OVRInput.GetDown(OVRInput.Button.PrimaryThumbstick, OVRInput.Controller.Active))
			{
				this.ToggleUI();
			}
		}
	}

	// Token: 0x0600056C RID: 1388 RVA: 0x000228AC File Offset: 0x00020AAC
	private void ToggleCamera()
	{
		this.spyCamera.enabled = !this.spyCamera.enabled;
		this.localAvatar.ShowThirdPerson = !this.localAvatar.ShowThirdPerson;
		this.cameraRig.SetActive(!this.cameraRig.activeSelf);
	}

	// Token: 0x0600056D RID: 1389 RVA: 0x00022904 File Offset: 0x00020B04
	private void ToggleUI()
	{
		this.showUI = !this.showUI;
		this.helpPanel.SetActive(this.showUI);
		this.localAvatar.ShowLeftController(this.showUI);
	}

	// Token: 0x0400067B RID: 1659
	public Camera spyCamera;

	// Token: 0x0400067C RID: 1660
	private GameObject cameraRig;

	// Token: 0x0400067D RID: 1661
	private bool showUI = true;
}
