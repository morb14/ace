﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

// Token: 0x02000052 RID: 82
public class Projectile : MonoBehaviour
{
	// Token: 0x060002D0 RID: 720 RVA: 0x000102E0 File Offset: 0x0000E4E0
	private void Start()
	{
		this.objectPooler = Object.FindObjectOfType<ObjectManager>();
		this.paperHit = false;
		this.throughBarricade = false;
		base.transform.parent = null;
		this.bulletHoleScale = this.caliber / 1000f / 0.009f;
		this.velocity = (int)((double)this.velocity / 3.28084);
		if (this.muzzleEnergy == 0)
		{
			this.muzzleEnergy = (int)(0.5 * (double)((float)this.projectileWeight / 15432f) * (double)(this.velocity * this.velocity));
		}
		this.origin = base.transform.position;
		this.BallisticUpdate(this.velocity);
		base.Invoke("SelfDestruct", this.lifeTime + 1f);
	}

	// Token: 0x060002D1 RID: 721 RVA: 0x000103AC File Offset: 0x0000E5AC
	private void Update()
	{
		if (this.type == Projectile.ProjectileType.Bullet || this.type == Projectile.ProjectileType.Pallets || this.type == Projectile.ProjectileType.Grenade)
		{
			this.Trajectory();
		}
		if (this.type == Projectile.ProjectileType.DeathBeam)
		{
			this.Beam();
		}
	}

	// Token: 0x060002D2 RID: 722 RVA: 0x000103E0 File Offset: 0x0000E5E0
	public void ModifySpread(float spread)
	{
		Projectile[] array = this.projectiles;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].diviation = spread;
			this.BallisticUpdate(this.velocity);
		}
	}

	// Token: 0x060002D3 RID: 723 RVA: 0x00010418 File Offset: 0x0000E618
	private void Beam()
	{
		int num;
		if (this.velocity < 1)
		{
			num = 1;
		}
		else
		{
			num = this.velocity;
		}
		Vector3 localScale = base.transform.localScale + new Vector3(0f, 0f, (float)num);
		base.transform.localScale = localScale;
		base.transform.parent = this.gunTransform;
	}

	// Token: 0x060002D4 RID: 724 RVA: 0x0001047C File Offset: 0x0000E67C
	public void BallisticUpdate(int inputBulletSpeed)
	{
		if (this.type != Projectile.ProjectileType.Bullet && this.type != Projectile.ProjectileType.Pallets && this.type != Projectile.ProjectileType.Grenade)
		{
			return;
		}
		float x = Random.Range(-this.diviation, this.diviation);
		float y = Random.Range(-this.diviation, this.diviation);
		this.bulletVelocity = (base.transform.forward + new Vector3(x, y, Random.Range(-this.diviation, this.diviation))) * (float)inputBulletSpeed;
		this.penetrationVelocity = this.bulletVelocity;
	}

	// Token: 0x060002D5 RID: 725 RVA: 0x0001050C File Offset: 0x0000E70C
	private void Trajectory()
	{
		Vector3 vector = base.transform.position;
		float num = 1f / (float)this.iterations;
		for (float num2 = 0f; num2 < 1f; num2 += num)
		{
			this.bulletVelocity += Physics.gravity * num * Time.deltaTime;
			Vector3 vector2 = vector + this.bulletVelocity * num * Time.deltaTime;
			RaycastHit[] array = Physics.RaycastAll(new Ray(vector, vector2 - vector), (vector2 - vector).magnitude, this.layerMask);
			if (array.Length == 0 && this.penetration > 0f)
			{
				Debug.DrawRay(vector, Vector3.up / 5f, Color.green, 5f);
				Debug.DrawLine(vector, vector2, Color.green, 5f);
			}
			foreach (RaycastHit item in array)
			{
				this.hitList.Add(item);
			}
			this.hitList = (from x in this.hitList
			orderby Vector3.Distance(x.point, this.origin)
			select x).ToList<RaycastHit>();
			foreach (RaycastHit raycastHit in this.hitList)
			{
				MonoBehaviour.print(string.Concat(new object[]
				{
					"HIT LIST DISTANCE: ",
					this.hitList.Count<RaycastHit>(),
					"  ",
					raycastHit.transform.gameObject,
					Vector3.Distance(raycastHit.point, this.origin)
				}));
			}
			foreach (RaycastHit hit in this.hitList)
			{
				if (this.penetration <= 0f)
				{
					break;
				}
				Debug.DrawLine(vector, hit.point, Color.green, 5f);
				GameObject gameObject = this.PoolBulletHole();
				gameObject.transform.position = hit.point;
				gameObject.transform.rotation = Quaternion.FromToRotation(Vector3.forward, hit.normal);
				gameObject.transform.localScale = Vector3.one;
				gameObject.transform.Rotate(new Vector3(0f, 0f, (float)Random.Range(0, 360)), Space.Self);
				gameObject.transform.parent = hit.collider.transform;
				if (hit.transform.tag == "Barricade" || hit.transform.tag == "PaintOnBarricade")
				{
					this.throughBarricade = true;
					MonoBehaviour.print("Barricade shot");
				}
				if (hit.transform.tag == "ProceduralPlane" && !this.throughBarricade)
				{
					this.throughProceduralPlane = true;
				}
				if (hit.collider.GetComponentInParent<OtherTarget>())
				{
					OtherTarget componentInParent = hit.collider.GetComponentInParent<OtherTarget>();
					if (hit.collider.gameObject.layer == LayerMask.NameToLayer("ShotgunPhysics"))
					{
						componentInParent = hit.collider.transform.parent.GetComponentInParent<OtherTarget>();
					}
					componentInParent.Reaction(hit.point, Quaternion.FromToRotation(Vector3.forward, hit.normal), (float)this.muzzleEnergy);
					MonoBehaviour.print("OTHER TARGET HIT");
					this.ApplyForce(hit, hit.normal);
				}
				if (hit.collider.GetComponentInParent<PaperTarget>())
				{
					TargetReaction component = gameObject.GetComponent<TargetReaction>();
					if (!this.paperHit && !this.throughBarricade)
					{
						hit.collider.GetComponentInParent<PaperTarget>().Score(hit.point, this.caliber / 1000f, this.muzzleEnergy);
						if (hit.collider.transform.tag != "Mike")
						{
							this.paperHit = true;
						}
						this.ProceduralCheck();
					}
					string zone;
					if (hit.collider.transform.tag == "Mike" || this.throughBarricade)
					{
						zone = "Missed";
					}
					else
					{
						zone = hit.collider.transform.tag;
					}
					component.ImpactInfo(TargetReaction.TargetType.Paper, this.velocity, null, zone);
					Vector3 localScale = gameObject.transform.localScale;
					gameObject.transform.localScale = new Vector3(localScale.x * this.bulletHoleScale, localScale.y * this.bulletHoleScale, localScale.z);
				}
				else if (hit.collider.GetComponentInParent<SteelTarget>())
				{
					this.penetration = 0f;
					TargetReaction component2 = gameObject.GetComponent<TargetReaction>();
					if (hit.collider.GetComponentInParent<SteelTarget>())
					{
						component2.ImpactInfo(TargetReaction.TargetType.Steel, this.velocity, hit.collider.GetComponentInParent<SteelTarget>().bespokeHitAudio, "");
					}
					if (!this.throughBarricade)
					{
						if (hit.collider.GetComponentInParent<TargetDetach>())
						{
							hit.collider.GetComponentInParent<TargetDetach>().Detach();
						}
						hit.collider.GetComponentInParent<SteelTarget>().Hit(new Vector3?(hit.point));
						component2.enabled = true;
						this.ProceduralCheck();
						MonoBehaviour.print("steel target hit");
					}
				}
				else
				{
					TargetReaction component3 = gameObject.GetComponent<TargetReaction>();
					if (component3 != null && hit.transform.tag != "PaintOnBarricade" && hit.transform.tag != "ProceduralPlane")
					{
						component3.ImpactInfo(TargetReaction.TargetType.Default, this.velocity, null, "");
					}
				}
				this.PenetrationCheck(hit, vector2);
				if (!this.throughBarricade && hit.collider.GetComponentInParent<SteelTarget>())
				{
					this.ApplyForce(hit, this.origin);
				}
			}
			this.hitList.Clear();
			vector = vector2;
		}
		base.transform.position = vector;
		if (this.hasDrag)
		{
			this.bulletVelocity -= this.bulletVelocity * this.supersonicDrag * Time.deltaTime;
		}
		this.paperList.Clear();
	}

	// Token: 0x060002D6 RID: 726 RVA: 0x00010BB8 File Offset: 0x0000EDB8
	private void ProceduralCheck()
	{
		if (this.throughProceduralPlane && !this.throughBarricade)
		{
			GameEvents.current.ShotThroughProcedural();
		}
	}

	// Token: 0x060002D7 RID: 727 RVA: 0x00010BD4 File Offset: 0x0000EDD4
	private GameObject PoolBulletHole()
	{
		return this.objectPooler.PoolObject(this.testBulletHole, ObjectManager.ObjectType.BulletHoles);
	}

	// Token: 0x060002D8 RID: 728 RVA: 0x00010BE8 File Offset: 0x0000EDE8
	private void ApplyForce(RaycastHit hit, Vector3 shotFrom)
	{
		float d = 1f;
		Rigidbody component = hit.transform.GetComponent<Rigidbody>();
		if (component != null)
		{
			if (hit.collider.GetComponent<ForceDampener>())
			{
				d = hit.collider.GetComponent<ForceDampener>().Dampen();
			}
			MonoBehaviour.print(((hit.point - shotFrom).normalized * ((float)this.muzzleEnergy / 482f) * this.forceMultiplier).magnitude);
			component.AddForce((hit.point - shotFrom).normalized * ((float)this.muzzleEnergy / 482f) * this.forceMultiplier * d, ForceMode.Impulse);
		}
	}

	// Token: 0x060002D9 RID: 729 RVA: 0x00010CC0 File Offset: 0x0000EEC0
	private void PenetrationCheck(RaycastHit hit, Vector3 debugPoint2)
	{
		float d = 1f / (float)this.iterations;
		Vector3 vector = hit.point;
		Vector3 vector2 = vector + this.penetrationVelocity * d * Time.deltaTime;
		while (Vector3.Distance(vector2, hit.point) < this.penCalculationLimit)
		{
			this.penetrationVelocity += Physics.gravity * d * Time.deltaTime;
			vector2 = vector + this.penetrationVelocity * d * Time.deltaTime;
			foreach (RaycastHit raycastHit in Physics.RaycastAll(new Ray(vector2, vector - vector2), (vector2 - vector).magnitude, this.layerMask))
			{
				if (raycastHit.transform.gameObject == hit.transform.gameObject)
				{
					float num = Vector3.Distance(raycastHit.point, hit.point);
					this.penetration -= num;
					if (this.penetration <= 0f)
					{
						base.transform.position = vector;
						this.SelfDestruct();
						break;
					}
					Debug.DrawLine(debugPoint2, raycastHit.point, Color.green, 5f);
					Debug.DrawLine(vector, raycastHit.point, Color.red, 5f);
				}
			}
			vector = vector2;
		}
	}

	// Token: 0x060002DA RID: 730 RVA: 0x00010E48 File Offset: 0x0000F048
	private void SelfDestruct()
	{
		if (this.unParentOnDestroy)
		{
			ParticleSystem[] componentsInChildren = base.GetComponentsInChildren<ParticleSystem>();
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].gameObject.transform.parent = null;
			}
		}
		Object.Destroy(base.gameObject);
	}

	// Token: 0x0400030C RID: 780
	[Header("Projectile")]
	[SerializeField]
	public Projectile.ProjectileType type;

	// Token: 0x0400030D RID: 781
	[SerializeField]
	private float lifeTime;

	// Token: 0x0400030E RID: 782
	[SerializeField]
	private int iterations;

	// Token: 0x0400030F RID: 783
	[SerializeField]
	private float diviation;

	// Token: 0x04000310 RID: 784
	[SerializeField]
	private int damage;

	// Token: 0x04000311 RID: 785
	[SerializeField]
	private float penetration;

	// Token: 0x04000312 RID: 786
	[SerializeField]
	private float penCalculationLimit = 3f;

	// Token: 0x04000313 RID: 787
	[SerializeField]
	private bool unParentOnDestroy;

	// Token: 0x04000314 RID: 788
	[Tooltip("in millimeter")]
	[SerializeField]
	private float caliber = 9f;

	// Token: 0x04000315 RID: 789
	[Tooltip("Velocity in feet per second")]
	[SerializeField]
	private int velocity;

	// Token: 0x04000316 RID: 790
	[Tooltip("Weight in gr / grains")]
	[SerializeField]
	private int projectileWeight = 115;

	// Token: 0x04000317 RID: 791
	[Tooltip("Calculated at runtime, keep at zero unless you want manual power that ignores weight / velocity, 482 is recommended minimum")]
	public int muzzleEnergy;

	// Token: 0x04000318 RID: 792
	private float forceMultiplier = 0.75f;

	// Token: 0x04000319 RID: 793
	[Header("Projectile Drag")]
	[SerializeField]
	private bool hasDrag;

	// Token: 0x0400031A RID: 794
	[Tooltip("In meters")]
	[SerializeField]
	private float speedOfSound = 343.2f;

	// Token: 0x0400031B RID: 795
	[Tooltip("In milliseconds")]
	[SerializeField]
	private int sampleRate = 50;

	// Token: 0x0400031C RID: 796
	[SerializeField]
	private float supersonicDrag = 0.92f;

	// Token: 0x0400031D RID: 797
	[SerializeField]
	private float subsonicDrag = 0.98f;

	// Token: 0x0400031E RID: 798
	private float velocityAfterDrag;

	// Token: 0x0400031F RID: 799
	private float timeSinceDragSampling;

	// Token: 0x04000320 RID: 800
	[Header("Pallets")]
	[SerializeField]
	public int palletCount;

	// Token: 0x04000321 RID: 801
	[SerializeField]
	public Projectile[] projectiles;

	// Token: 0x04000322 RID: 802
	[Header("Others")]
	[SerializeField]
	public Material shellMaterial;

	// Token: 0x04000323 RID: 803
	[SerializeField]
	private LayerMask layerMask;

	// Token: 0x04000324 RID: 804
	[SerializeField]
	private GameObject testBulletHole;

	// Token: 0x04000325 RID: 805
	[SerializeField]
	private GameObject bodyBulletImpact;

	// Token: 0x04000326 RID: 806
	private float bulletHoleScale;

	// Token: 0x04000327 RID: 807
	private float distanceToLastPoint;

	// Token: 0x04000328 RID: 808
	public Vector3 bulletVelocity;

	// Token: 0x04000329 RID: 809
	public Vector3 penetrationVelocity;

	// Token: 0x0400032A RID: 810
	public Transform gunTransform;

	// Token: 0x0400032B RID: 811
	private LineRenderer lineRenderer;

	// Token: 0x0400032C RID: 812
	private GameObject trail;

	// Token: 0x0400032D RID: 813
	private bool paperHit;

	// Token: 0x0400032E RID: 814
	private bool throughBarricade;

	// Token: 0x0400032F RID: 815
	private bool throughProceduralPlane;

	// Token: 0x04000330 RID: 816
	private List<RaycastHit> paperList = new List<RaycastHit>();

	// Token: 0x04000331 RID: 817
	private List<RaycastHit> hitList = new List<RaycastHit>();

	// Token: 0x04000332 RID: 818
	private ObjectManager objectPooler;

	// Token: 0x04000333 RID: 819
	private Vector3 origin;

	// Token: 0x020001CA RID: 458
	public enum ProjectileType
	{
		// Token: 0x04000D98 RID: 3480
		Bullet,
		// Token: 0x04000D99 RID: 3481
		DeathBeam,
		// Token: 0x04000D9A RID: 3482
		Pallets,
		// Token: 0x04000D9B RID: 3483
		Grenade,
		// Token: 0x04000D9C RID: 3484
		Rocket
	}

	// Token: 0x020001CB RID: 459
	public enum SurfaceType
	{
		// Token: 0x04000D9E RID: 3486
		Steel,
		// Token: 0x04000D9F RID: 3487
		Wood,
		// Token: 0x04000DA0 RID: 3488
		Paper,
		// Token: 0x04000DA1 RID: 3489
		Generic
	}
}
