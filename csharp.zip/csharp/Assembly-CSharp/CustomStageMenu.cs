﻿using System;
using System.Collections.Generic;
using System.IO;
using TMPro;
using UnityEngine;

// Token: 0x02000007 RID: 7
public class CustomStageMenu : MonoBehaviour
{
	// Token: 0x0600001E RID: 30 RVA: 0x00002AC8 File Offset: 0x00000CC8
	private void Start()
	{
		GameEvents.current.onNewCustomStageLoad += this.OnNewCustomStageLoad;
		GameEvents.current.onKeyboardHighlighted += this.DelayRescale;
		this.sceneSettings = Object.FindObjectOfType<SceneSettings>();
		this.soundManager = Object.FindObjectOfType<SoundManager>();
		this.ResetList();
		this.menuObject.SetActive(false);
		this.OnNewCustomStageLoad();
	}

	// Token: 0x0600001F RID: 31 RVA: 0x00002B2F File Offset: 0x00000D2F
	public string CurrentOpenedFile()
	{
		return this.openedFileText.text;
	}

	// Token: 0x06000020 RID: 32 RVA: 0x00002B3C File Offset: 0x00000D3C
	private void GetFiles()
	{
		this.fileList.Clear();
		foreach (string text in Directory.GetFiles(SaveSystem.CUSTOMSTAGES_FOLDER))
		{
			if (text.Contains(this.sceneSettings.customStageName))
			{
				this.fileList.Add(text);
			}
		}
		this.pageCount = this.fileList.Count / this.slots.Length + 1;
		if (this.pageCount > 1 && this.fileList.Count % this.slots.Length == 0)
		{
			this.pageCount--;
		}
		if (this.pageCount < 1)
		{
			this.pageCount = 1;
		}
		this.currentPage = 1;
	}

	// Token: 0x06000021 RID: 33 RVA: 0x00002BF0 File Offset: 0x00000DF0
	private void Update()
	{
		this.AutoDisable();
	}

	// Token: 0x06000022 RID: 34 RVA: 0x00002BF8 File Offset: 0x00000DF8
	private void AutoDisable()
	{
		if (Time.time >= this.inactivityTime + this.disableTime && this.menuObject.activeSelf)
		{
			this.DisableMenu();
		}
	}

	// Token: 0x06000023 RID: 35 RVA: 0x00002C21 File Offset: 0x00000E21
	private void DisableMenu()
	{
		this.menuObject.SetActive(false);
		GameEvents.current.SaveMenuDisabled();
		if (Object.FindObjectOfType<KeyboardManager>())
		{
			Object.FindObjectOfType<KeyboardManager>().ActivateKeyboard(false, null);
		}
	}

	// Token: 0x06000024 RID: 36 RVA: 0x00002C51 File Offset: 0x00000E51
	public void ActivateMenu(bool activate, CustomStageMenu.MenuMode mode)
	{
		this.menuMode = mode;
		if (activate)
		{
			this.DisableMenu();
			this.inactivityTime = Time.time;
			this.menuObject.SetActive(true);
			return;
		}
		this.DisableMenu();
	}

	// Token: 0x06000025 RID: 37 RVA: 0x00002C84 File Offset: 0x00000E84
	public bool SaveNewFile(string newFileName)
	{
		MonoBehaviour.print("KEYBOARD ATTEMPTING TO SAVE FILE " + newFileName);
		bool flag = false;
		foreach (string text in this.fileList)
		{
			string text2 = text.Remove(0, Application.persistentDataPath.Length + 1 + this.sceneSettings.customStageName.Length + 1);
			text2 = text2.Substring(0, text2.Length - 4);
			MonoBehaviour.print(newFileName + " compared to " + text2);
			if (text2 == newFileName || newFileName.Contains("CustomStage") || newFileName == "Default" || newFileName == "")
			{
				this.soundManager.Play(this.soundManager.UIerror);
				flag = true;
				break;
			}
		}
		if (!flag)
		{
			Object.FindObjectOfType<SaveManager>().Save(this.sceneSettings.customStageName + "_" + newFileName);
			this.soundManager.Play(this.soundManager.UIcorrect);
			this.ResetList();
			return true;
		}
		return false;
	}

	// Token: 0x06000026 RID: 38 RVA: 0x00002DBC File Offset: 0x00000FBC
	public void ResetList()
	{
		this.GetFiles();
		this.PopulateSlots();
	}

	// Token: 0x06000027 RID: 39 RVA: 0x00002DCC File Offset: 0x00000FCC
	public bool Delete(string fileName)
	{
		bool result;
		try
		{
			SaveSystem.DeleteFile(fileName);
			this.soundManager.Play(this.soundManager.UIcorrect);
			this.ResetList();
			result = true;
		}
		catch
		{
			this.soundManager.Play(this.soundManager.UIerror);
			result = false;
		}
		return result;
	}

	// Token: 0x06000028 RID: 40 RVA: 0x00002E2C File Offset: 0x0000102C
	public void Rename(string oldName, string newName)
	{
		MonoBehaviour.print("RENAME " + oldName + " " + newName);
		oldName = this.sceneSettings.customStageName + "_" + oldName;
		newName = this.sceneSettings.customStageName + "_" + newName;
		try
		{
			SaveSystem.Rename(oldName, newName);
			this.soundManager.Play(this.soundManager.UIcorrect);
		}
		catch
		{
			this.soundManager.Play(this.soundManager.UIerror);
		}
		this.ResetList();
	}

	// Token: 0x06000029 RID: 41 RVA: 0x00002ED0 File Offset: 0x000010D0
	public void DelayRescale()
	{
		this.inactivityTime = Time.time;
	}

	// Token: 0x0600002A RID: 42 RVA: 0x00002EE0 File Offset: 0x000010E0
	public void TurnPage(bool nextPage)
	{
		if (nextPage)
		{
			if (this.currentPage < this.pageCount)
			{
				this.currentPage++;
				this.PopulateSlots();
				return;
			}
		}
		else if (this.currentPage > 1)
		{
			this.currentPage--;
			this.PopulateSlots();
		}
	}

	// Token: 0x0600002B RID: 43 RVA: 0x00002F30 File Offset: 0x00001130
	private void OnNewCustomStageLoad()
	{
		string text = Object.FindObjectOfType<SaveManager>().currentOpenedFile;
		if (text == "")
		{
			text = "Default";
		}
		else if (text.Contains(this.sceneSettings.customStageName))
		{
			text = text.Remove(0, this.sceneSettings.customStageName.Length + 1);
		}
		this.openedFileText.text = text;
	}

	// Token: 0x0600002C RID: 44 RVA: 0x00002F98 File Offset: 0x00001198
	private void PopulateSlots()
	{
		int num = this.slots.Length;
		int num2 = 0;
		int num3 = num * (this.currentPage - 1);
		MonoBehaviour.print(string.Concat(new object[]
		{
			this.currentPage,
			" ",
			num3,
			" ",
			num,
			" ",
			this.fileList.Count
		}));
		foreach (GameObject gameObject in this.slots)
		{
			gameObject.GetComponent<CustomStageLoadButton>().fieldText.text = "";
			gameObject.GetComponent<CustomStageLoadButton>().AssignLoadFile("");
		}
		int num4 = num3;
		while (num4 < num3 + num && num4 < this.fileList.Count)
		{
			if (this.slots[num2].GetComponent<CustomStageLoadButton>())
			{
				string path = this.fileList[num4];
				this.slots[num2].GetComponent<CustomStageLoadButton>().AssignLoadFile(Path.GetFileNameWithoutExtension(path));
				string text = Path.GetFileNameWithoutExtension(path).Replace(this.sceneSettings.customStageName + "_", "");
				this.slots[num2].GetComponent<CustomStageLoadButton>().fieldText.text = text;
			}
			num2++;
			num4++;
		}
	}

	// Token: 0x0600002D RID: 45 RVA: 0x00003105 File Offset: 0x00001305
	private void OnDestroy()
	{
		GameEvents.current.onKeyboardHighlighted -= this.DelayRescale;
		GameEvents.current.onNewCustomStageLoad -= this.OnNewCustomStageLoad;
	}

	// Token: 0x04000021 RID: 33
	[SerializeField]
	public CustomStageMenu.MenuMode menuMode;

	// Token: 0x04000022 RID: 34
	[SerializeField]
	private GameObject[] slots;

	// Token: 0x04000023 RID: 35
	[SerializeField]
	private float disableTime = 3f;

	// Token: 0x04000024 RID: 36
	[SerializeField]
	private GameObject menuObject;

	// Token: 0x04000025 RID: 37
	[SerializeField]
	private TMP_Text openedFileText;

	// Token: 0x04000026 RID: 38
	private SceneSettings sceneSettings;

	// Token: 0x04000027 RID: 39
	public string currentSelectedLoadButton;

	// Token: 0x04000028 RID: 40
	private List<string> fileList = new List<string>();

	// Token: 0x04000029 RID: 41
	private string fileToLoad;

	// Token: 0x0400002A RID: 42
	public int pageCount;

	// Token: 0x0400002B RID: 43
	public int currentPage;

	// Token: 0x0400002C RID: 44
	private bool scaleUp;

	// Token: 0x0400002D RID: 45
	private bool scaleDown;

	// Token: 0x0400002E RID: 46
	private float inactivityTime;

	// Token: 0x0400002F RID: 47
	private SoundManager soundManager;

	// Token: 0x020001A5 RID: 421
	public enum MenuMode
	{
		// Token: 0x04000CE6 RID: 3302
		Load,
		// Token: 0x04000CE7 RID: 3303
		Save,
		// Token: 0x04000CE8 RID: 3304
		Delete,
		// Token: 0x04000CE9 RID: 3305
		Rename,
		// Token: 0x04000CEA RID: 3306
		Overwrite
	}
}
