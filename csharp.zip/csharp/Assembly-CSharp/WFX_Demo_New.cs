﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000017 RID: 23
public class WFX_Demo_New : MonoBehaviour
{
	// Token: 0x06000067 RID: 103 RVA: 0x000042D4 File Offset: 0x000024D4
	private void Awake()
	{
		List<GameObject> list = new List<GameObject>();
		int childCount = base.transform.childCount;
		for (int i = 0; i < childCount; i++)
		{
			GameObject gameObject = base.transform.GetChild(i).gameObject;
			list.Add(gameObject);
		}
		list.AddRange(this.AdditionalEffects);
		this.ParticleExamples = list.ToArray();
		this.defaultCamPosition = Camera.main.transform.position;
		this.defaultCamRotation = Camera.main.transform.rotation;
		base.StartCoroutine("CheckForDeletedParticles");
		this.UpdateUI();
	}

	// Token: 0x06000068 RID: 104 RVA: 0x0000436C File Offset: 0x0000256C
	private void Update()
	{
		if (Input.GetKeyDown(KeyCode.LeftArrow))
		{
			this.prevParticle();
		}
		else if (Input.GetKeyDown(KeyCode.RightArrow))
		{
			this.nextParticle();
		}
		else if (Input.GetKeyDown(KeyCode.Delete))
		{
			this.destroyParticles();
		}
		if (Input.GetMouseButtonDown(0))
		{
			RaycastHit raycastHit = default(RaycastHit);
			if (this.groundCollider.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out raycastHit, 9999f))
			{
				GameObject gameObject = this.spawnParticle();
				if (!gameObject.name.StartsWith("WFX_MF"))
				{
					gameObject.transform.position = raycastHit.point + gameObject.transform.position;
				}
			}
		}
		float axis = Input.GetAxis("Mouse ScrollWheel");
		if (axis != 0f)
		{
			Camera.main.transform.Translate(Vector3.forward * ((axis < 0f) ? -1f : 1f), Space.Self);
		}
		if (Input.GetMouseButtonDown(2))
		{
			Camera.main.transform.position = this.defaultCamPosition;
			Camera.main.transform.rotation = this.defaultCamRotation;
		}
	}

	// Token: 0x06000069 RID: 105 RVA: 0x00004494 File Offset: 0x00002694
	public void OnToggleGround()
	{
		Color white = Color.white;
		this.groundRenderer.enabled = !this.groundRenderer.enabled;
		white.a = (this.groundRenderer.enabled ? 1f : 0.33f);
		this.groundBtn.color = white;
		this.groundLabel.color = white;
	}

	// Token: 0x0600006A RID: 106 RVA: 0x000044F8 File Offset: 0x000026F8
	public void OnToggleCamera()
	{
		Color white = Color.white;
		CFX_Demo_RotateCamera.rotating = !CFX_Demo_RotateCamera.rotating;
		white.a = (CFX_Demo_RotateCamera.rotating ? 1f : 0.33f);
		this.camRotBtn.color = white;
		this.camRotLabel.color = white;
	}

	// Token: 0x0600006B RID: 107 RVA: 0x0000454C File Offset: 0x0000274C
	public void OnToggleSlowMo()
	{
		Color white = Color.white;
		this.slowMo = !this.slowMo;
		if (this.slowMo)
		{
			Time.timeScale = 0.33f;
			white.a = 1f;
		}
		else
		{
			Time.timeScale = 1f;
			white.a = 0.33f;
		}
		this.slowMoBtn.color = white;
		this.slowMoLabel.color = white;
	}

	// Token: 0x0600006C RID: 108 RVA: 0x000045BC File Offset: 0x000027BC
	public void OnPreviousEffect()
	{
		this.prevParticle();
	}

	// Token: 0x0600006D RID: 109 RVA: 0x000045C4 File Offset: 0x000027C4
	public void OnNextEffect()
	{
		this.nextParticle();
	}

	// Token: 0x0600006E RID: 110 RVA: 0x000045CC File Offset: 0x000027CC
	private void UpdateUI()
	{
		this.EffectLabel.text = this.ParticleExamples[this.exampleIndex].name;
		this.EffectIndexLabel.text = string.Format("{0}/{1}", (this.exampleIndex + 1).ToString("00"), this.ParticleExamples.Length.ToString("00"));
	}

	// Token: 0x0600006F RID: 111 RVA: 0x00004638 File Offset: 0x00002838
	public GameObject spawnParticle()
	{
		GameObject gameObject = Object.Instantiate<GameObject>(this.ParticleExamples[this.exampleIndex]);
		gameObject.transform.position = new Vector3(0f, gameObject.transform.position.y, 0f);
		gameObject.SetActive(true);
		if (gameObject.name.StartsWith("WFX_MF"))
		{
			gameObject.transform.parent = this.ParticleExamples[this.exampleIndex].transform.parent;
			gameObject.transform.localPosition = this.ParticleExamples[this.exampleIndex].transform.localPosition;
			gameObject.transform.localRotation = this.ParticleExamples[this.exampleIndex].transform.localRotation;
		}
		else if (gameObject.name.Contains("Hole"))
		{
			gameObject.transform.parent = this.bulletholes.transform;
		}
		ParticleSystem component = gameObject.GetComponent<ParticleSystem>();
		if (component != null && component.main.loop)
		{
			component.gameObject.AddComponent<CFX_AutoStopLoopedEffect>();
			component.gameObject.AddComponent<CFX_AutoDestructShuriken>();
		}
		this.onScreenParticles.Add(gameObject);
		return gameObject;
	}

	// Token: 0x06000070 RID: 112 RVA: 0x00004770 File Offset: 0x00002970
	private IEnumerator CheckForDeletedParticles()
	{
		for (;;)
		{
			yield return new WaitForSeconds(5f);
			for (int i = this.onScreenParticles.Count - 1; i >= 0; i--)
			{
				if (this.onScreenParticles[i] == null)
				{
					this.onScreenParticles.RemoveAt(i);
				}
			}
		}
		yield break;
	}

	// Token: 0x06000071 RID: 113 RVA: 0x0000477F File Offset: 0x0000297F
	private void prevParticle()
	{
		this.exampleIndex--;
		if (this.exampleIndex < 0)
		{
			this.exampleIndex = this.ParticleExamples.Length - 1;
		}
		this.UpdateUI();
		this.showHideStuff();
	}

	// Token: 0x06000072 RID: 114 RVA: 0x000047B4 File Offset: 0x000029B4
	private void nextParticle()
	{
		this.exampleIndex++;
		if (this.exampleIndex >= this.ParticleExamples.Length)
		{
			this.exampleIndex = 0;
		}
		this.UpdateUI();
		this.showHideStuff();
	}

	// Token: 0x06000073 RID: 115 RVA: 0x000047E8 File Offset: 0x000029E8
	private void destroyParticles()
	{
		for (int i = this.onScreenParticles.Count - 1; i >= 0; i--)
		{
			if (this.onScreenParticles[i] != null)
			{
				Object.Destroy(this.onScreenParticles[i]);
			}
			this.onScreenParticles.RemoveAt(i);
		}
	}

	// Token: 0x06000074 RID: 116 RVA: 0x00004840 File Offset: 0x00002A40
	private void prevTexture()
	{
		int num = this.groundTextures.IndexOf(this.groundTextureStr);
		num--;
		if (num < 0)
		{
			num = this.groundTextures.Count - 1;
		}
		this.groundTextureStr = this.groundTextures[num];
		this.selectMaterial();
	}

	// Token: 0x06000075 RID: 117 RVA: 0x00004890 File Offset: 0x00002A90
	private void nextTexture()
	{
		int num = this.groundTextures.IndexOf(this.groundTextureStr);
		num++;
		if (num >= this.groundTextures.Count)
		{
			num = 0;
		}
		this.groundTextureStr = this.groundTextures[num];
		this.selectMaterial();
	}

	// Token: 0x06000076 RID: 118 RVA: 0x000048DC File Offset: 0x00002ADC
	private void selectMaterial()
	{
		string a = this.groundTextureStr;
		if (a == "Concrete")
		{
			this.ground.GetComponent<Renderer>().material = this.concrete;
			this.walls.transform.GetChild(0).GetComponent<Renderer>().material = this.concreteWall;
			this.walls.transform.GetChild(1).GetComponent<Renderer>().material = this.concreteWall;
			return;
		}
		if (a == "Wood")
		{
			this.ground.GetComponent<Renderer>().material = this.wood;
			this.walls.transform.GetChild(0).GetComponent<Renderer>().material = this.woodWall;
			this.walls.transform.GetChild(1).GetComponent<Renderer>().material = this.woodWall;
			return;
		}
		if (a == "Metal")
		{
			this.ground.GetComponent<Renderer>().material = this.metal;
			this.walls.transform.GetChild(0).GetComponent<Renderer>().material = this.metalWall;
			this.walls.transform.GetChild(1).GetComponent<Renderer>().material = this.metalWall;
			return;
		}
		if (!(a == "Checker"))
		{
			return;
		}
		this.ground.GetComponent<Renderer>().material = this.checker;
		this.walls.transform.GetChild(0).GetComponent<Renderer>().material = this.checkerWall;
		this.walls.transform.GetChild(1).GetComponent<Renderer>().material = this.checkerWall;
	}

	// Token: 0x06000077 RID: 119 RVA: 0x00004A90 File Offset: 0x00002C90
	private void showHideStuff()
	{
		if (this.ParticleExamples[this.exampleIndex].name.StartsWith("WFX_MF Spr"))
		{
			this.m4.GetComponent<Renderer>().enabled = true;
			Camera.main.transform.position = new Vector3(-2.482457f, 3.263842f, -0.004924395f);
			Camera.main.transform.eulerAngles = new Vector3(20f, 90f, 0f);
		}
		else
		{
			this.m4.GetComponent<Renderer>().enabled = false;
		}
		if (this.ParticleExamples[this.exampleIndex].name.StartsWith("WFX_MF FPS"))
		{
			this.m4fps.GetComponent<Renderer>().enabled = true;
		}
		else
		{
			this.m4fps.GetComponent<Renderer>().enabled = false;
		}
		if (this.ParticleExamples[this.exampleIndex].name.StartsWith("WFX_BImpact"))
		{
			this.walls.SetActive(true);
			Renderer[] componentsInChildren = this.bulletholes.GetComponentsInChildren<Renderer>();
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].enabled = true;
			}
		}
		else
		{
			this.walls.SetActive(false);
			Renderer[] componentsInChildren = this.bulletholes.GetComponentsInChildren<Renderer>();
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].enabled = false;
			}
		}
		if (this.ParticleExamples[this.exampleIndex].name.Contains("Wood"))
		{
			this.groundTextureStr = "Wood";
			this.selectMaterial();
			return;
		}
		if (this.ParticleExamples[this.exampleIndex].name.Contains("Concrete"))
		{
			this.groundTextureStr = "Concrete";
			this.selectMaterial();
			return;
		}
		if (this.ParticleExamples[this.exampleIndex].name.Contains("Metal"))
		{
			this.groundTextureStr = "Metal";
			this.selectMaterial();
			return;
		}
		if (this.ParticleExamples[this.exampleIndex].name.Contains("Dirt") || this.ParticleExamples[this.exampleIndex].name.Contains("Sand") || this.ParticleExamples[this.exampleIndex].name.Contains("SoftBody"))
		{
			this.groundTextureStr = "Checker";
			this.selectMaterial();
			return;
		}
		if (this.ParticleExamples[this.exampleIndex].name == "WFX_Explosion")
		{
			this.groundTextureStr = "Checker";
			this.selectMaterial();
		}
	}

	// Token: 0x04000062 RID: 98
	public Renderer groundRenderer;

	// Token: 0x04000063 RID: 99
	public Collider groundCollider;

	// Token: 0x04000064 RID: 100
	[Space]
	[Space]
	public Image slowMoBtn;

	// Token: 0x04000065 RID: 101
	public Text slowMoLabel;

	// Token: 0x04000066 RID: 102
	public Image camRotBtn;

	// Token: 0x04000067 RID: 103
	public Text camRotLabel;

	// Token: 0x04000068 RID: 104
	public Image groundBtn;

	// Token: 0x04000069 RID: 105
	public Text groundLabel;

	// Token: 0x0400006A RID: 106
	[Space]
	public Text EffectLabel;

	// Token: 0x0400006B RID: 107
	public Text EffectIndexLabel;

	// Token: 0x0400006C RID: 108
	public GameObject[] AdditionalEffects;

	// Token: 0x0400006D RID: 109
	public GameObject ground;

	// Token: 0x0400006E RID: 110
	public GameObject walls;

	// Token: 0x0400006F RID: 111
	public GameObject bulletholes;

	// Token: 0x04000070 RID: 112
	public GameObject m4;

	// Token: 0x04000071 RID: 113
	public GameObject m4fps;

	// Token: 0x04000072 RID: 114
	public Material wood;

	// Token: 0x04000073 RID: 115
	public Material concrete;

	// Token: 0x04000074 RID: 116
	public Material metal;

	// Token: 0x04000075 RID: 117
	public Material checker;

	// Token: 0x04000076 RID: 118
	public Material woodWall;

	// Token: 0x04000077 RID: 119
	public Material concreteWall;

	// Token: 0x04000078 RID: 120
	public Material metalWall;

	// Token: 0x04000079 RID: 121
	public Material checkerWall;

	// Token: 0x0400007A RID: 122
	private string groundTextureStr = "Checker";

	// Token: 0x0400007B RID: 123
	private List<string> groundTextures = new List<string>(new string[]
	{
		"Concrete",
		"Wood",
		"Metal",
		"Checker"
	});

	// Token: 0x0400007C RID: 124
	private GameObject[] ParticleExamples;

	// Token: 0x0400007D RID: 125
	private int exampleIndex;

	// Token: 0x0400007E RID: 126
	private bool slowMo;

	// Token: 0x0400007F RID: 127
	private Vector3 defaultCamPosition;

	// Token: 0x04000080 RID: 128
	private Quaternion defaultCamRotation;

	// Token: 0x04000081 RID: 129
	private List<GameObject> onScreenParticles = new List<GameObject>();
}
