﻿using System;
using UnityEngine;

// Token: 0x02000073 RID: 115
public class KeyboardManager : MonoBehaviour
{
	// Token: 0x0600044B RID: 1099 RVA: 0x0001D348 File Offset: 0x0001B548
	private void Start()
	{
		this.soundManager = Object.FindObjectOfType<SoundManager>();
		this.hapticManager = Object.FindObjectOfType<HapticManager>();
		GameEvents.current.onKeyboardKeyPressed += this.KeyPress;
		GameEvents.current.onSaveMenuDisabled += this.OnSaveMenuDisabled;
	}

	// Token: 0x0600044C RID: 1100 RVA: 0x0001D398 File Offset: 0x0001B598
	public void ActivateKeyboard(bool toActivate, Transform passInTransform = null)
	{
		if (toActivate)
		{
			passInTransform != null;
			if (this.keyboard == null)
			{
				this.keyboard = Object.Instantiate<GameObject>(this.keyboardObject, base.gameObject.transform);
			}
			this.keyboard.SetActive(toActivate);
			KeyboardKey[] componentsInChildren = base.GetComponentsInChildren<KeyboardKey>();
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].keyboardManager = this;
			}
			this.keyboard.transform.position = passInTransform.position;
			this.keyboard.transform.rotation = passInTransform.rotation;
			return;
		}
		if (this.keyboard == null)
		{
			return;
		}
		this.keyboard.SetActive(toActivate);
		this.firstLetterTyped = false;
		this.lowerCase = false;
		GameEvents.current.KeyboardCaseToggle();
		this.clipBoardText = "";
	}

	// Token: 0x0600044D RID: 1101 RVA: 0x0001D472 File Offset: 0x0001B672
	public bool IsActivated()
	{
		return this.keyboardObject.activeSelf;
	}

	// Token: 0x0600044E RID: 1102 RVA: 0x00003297 File Offset: 0x00001497
	private void OnSaveMenuDisabled()
	{
	}

	// Token: 0x0600044F RID: 1103 RVA: 0x0001D484 File Offset: 0x0001B684
	private void KeyPress()
	{
		if (!this.firstLetterTyped)
		{
			this.firstLetterTyped = true;
			this.lowerCase = true;
			GameEvents.current.KeyboardCaseToggle();
		}
		if (this.clipBoardText.Length >= this.maxSize)
		{
			this.soundManager.Play(this.soundManager.UIerror);
		}
		else
		{
			this.soundManager.Play(this.soundManager.UIKey);
		}
		this.hapticManager.VibrateAudio(this.soundManager.UIKey, OVRInput.Controller.Active);
	}

	// Token: 0x06000450 RID: 1104 RVA: 0x0001D50D File Offset: 0x0001B70D
	private void OnDestroy()
	{
		GameEvents.current.onKeyboardKeyPressed -= this.KeyPress;
		GameEvents.current.onSaveMenuDisabled -= this.OnSaveMenuDisabled;
	}

	// Token: 0x0400057D RID: 1405
	[SerializeField]
	private GameObject keyboardObject;

	// Token: 0x0400057E RID: 1406
	[SerializeField]
	public int maxSize = 20;

	// Token: 0x0400057F RID: 1407
	public bool lowerCase;

	// Token: 0x04000580 RID: 1408
	public string clipBoardText;

	// Token: 0x04000581 RID: 1409
	private KeyboardManager keyboardManager;

	// Token: 0x04000582 RID: 1410
	private GameObject keyboard;

	// Token: 0x04000583 RID: 1411
	private SoundManager soundManager;

	// Token: 0x04000584 RID: 1412
	private HapticManager hapticManager;

	// Token: 0x04000585 RID: 1413
	private bool firstLetterTyped;
}
