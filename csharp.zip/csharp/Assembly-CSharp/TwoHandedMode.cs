﻿using System;
using UnityEngine;

// Token: 0x02000069 RID: 105
public class TwoHandedMode : MonoBehaviour
{
	// Token: 0x060003D5 RID: 981 RVA: 0x00019540 File Offset: 0x00017740
	private void Start()
	{
		this.controlManager = Object.FindObjectOfType<ControlManager>();
		this.soundManager = Object.FindObjectOfType<SoundManager>();
		if (this.controller == null)
		{
			this.controller = base.gameObject.GetComponent<WeaponController>();
		}
		this.originalWeaponRotation = this.controller.transform.localRotation;
		this.originalWeaponPosition = this.controller.transform.localPosition;
		base.Invoke("InitiateHands", 0.1f);
		this.controllerAppearance = Object.FindObjectOfType<ControllerAppearance>();
	}

	// Token: 0x060003D6 RID: 982 RVA: 0x000195CC File Offset: 0x000177CC
	private void InitiateHands()
	{
		foreach (OVRGrabber ovrgrabber in Object.FindObjectsOfType<OVRGrabber>())
		{
			if (ovrgrabber.controllerType == OVRInput.Controller.LTouch)
			{
				this.controllerLeft = ovrgrabber.transform;
			}
			if (ovrgrabber.controllerType == OVRInput.Controller.RTouch)
			{
				this.controllerRight = ovrgrabber.transform;
			}
		}
	}

	// Token: 0x060003D7 RID: 983 RVA: 0x0001961B File Offset: 0x0001781B
	private void Update()
	{
		if (!this.controller.IsHolstered())
		{
			this.CheekWeldCheck();
		}
	}

	// Token: 0x060003D8 RID: 984 RVA: 0x00019630 File Offset: 0x00017830
	private bool IsRightHanded()
	{
		return this.controlManager.handedness != ControlManager.Handedness.Left;
	}

	// Token: 0x060003D9 RID: 985 RVA: 0x00019643 File Offset: 0x00017843
	private SkinnedMeshRenderer CurrentHandRenderer()
	{
		if (this.IsRightHanded())
		{
			return this.controllerAppearance.leftHand;
		}
		return this.controllerAppearance.rightHand;
	}

	// Token: 0x060003DA RID: 986 RVA: 0x00019664 File Offset: 0x00017864
	private void CheekWeldCheck()
	{
		if (this.IsRightHanded())
		{
			this.currentController = OVRInput.Controller.LTouch;
		}
		else
		{
			this.currentController = OVRInput.Controller.RTouch;
		}
		if (OVRInput.GetDown(OVRInput.Button.PrimaryHandTrigger, this.currentController))
		{
			this.UpdateCurrentWeaponHand();
			this.CurrentHandRenderer().enabled = false;
		}
		if (this.HeadAligned() && OVRInput.Get(OVRInput.Button.PrimaryHandTrigger, this.currentController))
		{
			if (OVRInput.GetDown(OVRInput.Button.PrimaryIndexTrigger, this.currentController))
			{
				this.soundManager.Play(this.soundManager.breatheIn);
				this.lastWeaponPosition = this.controller.transform.localPosition;
				this.lastWeaponRotation = this.controller.transform.rotation;
			}
			if (OVRInput.Get(OVRInput.Button.PrimaryIndexTrigger, this.currentController))
			{
				this.DampenWeapon();
			}
			if (OVRInput.GetUp(OVRInput.Button.PrimaryIndexTrigger, this.currentController))
			{
				this.soundManager.Play(this.soundManager.breatheOut);
			}
			this.AlignWeapon();
		}
		else if (this.controller.transform.rotation != this.originalWeaponRotation && OVRInput.Get(OVRInput.Button.PrimaryHandTrigger, this.currentController))
		{
			this.controller.transform.localRotation = this.originalWeaponRotation;
			this.controller.transform.localPosition = this.originalWeaponPosition;
		}
		if (OVRInput.GetDown(OVRInput.Button.PrimaryIndexTrigger, this.currentController) && !OVRInput.Get(OVRInput.Button.PrimaryHandTrigger, this.currentController) && Vector3.Distance(this.loadingPortTransform.position, this.currentSupportHand.position) < 0.1f)
		{
			this.controller.ShotgunReloadRefactor();
		}
		if (OVRInput.GetUp(OVRInput.Button.PrimaryHandTrigger, this.currentController))
		{
			this.CurrentHandRenderer().enabled = true;
			this.controller.transform.localRotation = this.originalWeaponRotation;
			this.controller.transform.localPosition = this.originalWeaponPosition;
		}
	}

	// Token: 0x060003DB RID: 987 RVA: 0x0001985F File Offset: 0x00017A5F
	private void UpdateCurrentWeaponHand()
	{
		if (this.IsRightHanded())
		{
			this.currentWeaponHand = this.controllerRight;
			this.currentSupportHand = this.controllerLeft;
			return;
		}
		this.currentWeaponHand = this.controllerLeft;
		this.currentSupportHand = this.controllerRight;
	}

	// Token: 0x060003DC RID: 988 RVA: 0x0001989C File Offset: 0x00017A9C
	private void AlignWeapon()
	{
		Quaternion rotation = this.controller.transform.rotation;
		if (this.currentSupportHand == null)
		{
			this.InitiateHands();
			this.UpdateCurrentWeaponHand();
		}
		this.controller.transform.LookAt(this.currentSupportHand.position, this.controller.transform.up);
		Quaternion rotation2 = this.controller.transform.rotation;
		this.controller.transform.eulerAngles = new Vector3(this.controller.transform.eulerAngles.x, this.controller.transform.eulerAngles.y, this.currentWeaponHand.parent.eulerAngles.z);
		if (OVRInput.Get(OVRInput.Axis1D.PrimaryIndexTrigger, this.currentController) > 0f)
		{
			float num = OVRInput.Get(OVRInput.Axis1D.PrimaryIndexTrigger, this.currentController);
			float num2 = Mathf.Abs(1f - num);
			if (num2 < 0.07f)
			{
				num2 = 0.07f;
			}
			this.controller.transform.rotation = Quaternion.Lerp(rotation, rotation2, num2);
		}
	}

	// Token: 0x060003DD RID: 989 RVA: 0x000199BD File Offset: 0x00017BBD
	private void DampenWeapon()
	{
		this.controller.transform.localPosition = this.lastWeaponPosition;
		this.controller.transform.rotation = this.lastWeaponRotation;
	}

	// Token: 0x060003DE RID: 990 RVA: 0x00018666 File Offset: 0x00016866
	private bool HeadAligned()
	{
		return true;
	}

	// Token: 0x040004BC RID: 1212
	[SerializeField]
	private WeaponController controller;

	// Token: 0x040004BD RID: 1213
	[SerializeField]
	private Transform scopePosition;

	// Token: 0x040004BE RID: 1214
	[SerializeField]
	private LayerMask layer;

	// Token: 0x040004BF RID: 1215
	[SerializeField]
	private Transform loadingPortTransform;

	// Token: 0x040004C0 RID: 1216
	private Transform controllerLeft;

	// Token: 0x040004C1 RID: 1217
	private Transform controllerRight;

	// Token: 0x040004C2 RID: 1218
	private Transform currentSupportHand;

	// Token: 0x040004C3 RID: 1219
	private Transform currentWeaponHand;

	// Token: 0x040004C4 RID: 1220
	private Quaternion originalWeaponRotation;

	// Token: 0x040004C5 RID: 1221
	private Quaternion lastWeaponRotation;

	// Token: 0x040004C6 RID: 1222
	private Vector3 originalWeaponPosition;

	// Token: 0x040004C7 RID: 1223
	private Vector3 lastWeaponPosition;

	// Token: 0x040004C8 RID: 1224
	private float timeDampenInterval = 0.1f;

	// Token: 0x040004C9 RID: 1225
	private float timeSinceLastDampen;

	// Token: 0x040004CA RID: 1226
	private OVRInput.Controller currentController;

	// Token: 0x040004CB RID: 1227
	private ControllerAppearance controllerAppearance;

	// Token: 0x040004CC RID: 1228
	private ControlManager controlManager;

	// Token: 0x040004CD RID: 1229
	private SoundManager soundManager;

	// Token: 0x040004CE RID: 1230
	private HandedTest test;
}
