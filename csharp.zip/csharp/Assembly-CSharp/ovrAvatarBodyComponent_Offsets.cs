﻿using System;
using System.Runtime.InteropServices;

// Token: 0x020000D1 RID: 209
public struct ovrAvatarBodyComponent_Offsets
{
	// Token: 0x040007EB RID: 2027
	public static long leftEyeTransform = Marshal.OffsetOf(typeof(ovrAvatarBodyComponent), "leftEyeTransform").ToInt64();

	// Token: 0x040007EC RID: 2028
	public static long rightEyeTransform = Marshal.OffsetOf(typeof(ovrAvatarBodyComponent), "rightEyeTransform").ToInt64();

	// Token: 0x040007ED RID: 2029
	public static long centerEyeTransform = Marshal.OffsetOf(typeof(ovrAvatarBodyComponent), "centerEyeTransform").ToInt64();

	// Token: 0x040007EE RID: 2030
	public static long renderComponent = Marshal.OffsetOf(typeof(ovrAvatarBodyComponent), "renderComponent").ToInt64();
}
