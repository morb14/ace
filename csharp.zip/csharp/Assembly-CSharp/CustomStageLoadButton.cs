﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x02000006 RID: 6
public class CustomStageLoadButton : MonoBehaviour
{
	// Token: 0x06000012 RID: 18 RVA: 0x0000236C File Offset: 0x0000056C
	private void Start()
	{
		this.defaultTextColor = this.fieldText.color;
		if (this.isNewButton)
		{
			this.fieldText.text = this.newSaveText;
		}
		this.originalScale = base.transform.localScale;
		GameEvents.current.onSaveMenuDisabled += this.OnSaveMenuDisabled;
		GameEvents.current.onKeyboardReturnPressed += this.OnKeyboardReturnPressed;
		GameEvents.current.onKeyboardKeyPressed += this.OnKeyboardKeyPressed;
	}

	// Token: 0x06000013 RID: 19 RVA: 0x000023F6 File Offset: 0x000005F6
	private void FixedUpdate()
	{
		if (this.highlightActivated)
		{
			this.highlight.SetActive(false);
			this.highlightActivated = false;
		}
	}

	// Token: 0x06000014 RID: 20 RVA: 0x00002413 File Offset: 0x00000613
	public void AssignLoadFile(string file)
	{
		this.fileToLoad = file;
	}

	// Token: 0x06000015 RID: 21 RVA: 0x0000241C File Offset: 0x0000061C
	public void Highlight()
	{
		this.highlight.SetActive(true);
		this.highlight.transform.localPosition = base.transform.localPosition;
		this.highlightActivated = true;
		this.menu.DelayRescale();
	}

	// Token: 0x06000016 RID: 22 RVA: 0x00002458 File Offset: 0x00000658
	public void Select()
	{
		if (this.soundManager == null)
		{
			this.soundManager = Object.FindObjectOfType<SoundManager>();
		}
		this.soundManager.Play(this.soundManager.UIclick);
		base.transform.localScale = new Vector3(base.transform.localScale.x * 1.1f, base.transform.localScale.y * 1.1f, base.transform.localScale.z * 1.1f);
		if (this.fileToLoad != "")
		{
			SaveManager saveManager = Object.FindObjectOfType<SaveManager>();
			if (this.menu.menuMode == CustomStageMenu.MenuMode.Load)
			{
				if (this.isNewButton)
				{
					Object.FindObjectOfType<SceneLoader>().loadMode = SceneLoader.LoadMode.Wipe;
					SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
					Object.FindObjectOfType<SceneLoader>().loadMode = SceneLoader.LoadMode.Default;
				}
				else
				{
					MonoBehaviour.print("Attempt to load " + this.fileToLoad);
					Object.FindObjectOfType<SceneLoader>().loadMode = SceneLoader.LoadMode.Default;
					Object.FindObjectOfType<SaveManager>().UpdateCurrentFile(this.fileToLoad);
					saveManager.Load(this.fileToLoad, false);
				}
			}
			if (this.menu.menuMode == CustomStageMenu.MenuMode.Delete && !this.isNewButton)
			{
				if (!this.overWriteConfirmation)
				{
					this.fieldName = this.fieldText.text;
					this.defaultTextColor = this.fieldText.color;
					this.fieldText.text = "Delete?";
					this.fieldText.color = Color.red;
					this.overWriteConfirmation = true;
					base.Invoke("RenameField", 2f);
				}
				else
				{
					if (this.menu.Delete(this.fileToLoad))
					{
						this.fieldText.color = this.defaultTextColor;
						this.fieldText.text = "Deleted!";
					}
					else
					{
						this.fieldText.text = "Failed";
					}
					this.overWriteConfirmation = false;
					base.Invoke("RenameField", 1f);
				}
			}
			if (this.menu.menuMode == CustomStageMenu.MenuMode.Rename && !this.isNewButton)
			{
				this.fieldName = this.fieldText.text;
				KeyboardManager keyboardManager = Object.FindObjectOfType<KeyboardManager>();
				this.keyboardActivated = !this.keyboardActivated;
				keyboardManager.ActivateKeyboard(this.keyboardActivated, this.keyboardTransform);
				this.menu.currentSelectedLoadButton = this.fieldName;
			}
			if (this.menu.menuMode == CustomStageMenu.MenuMode.Save && !this.isNewButton)
			{
				if (!this.overWriteConfirmation)
				{
					this.fieldName = this.fieldText.text;
					this.defaultTextColor = this.fieldText.color;
					this.fieldText.text = "Overwrite?";
					this.overWriteConfirmation = true;
					base.Invoke("RenameField", 2f);
				}
				else
				{
					saveManager.Save(this.fileToLoad);
					this.soundManager.Play(this.soundManager.UIcorrect);
					Object.FindObjectOfType<SaveManager>().UpdateCurrentFile(this.fileToLoad);
					this.overWriteConfirmation = false;
					this.fieldText.text = "Saved!";
					base.Invoke("RenameField", 1f);
				}
			}
		}
		base.Invoke("ResizeButton", 0.1f);
		if (this.isNewButton && this.menu.menuMode == CustomStageMenu.MenuMode.Save)
		{
			KeyboardManager keyboardManager2 = Object.FindObjectOfType<KeyboardManager>();
			this.keyboardActivated = !this.keyboardActivated;
			keyboardManager2.ActivateKeyboard(this.keyboardActivated, this.keyboardTransform);
		}
		if (this.isNewButton && (this.menu.menuMode == CustomStageMenu.MenuMode.Rename || this.menu.menuMode == CustomStageMenu.MenuMode.Delete))
		{
			this.soundManager.Play(this.soundManager.UIerror);
		}
	}

	// Token: 0x06000017 RID: 23 RVA: 0x00002804 File Offset: 0x00000A04
	private void OnKeyboardKeyPressed()
	{
		if (this.isNewButton && this.menu.menuMode == CustomStageMenu.MenuMode.Save)
		{
			this.fieldText.text = Object.FindObjectOfType<KeyboardManager>().clipBoardText;
		}
		if (this.menu.menuMode == CustomStageMenu.MenuMode.Rename && this.fieldName == this.menu.currentSelectedLoadButton)
		{
			this.fieldText.text = Object.FindObjectOfType<KeyboardManager>().clipBoardText;
		}
	}

	// Token: 0x06000018 RID: 24 RVA: 0x00002877 File Offset: 0x00000A77
	private void OnSaveMenuDisabled()
	{
		this.keyboardActivated = false;
		if (this.isNewButton && this.fieldText.text != this.newSaveText)
		{
			this.fieldText.text = this.newSaveText;
		}
	}

	// Token: 0x06000019 RID: 25 RVA: 0x000028B4 File Offset: 0x00000AB4
	private void OnKeyboardReturnPressed()
	{
		if (this.menu.menuMode == CustomStageMenu.MenuMode.Rename && this.fieldName == this.menu.currentSelectedLoadButton)
		{
			this.menu.Rename(this.fieldName, this.fieldText.text);
		}
		if (this.isNewButton && this.menu.menuMode == CustomStageMenu.MenuMode.Save)
		{
			KeyboardManager keyboardManager = Object.FindObjectOfType<KeyboardManager>();
			if (keyboardManager.clipBoardText != "")
			{
				if (this.menu.SaveNewFile(keyboardManager.clipBoardText))
				{
					MonoBehaviour.print("KEYBOARD SAVE SUCCESS");
					Object.FindObjectOfType<SaveManager>().UpdateCurrentFile(keyboardManager.clipBoardText);
					this.fieldText.text = "Saved!";
					base.Invoke("RenameField", 1f);
					return;
				}
				MonoBehaviour.print("KEYBOARD SAVE FAILED DUE TO NAME");
				this.fieldText.text = "Name already used!";
				base.Invoke("RenameField", 1f);
			}
		}
	}

	// Token: 0x0600001A RID: 26 RVA: 0x000029B0 File Offset: 0x00000BB0
	private void RenameField()
	{
		MonoBehaviour.print("SAVE AS RENAME TEST " + this.fileToLoad);
		string text = this.fileToLoad;
		if (this.fileToLoad != "")
		{
			text = text.Remove(0, Object.FindObjectOfType<SceneSettings>().customStageName.Length + 1);
		}
		else
		{
			text = "";
		}
		this.overWriteConfirmation = false;
		this.fieldText.text = text;
		Color color = this.defaultTextColor;
		this.fieldText.color = this.defaultTextColor;
		if (this.isNewButton)
		{
			this.fieldText.text = this.newSaveText;
		}
	}

	// Token: 0x0600001B RID: 27 RVA: 0x00002A50 File Offset: 0x00000C50
	private void ResizeButton()
	{
		base.transform.localScale = this.originalScale;
	}

	// Token: 0x0600001C RID: 28 RVA: 0x00002A64 File Offset: 0x00000C64
	private void OnDestroy()
	{
		GameEvents.current.onSaveMenuDisabled -= this.OnSaveMenuDisabled;
		GameEvents.current.onKeyboardReturnPressed -= this.OnKeyboardReturnPressed;
		GameEvents.current.onKeyboardKeyPressed -= this.OnKeyboardKeyPressed;
	}

	// Token: 0x04000012 RID: 18
	[Header("Load Fields")]
	[SerializeField]
	public TMP_Text fieldText;

	// Token: 0x04000013 RID: 19
	[SerializeField]
	private GameObject highlight;

	// Token: 0x04000014 RID: 20
	[SerializeField]
	private CustomStageMenu menu;

	// Token: 0x04000015 RID: 21
	[Header("Save Fields")]
	private bool overWriteConfirmation;

	// Token: 0x04000016 RID: 22
	private string fieldName;

	// Token: 0x04000017 RID: 23
	private Color defaultTextColor;

	// Token: 0x04000018 RID: 24
	[SerializeField]
	private string newSaveText = "New Save";

	// Token: 0x04000019 RID: 25
	public string fileToLoad;

	// Token: 0x0400001A RID: 26
	private bool highlightActivated;

	// Token: 0x0400001B RID: 27
	private bool keyboardActivated;

	// Token: 0x0400001C RID: 28
	private SoundManager soundManager;

	// Token: 0x0400001D RID: 29
	private Vector3 originalScale;

	// Token: 0x0400001E RID: 30
	[Header("Keyboard Related")]
	[SerializeField]
	public bool isNewButton;

	// Token: 0x0400001F RID: 31
	[SerializeField]
	private GameObject keyboardObject;

	// Token: 0x04000020 RID: 32
	[SerializeField]
	private Transform keyboardTransform;
}
