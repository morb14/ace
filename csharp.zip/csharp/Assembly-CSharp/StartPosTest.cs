﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x0200008D RID: 141
public class StartPosTest : MonoBehaviour
{
	// Token: 0x060004E5 RID: 1253 RVA: 0x00020652 File Offset: 0x0001E852
	private void Start()
	{
		GameEvents.current.onShootingAreaEnter += this.OnShootingAreaEnter;
		GameEvents.current.onShootingAreaExit += this.OnShootingAreaExit;
		SceneManager.sceneLoaded += this.OnSceneLoaded;
	}

	// Token: 0x060004E6 RID: 1254 RVA: 0x00020691 File Offset: 0x0001E891
	private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
	{
		MonoBehaviour.print("START POS TEST");
		this.sceneSettings = Object.FindObjectOfType<SceneSettings>();
	}

	// Token: 0x060004E7 RID: 1255 RVA: 0x00003297 File Offset: 0x00001497
	private void OnShootingAreaEnter()
	{
	}

	// Token: 0x060004E8 RID: 1256 RVA: 0x00003297 File Offset: 0x00001497
	private void OnShootingAreaExit()
	{
	}

	// Token: 0x060004E9 RID: 1257 RVA: 0x000206A8 File Offset: 0x0001E8A8
	private void OnDestroy()
	{
		SceneManager.sceneLoaded -= this.OnSceneLoaded;
	}

	// Token: 0x04000633 RID: 1587
	[SerializeField]
	private TMP_Text text;

	// Token: 0x04000634 RID: 1588
	private SceneSettings sceneSettings;
}
