﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000086 RID: 134
public class InputManager : MonoBehaviour
{
	// Token: 0x060004B9 RID: 1209 RVA: 0x0001F218 File Offset: 0x0001D418
	private void Start()
	{
		this.spawnTeleportPoint = Object.Instantiate<GameObject>(this.teleportPoint);
		this.spawnTeleportPoint.SetActive(false);
		this.lineRenderer = base.GetComponent<LineRenderer>();
		this.controllerMode = ControllerMode.Hands;
		this.previousGesture = default(Gesture);
		this.handRendererLeft = this.skeletonLeft.GetComponent<SkinnedMeshRenderer>();
		this.handRendererRight = this.skeleton.GetComponent<SkinnedMeshRenderer>();
	}

	// Token: 0x060004BA RID: 1210 RVA: 0x0001F284 File Offset: 0x0001D484
	private void Update()
	{
		this.GetBones();
		this.HandConfidence();
		this.ControllerDetection();
		this.ControllerMovement();
		if (this.skeleton.transform.childCount > 0)
		{
			this.Recognise();
			this.RecogniseLeft();
			this.HandAction();
		}
		if (Input.GetKeyDown(KeyCode.Space))
		{
			MonoBehaviour.print("Right Hand Gesture Saved.");
			this.Save(false);
		}
		if (Input.GetKeyDown(KeyCode.LeftShift))
		{
			MonoBehaviour.print("Left Hand Gesture Saved");
			this.Save(true);
		}
	}

	// Token: 0x060004BB RID: 1211 RVA: 0x0001F308 File Offset: 0x0001D508
	private void ControllerMovement()
	{
		if (this.controllerMode != ControllerMode.Controllers)
		{
			return;
		}
		if (this.movementMode == MovementMode.Teleport)
		{
			if (OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, OVRInput.Controller.Active).y > 0.5f)
			{
				this.TeleportTrajectory(true, this.controllerRendererLeft.transform.parent, default(Vector3));
			}
			if (OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, OVRInput.Controller.Active).y == 0f)
			{
				this.TeleportTrajectory(false, null, default(Vector3));
			}
		}
		else if (this.movementMode == MovementMode.Glide)
		{
			Vector3 vector = new Vector3(this.camera.transform.forward.x, 0f, this.camera.transform.forward.z);
			if (OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, OVRInput.Controller.Active).y > 0.5f)
			{
				this.characterController.SimpleMove(vector);
				MonoBehaviour.print("MOVING");
			}
			if (OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, OVRInput.Controller.Active).y < -0.5f)
			{
				this.characterController.SimpleMove(-vector);
			}
		}
		if (!this.movementRotationReset)
		{
			if (OVRInput.Get(OVRInput.Axis2D.SecondaryThumbstick, OVRInput.Controller.Active).x > 0.5f)
			{
				this.characterController.transform.Rotate(0f, 90f, 0f);
				this.movementRotationReset = true;
			}
			if (OVRInput.Get(OVRInput.Axis2D.SecondaryThumbstick, OVRInput.Controller.Active).x < -0.5f)
			{
				this.characterController.transform.Rotate(0f, -90f, 0f);
				this.movementRotationReset = true;
				return;
			}
		}
		else if (OVRInput.Get(OVRInput.Axis2D.SecondaryThumbstick, OVRInput.Controller.Active).x == 0f)
		{
			this.movementRotationReset = false;
		}
	}

	// Token: 0x060004BC RID: 1212 RVA: 0x0001F4C8 File Offset: 0x0001D6C8
	private void TeleportTrajectory(bool turnOn = true, Transform posTransform = null, Vector3 front = default(Vector3))
	{
		if (turnOn)
		{
			this.lineRenderer.enabled = true;
			float num = 1f / (float)this.trajectorySegments;
			int num2 = 0;
			Vector3 vector = posTransform.position;
			Vector3 vector2 = Vector3.zero;
			this.lineRenderer.positionCount = this.trajectorySegments;
			bool flag = false;
			for (float num3 = 0f; num3 < 1f; num3 += num)
			{
				if (!flag)
				{
					this.lineRenderer.SetPosition(num2, vector);
				}
				else
				{
					this.lineRenderer.SetPosition(num2, this.teleportPos);
				}
				if (front == default(Vector3))
				{
					front = posTransform.forward;
				}
				vector2 = vector + front * this.trajectorySpeed + this.trajectoryCurve * new Vector3(0f, (float)(-(float)num2), 0f) / (float)this.trajectorySegments;
				RaycastHit raycastHit;
				if (Physics.Raycast(vector, vector2 - vector, out raycastHit, Vector3.Magnitude(vector2 - vector), this.layerMask))
				{
					MonoBehaviour.print(raycastHit.transform);
					this.teleportPos = raycastHit.point;
					this.spawnTeleportPoint.transform.position = this.teleportPos;
					this.spawnTeleportPoint.SetActive(true);
					flag = true;
				}
				vector = vector2;
				num2++;
			}
			return;
		}
		this.lineRenderer.enabled = false;
		if (this.teleportPos != Vector3.zero)
		{
			this.characterController.enabled = false;
			this.characterController.transform.position = this.teleportPos;
			this.spawnTeleportPoint.SetActive(false);
			this.characterController.enabled = true;
			this.teleportPos = Vector3.zero;
		}
	}

	// Token: 0x060004BD RID: 1213 RVA: 0x0001F68C File Offset: 0x0001D88C
	private void ToggleControllers()
	{
		ControllerMode controllerMode = this.controllerMode;
		if (controllerMode == ControllerMode.Hands)
		{
			this.handRendererLeft.enabled = false;
			this.handRendererRight.enabled = false;
			this.controllerRendererLeft.enabled = true;
			this.controllerRendererRight.enabled = true;
			this.controllerMode = ControllerMode.Controllers;
			return;
		}
		if (controllerMode != ControllerMode.Controllers)
		{
			return;
		}
		this.handRendererLeft.enabled = true;
		this.handRendererRight.enabled = true;
		this.controllerRendererLeft.enabled = false;
		this.controllerRendererRight.enabled = false;
		this.controllerMode = ControllerMode.Hands;
	}

	// Token: 0x060004BE RID: 1214 RVA: 0x0001F717 File Offset: 0x0001D917
	private void ControllerDetection()
	{
		if (OVRInput.GetDown(OVRInput.Button.Any, OVRInput.Controller.Touch) && this.controllerMode == ControllerMode.Hands)
		{
			this.ToggleControllers();
		}
	}

	// Token: 0x060004BF RID: 1215 RVA: 0x0001F730 File Offset: 0x0001D930
	private void HandConfidence()
	{
		if (this.skeleton.transform.childCount > 0 && this.skeletonLeft.transform.childCount >= 0 && this.handRendererLeft.enabled && this.handRendererRight.enabled && (this.controllerRendererRight.enabled || (this.controllerRendererLeft.enabled && this.controllerMode == ControllerMode.Controllers)))
		{
			this.ToggleControllers();
		}
	}

	// Token: 0x060004C0 RID: 1216 RVA: 0x0001F7A8 File Offset: 0x0001D9A8
	private void GetBones()
	{
		if (this.skeleton.transform.childCount <= 0 && this.skeletonLeft.transform.childCount <= 0)
		{
			MonoBehaviour.print("Hands not spawned yet");
			return;
		}
		if (this.fingerBones == null && this.fingerBonesLeft == null)
		{
			this.fingerBones = new List<OVRBone>(this.skeleton.Bones);
			this.fingerBonesLeft = new List<OVRBone>(this.skeletonLeft.Bones);
			MonoBehaviour.print("Hand bone assigned");
		}
	}

	// Token: 0x060004C1 RID: 1217 RVA: 0x0001F82C File Offset: 0x0001DA2C
	private void Save(bool leftHanded = false)
	{
		Gesture item = default(Gesture);
		item.name = "New Gesture";
		List<Vector3> list = new List<Vector3>();
		if (leftHanded)
		{
			using (List<OVRBone>.Enumerator enumerator = this.fingerBonesLeft.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					OVRBone ovrbone = enumerator.Current;
					list.Add(this.skeletonLeft.transform.InverseTransformPoint(ovrbone.Transform.position));
				}
				goto IL_BF;
			}
		}
		foreach (OVRBone ovrbone2 in this.fingerBones)
		{
			list.Add(this.skeleton.transform.InverseTransformPoint(ovrbone2.Transform.position));
		}
		IL_BF:
		item.fingerData = list;
		this.gestures.Add(item);
		MonoBehaviour.print("Gesture saved");
	}

	// Token: 0x060004C2 RID: 1218 RVA: 0x0001F934 File Offset: 0x0001DB34
	private Gesture RecogniseLeft()
	{
		Gesture result = default(Gesture);
		float num = float.PositiveInfinity;
		foreach (Gesture gesture in this.gestures)
		{
			float num2 = 0f;
			bool flag = false;
			for (int i = 0; i < this.fingerBonesLeft.Count; i++)
			{
				float num3 = Vector3.Distance(this.skeletonLeft.transform.InverseTransformPoint(this.fingerBonesLeft[i].Transform.position), gesture.fingerData[i]);
				if (num3 > this.threshold)
				{
					flag = true;
					break;
				}
				num2 += num3;
			}
			if (!flag && num2 < num)
			{
				num = num2;
				result = gesture;
				if (gesture.name == "LeftForward")
				{
					this.leftForward = true;
				}
				if (gesture.name == "LeftBackwards")
				{
					this.leftBackwards = true;
				}
			}
		}
		return result;
	}

	// Token: 0x060004C3 RID: 1219 RVA: 0x0001FA4C File Offset: 0x0001DC4C
	private Gesture Recognise()
	{
		Gesture result = default(Gesture);
		float num = float.PositiveInfinity;
		foreach (Gesture gesture in this.gestures)
		{
			float num2 = 0f;
			bool flag = false;
			for (int i = 0; i < this.fingerBones.Count; i++)
			{
				float num3 = Vector3.Distance(this.skeleton.transform.InverseTransformPoint(this.fingerBones[i].Transform.position), gesture.fingerData[i]);
				if (num3 > this.threshold)
				{
					flag = true;
					break;
				}
				num2 += num3;
			}
			if (!flag && num2 < num)
			{
				num = num2;
				result = gesture;
				if (gesture.name == "Forward")
				{
					this.rightForward = true;
				}
				if (gesture.name == "Backwards")
				{
					this.rightBackwards = true;
				}
			}
		}
		return result;
	}

	// Token: 0x060004C4 RID: 1220 RVA: 0x0001FB64 File Offset: 0x0001DD64
	private void HandAction()
	{
		if (this.controllerMode != ControllerMode.Hands)
		{
			return;
		}
		if (this.movementMode == MovementMode.Glide)
		{
			Vector3 vector = new Vector3(this.camera.transform.forward.x, 0f, this.camera.transform.forward.z);
			if (this.rightForward && this.leftForward)
			{
				this.characterController.SimpleMove(vector);
			}
			if (this.leftBackwards && this.rightBackwards)
			{
				this.characterController.SimpleMove(-vector);
			}
			this.rightBackwards = false;
			this.leftBackwards = false;
			this.rightForward = false;
			this.leftForward = false;
			return;
		}
		if (this.movementMode == MovementMode.Teleport)
		{
			if (this.rightForward && this.leftForward)
			{
				this.TeleportTrajectory(true, this.skeletonLeft.transform, this.skeletonLeft.transform.right);
				this.rightForward = false;
				this.leftForward = false;
				return;
			}
			this.TeleportTrajectory(false, null, default(Vector3));
		}
	}

	// Token: 0x040005F3 RID: 1523
	public float threshold = 0.1f;

	// Token: 0x040005F4 RID: 1524
	public OVRSkeleton skeletonLeft;

	// Token: 0x040005F5 RID: 1525
	public OVRSkeleton skeleton;

	// Token: 0x040005F6 RID: 1526
	public List<Gesture> gestures;

	// Token: 0x040005F7 RID: 1527
	private List<OVRBone> fingerBones;

	// Token: 0x040005F8 RID: 1528
	private List<OVRBone> fingerBonesLeft;

	// Token: 0x040005F9 RID: 1529
	private Gesture previousGesture;

	// Token: 0x040005FA RID: 1530
	public CharacterController characterController;

	// Token: 0x040005FB RID: 1531
	[SerializeField]
	private LayerMask layerMask;

	// Token: 0x040005FC RID: 1532
	public Camera camera;

	// Token: 0x040005FD RID: 1533
	[SerializeField]
	private int trajectorySegments = 10;

	// Token: 0x040005FE RID: 1534
	[SerializeField]
	private float trajectorySpeed = 1f;

	// Token: 0x040005FF RID: 1535
	[SerializeField]
	private float trajectoryCurve = 1f;

	// Token: 0x04000600 RID: 1536
	private bool movementRotationReset;

	// Token: 0x04000601 RID: 1537
	private LineRenderer lineRenderer;

	// Token: 0x04000602 RID: 1538
	public ControllerMode controllerMode;

	// Token: 0x04000603 RID: 1539
	public MovementMode movementMode;

	// Token: 0x04000604 RID: 1540
	[SerializeField]
	private SkinnedMeshRenderer controllerRendererRight;

	// Token: 0x04000605 RID: 1541
	[SerializeField]
	private SkinnedMeshRenderer controllerRendererLeft;

	// Token: 0x04000606 RID: 1542
	[SerializeField]
	private GameObject teleportPoint;

	// Token: 0x04000607 RID: 1543
	private GameObject spawnTeleportPoint;

	// Token: 0x04000608 RID: 1544
	private SkinnedMeshRenderer handRendererLeft;

	// Token: 0x04000609 RID: 1545
	private SkinnedMeshRenderer handRendererRight;

	// Token: 0x0400060A RID: 1546
	private Vector3 teleportPos = Vector3.zero;

	// Token: 0x0400060B RID: 1547
	private bool leftForward;

	// Token: 0x0400060C RID: 1548
	private bool leftBackwards;

	// Token: 0x0400060D RID: 1549
	private bool rightForward;

	// Token: 0x0400060E RID: 1550
	private bool rightBackwards;
}
