﻿using System;
using UnityEngine;

// Token: 0x02000077 RID: 119
public class MissingTextureFinder : MonoBehaviour
{
	// Token: 0x0600045E RID: 1118 RVA: 0x0001D75C File Offset: 0x0001B95C
	private void Start()
	{
		this.DelayedFunction();
	}

	// Token: 0x0600045F RID: 1119 RVA: 0x0001D764 File Offset: 0x0001B964
	private void DelayedFunction()
	{
		this.renderers = Object.FindObjectsOfType<Renderer>();
		int num = 0;
		int num2 = this.renderers.Length;
		Renderer[] array = this.renderers;
		for (int i = 0; i < array.Length; i++)
		{
			Material[] materials = array[i].materials;
			for (int j = 0; j < materials.Length; j++)
			{
				if (materials[j] == null)
				{
					num++;
				}
			}
		}
		MonoBehaviour.print(string.Concat(new object[]
		{
			"MISSING TEXTURE FOUND: ",
			num,
			" FROM ",
			num2
		}));
	}

	// Token: 0x04000592 RID: 1426
	private Renderer[] renderers;
}
