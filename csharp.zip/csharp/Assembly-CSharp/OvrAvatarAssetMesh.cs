﻿using System;
using System.Runtime.InteropServices;
using Oculus.Avatar;
using UnityEngine;

// Token: 0x020000AD RID: 173
public class OvrAvatarAssetMesh : OvrAvatarAsset
{
	// Token: 0x060005DC RID: 1500 RVA: 0x000259FC File Offset: 0x00023BFC
	public OvrAvatarAssetMesh(ulong _assetId, IntPtr asset, ovrAvatarAssetType meshType)
	{
		this.assetID = _assetId;
		this.mesh = new Mesh();
		this.mesh.name = "Procedural Geometry for asset " + _assetId;
		this.SetSkinnedBindPose(asset, meshType);
		long num = 0L;
		IntPtr zero = IntPtr.Zero;
		uint num2 = 0U;
		IntPtr zero2 = IntPtr.Zero;
		this.GetVertexAndIndexData(asset, meshType, out num, out zero, out num2, out zero2);
		Vector3[] array = new Vector3[num];
		Vector3[] array2 = new Vector3[num];
		Vector4[] array3 = new Vector4[num];
		Vector2[] array4 = new Vector2[num];
		Color[] array5 = new Color[num];
		BoneWeight[] array6 = new BoneWeight[num];
		long num3 = zero.ToInt64();
		if (meshType != ovrAvatarAssetType.Mesh)
		{
			if (meshType != ovrAvatarAssetType.CombinedMesh)
			{
				throw new Exception("Bad Mesh Asset Type");
			}
			long num4 = (long)Marshal.SizeOf(typeof(ovrAvatarMeshVertexV2));
			for (long num5 = 0L; num5 < num; num5 += 1L)
			{
				long num6 = num4 * num5;
				ovrAvatarMeshVertexV2 ovrAvatarMeshVertexV = (ovrAvatarMeshVertexV2)Marshal.PtrToStructure(new IntPtr(num3 + num6), typeof(ovrAvatarMeshVertexV2));
				array[(int)(checked((IntPtr)num5))] = new Vector3(ovrAvatarMeshVertexV.x, ovrAvatarMeshVertexV.y, -ovrAvatarMeshVertexV.z);
				array2[(int)(checked((IntPtr)num5))] = new Vector3(ovrAvatarMeshVertexV.nx, ovrAvatarMeshVertexV.ny, -ovrAvatarMeshVertexV.nz);
				array3[(int)(checked((IntPtr)num5))] = new Vector4(ovrAvatarMeshVertexV.tx, ovrAvatarMeshVertexV.ty, -ovrAvatarMeshVertexV.tz, ovrAvatarMeshVertexV.tw);
				checked
				{
					array4[(int)((IntPtr)num5)] = new Vector2(ovrAvatarMeshVertexV.u, ovrAvatarMeshVertexV.v);
					array5[(int)((IntPtr)num5)] = new Color(ovrAvatarMeshVertexV.r, ovrAvatarMeshVertexV.g, ovrAvatarMeshVertexV.b, ovrAvatarMeshVertexV.a);
					array6[(int)((IntPtr)num5)].boneIndex0 = (int)ovrAvatarMeshVertexV.blendIndices[0];
					array6[(int)((IntPtr)num5)].boneIndex1 = (int)ovrAvatarMeshVertexV.blendIndices[1];
					array6[(int)((IntPtr)num5)].boneIndex2 = (int)ovrAvatarMeshVertexV.blendIndices[2];
					array6[(int)((IntPtr)num5)].boneIndex3 = (int)ovrAvatarMeshVertexV.blendIndices[3];
					array6[(int)((IntPtr)num5)].weight0 = ovrAvatarMeshVertexV.blendWeights[0];
					array6[(int)((IntPtr)num5)].weight1 = ovrAvatarMeshVertexV.blendWeights[1];
					array6[(int)((IntPtr)num5)].weight2 = ovrAvatarMeshVertexV.blendWeights[2];
					array6[(int)((IntPtr)num5)].weight3 = ovrAvatarMeshVertexV.blendWeights[3];
				}
			}
		}
		else
		{
			long num7 = (long)Marshal.SizeOf(typeof(ovrAvatarMeshVertex));
			for (long num8 = 0L; num8 < num; num8 += 1L)
			{
				long num9 = num7 * num8;
				ovrAvatarMeshVertex ovrAvatarMeshVertex = (ovrAvatarMeshVertex)Marshal.PtrToStructure(new IntPtr(num3 + num9), typeof(ovrAvatarMeshVertex));
				array[(int)(checked((IntPtr)num8))] = new Vector3(ovrAvatarMeshVertex.x, ovrAvatarMeshVertex.y, -ovrAvatarMeshVertex.z);
				array2[(int)(checked((IntPtr)num8))] = new Vector3(ovrAvatarMeshVertex.nx, ovrAvatarMeshVertex.ny, -ovrAvatarMeshVertex.nz);
				array3[(int)(checked((IntPtr)num8))] = new Vector4(ovrAvatarMeshVertex.tx, ovrAvatarMeshVertex.ty, -ovrAvatarMeshVertex.tz, ovrAvatarMeshVertex.tw);
				checked
				{
					array4[(int)((IntPtr)num8)] = new Vector2(ovrAvatarMeshVertex.u, ovrAvatarMeshVertex.v);
					array5[(int)((IntPtr)num8)] = new Color(0f, 0f, 0f, 1f);
					array6[(int)((IntPtr)num8)].boneIndex0 = (int)ovrAvatarMeshVertex.blendIndices[0];
					array6[(int)((IntPtr)num8)].boneIndex1 = (int)ovrAvatarMeshVertex.blendIndices[1];
					array6[(int)((IntPtr)num8)].boneIndex2 = (int)ovrAvatarMeshVertex.blendIndices[2];
					array6[(int)((IntPtr)num8)].boneIndex3 = (int)ovrAvatarMeshVertex.blendIndices[3];
					array6[(int)((IntPtr)num8)].weight0 = ovrAvatarMeshVertex.blendWeights[0];
					array6[(int)((IntPtr)num8)].weight1 = ovrAvatarMeshVertex.blendWeights[1];
					array6[(int)((IntPtr)num8)].weight2 = ovrAvatarMeshVertex.blendWeights[2];
					array6[(int)((IntPtr)num8)].weight3 = ovrAvatarMeshVertex.blendWeights[3];
				}
			}
		}
		this.mesh.vertices = array;
		this.mesh.normals = array2;
		this.mesh.uv = array4;
		this.mesh.tangents = array3;
		this.mesh.boneWeights = array6;
		this.mesh.colors = array5;
		this.LoadBlendShapes(asset, num);
		this.LoadSubmeshes(asset, zero2, (ulong)num2);
		uint jointCount = this.skinnedBindPose.jointCount;
		this.jointNames = new string[jointCount];
		for (uint num10 = 0U; num10 < jointCount; num10 += 1U)
		{
			this.jointNames[(int)num10] = Marshal.PtrToStringAnsi(this.skinnedBindPose.jointNames[(int)num10]);
		}
	}

	// Token: 0x060005DD RID: 1501 RVA: 0x00025F04 File Offset: 0x00024104
	private void LoadSubmeshes(IntPtr asset, IntPtr indexBufferPtr, ulong indexCount)
	{
		uint num = CAPI.ovrAvatarAsset_GetSubmeshCount(asset);
		short[] array = new short[indexCount];
		Marshal.Copy(indexBufferPtr, array, 0, (int)indexCount);
		this.mesh.subMeshCount = (int)num;
		uint num2 = 0U;
		for (uint num3 = 0U; num3 < num; num3 += 1U)
		{
			uint num4 = CAPI.ovrAvatarAsset_GetSubmeshLastIndex(asset, num3);
			uint num5 = num4 - num2;
			int[] array2 = new int[num5];
			int num6 = 0;
			for (ulong num7 = (ulong)num2; num7 < (ulong)num4; num7 += 3UL)
			{
				array2[num6 + 2] = (int)array[(int)(checked((IntPtr)num7))];
				array2[num6 + 1] = (int)array[(int)(checked((IntPtr)(unchecked(num7 + 1UL))))];
				array2[num6] = (int)array[(int)(checked((IntPtr)(unchecked(num7 + 2UL))))];
				num6 += 3;
			}
			num2 += num5;
			this.mesh.SetIndices(array2, MeshTopology.Triangles, (int)num3);
		}
	}

	// Token: 0x060005DE RID: 1502 RVA: 0x00025FB8 File Offset: 0x000241B8
	private void LoadBlendShapes(IntPtr asset, long vertexCount)
	{
		uint num = CAPI.ovrAvatarAsset_GetMeshBlendShapeCount(asset);
		IntPtr value = CAPI.ovrAvatarAsset_GetMeshBlendShapeVertices(asset);
		if (value != IntPtr.Zero)
		{
			long num2 = 0L;
			long num3 = (long)Marshal.SizeOf(typeof(ovrAvatarBlendVertex));
			long num4 = value.ToInt64();
			for (uint num5 = 0U; num5 < num; num5 += 1U)
			{
				Vector3[] array = new Vector3[vertexCount];
				Vector3[] array2 = new Vector3[vertexCount];
				Vector3[] array3 = new Vector3[vertexCount];
				for (long num6 = 0L; num6 < vertexCount; num6 += 1L)
				{
					ovrAvatarBlendVertex ovrAvatarBlendVertex = (ovrAvatarBlendVertex)Marshal.PtrToStructure(new IntPtr(num4 + num2), typeof(ovrAvatarBlendVertex));
					array[(int)(checked((IntPtr)num6))] = new Vector3(ovrAvatarBlendVertex.x, ovrAvatarBlendVertex.y, -ovrAvatarBlendVertex.z);
					array2[(int)(checked((IntPtr)num6))] = new Vector3(ovrAvatarBlendVertex.nx, ovrAvatarBlendVertex.ny, -ovrAvatarBlendVertex.nz);
					array3[(int)(checked((IntPtr)num6))] = new Vector4(ovrAvatarBlendVertex.tx, ovrAvatarBlendVertex.ty, -ovrAvatarBlendVertex.tz);
					num2 += num3;
				}
				string shapeName = Marshal.PtrToStringAnsi(CAPI.ovrAvatarAsset_GetMeshBlendShapeName(asset, num5));
				this.mesh.AddBlendShapeFrame(shapeName, 100f, array, array2, array3);
			}
		}
	}

	// Token: 0x060005DF RID: 1503 RVA: 0x00026107 File Offset: 0x00024307
	private void SetSkinnedBindPose(IntPtr asset, ovrAvatarAssetType meshType)
	{
		if (meshType == ovrAvatarAssetType.Mesh)
		{
			this.skinnedBindPose = CAPI.ovrAvatarAsset_GetMeshData(asset).skinnedBindPose;
			return;
		}
		if (meshType != ovrAvatarAssetType.CombinedMesh)
		{
			return;
		}
		this.skinnedBindPose = CAPI.ovrAvatarAsset_GetCombinedMeshData(asset).skinnedBindPose;
	}

	// Token: 0x060005E0 RID: 1504 RVA: 0x00026134 File Offset: 0x00024334
	private void GetVertexAndIndexData(IntPtr asset, ovrAvatarAssetType meshType, out long vertexCount, out IntPtr vertexBuffer, out uint indexCount, out IntPtr indexBuffer)
	{
		vertexCount = 0L;
		vertexBuffer = IntPtr.Zero;
		indexCount = 0U;
		indexBuffer = IntPtr.Zero;
		if (meshType == ovrAvatarAssetType.Mesh)
		{
			vertexCount = (long)((ulong)CAPI.ovrAvatarAsset_GetMeshData(asset).vertexCount);
			vertexBuffer = CAPI.ovrAvatarAsset_GetMeshData(asset).vertexBuffer;
			indexCount = CAPI.ovrAvatarAsset_GetMeshData(asset).indexCount;
			indexBuffer = CAPI.ovrAvatarAsset_GetMeshData(asset).indexBuffer;
			return;
		}
		if (meshType != ovrAvatarAssetType.CombinedMesh)
		{
			return;
		}
		vertexCount = (long)((ulong)CAPI.ovrAvatarAsset_GetCombinedMeshData(asset).vertexCount);
		vertexBuffer = CAPI.ovrAvatarAsset_GetCombinedMeshData(asset).vertexBuffer;
		indexCount = CAPI.ovrAvatarAsset_GetCombinedMeshData(asset).indexCount;
		indexBuffer = CAPI.ovrAvatarAsset_GetCombinedMeshData(asset).indexBuffer;
	}

	// Token: 0x060005E1 RID: 1505 RVA: 0x000261D4 File Offset: 0x000243D4
	public SkinnedMeshRenderer CreateSkinnedMeshRendererOnObject(GameObject target)
	{
		SkinnedMeshRenderer skinnedMeshRenderer = target.AddComponent<SkinnedMeshRenderer>();
		skinnedMeshRenderer.sharedMesh = this.mesh;
		this.mesh.name = "AvatarMesh_" + this.assetID;
		uint jointCount = this.skinnedBindPose.jointCount;
		GameObject[] array = new GameObject[jointCount];
		Transform[] array2 = new Transform[jointCount];
		Matrix4x4[] array3 = new Matrix4x4[jointCount];
		for (uint num = 0U; num < jointCount; num += 1U)
		{
			array[(int)num] = new GameObject();
			array2[(int)num] = array[(int)num].transform;
			array[(int)num].name = this.jointNames[(int)num];
			int num2 = this.skinnedBindPose.jointParents[(int)num];
			if (num2 == -1)
			{
				array[(int)num].transform.parent = skinnedMeshRenderer.transform;
				skinnedMeshRenderer.rootBone = array[(int)num].transform;
			}
			else
			{
				array[(int)num].transform.parent = array[num2].transform;
			}
			Vector3 position = this.skinnedBindPose.jointTransform[(int)num].position;
			position.z = -position.z;
			array[(int)num].transform.localPosition = position;
			Quaternion orientation = this.skinnedBindPose.jointTransform[(int)num].orientation;
			orientation.x = -orientation.x;
			orientation.y = -orientation.y;
			array[(int)num].transform.localRotation = orientation;
			array[(int)num].transform.localScale = this.skinnedBindPose.jointTransform[(int)num].scale;
			array3[(int)num] = array[(int)num].transform.worldToLocalMatrix * skinnedMeshRenderer.transform.localToWorldMatrix;
		}
		skinnedMeshRenderer.bones = array2;
		this.mesh.bindposes = array3;
		return skinnedMeshRenderer;
	}

	// Token: 0x04000711 RID: 1809
	public Mesh mesh;

	// Token: 0x04000712 RID: 1810
	private ovrAvatarSkinnedMeshPose skinnedBindPose;

	// Token: 0x04000713 RID: 1811
	public string[] jointNames;
}
