﻿using System;

// Token: 0x020000D5 RID: 213
public enum ovrAvatarMaterialLayerSampleMode
{
	// Token: 0x040007F8 RID: 2040
	Color,
	// Token: 0x040007F9 RID: 2041
	Texture,
	// Token: 0x040007FA RID: 2042
	TextureSingleChannel,
	// Token: 0x040007FB RID: 2043
	Parallax,
	// Token: 0x040007FC RID: 2044
	Count
}
