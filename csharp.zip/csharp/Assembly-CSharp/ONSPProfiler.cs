﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

// Token: 0x02000141 RID: 321
public class ONSPProfiler : MonoBehaviour
{
	// Token: 0x06000867 RID: 2151 RVA: 0x000347EA File Offset: 0x000329EA
	private void Start()
	{
		Application.runInBackground = true;
	}

	// Token: 0x06000868 RID: 2152 RVA: 0x000347F2 File Offset: 0x000329F2
	private void Update()
	{
		if (this.port < 0 || this.port > 65535)
		{
			this.port = 2121;
		}
		ONSPProfiler.ONSP_SetProfilerPort(this.port);
		ONSPProfiler.ONSP_SetProfilerEnabled(this.profilerEnabled);
	}

	// Token: 0x06000869 RID: 2153
	[DllImport("AudioPluginOculusSpatializer")]
	private static extern int ONSP_SetProfilerEnabled(bool enabled);

	// Token: 0x0600086A RID: 2154
	[DllImport("AudioPluginOculusSpatializer")]
	private static extern int ONSP_SetProfilerPort(int port);

	// Token: 0x04000A63 RID: 2659
	public bool profilerEnabled;

	// Token: 0x04000A64 RID: 2660
	private const int DEFAULT_PORT = 2121;

	// Token: 0x04000A65 RID: 2661
	public int port = 2121;

	// Token: 0x04000A66 RID: 2662
	public const string strONSPS = "AudioPluginOculusSpatializer";
}
