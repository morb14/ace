﻿using System;

// Token: 0x020000D4 RID: 212
public enum ovrAvatarMaterialLayerBlendMode
{
	// Token: 0x040007F4 RID: 2036
	Add,
	// Token: 0x040007F5 RID: 2037
	Multiply,
	// Token: 0x040007F6 RID: 2038
	Count
}
