﻿using System;
using UnityEngine;

// Token: 0x02000137 RID: 311
public static class VectorUtil
{
	// Token: 0x0600080F RID: 2063 RVA: 0x00032660 File Offset: 0x00030860
	public static Vector4 ToVector(this Rect rect)
	{
		return new Vector4(rect.x, rect.y, rect.width, rect.height);
	}
}
