﻿using System;
using UnityEngine;

// Token: 0x02000104 RID: 260
public class LipSyncDemo_SetCurrentTarget : MonoBehaviour
{
	// Token: 0x06000681 RID: 1665 RVA: 0x0002AC09 File Offset: 0x00028E09
	private void Start()
	{
		OVRTouchpad.AddListener(new OVRTouchpad.OVRTouchpadCallback<OVRTouchpad.TouchEvent>(this.LocalTouchEventCallback));
		this.targetSet = 0;
		this.SwitchTargets[0].SetActive<OVRLipSyncContextMorphTarget>(0);
		this.SwitchTargets[1].SetActive<OVRLipSyncContextMorphTarget>(0);
	}

	// Token: 0x06000682 RID: 1666 RVA: 0x0002AC44 File Offset: 0x00028E44
	private void Update()
	{
		if (Input.GetKeyDown(KeyCode.Alpha1))
		{
			this.targetSet = 0;
			this.SetCurrentTarget();
		}
		else if (Input.GetKeyDown(KeyCode.Alpha2))
		{
			this.targetSet = 1;
			this.SetCurrentTarget();
		}
		else if (Input.GetKeyDown(KeyCode.Alpha3))
		{
			this.targetSet = 2;
			this.SetCurrentTarget();
		}
		else if (Input.GetKeyDown(KeyCode.Alpha4))
		{
			this.targetSet = 3;
			this.SetCurrentTarget();
		}
		else if (Input.GetKeyDown(KeyCode.Alpha5))
		{
			this.targetSet = 4;
			this.SetCurrentTarget();
		}
		else if (Input.GetKeyDown(KeyCode.Alpha6))
		{
			this.targetSet = 5;
			this.SetCurrentTarget();
		}
		if (Input.GetKeyDown(KeyCode.Escape))
		{
			Application.Quit();
		}
	}

	// Token: 0x06000683 RID: 1667 RVA: 0x0002ACF0 File Offset: 0x00028EF0
	private void SetCurrentTarget()
	{
		switch (this.targetSet)
		{
		case 0:
			this.SwitchTargets[0].SetActive<OVRLipSyncContextMorphTarget>(0);
			this.SwitchTargets[1].SetActive<OVRLipSyncContextMorphTarget>(0);
			break;
		case 1:
			this.SwitchTargets[0].SetActive<OVRLipSyncContextTextureFlip>(0);
			this.SwitchTargets[1].SetActive<OVRLipSyncContextTextureFlip>(1);
			break;
		case 2:
			this.SwitchTargets[0].SetActive<OVRLipSyncContextMorphTarget>(1);
			this.SwitchTargets[1].SetActive<OVRLipSyncContextMorphTarget>(2);
			break;
		case 3:
			this.SwitchTargets[0].SetActive<OVRLipSyncContextTextureFlip>(1);
			this.SwitchTargets[1].SetActive<OVRLipSyncContextTextureFlip>(3);
			break;
		case 4:
			this.SwitchTargets[0].SetActive<OVRLipSyncContextMorphTarget>(2);
			this.SwitchTargets[1].SetActive<OVRLipSyncContextMorphTarget>(4);
			break;
		case 5:
			this.SwitchTargets[0].SetActive<OVRLipSyncContextTextureFlip>(2);
			this.SwitchTargets[1].SetActive<OVRLipSyncContextTextureFlip>(5);
			break;
		}
		OVRLipSyncDebugConsole.Clear();
	}

	// Token: 0x06000684 RID: 1668 RVA: 0x0002ADF0 File Offset: 0x00028FF0
	private void LocalTouchEventCallback(OVRTouchpad.TouchEvent touchEvent)
	{
		if (touchEvent == OVRTouchpad.TouchEvent.Left)
		{
			this.targetSet--;
			if (this.targetSet < 0)
			{
				this.targetSet = this.maxTarget - 1;
			}
			this.SetCurrentTarget();
			return;
		}
		if (touchEvent != OVRTouchpad.TouchEvent.Right)
		{
			return;
		}
		this.targetSet++;
		if (this.targetSet >= this.maxTarget)
		{
			this.targetSet = 0;
		}
		this.SetCurrentTarget();
	}

	// Token: 0x040008DB RID: 2267
	public EnableSwitch[] SwitchTargets;

	// Token: 0x040008DC RID: 2268
	private int targetSet;

	// Token: 0x040008DD RID: 2269
	private int maxTarget = 6;
}
