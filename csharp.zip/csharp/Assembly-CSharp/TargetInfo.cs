﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200005B RID: 91
public class TargetInfo : MonoBehaviour
{
	// Token: 0x06000374 RID: 884 RVA: 0x00017114 File Offset: 0x00015314
	private void Awake()
	{
		this.sceneSettings = Object.FindObjectOfType<SceneSettings>();
		this.settingsManager = Object.FindObjectOfType<SettingsManager>();
		if (this.changeableMaterialList != null && this.changeableMaterials != null && this.changeableMaterials.Length == 0)
		{
			this.useList = true;
		}
		if (this.sceneSettings != null && this.sceneSettings.sceneType == SceneSettings.SceneType.StagePlanner)
		{
			base.gameObject.AddComponent<MaterialAssigner>();
			base.gameObject.GetComponent<MaterialAssigner>().enabled = true;
		}
	}

	// Token: 0x06000375 RID: 885 RVA: 0x00017190 File Offset: 0x00015390
	private void Start()
	{
		if (this.settingsManager == null)
		{
			return;
		}
		if (this.settingsManager.MaterialToggled())
		{
			this.CheckTargetType();
			this.GetMeshRenderers();
			this.ToggleMaterial();
		}
	}

	// Token: 0x06000376 RID: 886 RVA: 0x000171C0 File Offset: 0x000153C0
	public bool ContainsID(int IDcheck)
	{
		int[] array = this.linkID;
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i] == IDcheck)
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000377 RID: 887 RVA: 0x000171EC File Offset: 0x000153EC
	private void CheckTargetType()
	{
		if (base.GetComponentInChildren<PaperTarget>())
		{
			this.targetType = SettingsManager.TargetType.PaperTarget;
			if (base.GetComponentInChildren<PaperTarget>().noShoot)
			{
				this.isNoShoot = true;
				return;
			}
		}
		else if (base.GetComponentInChildren<SteelTarget>())
		{
			this.targetType = SettingsManager.TargetType.SteelTarget;
			if (base.GetComponentInChildren<SteelTarget>().noShoot)
			{
				this.isNoShoot = true;
			}
		}
	}

	// Token: 0x06000378 RID: 888 RVA: 0x0001724C File Offset: 0x0001544C
	private void GetMeshRenderers()
	{
		if (this.sceneSettings.sceneType != SceneSettings.SceneType.Comp || !this.useList)
		{
			return;
		}
		if (this.targetType == SettingsManager.TargetType.PaperTarget)
		{
			foreach (Renderer renderer in base.GetComponentsInChildren<Renderer>())
			{
				if (this.isNoShoot)
				{
					if (renderer.material.name.Contains(this.settingsManager.paperNoShootDefault.name))
					{
						this.changeableMaterialList.Add(renderer);
					}
				}
				else if (renderer.material.name.Contains(this.settingsManager.paperDefault.name))
				{
					this.changeableMaterialList.Add(renderer);
				}
			}
		}
		if (this.targetType == SettingsManager.TargetType.SteelTarget)
		{
			foreach (Renderer renderer2 in base.GetComponentsInChildren<Renderer>())
			{
				if (this.isNoShoot)
				{
					if (renderer2.material.name.Contains(this.settingsManager.steelNoShootDefault.name))
					{
						this.changeableMaterialList.Add(renderer2);
					}
				}
				else if (renderer2.material.name.Contains(this.settingsManager.steelDefault.name))
				{
					this.changeableMaterialList.Add(renderer2);
				}
			}
		}
		MonoBehaviour.print("Renderer count " + this.changeableMaterialList.Count);
	}

	// Token: 0x06000379 RID: 889 RVA: 0x000173A0 File Offset: 0x000155A0
	private void ToggleMaterial()
	{
		Material material = null;
		if (this.sceneSettings.sceneType == SceneSettings.SceneType.Comp)
		{
			if (this.targetType == SettingsManager.TargetType.PaperTarget)
			{
				if (!this.isNoShoot)
				{
					if (this.settingsManager.paperColour == SettingsManager.PaperColours.BrownScoreWhitePenalty)
					{
						material = this.settingsManager.paperBrown;
					}
					else if (this.settingsManager.paperColour == SettingsManager.PaperColours.WhiteScoreBrownPenalty || this.settingsManager.paperColour == SettingsManager.PaperColours.WhiteScoreRedPenalty)
					{
						material = this.settingsManager.paperWhite;
					}
				}
				else if (this.settingsManager.paperColour == SettingsManager.PaperColours.BrownScoreWhitePenalty)
				{
					material = this.settingsManager.paperWhite;
				}
				else if (this.settingsManager.paperColour == SettingsManager.PaperColours.WhiteScoreBrownPenalty)
				{
					material = this.settingsManager.paperBrown;
				}
				else if (this.settingsManager.paperColour == SettingsManager.PaperColours.WhiteScoreRedPenalty)
				{
					material = this.settingsManager.paperRed;
				}
			}
			if (this.targetType == SettingsManager.TargetType.SteelTarget)
			{
				if (!this.isNoShoot)
				{
					if (this.settingsManager.steelColour == SettingsManager.SteelColours.WhiteScoreRedPenalty)
					{
						material = this.settingsManager.steelWhite;
					}
					else if (this.settingsManager.steelColour == SettingsManager.SteelColours.BlueScoreWhitePenalty || this.settingsManager.steelColour == SettingsManager.SteelColours.BlueScoreRedPenalty)
					{
						material = this.settingsManager.steelBlue;
					}
				}
				else if (this.settingsManager.steelColour == SettingsManager.SteelColours.WhiteScoreRedPenalty)
				{
					material = this.settingsManager.steelRed;
				}
				else if (this.settingsManager.steelColour == SettingsManager.SteelColours.BlueScoreWhitePenalty)
				{
					material = this.settingsManager.steelWhite;
				}
				else if (this.settingsManager.steelColour == SettingsManager.SteelColours.BlueScoreRedPenalty)
				{
					material = this.settingsManager.steelRed;
				}
			}
			if (!this.useList)
			{
				Renderer[] array = this.changeableMaterials;
				for (int i = 0; i < array.Length; i++)
				{
					((MeshRenderer)array[i]).material = material;
				}
				return;
			}
			foreach (Renderer renderer in this.changeableMaterialList)
			{
				((MeshRenderer)renderer).material = material;
				MonoBehaviour.print("MATERIAL CHANGED");
			}
		}
	}

	// Token: 0x0400043E RID: 1086
	[SerializeField]
	public string targetID;

	// Token: 0x0400043F RID: 1087
	[SerializeField]
	public int instanceID;

	// Token: 0x04000440 RID: 1088
	[SerializeField]
	public int[] linkID;

	// Token: 0x04000441 RID: 1089
	[SerializeField]
	private Renderer[] changeableMaterials;

	// Token: 0x04000442 RID: 1090
	public bool dontSave;

	// Token: 0x04000443 RID: 1091
	[SerializeField]
	private SettingsManager.TargetType targetType;

	// Token: 0x04000444 RID: 1092
	private List<Renderer> changeableMaterialList = new List<Renderer>();

	// Token: 0x04000445 RID: 1093
	private SceneSettings sceneSettings;

	// Token: 0x04000446 RID: 1094
	private SettingsManager settingsManager;

	// Token: 0x04000447 RID: 1095
	private bool useList;

	// Token: 0x04000448 RID: 1096
	private bool isNoShoot;
}
