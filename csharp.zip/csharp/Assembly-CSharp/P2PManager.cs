﻿using System;
using Oculus.Avatar;
using Oculus.Platform;
using Oculus.Platform.Models;
using UnityEngine;

// Token: 0x020000A2 RID: 162
public class P2PManager
{
	// Token: 0x06000558 RID: 1368 RVA: 0x000222DA File Offset: 0x000204DA
	public P2PManager()
	{
		Net.SetPeerConnectRequestCallback(new Message<NetworkingPeer>.Callback(this.PeerConnectRequestCallback));
		Net.SetConnectionStateChangedCallback(new Message<NetworkingPeer>.Callback(this.ConnectionStateChangedCallback));
	}

	// Token: 0x06000559 RID: 1369 RVA: 0x00022304 File Offset: 0x00020504
	public void ConnectTo(ulong userID)
	{
		if (SocialPlatformManager.MyID < userID)
		{
			Net.Connect(userID);
			SocialPlatformManager.LogOutput("P2P connect to " + userID);
		}
	}

	// Token: 0x0600055A RID: 1370 RVA: 0x0002232C File Offset: 0x0002052C
	public void Disconnect(ulong userID)
	{
		if (userID != 0UL)
		{
			Net.Close(userID);
			RemotePlayer remoteUser = SocialPlatformManager.GetRemoteUser(userID);
			if (remoteUser != null)
			{
				remoteUser.p2pConnectionState = PeerConnectionState.Unknown;
			}
		}
	}

	// Token: 0x0600055B RID: 1371 RVA: 0x00022354 File Offset: 0x00020554
	private void PeerConnectRequestCallback(Message<NetworkingPeer> msg)
	{
		SocialPlatformManager.LogOutput("P2P request from " + msg.Data.ID);
		if (SocialPlatformManager.GetRemoteUser(msg.Data.ID) != null)
		{
			SocialPlatformManager.LogOutput("P2P request accepted from " + msg.Data.ID);
			Net.Accept(msg.Data.ID);
		}
	}

	// Token: 0x0600055C RID: 1372 RVA: 0x000223C4 File Offset: 0x000205C4
	private void ConnectionStateChangedCallback(Message<NetworkingPeer> msg)
	{
		SocialPlatformManager.LogOutput(string.Concat(new object[]
		{
			"P2P state to ",
			msg.Data.ID,
			" changed to  ",
			msg.Data.State
		}));
		RemotePlayer remoteUser = SocialPlatformManager.GetRemoteUser(msg.Data.ID);
		if (remoteUser != null)
		{
			remoteUser.p2pConnectionState = msg.Data.State;
			if (msg.Data.State == PeerConnectionState.Timeout && SocialPlatformManager.MyID < msg.Data.ID)
			{
				Net.Connect(msg.Data.ID);
				SocialPlatformManager.LogOutput("P2P re-connect to " + msg.Data.ID);
			}
		}
	}

	// Token: 0x0600055D RID: 1373 RVA: 0x0002248C File Offset: 0x0002068C
	public void SendAvatarUpdate(ulong userID, Transform rootTransform, uint sequence, byte[] avatarPacket)
	{
		byte[] array = new byte[avatarPacket.Length + 41];
		int dstOffset = 0;
		this.PackByte(1, array, ref dstOffset);
		this.PackULong(SocialPlatformManager.MyID, array, ref dstOffset);
		this.PackFloat(rootTransform.position.x, array, ref dstOffset);
		this.PackFloat(0f, array, ref dstOffset);
		this.PackFloat(rootTransform.position.z, array, ref dstOffset);
		this.PackFloat(rootTransform.rotation.x, array, ref dstOffset);
		this.PackFloat(rootTransform.rotation.y, array, ref dstOffset);
		this.PackFloat(rootTransform.rotation.z, array, ref dstOffset);
		this.PackFloat(rootTransform.rotation.w, array, ref dstOffset);
		this.PackUInt32(sequence, array, ref dstOffset);
		Buffer.BlockCopy(avatarPacket, 0, array, dstOffset, avatarPacket.Length);
		Net.SendPacket(userID, array, SendPolicy.Unreliable);
	}

	// Token: 0x0600055E RID: 1374 RVA: 0x00022568 File Offset: 0x00020768
	public void GetRemotePackets()
	{
		Packet packet;
		while ((packet = Net.ReadPacket()) != null)
		{
			byte[] array = new byte[packet.Size];
			packet.ReadBytes(array);
			int num = 0;
			P2PManager.MessageType messageType = (P2PManager.MessageType)this.ReadByte(array, ref num);
			ulong num2 = this.ReadULong(array, ref num);
			RemotePlayer remoteUser = SocialPlatformManager.GetRemoteUser(num2);
			if (remoteUser == null)
			{
				SocialPlatformManager.LogOutput("Unknown remote player: " + num2);
			}
			else if (messageType == P2PManager.MessageType.Update)
			{
				this.processAvatarPacket(remoteUser, ref array, ref num);
			}
			else
			{
				SocialPlatformManager.LogOutput("Invalid packet type: " + packet.Size);
			}
		}
	}

	// Token: 0x0600055F RID: 1375 RVA: 0x00022600 File Offset: 0x00020800
	public void processAvatarPacket(RemotePlayer remote, ref byte[] packet, ref int offset)
	{
		if (remote == null)
		{
			return;
		}
		remote.receivedRootPositionPrior = remote.receivedRootPosition;
		remote.receivedRootPosition.x = this.ReadFloat(packet, ref offset);
		remote.receivedRootPosition.y = this.ReadFloat(packet, ref offset);
		remote.receivedRootPosition.z = this.ReadFloat(packet, ref offset);
		remote.receivedRootRotationPrior = remote.receivedRootRotation;
		remote.receivedRootRotation.x = this.ReadFloat(packet, ref offset);
		remote.receivedRootRotation.y = this.ReadFloat(packet, ref offset);
		remote.receivedRootRotation.z = this.ReadFloat(packet, ref offset);
		remote.receivedRootRotation.w = this.ReadFloat(packet, ref offset);
		remote.RemoteAvatar.transform.position = remote.receivedRootPosition;
		remote.RemoteAvatar.transform.rotation = remote.receivedRootRotation;
		int sequence = (int)this.ReadUInt32(packet, ref offset);
		byte[] array = new byte[packet.Length - offset];
		Buffer.BlockCopy(packet, offset, array, 0, array.Length);
		IntPtr ovrNativePacket = Oculus.Avatar.CAPI.ovrAvatarPacket_Read((uint)array.Length, array);
		OvrAvatarPacket packet2 = new OvrAvatarPacket
		{
			ovrNativePacket = ovrNativePacket
		};
		remote.RemoteAvatar.GetComponent<OvrAvatarRemoteDriver>().QueuePacket(sequence, packet2);
	}

	// Token: 0x06000560 RID: 1376 RVA: 0x0002272F File Offset: 0x0002092F
	private void PackByte(byte b, byte[] buf, ref int offset)
	{
		buf[offset] = b;
		offset++;
	}

	// Token: 0x06000561 RID: 1377 RVA: 0x0002273C File Offset: 0x0002093C
	private byte ReadByte(byte[] buf, ref int offset)
	{
		byte result = buf[offset];
		offset++;
		return result;
	}

	// Token: 0x06000562 RID: 1378 RVA: 0x00022748 File Offset: 0x00020948
	private void PackFloat(float f, byte[] buf, ref int offset)
	{
		Buffer.BlockCopy(BitConverter.GetBytes(f), 0, buf, offset, 4);
		offset += 4;
	}

	// Token: 0x06000563 RID: 1379 RVA: 0x00022760 File Offset: 0x00020960
	private float ReadFloat(byte[] buf, ref int offset)
	{
		float result = BitConverter.ToSingle(buf, offset);
		offset += 4;
		return result;
	}

	// Token: 0x06000564 RID: 1380 RVA: 0x00022770 File Offset: 0x00020970
	private void PackULong(ulong u, byte[] buf, ref int offset)
	{
		Buffer.BlockCopy(BitConverter.GetBytes(u), 0, buf, offset, 8);
		offset += 8;
	}

	// Token: 0x06000565 RID: 1381 RVA: 0x00022788 File Offset: 0x00020988
	private ulong ReadULong(byte[] buf, ref int offset)
	{
		ulong result = BitConverter.ToUInt64(buf, offset);
		offset += 8;
		return result;
	}

	// Token: 0x06000566 RID: 1382 RVA: 0x00022798 File Offset: 0x00020998
	private void PackUInt32(uint u, byte[] buf, ref int offset)
	{
		Buffer.BlockCopy(BitConverter.GetBytes(u), 0, buf, offset, 4);
		offset += 4;
	}

	// Token: 0x06000567 RID: 1383 RVA: 0x000227B0 File Offset: 0x000209B0
	private uint ReadUInt32(byte[] buf, ref int offset)
	{
		uint result = BitConverter.ToUInt32(buf, offset);
		offset += 4;
		return result;
	}

	// Token: 0x020001E6 RID: 486
	private enum MessageType : byte
	{
		// Token: 0x04000E2D RID: 3629
		Update = 1
	}
}
