﻿using System;
using Oculus.Platform;
using Oculus.Platform.Models;

// Token: 0x020000A7 RID: 167
public class VoipManager
{
	// Token: 0x06000599 RID: 1433 RVA: 0x00023BEE File Offset: 0x00021DEE
	public VoipManager()
	{
		Voip.SetVoipConnectRequestCallback(new Message<NetworkingPeer>.Callback(this.VoipConnectRequestCallback));
		Voip.SetVoipStateChangeCallback(new Message<NetworkingPeer>.Callback(this.VoipStateChangedCallback));
	}

	// Token: 0x0600059A RID: 1434 RVA: 0x00023C18 File Offset: 0x00021E18
	public void ConnectTo(ulong userID)
	{
		if (SocialPlatformManager.MyID < userID)
		{
			Voip.Start(userID);
			SocialPlatformManager.LogOutput("Voip connect to " + userID);
		}
	}

	// Token: 0x0600059B RID: 1435 RVA: 0x00023C40 File Offset: 0x00021E40
	public void Disconnect(ulong userID)
	{
		if (userID != 0UL)
		{
			Voip.Stop(userID);
			RemotePlayer remoteUser = SocialPlatformManager.GetRemoteUser(userID);
			if (remoteUser != null)
			{
				remoteUser.voipConnectionState = PeerConnectionState.Unknown;
			}
		}
	}

	// Token: 0x0600059C RID: 1436 RVA: 0x00023C68 File Offset: 0x00021E68
	private void VoipConnectRequestCallback(Message<NetworkingPeer> msg)
	{
		SocialPlatformManager.LogOutput("Voip request from " + msg.Data.ID);
		if (SocialPlatformManager.GetRemoteUser(msg.Data.ID) != null)
		{
			SocialPlatformManager.LogOutput("Voip request accepted from " + msg.Data.ID);
			Voip.Accept(msg.Data.ID);
		}
	}

	// Token: 0x0600059D RID: 1437 RVA: 0x00023CD8 File Offset: 0x00021ED8
	private void VoipStateChangedCallback(Message<NetworkingPeer> msg)
	{
		SocialPlatformManager.LogOutput(string.Concat(new object[]
		{
			"Voip state to ",
			msg.Data.ID,
			" changed to  ",
			msg.Data.State
		}));
		RemotePlayer remoteUser = SocialPlatformManager.GetRemoteUser(msg.Data.ID);
		if (remoteUser != null)
		{
			remoteUser.voipConnectionState = msg.Data.State;
			if (msg.Data.State == PeerConnectionState.Timeout && SocialPlatformManager.MyID < msg.Data.ID)
			{
				Voip.Start(msg.Data.ID);
				SocialPlatformManager.LogOutput("Voip re-connect to " + msg.Data.ID);
			}
		}
	}
}
