﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x02000050 RID: 80
public class SceneSettings : MonoBehaviour
{
	// Token: 0x06000288 RID: 648 RVA: 0x0000EB14 File Offset: 0x0000CD14
	private void Start()
	{
		base.Invoke("InitiateComp", 0.1f);
		this.InitiateStagePlanner();
		SceneManager.sceneLoaded += this.OnSceneLoaded;
		GameEvents.current.onHolster += this.OnHolster;
		GameEvents.current.onHolsterDraw += this.OnHolsterDraw;
		GameEvents.current.onShotFired += this.OnShotFired;
		GameEvents.current.onChamberEmpty += this.OnGunEmpty;
		GameEvents.current.onShootingAreaEnter += this.OnShootingAreaEnter;
		GameEvents.current.onShootingAreaExit += this.OnShootingAreaExit;
		GameEvents.current.onBreaking90 += this.OnBreaking90;
		GameEvents.current.onDisqualify += this.OnDisqualify;
		GameEvents.current.onStartingAreaEnter += this.OnStartingAreaEnter;
		GameEvents.current.onStartingAreaExit += this.OnStartingAreaExit;
		GameEvents.current.onMagazineLoad += this.OnMagazineLoad;
		GameEvents.current.onSceneSettingsTransferred += this.OnSceneSettingsTransferred;
		GameEvents.current.onStopPlateHit += this.StopPlateHit;
		GameEvents.current.onSteelHit += this.SteelHit;
	}

	// Token: 0x06000289 RID: 649 RVA: 0x0000EC7C File Offset: 0x0000CE7C
	public SaveManager.ResultList GetCompStageResults()
	{
		return null;
	}

	// Token: 0x0600028A RID: 650 RVA: 0x0000EC7F File Offset: 0x0000CE7F
	private void InitiateStagePlanner()
	{
		if (this.sceneType != SceneSettings.SceneType.StagePlanner)
		{
			return;
		}
		if (Object.FindObjectOfType<GameManager>() && !Object.FindObjectOfType<StagePlanner>())
		{
			Object.Instantiate<GameObject>(Object.FindObjectOfType<GameManager>().stagePlannerObject);
		}
	}

	// Token: 0x0600028B RID: 651 RVA: 0x0000ECB3 File Offset: 0x0000CEB3
	public void StartComp()
	{
		this.InitiateComp();
	}

	// Token: 0x0600028C RID: 652 RVA: 0x0000ECBC File Offset: 0x0000CEBC
	private void InitiateComp()
	{
		this.AssignVariables();
		if (this.sceneType == SceneSettings.SceneType.Comp)
		{
			this.status = SceneSettings.CompStatus.MakeReady;
			this.ShotCountCalculator();
			if (this.weapon != null)
			{
				this.weapon.EmptyGun();
			}
			if (this.startCondition == WeaponController.WeaponStatus.Empty && this.NoneHolsterStart())
			{
				GameEvents.current.BroadcastMessage("Place firearm on starting surface", false);
			}
		}
	}

	// Token: 0x0600028D RID: 653 RVA: 0x0000ED20 File Offset: 0x0000CF20
	private bool NoneHolsterStart()
	{
		if (this.isNonHolsterStart)
		{
			return true;
		}
		if (this.tablePistolLeft != null && this.tablePistolRight != null && this.tableRifleLeft != null && this.tablePistolRight != null)
		{
			this.isNonHolsterStart = true;
			return true;
		}
		return false;
	}

	// Token: 0x0600028E RID: 654 RVA: 0x0000ED7C File Offset: 0x0000CF7C
	private void RepositionHolster()
	{
		if (this.NoneHolsterStart())
		{
			this.holsteredWeapon.transform.parent = null;
			Transform transform = null;
			if (this.controlManager.controllerMode == ControlManager.ControllerMode.OneHand)
			{
				if (this.controlManager.handedness == ControlManager.Handedness.Right)
				{
					transform = this.tablePistolRight;
				}
				else
				{
					transform = this.tablePistolLeft;
				}
			}
			else if (this.controlManager.controllerMode == ControlManager.ControllerMode.TwoHand || this.controlManager.controllerMode == ControlManager.ControllerMode.ControlAR || this.controlManager.controllerMode == ControlManager.ControllerMode.ControlAR2 || this.controlManager.controllerMode == ControlManager.ControllerMode.ControlARPro)
			{
				if (this.controlManager.handedness == ControlManager.Handedness.Right)
				{
					transform = this.tableRifleRight;
				}
				else
				{
					transform = this.tablePistolLeft;
				}
			}
			this.holsteredWeapon.transform.position = transform.position;
			this.holsteredWeapon.transform.rotation = transform.rotation;
			this.holsteredWeapon.transform.parent = transform;
			this.holsteredWeapon.GetComponent<HolsterControl>().drawOverRide = true;
			this.holsteredWeapon.GetComponent<HolsterControl>().Lock();
			GameEvents.current.EnterVehicle();
		}
	}

	// Token: 0x0600028F RID: 655 RVA: 0x0000EE90 File Offset: 0x0000D090
	private void AssignVariables()
	{
		this.headTurn = SceneSettings.HeadTurn.NotTurning;
		GameEvents.current.ShootingAreaCheck();
		this.camera = Camera.main;
		this.soundManager = Object.FindObjectOfType<SoundManager>();
		this.movementDetection = Object.FindObjectOfType<MovementDetection>();
		this.controlManager = Object.FindObjectOfType<ControlManager>();
		this.weapon = this.controlManager.GetWeapon();
		this.gameManager = Object.FindObjectOfType<GameManager>();
		this.holsteredWeapon = this.gameManager.holsteredWeapon;
		if (this.holsteredWeapon != null)
		{
			this.originalHolsterParent = this.holsteredWeapon.transform.parent;
			this.originalHolsterPos = this.holsteredWeapon.transform.localPosition;
			this.originalHolsterRot = this.holsteredWeapon.transform.localRotation;
		}
		if (this.isSteelChallenge)
		{
			this.steelChallengeTimeList = new List<float>(new float[this.steelChallengeStrings]);
		}
	}

	// Token: 0x06000290 RID: 656 RVA: 0x0000EF78 File Offset: 0x0000D178
	private void ShotCountCalculator()
	{
		this.stageRoundCount = 0;
		PaperTarget[] array = Object.FindObjectsOfType<PaperTarget>();
		SteelTarget[] array2 = Object.FindObjectsOfType<SteelTarget>();
		foreach (PaperTarget paperTarget in array)
		{
			if (!paperTarget.dormant && !paperTarget.noShoot)
			{
				this.stageRoundCount += paperTarget.RoundCount();
				MonoBehaviour.print(paperTarget.RoundCount());
			}
		}
		foreach (SteelTarget steelTarget in array2)
		{
			if (!steelTarget.dormant && !steelTarget.noShoot)
			{
				this.stageRoundCount += steelTarget.RoundCount();
				MonoBehaviour.print(steelTarget.RoundCount());
			}
		}
		MonoBehaviour.print("Stage shotcount: " + this.stageRoundCount);
	}

	// Token: 0x06000291 RID: 657 RVA: 0x0000F046 File Offset: 0x0000D246
	public int GetStageShotCount()
	{
		this.ShotCountCalculator();
		return this.stageRoundCount;
	}

	// Token: 0x06000292 RID: 658 RVA: 0x0000F054 File Offset: 0x0000D254
	public int GetShotFired()
	{
		if (this.multiStringOver)
		{
			return this.multiStringShots;
		}
		return this.stageShotsFired;
	}

	// Token: 0x06000293 RID: 659 RVA: 0x0000F06C File Offset: 0x0000D26C
	private void Update()
	{
		if (this.gunCheckTest)
		{
			this.gunCheckTest = false;
			this.GunCheck();
		}
		if (this.sceneType == SceneSettings.SceneType.Comp)
		{
			this.InitiateStartingProcedure();
			if (this.status == SceneSettings.CompStatus.MakeReady)
			{
				this.MakeReady();
			}
			if (this.status == SceneSettings.CompStatus.CountingDown)
			{
				this.CountDownMovementCheck();
			}
			if (this.status == SceneSettings.CompStatus.Hot)
			{
				this.UnloadShowclear();
			}
			if (this.detectHeadShake)
			{
				this.DetectingHeadShake();
			}
		}
	}

	// Token: 0x06000294 RID: 660 RVA: 0x0000F0D8 File Offset: 0x0000D2D8
	private void OnBreaking90()
	{
		if (this.status == SceneSettings.CompStatus.Hot && !this.drawCoolDown)
		{
			this.Disqaulify();
		}
	}

	// Token: 0x06000295 RID: 661 RVA: 0x0000F0F1 File Offset: 0x0000D2F1
	private void Disqaulify()
	{
		if (this.status != SceneSettings.CompStatus.Disqualified)
		{
			this.soundManager.Play(this.soundManager.signalStop);
			this.status = SceneSettings.CompStatus.Disqualified;
			GameEvents.current.Disqualify();
		}
	}

	// Token: 0x06000296 RID: 662 RVA: 0x0000F123 File Offset: 0x0000D323
	private void OnDisqualify()
	{
		if (this.isTutorial && Object.FindObjectOfType<StageTutorialManager>())
		{
			Object.FindObjectOfType<StageTutorialManager>().tutorialReload = true;
		}
		base.Invoke("RestartScene", 3f);
	}

	// Token: 0x06000297 RID: 663 RVA: 0x0000F154 File Offset: 0x0000D354
	private void RestartScene()
	{
		if (Object.FindObjectOfType<StagePlanner>())
		{
			Object.FindObjectOfType<SaveManager>().ResetCustomStage();
			return;
		}
		SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
	}

	// Token: 0x06000298 RID: 664 RVA: 0x0000F18A File Offset: 0x0000D38A
	private void OnStartingAreaEnter()
	{
		this.startingBoundaries++;
		MonoBehaviour.print("STARTING POSITION ENTER");
	}

	// Token: 0x06000299 RID: 665 RVA: 0x0000F1A4 File Offset: 0x0000D3A4
	private void OnStartingAreaExit()
	{
		this.startingBoundaries--;
		this.makeReadyInitiated = false;
		this.signalStartingCondition = false;
	}

	// Token: 0x0600029A RID: 666 RVA: 0x0000F1C2 File Offset: 0x0000D3C2
	private bool WithinStartingPosition()
	{
		return this.startingBoundaries > 0 || this.withinStartingPosition;
	}

	// Token: 0x0600029B RID: 667 RVA: 0x0000F1D8 File Offset: 0x0000D3D8
	private void OnShootingAreaEnter()
	{
		this.returnSignalLock = false;
		this.shootingBoundaries++;
		if (this.isSteelChallenge && this.status == SceneSettings.CompStatus.Hot)
		{
			this.steelChallengeHasMoved = true;
		}
	}

	// Token: 0x0600029C RID: 668 RVA: 0x0000F207 File Offset: 0x0000D407
	private void OnShootingAreaExit()
	{
		this.shootingBoundaries--;
	}

	// Token: 0x0600029D RID: 669 RVA: 0x0000F217 File Offset: 0x0000D417
	public SceneSettings.CompStatus Status()
	{
		return this.status;
	}

	// Token: 0x0600029E RID: 670 RVA: 0x0000F220 File Offset: 0x0000D420
	private void InitiateStartingProcedure()
	{
		if (this.status == SceneSettings.CompStatus.MakeReady)
		{
			if (this.startingPosition == null)
			{
				this.withinStartingPosition = true;
			}
			if (!this.WithinStartingPosition() && !this.signalStartingCondition && !this.returnSignalLock && !Object.FindObjectOfType<StagePlanner>())
			{
				this.gameManager.playerRig.transform.position = this.gameManager.playerRig.transform.position;
				base.Invoke("ReturnToStartingArea", 0.5f);
				this.returnSignalLock = true;
				this.signalStartingCondition = true;
			}
			if (this.WithinStartingPosition() && !this.makeReadyInitiated)
			{
				this.InitiateCompStage();
				this.makeReadyInitiated = true;
			}
		}
	}

	// Token: 0x0600029F RID: 671 RVA: 0x0000F2D8 File Offset: 0x0000D4D8
	private bool FacingCorrectDirection()
	{
		return this.controlManager.controllerMode != ControlManager.ControllerMode.OneHand || !(this.faceDirectionAtStart != null) || Mathf.Abs(this.faceDirectionAtStart.transform.eulerAngles.y - Camera.main.transform.eulerAngles.y) < 10f;
	}

	// Token: 0x060002A0 RID: 672 RVA: 0x0000F33D File Offset: 0x0000D53D
	private void ReturnToStartingArea()
	{
		if (!this.WithinStartingPosition() && !this.soundManager.GetComponent<AudioSource>().isPlaying)
		{
			this.returnSignalLock = true;
			this.soundManager.Play(this.soundManager.signalReturnToStartingArea);
		}
	}

	// Token: 0x060002A1 RID: 673 RVA: 0x0000F376 File Offset: 0x0000D576
	private void InitiateCompStage()
	{
		if (this.currentString == 0)
		{
			base.Invoke("LoadMakeReady", 2f);
		}
	}

	// Token: 0x060002A2 RID: 674 RVA: 0x00003297 File Offset: 0x00001497
	public void MovePlayerToStartPos(GameObject player)
	{
	}

	// Token: 0x060002A3 RID: 675 RVA: 0x0000F390 File Offset: 0x0000D590
	private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
	{
		this.InitiateComp();
		this.InitiateStagePlanner();
		MonoBehaviour.print("initiate comp on sceneload");
		this.signalStartingCondition = false;
		if (scene.buildIndex == 0)
		{
			this.GunCheck();
			base.Invoke("GunCheck", 0.05f);
			Object.FindObjectOfType<SaveManager>().currentOpenedFile = "";
		}
		if (SceneManager.GetActiveScene().buildIndex != 0 && Object.FindObjectOfType<SettingsManager>().doNotRecenter)
		{
			return;
		}
		if (this.startingPosition != null)
		{
			GameObject gameObject = this.gameManager.Player();
			Vector3 position = new Vector3(this.startingPosition.position.x, this.startingPosition.position.y, this.startingPosition.position.z);
			gameObject.GetComponent<CharacterController>().enabled = false;
			gameObject.GetComponent<CharacterController>().transform.position = position;
			GameEvents.current.Teleported();
			gameObject.GetComponent<CharacterController>().enabled = true;
		}
	}

	// Token: 0x060002A4 RID: 676 RVA: 0x0000F486 File Offset: 0x0000D686
	private void OnSceneSettingsTransferred()
	{
		MonoBehaviour.print("SCENE SETTINGS TRANSFERRED");
		if (this.sceneType == SceneSettings.SceneType.StagePlanner && Object.FindObjectOfType<SceneLoader>().loadMode == SceneLoader.LoadMode.FromMenu)
		{
			Object.FindObjectOfType<SaveManager>().Load(this.customStageName + "_Default", true);
		}
	}

	// Token: 0x060002A5 RID: 677 RVA: 0x0000F4C4 File Offset: 0x0000D6C4
	public void GunCheck()
	{
		foreach (WeaponController weaponController in Object.FindObjectsOfType<WeaponController>())
		{
			if (!(this.controlManager.GetWeapon() == null) && weaponController.WeaponID() == this.controlManager.GetWeapon().WeaponID() && weaponController != this.controlManager.GetWeapon())
			{
				if (weaponController.GetComponentInParent<HolsterControl>())
				{
					Object.Destroy(weaponController.GetComponentInParent<HolsterControl>().gameObject);
				}
				else
				{
					Object.Destroy(weaponController.gameObject);
				}
			}
		}
		ShotTimer[] array2 = Object.FindObjectsOfType<ShotTimer>();
		if (array2.Length > 1)
		{
			foreach (ShotTimer shotTimer in array2)
			{
				if (!shotTimer.GetComponentInParent<HolsterVolume>())
				{
					Object.Destroy(shotTimer.gameObject);
				}
			}
		}
	}

	// Token: 0x060002A6 RID: 678 RVA: 0x0000F594 File Offset: 0x0000D794
	private void ConditionMet()
	{
		if (this.WithinStartingPosition() && !this.startConditionMet)
		{
			if (!this.FacingCorrectDirection())
			{
				if (!this.awaitCorrectFacingDirection)
				{
					this.soundManager.Play(this.soundManager.signalFaceStartingDirection);
					this.awaitCorrectFacingDirection = true;
					return;
				}
			}
			else
			{
				this.startConditionMet = true;
				this.awaitCorrectFacingDirection = false;
				GameEvents.current.StageConditionMet();
			}
		}
	}

	// Token: 0x060002A7 RID: 679 RVA: 0x0000F5F7 File Offset: 0x0000D7F7
	private void ConditionUnmet()
	{
		this.startConditionMet = false;
		GameEvents.current.StageConditionUnMet();
	}

	// Token: 0x060002A8 RID: 680 RVA: 0x0000F60C File Offset: 0x0000D80C
	private void LoadMakeReady()
	{
		if (Object.FindObjectOfType<SceneTypeChanger>())
		{
			return;
		}
		if (this.startCondition == WeaponController.WeaponStatus.Empty)
		{
			this.ConditionMet();
			this.soundManager.Play(this.soundManager.signalMakeReady);
			return;
		}
		if (this.WithinStartingPosition() && !this.soundManager.GetComponent<AudioSource>().isPlaying && !this.startConditionMet)
		{
			this.soundManager.Play(this.soundManager.signalLoadMakeReady);
		}
	}

	// Token: 0x060002A9 RID: 681 RVA: 0x0000F684 File Offset: 0x0000D884
	private void MakeReady()
	{
		if (this.status != SceneSettings.CompStatus.MakeReady)
		{
			return;
		}
		if (this.awaitCorrectFacingDirection)
		{
			this.ConditionMet();
		}
		if (this.startCondition == WeaponController.WeaponStatus.Empty)
		{
			this.ConditionMet();
		}
		if (this.startConditionMet && this.startCondition != this.weapon.CheckCondition())
		{
			this.ConditionUnmet();
			MonoBehaviour.print("start condition changed, fix");
		}
		if (this.startConditionMet && this.movementDetection.DetectMovement(3f, MovementDetection.MovementType.Head))
		{
			this.status = SceneSettings.CompStatus.CountingDown;
			MonoBehaviour.print("shooter are you ready, stand by, beep");
			this.movementDetection.DetectMovementReset();
			this.CountDownReady();
		}
	}

	// Token: 0x060002AA RID: 682 RVA: 0x0000F720 File Offset: 0x0000D920
	private void CountDownMovementCheck()
	{
		if (this.movementDetection.DetectMovement(0f, MovementDetection.MovementType.Hand))
		{
			this.soundManager.Play(this.soundManager.signalCreeping);
			MonoBehaviour.print("shooter stop creeping");
			this.status = SceneSettings.CompStatus.Cold;
			GameEvents.current.StageConditionUnMet();
			base.Invoke("ResumeMakeReady", 2f);
		}
	}

	// Token: 0x060002AB RID: 683 RVA: 0x0000F781 File Offset: 0x0000D981
	private void ResumeMakeReady()
	{
		this.status = SceneSettings.CompStatus.MakeReady;
		GameEvents.current.StageConditionMet();
	}

	// Token: 0x060002AC RID: 684 RVA: 0x0000F794 File Offset: 0x0000D994
	private void CountDownReady()
	{
		if (this.status != SceneSettings.CompStatus.CountingDown)
		{
			return;
		}
		this.soundManager.Play(this.soundManager.signalReady);
		base.Invoke("CountDownStandBy", 2f);
	}

	// Token: 0x060002AD RID: 685 RVA: 0x0000F7C6 File Offset: 0x0000D9C6
	private void CountDownStandBy()
	{
		if (this.status != SceneSettings.CompStatus.CountingDown)
		{
			return;
		}
		this.soundManager.Play(this.soundManager.signalStandby);
		base.Invoke("CountDownBeep", Random.Range(1f, 3f));
	}

	// Token: 0x060002AE RID: 686 RVA: 0x0000F804 File Offset: 0x0000DA04
	private void CountDownBeep()
	{
		if (this.status != SceneSettings.CompStatus.CountingDown)
		{
			return;
		}
		this.soundManager.Play(this.soundManager.signalBeep);
		GameEvents.current.StageStart();
		this.ConditionUnmet();
		this.stageStartTime = Time.time;
		this.status = SceneSettings.CompStatus.Hot;
		if (!this.AllStringsCompleted() && this.isFixedTimed)
		{
			base.Invoke("FixedTimeNextString", this.timeAllowedPerString[this.currentString]);
		}
	}

	// Token: 0x060002AF RID: 687 RVA: 0x0000F87B File Offset: 0x0000DA7B
	private void FixedTimeNextString()
	{
		this.soundManager.Play(this.soundManager.signalBeep);
		this.currentString++;
		this.status = SceneSettings.CompStatus.MakeReady;
		base.Invoke("NextString", 0.5f);
	}

	// Token: 0x060002B0 RID: 688 RVA: 0x0000F8B8 File Offset: 0x0000DAB8
	public float StageTime()
	{
		if (this.multiStringOver)
		{
			return Mathf.Round(this.multiStringTime * 100f) / 100f;
		}
		return Mathf.Round((this.stageLastShot - this.stageStartTime) * 100f) / 100f;
	}

	// Token: 0x060002B1 RID: 689 RVA: 0x0000F8F8 File Offset: 0x0000DAF8
	private void OnShotFired()
	{
		if (this.sceneType != SceneSettings.SceneType.Comp)
		{
			return;
		}
		if (this.status == SceneSettings.CompStatus.Clearing)
		{
			this.status = SceneSettings.CompStatus.Hot;
		}
		if (this.status == SceneSettings.CompStatus.Hot)
		{
			this.stageShotsFired++;
			this.stageLastShot = Time.time;
			this.movementDetection.DelayDetection();
			if (this.ProceduralPenaltyCheck())
			{
				this.procedurals++;
			}
			if (this.showClear)
			{
				this.showClear = false;
			}
			return;
		}
		if (this.isFixedTimed && this.currentString != 0)
		{
			this.procedurals++;
			return;
		}
		this.Disqaulify();
	}

	// Token: 0x060002B2 RID: 690 RVA: 0x0000F997 File Offset: 0x0000DB97
	private bool ProceduralPenaltyCheck()
	{
		return this.shootingBoundaries <= 0 || (this.stageShotsFired > this.virginiaCount && this.virginiaCount != 0);
	}

	// Token: 0x060002B3 RID: 691 RVA: 0x0000F9BD File Offset: 0x0000DBBD
	private void OnMagazineLoad()
	{
		if (this.status != SceneSettings.CompStatus.Hot)
		{
			return;
		}
		if (this.mandatoryReloadLeft > 0)
		{
			this.mandatoryReloadLeft--;
		}
	}

	// Token: 0x060002B4 RID: 692 RVA: 0x0000F9E0 File Offset: 0x0000DBE0
	private void StopPlateHit()
	{
		this.stopPlateHitTime = Time.time;
		this.stopPlateHit = true;
	}

	// Token: 0x060002B5 RID: 693 RVA: 0x0000F9F4 File Offset: 0x0000DBF4
	private void SteelHit()
	{
		this.steelHit++;
		if (this.isOuterLimit && this.steelHit > 2 && !this.steelChallengeHasMoved)
		{
			this.procedurals++;
		}
	}

	// Token: 0x060002B6 RID: 694 RVA: 0x0000FA2C File Offset: 0x0000DC2C
	private void UnloadShowclear()
	{
		if (this.isFixedTimed || this.status != SceneSettings.CompStatus.Hot || this.stageShotsFired == 0 || this.showClear)
		{
			return;
		}
		if (this.stringVirginiaShots.Length != 0 && !this.progressingString)
		{
			if (this.stageShotsFired >= this.stringVirginiaShots[this.currentString] && this.currentString < this.stringVirginiaShots.Length)
			{
				this.multiStringShots += this.stageShotsFired;
				this.stageShotsFired = 0;
				this.progressingString = true;
				MonoBehaviour.print(string.Concat(new object[]
				{
					"multi string ",
					this.currentString,
					" ",
					this.stageLastShot - this.stageStartTime
				}));
				this.CombineStringScores();
				this.currentString++;
				base.Invoke("NextString", 0.5f);
				return;
			}
		}
		else if (this.isSteelChallenge)
		{
			if (this.stopPlateHit)
			{
				base.Invoke("UnloadShowClearSequence", 0.5f);
				this.stopPlateHit = false;
				return;
			}
		}
		else if (this.stageShotsFired >= this.stageRoundCount)
		{
			if (this.movementDetection.DetectMovement(3f, MovementDetection.MovementType.Hand) && this.movementDetection.CompareHeight(0.15f))
			{
				this.showClear = true;
				this.UnloadShowClearSequence();
				MonoBehaviour.print("Round count matched, 3 seconds");
				return;
			}
		}
		else if (this.movementDetection.DetectMovement(6f, MovementDetection.MovementType.Hand) && this.movementDetection.CompareHeight(0.15f))
		{
			this.showClear = true;
			this.UnloadShowClearSequence();
			MonoBehaviour.print("Round count not matched, 6 seconds");
		}
	}

	// Token: 0x060002B7 RID: 695 RVA: 0x0000FBD8 File Offset: 0x0000DDD8
	private void NextString()
	{
		if (this.AllStringsCompleted())
		{
			this.showClear = true;
			this.multiStringOver = true;
			this.UnloadShowClearSequence();
			return;
		}
		this.status = SceneSettings.CompStatus.MakeReady;
		this.soundManager.Play(this.soundManager.signalNextString);
	}

	// Token: 0x060002B8 RID: 696 RVA: 0x0000FC14 File Offset: 0x0000DE14
	private bool AllStringsCompleted()
	{
		return (this.stringVirginiaShots.Length != 0 && this.currentString >= this.stringVirginiaShots.Length) || (this.isFixedTimed && this.currentString >= this.timeAllowedPerString.Length);
	}

	// Token: 0x060002B9 RID: 697 RVA: 0x0000FC4C File Offset: 0x0000DE4C
	private void CombineStringScores()
	{
		if (this.stageShotsFired > this.stringVirginiaShots[this.currentString])
		{
			this.procedurals += this.stringVirginiaShots[this.currentString] - this.stageShotsFired;
		}
		this.multiStringTime += this.stageLastShot - this.stageStartTime;
	}

	// Token: 0x060002BA RID: 698 RVA: 0x0000FCA9 File Offset: 0x0000DEA9
	private void UnloadShowClearSequence()
	{
		GameEvents.current.StageFinish();
		this.soundManager.Play(this.soundManager.signalIfFinished);
		base.Invoke("UnloadShowClearSequenceUnload", this.soundManager.signalIfFinished.length);
	}

	// Token: 0x060002BB RID: 699 RVA: 0x0000FCE6 File Offset: 0x0000DEE6
	private void UnloadShowClearSequenceUnload()
	{
		this.soundManager.PlaySingle(this.soundManager.signalUnloadShowClear);
		this.status = SceneSettings.CompStatus.Clearing;
	}

	// Token: 0x060002BC RID: 700 RVA: 0x0000FD05 File Offset: 0x0000DF05
	private void UnloadShowClearSequenceHammerDown()
	{
		this.ReturnHolster();
		this.soundManager.PlaySingle(this.soundManager.signalHammerDownHolster);
	}

	// Token: 0x060002BD RID: 701 RVA: 0x0000FD23 File Offset: 0x0000DF23
	private void OnGunEmpty()
	{
		if (this.sceneType == SceneSettings.SceneType.Comp && this.status == SceneSettings.CompStatus.Clearing)
		{
			base.Invoke("UnloadShowClearSequenceHammerDown", 1f);
		}
		if (this.status == SceneSettings.CompStatus.Clearing)
		{
			this.status = SceneSettings.CompStatus.Cold;
		}
	}

	// Token: 0x060002BE RID: 702 RVA: 0x0000FD58 File Offset: 0x0000DF58
	private void ReturnHolster()
	{
		if (this.NoneHolsterStart())
		{
			MonoBehaviour.print("RETURNING HOLSTER TO PERSON");
			this.holsteredWeapon.GetComponent<HolsterControl>().drawOverRide = false;
			this.holsteredWeapon.transform.parent = this.originalHolsterParent;
			this.holsteredWeapon.transform.localPosition = this.originalHolsterPos;
			this.holsteredWeapon.transform.localRotation = this.originalHolsterRot;
			this.holsteredWeapon.GetComponent<HolsterControl>().Lock();
		}
	}

	// Token: 0x060002BF RID: 703 RVA: 0x0000FDDC File Offset: 0x0000DFDC
	private void OnHolster()
	{
		if (this.weapon == null)
		{
			this.weapon = this.controlManager.GetWeapon();
			this.weapon == null;
		}
		if (this.sceneType == SceneSettings.SceneType.Comp && this.status == SceneSettings.CompStatus.MakeReady)
		{
			if (this.weapon == null)
			{
				this.weapon = Object.FindObjectOfType<WeaponController>();
			}
			if (this.weapon.IsSafe() && this.startCondition == this.weapon.CheckCondition())
			{
				this.ConditionMet();
				MonoBehaviour.print("reholster, start condition met, waiting for stillness");
			}
		}
		if (this.sceneType == SceneSettings.SceneType.Comp && (this.status == SceneSettings.CompStatus.Hot || this.status == SceneSettings.CompStatus.Clearing))
		{
			if (this.weapon.status == WeaponController.WeaponStatus.Empty && !this.weapon.IsCocked())
			{
				this.status = SceneSettings.CompStatus.Cold;
				base.Invoke("ShowResults", 0.1f);
				this.ReturnHolster();
			}
			else
			{
				this.DetectHeadShake();
			}
		}
		if (this.currentString > 0)
		{
			this.progressingString = false;
		}
	}

	// Token: 0x060002C0 RID: 704 RVA: 0x00003297 File Offset: 0x00001497
	private void StringDelayedCountDown()
	{
	}

	// Token: 0x060002C1 RID: 705 RVA: 0x0000FEDA File Offset: 0x0000E0DA
	private void DetectHeadShake()
	{
		this.detectHeadShake = true;
	}

	// Token: 0x060002C2 RID: 706 RVA: 0x0000FEE4 File Offset: 0x0000E0E4
	private void DetectingHeadShake()
	{
		float y = Camera.main.transform.rotation.y;
		if (this.previousRotation == 0f)
		{
			this.previousRotation = y;
		}
		if (this.previousRotation > y + 0.01f)
		{
			if (this.headTurn == SceneSettings.HeadTurn.NotTurning || this.headTurn == SceneSettings.HeadTurn.TurningRight)
			{
				this.headTurn = SceneSettings.HeadTurn.TurningLeft;
				this.headTurnCount++;
			}
		}
		else if (this.previousRotation + 0.01f < y && (this.headTurn == SceneSettings.HeadTurn.NotTurning || this.headTurn == SceneSettings.HeadTurn.TurningLeft))
		{
			this.headTurn = SceneSettings.HeadTurn.TurningRight;
			this.headTurnCount++;
		}
		if (this.headTurnCount >= 4)
		{
			this.headTurnCount = 0;
			this.RestartScene();
		}
		this.previousRotation = y;
	}

	// Token: 0x060002C3 RID: 707 RVA: 0x0000FFA4 File Offset: 0x0000E1A4
	private void ShowResults()
	{
		Results[] array = Object.FindObjectsOfType<Results>();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].ShowResults();
		}
	}

	// Token: 0x060002C4 RID: 708 RVA: 0x0000FFCD File Offset: 0x0000E1CD
	public int TotalProcedurals()
	{
		this.procedurals += this.mandatoryReloadLeft;
		return this.procedurals;
	}

	// Token: 0x060002C5 RID: 709 RVA: 0x0000FFE8 File Offset: 0x0000E1E8
	private void OnHolsterDraw()
	{
		if (this.status == SceneSettings.CompStatus.CountingDown && this.controlManager.controllerMode == ControlManager.ControllerMode.OneHand)
		{
			MonoBehaviour.print("Early draw, reset");
			this.ConditionUnmet();
			this.status = SceneSettings.CompStatus.MakeReady;
		}
		if (this.status == SceneSettings.CompStatus.Hot)
		{
			this.drawCoolDown = true;
			base.Invoke("DrawCoolDownOver", 0.2f);
		}
		if (this.status == SceneSettings.CompStatus.MakeReady && this.NoneHolsterStart())
		{
			this.RepositionHolster();
		}
	}

	// Token: 0x060002C6 RID: 710 RVA: 0x00010059 File Offset: 0x0000E259
	private void DrawCoolDownOver()
	{
		this.drawCoolDown = false;
	}

	// Token: 0x060002C7 RID: 711 RVA: 0x00010064 File Offset: 0x0000E264
	private void OnDestroy()
	{
		SceneManager.sceneLoaded -= this.OnSceneLoaded;
		GameEvents.current.onHolster -= this.OnHolster;
		GameEvents.current.onHolsterDraw -= this.OnHolsterDraw;
		GameEvents.current.onShotFired -= this.OnShotFired;
		GameEvents.current.onChamberEmpty -= this.OnGunEmpty;
		GameEvents.current.onShootingAreaEnter -= this.OnShootingAreaEnter;
		GameEvents.current.onShootingAreaExit -= this.OnShootingAreaExit;
		GameEvents.current.onBreaking90 -= this.OnBreaking90;
		GameEvents.current.onDisqualify -= this.OnDisqualify;
		GameEvents.current.onStartingAreaEnter -= this.OnStartingAreaEnter;
		GameEvents.current.onStartingAreaExit -= this.OnStartingAreaExit;
		GameEvents.current.onMagazineLoad -= this.OnMagazineLoad;
		GameEvents.current.onSceneSettingsTransferred -= this.OnSceneSettingsTransferred;
		GameEvents.current.onStopPlateHit -= this.StopPlateHit;
		GameEvents.current.onSteelHit -= this.SteelHit;
	}

	// Token: 0x04000290 RID: 656
	[Header("Scene Info")]
	[SerializeField]
	public SceneSettings.SceneType sceneType;

	// Token: 0x04000291 RID: 657
	[SerializeField]
	public string sceneID;

	// Token: 0x04000292 RID: 658
	[Header("Custom Stage")]
	[SerializeField]
	public string customStageName;

	// Token: 0x04000293 RID: 659
	[SerializeField]
	public string currentCustomStage;

	// Token: 0x04000294 RID: 660
	[Header("Holster Detached")]
	[SerializeField]
	public Transform tablePistolRight;

	// Token: 0x04000295 RID: 661
	[SerializeField]
	public Transform tablePistolLeft;

	// Token: 0x04000296 RID: 662
	[SerializeField]
	public Transform tableRifleRight;

	// Token: 0x04000297 RID: 663
	[SerializeField]
	public Transform tableRifleLeft;

	// Token: 0x04000298 RID: 664
	[Header("Comp Settings")]
	[SerializeField]
	public WeaponController.WeaponStatus startCondition;

	// Token: 0x04000299 RID: 665
	[SerializeField]
	public Transform startingPosition;

	// Token: 0x0400029A RID: 666
	[SerializeField]
	public Transform downRange;

	// Token: 0x0400029B RID: 667
	[SerializeField]
	public Transform faceDirectionAtStart;

	// Token: 0x0400029C RID: 668
	[SerializeField]
	private int virginiaCount;

	// Token: 0x0400029D RID: 669
	[SerializeField]
	private int mandatoryReloadLeft;

	// Token: 0x0400029E RID: 670
	[SerializeField]
	private int[] stringVirginiaShots;

	// Token: 0x0400029F RID: 671
	[SerializeField]
	public bool isFixedTimed;

	// Token: 0x040002A0 RID: 672
	[SerializeField]
	private float[] timeAllowedPerString;

	// Token: 0x040002A1 RID: 673
	[Header("Steel Challenge")]
	[SerializeField]
	public bool isSteelChallenge;

	// Token: 0x040002A2 RID: 674
	[SerializeField]
	public bool isOuterLimit;

	// Token: 0x040002A3 RID: 675
	[SerializeField]
	private bool stopPlateHit;

	// Token: 0x040002A4 RID: 676
	[SerializeField]
	private int steelChallengeStrings;

	// Token: 0x040002A5 RID: 677
	private List<float> steelChallengeTimeList;

	// Token: 0x040002A6 RID: 678
	private int steelHit;

	// Token: 0x040002A7 RID: 679
	private bool steelChallengeLeftArea;

	// Token: 0x040002A8 RID: 680
	private bool steelChallengeHasMoved;

	// Token: 0x040002A9 RID: 681
	[Header("Comp Records")]
	[SerializeField]
	public float classifierMax;

	// Token: 0x040002AA RID: 682
	[SerializeField]
	public float bronzeHitFactor;

	// Token: 0x040002AB RID: 683
	[SerializeField]
	public float silverHitFactor;

	// Token: 0x040002AC RID: 684
	[SerializeField]
	public float goldHitFactor;

	// Token: 0x040002AD RID: 685
	[SerializeField]
	public float maxHitFactor;

	// Token: 0x040002AE RID: 686
	[Header("Comp Status")]
	public SceneSettings.CompStatus status;

	// Token: 0x040002AF RID: 687
	public bool withinStartingPosition;

	// Token: 0x040002B0 RID: 688
	public bool signalStartingCondition;

	// Token: 0x040002B1 RID: 689
	public bool makeReadyInitiated;

	// Token: 0x040002B2 RID: 690
	[Header("Comp Detection")]
	[SerializeField]
	private float headMovementThreshold;

	// Token: 0x040002B3 RID: 691
	[SerializeField]
	private float headRotationThreshold;

	// Token: 0x040002B4 RID: 692
	[SerializeField]
	private float headMovementTimeInterval;

	// Token: 0x040002B5 RID: 693
	[SerializeField]
	private float headStillTime = 2f;

	// Token: 0x040002B6 RID: 694
	[Header("Stage Planner")]
	[SerializeField]
	public SceneLoader.LoadMode loadMode;

	// Token: 0x040002B7 RID: 695
	[SerializeField]
	public Transform defaultPanelPosition;

	// Token: 0x040002B8 RID: 696
	[SerializeField]
	public Transform introPanelPosition;

	// Token: 0x040002B9 RID: 697
	[SerializeField]
	public Transform resultsPanelPosition;

	// Token: 0x040002BA RID: 698
	[Header("General Scene Settings")]
	[SerializeField]
	public bool isNight;

	// Token: 0x040002BB RID: 699
	[SerializeField]
	public bool isTutorial;

	// Token: 0x040002BC RID: 700
	[SerializeField]
	public bool noDefaultWeapon;

	// Token: 0x040002BD RID: 701
	[SerializeField]
	public bool rigOverride;

	// Token: 0x040002BE RID: 702
	[SerializeField]
	public bool returnWeaponToSpawn;

	// Token: 0x040002BF RID: 703
	[SerializeField]
	public GameObject rigToOverride;

	// Token: 0x040002C0 RID: 704
	public bool gunCheckTest;

	// Token: 0x040002C1 RID: 705
	public int procedurals;

	// Token: 0x040002C2 RID: 706
	private SceneSettings.HeadTurn headTurn;

	// Token: 0x040002C3 RID: 707
	private int headShakeCount;

	// Token: 0x040002C4 RID: 708
	private int headTurnCount;

	// Token: 0x040002C5 RID: 709
	private float previousRotation;

	// Token: 0x040002C6 RID: 710
	public bool inStageDesigner;

	// Token: 0x040002C7 RID: 711
	private SoundManager soundManager;

	// Token: 0x040002C8 RID: 712
	private WeaponController weapon;

	// Token: 0x040002C9 RID: 713
	private float timeSinceLastMovement;

	// Token: 0x040002CA RID: 714
	private float stageStartTime;

	// Token: 0x040002CB RID: 715
	private float stageLastShot;

	// Token: 0x040002CC RID: 716
	private Vector3 headPosition;

	// Token: 0x040002CD RID: 717
	private Quaternion headRotation;

	// Token: 0x040002CE RID: 718
	private Camera camera;

	// Token: 0x040002CF RID: 719
	private bool headSteady;

	// Token: 0x040002D0 RID: 720
	private bool startConditionMet;

	// Token: 0x040002D1 RID: 721
	private bool showClear;

	// Token: 0x040002D2 RID: 722
	private bool playerOutOfBounds;

	// Token: 0x040002D3 RID: 723
	private float cameraRotateY;

	// Token: 0x040002D4 RID: 724
	private bool detectHeadShake;

	// Token: 0x040002D5 RID: 725
	private bool drawCoolDown;

	// Token: 0x040002D6 RID: 726
	private bool awaitCorrectFacingDirection;

	// Token: 0x040002D7 RID: 727
	private int stageRoundCount;

	// Token: 0x040002D8 RID: 728
	private int stageShotsFired;

	// Token: 0x040002D9 RID: 729
	private int shootingBoundaries;

	// Token: 0x040002DA RID: 730
	private int startingBoundaries;

	// Token: 0x040002DB RID: 731
	private float countDown;

	// Token: 0x040002DC RID: 732
	private float countDownRandom;

	// Token: 0x040002DD RID: 733
	private float countDownTimeTotal;

	// Token: 0x040002DE RID: 734
	private GameManager gameManager;

	// Token: 0x040002DF RID: 735
	private SettingsManager settingsManager;

	// Token: 0x040002E0 RID: 736
	private ControlManager controlManager;

	// Token: 0x040002E1 RID: 737
	private SaveManager saveManager;

	// Token: 0x040002E2 RID: 738
	private bool handCheckFix;

	// Token: 0x040002E3 RID: 739
	private bool returnSignalLock;

	// Token: 0x040002E4 RID: 740
	private MovementDetection movementDetection;

	// Token: 0x040002E5 RID: 741
	private int currentString;

	// Token: 0x040002E6 RID: 742
	private int multiStringShots;

	// Token: 0x040002E7 RID: 743
	private bool progressingString;

	// Token: 0x040002E8 RID: 744
	private bool multiStringOver;

	// Token: 0x040002E9 RID: 745
	private float multiStringTime;

	// Token: 0x040002EA RID: 746
	private float stopPlateHitTime;

	// Token: 0x040002EB RID: 747
	private GameObject holsteredWeapon;

	// Token: 0x040002EC RID: 748
	private Transform originalHolsterParent;

	// Token: 0x040002ED RID: 749
	private Vector3 originalHolsterPos;

	// Token: 0x040002EE RID: 750
	private Quaternion originalHolsterRot;

	// Token: 0x040002EF RID: 751
	private bool isNonHolsterStart;

	// Token: 0x020001C2 RID: 450
	public enum SceneType
	{
		// Token: 0x04000D6C RID: 3436
		None,
		// Token: 0x04000D6D RID: 3437
		Menu,
		// Token: 0x04000D6E RID: 3438
		Practice,
		// Token: 0x04000D6F RID: 3439
		TimedPractice,
		// Token: 0x04000D70 RID: 3440
		Comp,
		// Token: 0x04000D71 RID: 3441
		StagePlanner,
		// Token: 0x04000D72 RID: 3442
		Tutorial
	}

	// Token: 0x020001C3 RID: 451
	public enum CompStatus
	{
		// Token: 0x04000D74 RID: 3444
		Cold,
		// Token: 0x04000D75 RID: 3445
		MakeReady,
		// Token: 0x04000D76 RID: 3446
		CountingDown,
		// Token: 0x04000D77 RID: 3447
		Hot,
		// Token: 0x04000D78 RID: 3448
		Clear,
		// Token: 0x04000D79 RID: 3449
		Clearing,
		// Token: 0x04000D7A RID: 3450
		Disqualified
	}

	// Token: 0x020001C4 RID: 452
	private enum HeadTurn
	{
		// Token: 0x04000D7C RID: 3452
		TurningLeft,
		// Token: 0x04000D7D RID: 3453
		TurningRight,
		// Token: 0x04000D7E RID: 3454
		NotTurning
	}
}
