﻿using System;

// Token: 0x020000D6 RID: 214
public enum ovrAvatarMaterialMaskType
{
	// Token: 0x040007FE RID: 2046
	None,
	// Token: 0x040007FF RID: 2047
	Positional,
	// Token: 0x04000800 RID: 2048
	ViewReflection,
	// Token: 0x04000801 RID: 2049
	Fresnel,
	// Token: 0x04000802 RID: 2050
	Pulse,
	// Token: 0x04000803 RID: 2051
	Count
}
