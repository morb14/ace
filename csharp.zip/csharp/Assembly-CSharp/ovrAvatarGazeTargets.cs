﻿using System;
using System.Runtime.InteropServices;

// Token: 0x020000EE RID: 238
public struct ovrAvatarGazeTargets
{
	// Token: 0x0400087D RID: 2173
	public uint targetCount;

	// Token: 0x0400087E RID: 2174
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 128)]
	public ovrAvatarGazeTarget[] targets;
}
