﻿using System;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x02000080 RID: 128
public class SceneTypeChanger : MonoBehaviour
{
	// Token: 0x0600049E RID: 1182 RVA: 0x0001EB51 File Offset: 0x0001CD51
	private void Start()
	{
		SceneManager.sceneLoaded += this.OnSceneLoaded;
	}

	// Token: 0x0600049F RID: 1183 RVA: 0x0001EB64 File Offset: 0x0001CD64
	private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
	{
		if (Object.FindObjectOfType<SceneSettings>().sceneType == SceneSettings.SceneType.Comp)
		{
			GameEvents.current.BroadcastMessage("You have a shot timer with you, this is now a practice stage", false);
			base.Invoke("ChangeType", 0.5f);
		}
	}

	// Token: 0x060004A0 RID: 1184 RVA: 0x0001EB93 File Offset: 0x0001CD93
	private void ChangeType()
	{
		Object.FindObjectOfType<SceneSettings>().sceneType = SceneSettings.SceneType.Practice;
	}

	// Token: 0x060004A1 RID: 1185 RVA: 0x0001EBA0 File Offset: 0x0001CDA0
	private void OnDestroy()
	{
		SceneManager.sceneLoaded -= this.OnSceneLoaded;
	}
}
