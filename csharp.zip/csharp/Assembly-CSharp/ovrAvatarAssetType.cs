﻿using System;

// Token: 0x020000BF RID: 191
public enum ovrAvatarAssetType
{
	// Token: 0x0400076D RID: 1901
	Mesh,
	// Token: 0x0400076E RID: 1902
	Texture,
	// Token: 0x0400076F RID: 1903
	Pose,
	// Token: 0x04000770 RID: 1904
	Material,
	// Token: 0x04000771 RID: 1905
	CombinedMesh,
	// Token: 0x04000772 RID: 1906
	PBSMaterial,
	// Token: 0x04000773 RID: 1907
	FailedLoad,
	// Token: 0x04000774 RID: 1908
	Count
}
