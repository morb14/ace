﻿using System;

// Token: 0x020000BB RID: 187
[Flags]
public enum ovrAvatarCapabilities
{
	// Token: 0x0400075E RID: 1886
	Body = 1,
	// Token: 0x0400075F RID: 1887
	Hands = 2,
	// Token: 0x04000760 RID: 1888
	Base = 4,
	// Token: 0x04000761 RID: 1889
	BodyTilt = 16,
	// Token: 0x04000762 RID: 1890
	Expressive = 32,
	// Token: 0x04000763 RID: 1891
	All = -1
}
