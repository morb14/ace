﻿using System;

// Token: 0x020000E1 RID: 225
public struct ovrAvatarRenderPart_SkinnedMeshRender
{
	// Token: 0x04000849 RID: 2121
	public ovrAvatarTransform localTransform;

	// Token: 0x0400084A RID: 2122
	public ovrAvatarVisibilityFlags visibilityMask;

	// Token: 0x0400084B RID: 2123
	public ulong meshAssetID;

	// Token: 0x0400084C RID: 2124
	public ovrAvatarMaterialState materialState;

	// Token: 0x0400084D RID: 2125
	public ovrAvatarSkinnedMeshPose skinnedPose;
}
