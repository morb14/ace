﻿using System;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x02000046 RID: 70
public class OutOfBoundsQuad : MonoBehaviour
{
	// Token: 0x06000236 RID: 566 RVA: 0x0000C9F4 File Offset: 0x0000ABF4
	private void Start()
	{
		SceneManager.sceneLoaded += this.OnSceneLoaded;
		GameEvents.current.onShootingAreaEnter += this.OnShootingAreaEnter;
		GameEvents.current.onShootingAreaExit += this.OnShootingAreaExit;
		this.CheckColliderStatus();
	}

	// Token: 0x06000237 RID: 567 RVA: 0x0000CA44 File Offset: 0x0000AC44
	private void CheckColliderStatus()
	{
		this.colliderCounts = 0;
		if (Object.FindObjectOfType<SceneSettings>())
		{
			if (Object.FindObjectOfType<SceneSettings>().sceneType == SceneSettings.SceneType.Comp)
			{
				if (this.colliderCounts <= 0)
				{
					this.renderer.enabled = true;
					return;
				}
				this.renderer.enabled = false;
				return;
			}
			else
			{
				this.renderer.enabled = false;
			}
		}
	}

	// Token: 0x06000238 RID: 568 RVA: 0x0000CAA0 File Offset: 0x0000ACA0
	private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
	{
		this.CheckColliderStatus();
	}

	// Token: 0x06000239 RID: 569 RVA: 0x0000CAA8 File Offset: 0x0000ACA8
	private void OnShootingAreaEnter()
	{
		this.colliderCounts++;
		if (this.colliderCounts > 0)
		{
			this.renderer.enabled = false;
		}
	}

	// Token: 0x0600023A RID: 570 RVA: 0x0000CACD File Offset: 0x0000ACCD
	private void OnShootingAreaExit()
	{
		this.colliderCounts--;
		if (this.colliderCounts <= 0)
		{
			this.renderer.enabled = true;
		}
	}

	// Token: 0x0600023B RID: 571 RVA: 0x0000CAF2 File Offset: 0x0000ACF2
	private void OnDestroy()
	{
		SceneManager.sceneLoaded -= this.OnSceneLoaded;
		GameEvents.current.onShootingAreaEnter -= this.OnShootingAreaEnter;
		GameEvents.current.onShootingAreaExit -= this.OnShootingAreaExit;
	}

	// Token: 0x04000223 RID: 547
	private int colliderCounts;

	// Token: 0x04000224 RID: 548
	[SerializeField]
	private MeshRenderer renderer;
}
