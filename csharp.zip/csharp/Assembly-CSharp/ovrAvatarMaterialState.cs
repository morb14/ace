﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

// Token: 0x020000DB RID: 219
public struct ovrAvatarMaterialState
{
	// Token: 0x0600062D RID: 1581 RVA: 0x000288A5 File Offset: 0x00026AA5
	private static bool VectorEquals(Vector4 a, Vector4 b)
	{
		return a.x == b.x && a.y == b.y && a.z == b.z && a.w == b.w;
	}

	// Token: 0x0600062E RID: 1582 RVA: 0x00028A54 File Offset: 0x00026C54
	public override bool Equals(object obj)
	{
		if (!(obj is ovrAvatarMaterialState))
		{
			return false;
		}
		ovrAvatarMaterialState ovrAvatarMaterialState = (ovrAvatarMaterialState)obj;
		if (!ovrAvatarMaterialState.VectorEquals(this.baseColor, ovrAvatarMaterialState.baseColor))
		{
			return false;
		}
		if (this.baseMaskType != ovrAvatarMaterialState.baseMaskType)
		{
			return false;
		}
		if (!ovrAvatarMaterialState.VectorEquals(this.baseMaskParameters, ovrAvatarMaterialState.baseMaskParameters))
		{
			return false;
		}
		if (!ovrAvatarMaterialState.VectorEquals(this.baseMaskAxis, ovrAvatarMaterialState.baseMaskAxis))
		{
			return false;
		}
		if (this.sampleMode != ovrAvatarMaterialState.sampleMode)
		{
			return false;
		}
		if (this.alphaMaskTextureID != ovrAvatarMaterialState.alphaMaskTextureID)
		{
			return false;
		}
		if (!ovrAvatarMaterialState.VectorEquals(this.alphaMaskScaleOffset, ovrAvatarMaterialState.alphaMaskScaleOffset))
		{
			return false;
		}
		if (this.normalMapTextureID != ovrAvatarMaterialState.normalMapTextureID)
		{
			return false;
		}
		if (!ovrAvatarMaterialState.VectorEquals(this.normalMapScaleOffset, ovrAvatarMaterialState.normalMapScaleOffset))
		{
			return false;
		}
		if (this.parallaxMapTextureID != ovrAvatarMaterialState.parallaxMapTextureID)
		{
			return false;
		}
		if (!ovrAvatarMaterialState.VectorEquals(this.parallaxMapScaleOffset, ovrAvatarMaterialState.parallaxMapScaleOffset))
		{
			return false;
		}
		if (this.roughnessMapTextureID != ovrAvatarMaterialState.roughnessMapTextureID)
		{
			return false;
		}
		if (!ovrAvatarMaterialState.VectorEquals(this.roughnessMapScaleOffset, ovrAvatarMaterialState.roughnessMapScaleOffset))
		{
			return false;
		}
		if (this.layerCount != ovrAvatarMaterialState.layerCount)
		{
			return false;
		}
		int num = 0;
		while ((long)num < (long)((ulong)this.layerCount))
		{
			if (!this.layers[num].Equals(ovrAvatarMaterialState.layers[num]))
			{
				return false;
			}
			num++;
		}
		return true;
	}

	// Token: 0x0600062F RID: 1583 RVA: 0x00028BB8 File Offset: 0x00026DB8
	public override int GetHashCode()
	{
		int num = 0;
		num ^= this.baseColor.GetHashCode();
		num ^= this.baseMaskType.GetHashCode();
		num ^= this.baseMaskParameters.GetHashCode();
		num ^= this.baseMaskAxis.GetHashCode();
		num ^= this.sampleMode.GetHashCode();
		num ^= this.alphaMaskTextureID.GetHashCode();
		num ^= this.alphaMaskScaleOffset.GetHashCode();
		num ^= this.normalMapTextureID.GetHashCode();
		num ^= this.normalMapScaleOffset.GetHashCode();
		num ^= this.parallaxMapTextureID.GetHashCode();
		num ^= this.parallaxMapScaleOffset.GetHashCode();
		num ^= this.roughnessMapTextureID.GetHashCode();
		num ^= this.roughnessMapScaleOffset.GetHashCode();
		num ^= this.layerCount.GetHashCode();
		int num2 = 0;
		while ((long)num2 < (long)((ulong)this.layerCount))
		{
			num ^= this.layers[num2].GetHashCode();
			num2++;
		}
		return num;
	}

	// Token: 0x0400081B RID: 2075
	public Vector4 baseColor;

	// Token: 0x0400081C RID: 2076
	public ovrAvatarMaterialMaskType baseMaskType;

	// Token: 0x0400081D RID: 2077
	public Vector4 baseMaskParameters;

	// Token: 0x0400081E RID: 2078
	public Vector4 baseMaskAxis;

	// Token: 0x0400081F RID: 2079
	public ovrAvatarMaterialLayerSampleMode sampleMode;

	// Token: 0x04000820 RID: 2080
	public ulong alphaMaskTextureID;

	// Token: 0x04000821 RID: 2081
	public Vector4 alphaMaskScaleOffset;

	// Token: 0x04000822 RID: 2082
	public ulong normalMapTextureID;

	// Token: 0x04000823 RID: 2083
	public Vector4 normalMapScaleOffset;

	// Token: 0x04000824 RID: 2084
	public ulong parallaxMapTextureID;

	// Token: 0x04000825 RID: 2085
	public Vector4 parallaxMapScaleOffset;

	// Token: 0x04000826 RID: 2086
	public ulong roughnessMapTextureID;

	// Token: 0x04000827 RID: 2087
	public Vector4 roughnessMapScaleOffset;

	// Token: 0x04000828 RID: 2088
	public uint layerCount;

	// Token: 0x04000829 RID: 2089
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
	public ovrAvatarMaterialLayerState[] layers;
}
