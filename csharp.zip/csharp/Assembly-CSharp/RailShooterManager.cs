﻿using System;
using UnityEngine;

// Token: 0x0200007F RID: 127
public class RailShooterManager : MonoBehaviour
{
	// Token: 0x06000498 RID: 1176 RVA: 0x0001EA68 File Offset: 0x0001CC68
	private void Start()
	{
		this.GatherTeleporters();
		GameEvents.current.onEnterVehicle += this.OnEnterVehicle;
		GameEvents.current.onExitVehicle += this.OnExitVehicle;
	}

	// Token: 0x06000499 RID: 1177 RVA: 0x0001EA9C File Offset: 0x0001CC9C
	private void GatherTeleporters()
	{
		this.teleporters = Object.FindObjectsOfType<TeleportProperty>();
	}

	// Token: 0x0600049A RID: 1178 RVA: 0x0001EAAC File Offset: 0x0001CCAC
	private void OnEnterVehicle()
	{
		foreach (TeleportProperty teleportProperty in this.teleporters)
		{
			if (teleportProperty != null)
			{
				teleportProperty.gameObject.SetActive(false);
			}
		}
	}

	// Token: 0x0600049B RID: 1179 RVA: 0x0001EAE8 File Offset: 0x0001CCE8
	private void OnExitVehicle()
	{
		foreach (TeleportProperty teleportProperty in this.teleporters)
		{
			if (teleportProperty != null)
			{
				teleportProperty.gameObject.SetActive(true);
			}
		}
	}

	// Token: 0x0600049C RID: 1180 RVA: 0x0001EB23 File Offset: 0x0001CD23
	private void OnDestroy()
	{
		GameEvents.current.onEnterVehicle -= this.OnEnterVehicle;
		GameEvents.current.onExitVehicle -= this.OnExitVehicle;
	}

	// Token: 0x040005D3 RID: 1491
	private TeleportProperty[] teleporters;
}
