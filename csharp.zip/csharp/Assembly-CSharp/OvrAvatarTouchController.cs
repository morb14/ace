﻿using System;
using Oculus.Avatar;
using UnityEngine;

// Token: 0x02000101 RID: 257
public class OvrAvatarTouchController : OvrAvatarComponent
{
	// Token: 0x06000679 RID: 1657 RVA: 0x0002A940 File Offset: 0x00028B40
	private void Update()
	{
		if (this.owner == null)
		{
			return;
		}
		bool flag;
		if (this.isLeftHand)
		{
			flag = CAPI.ovrAvatarPose_GetLeftControllerComponent(this.owner.sdkAvatar, ref this.component);
		}
		else
		{
			flag = CAPI.ovrAvatarPose_GetRightControllerComponent(this.owner.sdkAvatar, ref this.component);
		}
		if (flag)
		{
			base.UpdateAvatar(this.component.renderComponent);
			return;
		}
		if (this.isLeftHand)
		{
			this.owner.ControllerLeft = null;
		}
		else
		{
			this.owner.ControllerRight = null;
		}
		Object.Destroy(this);
	}

	// Token: 0x040008D2 RID: 2258
	public bool isLeftHand = true;

	// Token: 0x040008D3 RID: 2259
	private ovrAvatarControllerComponent component;
}
