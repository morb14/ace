﻿using System;
using UnityEngine;

// Token: 0x02000107 RID: 263
public static class OVRTouchpad
{
	// Token: 0x06000696 RID: 1686 RVA: 0x00003297 File Offset: 0x00001497
	public static void Create()
	{
	}

	// Token: 0x06000697 RID: 1687 RVA: 0x0002B0F2 File Offset: 0x000292F2
	public static void Update()
	{
		if (Input.GetMouseButtonDown(0))
		{
			OVRTouchpad.moveAmountMouse = Input.mousePosition;
			return;
		}
		if (Input.GetMouseButtonUp(0))
		{
			OVRTouchpad.moveAmountMouse -= Input.mousePosition;
			OVRTouchpad.HandleInputMouse(ref OVRTouchpad.moveAmountMouse);
		}
	}

	// Token: 0x06000698 RID: 1688 RVA: 0x00003297 File Offset: 0x00001497
	public static void OnDisable()
	{
	}

	// Token: 0x06000699 RID: 1689 RVA: 0x0002B130 File Offset: 0x00029330
	private static void HandleInputMouse(ref Vector3 move)
	{
		if (OVRTouchpad.touchPadCallbacks == null)
		{
			return;
		}
		OVRTouchpad.OVRTouchpadCallback<OVRTouchpad.TouchEvent> ovrtouchpadCallback = OVRTouchpad.touchPadCallbacks as OVRTouchpad.OVRTouchpadCallback<OVRTouchpad.TouchEvent>;
		if (move.magnitude < OVRTouchpad.minMovMagnitudeMouse)
		{
			ovrtouchpadCallback(OVRTouchpad.TouchEvent.SingleTap);
			return;
		}
		move.Normalize();
		if (Mathf.Abs(move.x) > Mathf.Abs(move.y))
		{
			if (move.x > 0f)
			{
				ovrtouchpadCallback(OVRTouchpad.TouchEvent.Left);
				return;
			}
			ovrtouchpadCallback(OVRTouchpad.TouchEvent.Right);
			return;
		}
		else
		{
			if (move.y > 0f)
			{
				ovrtouchpadCallback(OVRTouchpad.TouchEvent.Down);
				return;
			}
			ovrtouchpadCallback(OVRTouchpad.TouchEvent.Up);
			return;
		}
	}

	// Token: 0x0600069A RID: 1690 RVA: 0x0002B1BC File Offset: 0x000293BC
	public static void AddListener(OVRTouchpad.OVRTouchpadCallback<OVRTouchpad.TouchEvent> handler)
	{
		OVRTouchpad.touchPadCallbacks = (OVRTouchpad.OVRTouchpadCallback<OVRTouchpad.TouchEvent>)Delegate.Combine((OVRTouchpad.OVRTouchpadCallback<OVRTouchpad.TouchEvent>)OVRTouchpad.touchPadCallbacks, handler);
	}

	// Token: 0x040008E5 RID: 2277
	private static Vector3 moveAmountMouse;

	// Token: 0x040008E6 RID: 2278
	private static float minMovMagnitudeMouse = 25f;

	// Token: 0x040008E7 RID: 2279
	public static Delegate touchPadCallbacks = null;

	// Token: 0x040008E8 RID: 2280
	private static OVRTouchpadHelper touchpadHelper = new GameObject("OVRTouchpadHelper").AddComponent<OVRTouchpadHelper>();

	// Token: 0x020001FA RID: 506
	public enum TouchEvent
	{
		// Token: 0x04000E8F RID: 3727
		SingleTap,
		// Token: 0x04000E90 RID: 3728
		DoubleTap,
		// Token: 0x04000E91 RID: 3729
		Left,
		// Token: 0x04000E92 RID: 3730
		Right,
		// Token: 0x04000E93 RID: 3731
		Up,
		// Token: 0x04000E94 RID: 3732
		Down
	}

	// Token: 0x020001FB RID: 507
	// (Invoke) Token: 0x06000C4C RID: 3148
	public delegate void OVRTouchpadCallback<TouchEvent>(TouchEvent arg);
}
