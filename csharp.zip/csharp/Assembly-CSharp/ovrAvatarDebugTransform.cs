﻿using System;

// Token: 0x020000F7 RID: 247
public struct ovrAvatarDebugTransform
{
	// Token: 0x040008A3 RID: 2211
	public ovrAvatarTransform transform;

	// Token: 0x040008A4 RID: 2212
	public ovrAvatarDebugContext context;

	// Token: 0x040008A5 RID: 2213
	public IntPtr text;
}
