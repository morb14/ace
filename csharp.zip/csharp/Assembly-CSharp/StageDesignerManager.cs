﻿using System;
using UnityEngine;

// Token: 0x0200008C RID: 140
public class StageDesignerManager : MonoBehaviour
{
	// Token: 0x060004E3 RID: 1251 RVA: 0x00003297 File Offset: 0x00001497
	private void Start()
	{
	}
}
