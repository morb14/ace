﻿using System;
using UnityEngine;

// Token: 0x02000113 RID: 275
public class LaserPointer : OVRCursor
{
	// Token: 0x17000016 RID: 22
	// (get) Token: 0x06000705 RID: 1797 RVA: 0x0002CEFF File Offset: 0x0002B0FF
	// (set) Token: 0x06000704 RID: 1796 RVA: 0x0002CECB File Offset: 0x0002B0CB
	public LaserPointer.LaserBeamBehavior laserBeamBehavior
	{
		get
		{
			return this._laserBeamBehavior;
		}
		set
		{
			this._laserBeamBehavior = value;
			if (this.laserBeamBehavior == LaserPointer.LaserBeamBehavior.Off || this.laserBeamBehavior == LaserPointer.LaserBeamBehavior.OnWhenHitTarget)
			{
				this.lineRenderer.enabled = false;
				return;
			}
			this.lineRenderer.enabled = true;
		}
	}

	// Token: 0x06000706 RID: 1798 RVA: 0x0002CF07 File Offset: 0x0002B107
	private void Awake()
	{
		this.lineRenderer = base.GetComponent<LineRenderer>();
	}

	// Token: 0x06000707 RID: 1799 RVA: 0x0002CF15 File Offset: 0x0002B115
	private void Start()
	{
		if (this.cursorVisual)
		{
			this.cursorVisual.SetActive(false);
		}
		OVRManager.InputFocusAcquired += this.OnInputFocusAcquired;
		OVRManager.InputFocusLost += this.OnInputFocusLost;
	}

	// Token: 0x06000708 RID: 1800 RVA: 0x0002CF52 File Offset: 0x0002B152
	public override void SetCursorStartDest(Vector3 start, Vector3 dest, Vector3 normal)
	{
		this._startPoint = start;
		this._endPoint = dest;
		this._hitTarget = true;
	}

	// Token: 0x06000709 RID: 1801 RVA: 0x0002CF69 File Offset: 0x0002B169
	public override void SetCursorRay(Transform t)
	{
		this._startPoint = t.position;
		this._forward = t.forward;
		this._hitTarget = false;
	}

	// Token: 0x0600070A RID: 1802 RVA: 0x0002CF8C File Offset: 0x0002B18C
	private void LateUpdate()
	{
		this.lineRenderer.SetPosition(0, this._startPoint);
		if (this._hitTarget)
		{
			this.lineRenderer.SetPosition(1, this._endPoint);
			this.UpdateLaserBeam(this._startPoint, this._endPoint);
			if (this.cursorVisual)
			{
				this.cursorVisual.transform.position = this._endPoint;
				this.cursorVisual.SetActive(true);
				return;
			}
		}
		else
		{
			this.UpdateLaserBeam(this._startPoint, this._startPoint + this.maxLength * this._forward);
			this.lineRenderer.SetPosition(1, this._startPoint + this.maxLength * this._forward);
			if (this.cursorVisual)
			{
				this.cursorVisual.SetActive(false);
			}
		}
	}

	// Token: 0x0600070B RID: 1803 RVA: 0x0002D074 File Offset: 0x0002B274
	private void UpdateLaserBeam(Vector3 start, Vector3 end)
	{
		if (this.laserBeamBehavior == LaserPointer.LaserBeamBehavior.Off)
		{
			return;
		}
		if (this.laserBeamBehavior == LaserPointer.LaserBeamBehavior.On)
		{
			this.lineRenderer.SetPosition(0, start);
			this.lineRenderer.SetPosition(1, end);
			return;
		}
		if (this.laserBeamBehavior == LaserPointer.LaserBeamBehavior.OnWhenHitTarget)
		{
			if (this._hitTarget)
			{
				if (!this.lineRenderer.enabled)
				{
					this.lineRenderer.enabled = true;
					this.lineRenderer.SetPosition(0, start);
					this.lineRenderer.SetPosition(1, end);
					return;
				}
			}
			else if (this.lineRenderer.enabled)
			{
				this.lineRenderer.enabled = false;
			}
		}
	}

	// Token: 0x0600070C RID: 1804 RVA: 0x0002D10C File Offset: 0x0002B30C
	private void OnDisable()
	{
		if (this.cursorVisual)
		{
			this.cursorVisual.SetActive(false);
		}
	}

	// Token: 0x0600070D RID: 1805 RVA: 0x0002D127 File Offset: 0x0002B327
	public void OnInputFocusLost()
	{
		if (base.gameObject && base.gameObject.activeInHierarchy)
		{
			this.m_restoreOnInputAcquired = true;
			base.gameObject.SetActive(false);
		}
	}

	// Token: 0x0600070E RID: 1806 RVA: 0x0002D156 File Offset: 0x0002B356
	public void OnInputFocusAcquired()
	{
		if (this.m_restoreOnInputAcquired && base.gameObject)
		{
			this.m_restoreOnInputAcquired = false;
			base.gameObject.SetActive(true);
		}
	}

	// Token: 0x0600070F RID: 1807 RVA: 0x0002D180 File Offset: 0x0002B380
	private void OnDestroy()
	{
		OVRManager.InputFocusAcquired -= this.OnInputFocusAcquired;
		OVRManager.InputFocusLost -= this.OnInputFocusLost;
	}

	// Token: 0x0400093B RID: 2363
	public GameObject cursorVisual;

	// Token: 0x0400093C RID: 2364
	public float maxLength = 10f;

	// Token: 0x0400093D RID: 2365
	private LaserPointer.LaserBeamBehavior _laserBeamBehavior;

	// Token: 0x0400093E RID: 2366
	private bool m_restoreOnInputAcquired;

	// Token: 0x0400093F RID: 2367
	private Vector3 _startPoint;

	// Token: 0x04000940 RID: 2368
	private Vector3 _forward;

	// Token: 0x04000941 RID: 2369
	private Vector3 _endPoint;

	// Token: 0x04000942 RID: 2370
	private bool _hitTarget;

	// Token: 0x04000943 RID: 2371
	private LineRenderer lineRenderer;

	// Token: 0x0200020C RID: 524
	public enum LaserBeamBehavior
	{
		// Token: 0x04000ECE RID: 3790
		On,
		// Token: 0x04000ECF RID: 3791
		Off,
		// Token: 0x04000ED0 RID: 3792
		OnWhenHitTarget
	}
}
