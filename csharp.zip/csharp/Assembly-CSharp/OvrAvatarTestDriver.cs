﻿using System;
using UnityEngine;

// Token: 0x0200009E RID: 158
public class OvrAvatarTestDriver : OvrAvatarDriver
{
	// Token: 0x06000545 RID: 1349 RVA: 0x00021B28 File Offset: 0x0001FD28
	private OvrAvatarDriver.ControllerPose GetMalibuControllerPose(OVRInput.Controller controller)
	{
		ovrAvatarButton ovrAvatarButton = (ovrAvatarButton)0;
		if (OVRInput.Get(OVRInput.Button.PrimaryIndexTrigger, controller))
		{
			ovrAvatarButton |= ovrAvatarButton.One;
		}
		return new OvrAvatarDriver.ControllerPose
		{
			buttons = ovrAvatarButton,
			touches = (OVRInput.Get(OVRInput.Touch.PrimaryTouchpad, OVRInput.Controller.Active) ? ovrAvatarTouch.One : ((ovrAvatarTouch)0)),
			joystickPosition = OVRInput.Get(OVRInput.Axis2D.PrimaryTouchpad, controller),
			indexTrigger = 0f,
			handTrigger = 0f,
			isActive = ((OVRInput.GetActiveController() & controller) > OVRInput.Controller.None)
		};
	}

	// Token: 0x06000546 RID: 1350 RVA: 0x00021BAC File Offset: 0x0001FDAC
	private OvrAvatarDriver.ControllerPose GetControllerPose(OVRInput.Controller controller)
	{
		ovrAvatarButton ovrAvatarButton = (ovrAvatarButton)0;
		if (OVRInput.Get(OVRInput.Button.One, controller))
		{
			ovrAvatarButton |= ovrAvatarButton.One;
		}
		if (OVRInput.Get(OVRInput.Button.Two, controller))
		{
			ovrAvatarButton |= ovrAvatarButton.Two;
		}
		if (OVRInput.Get(OVRInput.Button.Start, controller))
		{
			ovrAvatarButton |= ovrAvatarButton.Three;
		}
		if (OVRInput.Get(OVRInput.Button.PrimaryThumbstick, controller))
		{
			ovrAvatarButton |= ovrAvatarButton.Joystick;
		}
		ovrAvatarTouch ovrAvatarTouch = (ovrAvatarTouch)0;
		if (OVRInput.Get(OVRInput.Touch.One, controller))
		{
			ovrAvatarTouch |= ovrAvatarTouch.One;
		}
		if (OVRInput.Get(OVRInput.Touch.Two, controller))
		{
			ovrAvatarTouch |= ovrAvatarTouch.Two;
		}
		if (OVRInput.Get(OVRInput.Touch.PrimaryThumbstick, controller))
		{
			ovrAvatarTouch |= ovrAvatarTouch.Joystick;
		}
		if (OVRInput.Get(OVRInput.Touch.PrimaryThumbRest, controller))
		{
			ovrAvatarTouch |= ovrAvatarTouch.ThumbRest;
		}
		if (OVRInput.Get(OVRInput.Touch.PrimaryIndexTrigger, controller))
		{
			ovrAvatarTouch |= ovrAvatarTouch.Index;
		}
		if (!OVRInput.Get(OVRInput.NearTouch.PrimaryIndexTrigger, controller))
		{
			ovrAvatarTouch |= ovrAvatarTouch.Pointing;
		}
		if (!OVRInput.Get(OVRInput.NearTouch.PrimaryThumbButtons, controller))
		{
			ovrAvatarTouch |= ovrAvatarTouch.ThumbUp;
		}
		return new OvrAvatarDriver.ControllerPose
		{
			buttons = ovrAvatarButton,
			touches = ovrAvatarTouch,
			joystickPosition = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, controller),
			indexTrigger = OVRInput.Get(OVRInput.Axis1D.PrimaryIndexTrigger, controller),
			handTrigger = OVRInput.Get(OVRInput.Axis1D.PrimaryHandTrigger, controller),
			isActive = ((OVRInput.GetActiveController() & controller) > OVRInput.Controller.None)
		};
	}

	// Token: 0x06000547 RID: 1351 RVA: 0x00021CBC File Offset: 0x0001FEBC
	private void CalculateCurrentPose()
	{
		if (OvrAvatarDriver.GetIsTrackedRemote())
		{
			this.CurrentPose = new OvrAvatarDriver.PoseFrame
			{
				voiceAmplitude = this.voiceAmplitude,
				headPosition = this.headPos,
				headRotation = this.headRot,
				handLeftPosition = OVRInput.GetLocalControllerPosition(OVRInput.Controller.LTrackedRemote),
				handLeftRotation = OVRInput.GetLocalControllerRotation(OVRInput.Controller.LTrackedRemote),
				handRightPosition = OVRInput.GetLocalControllerPosition(OVRInput.Controller.RTrackedRemote),
				handRightRotation = OVRInput.GetLocalControllerRotation(OVRInput.Controller.RTrackedRemote),
				controllerLeftPose = this.GetMalibuControllerPose(OVRInput.Controller.LTrackedRemote),
				controllerRightPose = this.GetMalibuControllerPose(OVRInput.Controller.RTrackedRemote)
			};
			return;
		}
		this.CurrentPose = new OvrAvatarDriver.PoseFrame
		{
			voiceAmplitude = this.voiceAmplitude,
			headPosition = this.headPos,
			headRotation = this.headRot,
			handLeftPosition = OVRInput.GetLocalControllerPosition(OVRInput.Controller.LTouch),
			handLeftRotation = OVRInput.GetLocalControllerRotation(OVRInput.Controller.LTouch),
			handRightPosition = OVRInput.GetLocalControllerPosition(OVRInput.Controller.RTouch),
			handRightRotation = OVRInput.GetLocalControllerRotation(OVRInput.Controller.RTouch),
			controllerLeftPose = this.GetControllerPose(OVRInput.Controller.LTouch),
			controllerRightPose = this.GetControllerPose(OVRInput.Controller.RTouch)
		};
	}

	// Token: 0x06000548 RID: 1352 RVA: 0x00021DF8 File Offset: 0x0001FFF8
	public override void UpdateTransforms(IntPtr sdkAvatar)
	{
		this.CalculateCurrentPose();
		base.UpdateTransformsFromPose(sdkAvatar);
	}

	// Token: 0x0400066E RID: 1646
	private Vector3 headPos = new Vector3(0f, 1.6f, 0f);

	// Token: 0x0400066F RID: 1647
	private Quaternion headRot = Quaternion.identity;

	// Token: 0x04000670 RID: 1648
	private float voiceAmplitude;
}
