﻿using System;
using System.Reflection;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x02000033 RID: 51
public class PersistentObject : MonoBehaviour
{
	// Token: 0x060001D9 RID: 473 RVA: 0x0000A941 File Offset: 0x00008B41
	private void Awake()
	{
		SceneManager.sceneLoaded += this.OnSceneLoaded;
		if (Object.FindObjectsOfType<GameManager>().Length == 0)
		{
			Object.Instantiate<GameObject>(this.persistentObject, base.transform);
			this.spawned = true;
			Object.DontDestroyOnLoad(base.gameObject);
		}
	}

	// Token: 0x060001DA RID: 474 RVA: 0x0000A980 File Offset: 0x00008B80
	private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
	{
		if (Object.FindObjectsOfType<PersistentObject>().Length > 1)
		{
			foreach (PersistentObject persistentObject in Object.FindObjectsOfType<PersistentObject>())
			{
				if (persistentObject != this && this.spawned)
				{
					SceneSettings component = persistentObject.GetComponent<SceneSettings>();
					SceneSettings component2 = base.GetComponent<SceneSettings>();
					if (component2 != null && component != null)
					{
						this.TransferSceneData(component, component2);
						GameEvents.current.SceneManagerTransferred();
					}
					Object.Destroy(persistentObject.gameObject);
				}
			}
		}
	}

	// Token: 0x060001DB RID: 475 RVA: 0x0000AA04 File Offset: 0x00008C04
	private void TransferSceneData(SceneSettings sourceComp, SceneSettings targetComp)
	{
		FieldInfo[] fields = sourceComp.GetType().GetFields(BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
		for (int i = 0; i < fields.Length; i++)
		{
			object value = fields[i].GetValue(sourceComp);
			fields[i].SetValue(targetComp, value);
		}
	}

	// Token: 0x04000183 RID: 387
	[SerializeField]
	private GameObject persistentObject;

	// Token: 0x04000184 RID: 388
	private bool spawned;
}
