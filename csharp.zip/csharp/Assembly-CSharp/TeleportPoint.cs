﻿using System;
using UnityEngine;

// Token: 0x02000127 RID: 295
public class TeleportPoint : MonoBehaviour
{
	// Token: 0x060007A3 RID: 1955 RVA: 0x00003297 File Offset: 0x00001497
	private void Start()
	{
	}

	// Token: 0x060007A4 RID: 1956 RVA: 0x0002F56B File Offset: 0x0002D76B
	public Transform GetDestTransform()
	{
		return this.destTransform;
	}

	// Token: 0x060007A5 RID: 1957 RVA: 0x0002F574 File Offset: 0x0002D774
	private void Update()
	{
		float value = Mathf.SmoothStep(this.fullIntensity, this.lowIntensity, (Time.time - this.lastLookAtTime) * this.dimmingSpeed);
		base.GetComponent<MeshRenderer>().material.SetFloat("_Intensity", value);
	}

	// Token: 0x060007A6 RID: 1958 RVA: 0x0002F5BC File Offset: 0x0002D7BC
	public void OnLookAt()
	{
		this.lastLookAtTime = Time.time;
	}

	// Token: 0x040009BF RID: 2495
	public float dimmingSpeed = 1f;

	// Token: 0x040009C0 RID: 2496
	public float fullIntensity = 1f;

	// Token: 0x040009C1 RID: 2497
	public float lowIntensity = 0.5f;

	// Token: 0x040009C2 RID: 2498
	public Transform destTransform;

	// Token: 0x040009C3 RID: 2499
	private float lastLookAtTime;
}
