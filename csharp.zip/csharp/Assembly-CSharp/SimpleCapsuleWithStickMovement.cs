﻿using System;
using UnityEngine;

// Token: 0x0200011A RID: 282
public class SimpleCapsuleWithStickMovement : MonoBehaviour
{
	// Token: 0x14000045 RID: 69
	// (add) Token: 0x0600075A RID: 1882 RVA: 0x0002E344 File Offset: 0x0002C544
	// (remove) Token: 0x0600075B RID: 1883 RVA: 0x0002E37C File Offset: 0x0002C57C
	public event Action CameraUpdated;

	// Token: 0x14000046 RID: 70
	// (add) Token: 0x0600075C RID: 1884 RVA: 0x0002E3B4 File Offset: 0x0002C5B4
	// (remove) Token: 0x0600075D RID: 1885 RVA: 0x0002E3EC File Offset: 0x0002C5EC
	public event Action PreCharacterMove;

	// Token: 0x0600075E RID: 1886 RVA: 0x0002E421 File Offset: 0x0002C621
	private void Awake()
	{
		this._rigidbody = base.GetComponent<Rigidbody>();
		if (this.CameraRig == null)
		{
			this.CameraRig = base.GetComponentInChildren<OVRCameraRig>();
		}
	}

	// Token: 0x0600075F RID: 1887 RVA: 0x00003297 File Offset: 0x00001497
	private void Start()
	{
	}

	// Token: 0x06000760 RID: 1888 RVA: 0x0002E44C File Offset: 0x0002C64C
	private void FixedUpdate()
	{
		if (this.CameraUpdated != null)
		{
			this.CameraUpdated();
		}
		if (this.PreCharacterMove != null)
		{
			this.PreCharacterMove();
		}
		if (this.HMDRotatesPlayer)
		{
			this.RotatePlayerToHMD();
		}
		if (this.EnableLinearMovement)
		{
			this.StickMovement();
		}
		if (this.EnableRotation)
		{
			this.SnapTurn();
		}
	}

	// Token: 0x06000761 RID: 1889 RVA: 0x0002E4AC File Offset: 0x0002C6AC
	private void RotatePlayerToHMD()
	{
		Transform trackingSpace = this.CameraRig.trackingSpace;
		Transform centerEyeAnchor = this.CameraRig.centerEyeAnchor;
		Vector3 position = trackingSpace.position;
		Quaternion rotation = trackingSpace.rotation;
		base.transform.rotation = Quaternion.Euler(0f, centerEyeAnchor.rotation.eulerAngles.y, 0f);
		trackingSpace.position = position;
		trackingSpace.rotation = rotation;
	}

	// Token: 0x06000762 RID: 1890 RVA: 0x0002E518 File Offset: 0x0002C718
	private void StickMovement()
	{
		Vector3 eulerAngles = this.CameraRig.centerEyeAnchor.rotation.eulerAngles;
		eulerAngles.z = (eulerAngles.x = 0f);
		Quaternion rotation = Quaternion.Euler(eulerAngles);
		Vector3 a = Vector3.zero;
		Vector2 vector = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, OVRInput.Controller.Active);
		a += rotation * (vector.x * Vector3.right);
		a += rotation * (vector.y * Vector3.forward);
		this._rigidbody.MovePosition(this._rigidbody.position + a * this.Speed * Time.fixedDeltaTime);
	}

	// Token: 0x06000763 RID: 1891 RVA: 0x0002E5DC File Offset: 0x0002C7DC
	private void SnapTurn()
	{
		Vector3 eulerAngles = base.transform.rotation.eulerAngles;
		if (OVRInput.Get(OVRInput.Button.SecondaryThumbstickLeft, OVRInput.Controller.Active) || (this.RotationEitherThumbstick && OVRInput.Get(OVRInput.Button.PrimaryThumbstickLeft, OVRInput.Controller.Active)))
		{
			if (this.ReadyToSnapTurn)
			{
				eulerAngles.y -= this.RotationAngle;
				this.ReadyToSnapTurn = false;
			}
		}
		else if (OVRInput.Get(OVRInput.Button.SecondaryThumbstickRight, OVRInput.Controller.Active) || (this.RotationEitherThumbstick && OVRInput.Get(OVRInput.Button.PrimaryThumbstickRight, OVRInput.Controller.Active)))
		{
			if (this.ReadyToSnapTurn)
			{
				eulerAngles.y += this.RotationAngle;
				this.ReadyToSnapTurn = false;
			}
		}
		else
		{
			this.ReadyToSnapTurn = true;
		}
		base.transform.rotation = Quaternion.Euler(eulerAngles);
	}

	// Token: 0x04000982 RID: 2434
	public bool EnableLinearMovement = true;

	// Token: 0x04000983 RID: 2435
	public bool EnableRotation = true;

	// Token: 0x04000984 RID: 2436
	public bool HMDRotatesPlayer = true;

	// Token: 0x04000985 RID: 2437
	public bool RotationEitherThumbstick;

	// Token: 0x04000986 RID: 2438
	public float RotationAngle = 45f;

	// Token: 0x04000987 RID: 2439
	public float Speed;

	// Token: 0x04000988 RID: 2440
	public OVRCameraRig CameraRig;

	// Token: 0x04000989 RID: 2441
	private bool ReadyToSnapTurn;

	// Token: 0x0400098A RID: 2442
	private Rigidbody _rigidbody;
}
