﻿using System;

// Token: 0x020000F5 RID: 245
[Flags]
public enum ovrAvatarDebugContext : uint
{
	// Token: 0x0400089B RID: 2203
	None = 0U,
	// Token: 0x0400089C RID: 2204
	GazeTarget = 1U,
	// Token: 0x0400089D RID: 2205
	Any = 4294967295U
}
