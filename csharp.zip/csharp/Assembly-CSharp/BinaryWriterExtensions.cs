﻿using System;
using System.IO;
using UnityEngine;

// Token: 0x020000B7 RID: 183
internal static class BinaryWriterExtensions
{
	// Token: 0x06000614 RID: 1556 RVA: 0x00027FC4 File Offset: 0x000261C4
	public static void Write(this BinaryWriter writer, OvrAvatarDriver.PoseFrame frame)
	{
		writer.Write(frame.headPosition);
		writer.Write(frame.headRotation);
		writer.Write(frame.handLeftPosition);
		writer.Write(frame.handLeftRotation);
		writer.Write(frame.handRightPosition);
		writer.Write(frame.handRightRotation);
		writer.Write(frame.voiceAmplitude);
		writer.Write(frame.controllerLeftPose);
		writer.Write(frame.controllerRightPose);
	}

	// Token: 0x06000615 RID: 1557 RVA: 0x0002803D File Offset: 0x0002623D
	public static void Write(this BinaryWriter writer, Vector3 vec3)
	{
		writer.Write(vec3.x);
		writer.Write(vec3.y);
		writer.Write(vec3.z);
	}

	// Token: 0x06000616 RID: 1558 RVA: 0x00028063 File Offset: 0x00026263
	public static void Write(this BinaryWriter writer, Vector2 vec2)
	{
		writer.Write(vec2.x);
		writer.Write(vec2.y);
	}

	// Token: 0x06000617 RID: 1559 RVA: 0x0002807D File Offset: 0x0002627D
	public static void Write(this BinaryWriter writer, Quaternion quat)
	{
		writer.Write(quat.x);
		writer.Write(quat.y);
		writer.Write(quat.z);
		writer.Write(quat.w);
	}

	// Token: 0x06000618 RID: 1560 RVA: 0x000280B0 File Offset: 0x000262B0
	public static void Write(this BinaryWriter writer, OvrAvatarDriver.ControllerPose pose)
	{
		writer.Write((uint)pose.buttons);
		writer.Write((uint)pose.touches);
		writer.Write(pose.joystickPosition);
		writer.Write(pose.indexTrigger);
		writer.Write(pose.handTrigger);
		writer.Write(pose.isActive);
	}
}
