﻿using System;

// Token: 0x020000C2 RID: 194
public struct ovrAvatarBlendVertex
{
	// Token: 0x04000795 RID: 1941
	public float x;

	// Token: 0x04000796 RID: 1942
	public float y;

	// Token: 0x04000797 RID: 1943
	public float z;

	// Token: 0x04000798 RID: 1944
	public float nx;

	// Token: 0x04000799 RID: 1945
	public float ny;

	// Token: 0x0400079A RID: 1946
	public float nz;

	// Token: 0x0400079B RID: 1947
	public float tx;

	// Token: 0x0400079C RID: 1948
	public float ty;

	// Token: 0x0400079D RID: 1949
	public float tz;
}
