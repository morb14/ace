﻿using System;
using System.Runtime.InteropServices;

// Token: 0x020000F4 RID: 244
internal struct ovrAvatarLights_Offsets
{
	// Token: 0x04000897 RID: 2199
	public static long ambientIntensity = Marshal.OffsetOf(typeof(ovrAvatarLights), "ambientIntensity").ToInt64();

	// Token: 0x04000898 RID: 2200
	public static long lightCount = Marshal.OffsetOf(typeof(ovrAvatarLights), "lightCount").ToInt64();

	// Token: 0x04000899 RID: 2201
	public static long lights = Marshal.OffsetOf(typeof(ovrAvatarLights), "lights").ToInt64();
}
