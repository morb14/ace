﻿using System;
using UnityEngine;

// Token: 0x020000F6 RID: 246
public struct ovrAvatarDebugLine
{
	// Token: 0x0400089E RID: 2206
	public Vector3 startPoint;

	// Token: 0x0400089F RID: 2207
	public Vector3 endPoint;

	// Token: 0x040008A0 RID: 2208
	public Vector3 color;

	// Token: 0x040008A1 RID: 2209
	public ovrAvatarDebugContext context;

	// Token: 0x040008A2 RID: 2210
	public IntPtr text;
}
