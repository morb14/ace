﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x02000030 RID: 48
public class MenuButton : MonoBehaviour
{
	// Token: 0x060001B9 RID: 441 RVA: 0x00009598 File Offset: 0x00007798
	private void Start()
	{
		this.sceneSettings = Object.FindObjectOfType<SceneSettings>();
		this.soundManager = Object.FindObjectOfType<SoundManager>();
		this.saveManager = Object.FindObjectOfType<SaveManager>();
		GameEvents.current.onSaveMenuDisabled += this.OnSaveMenuDisabled;
		if (this.highlight != null)
		{
			this.highlight.SetActive(false);
		}
		if (this.type == MenuButton.ButtonType.TriggerOverride)
		{
			this.TriggerOverrideInitiate();
		}
	}

	// Token: 0x060001BA RID: 442 RVA: 0x00009608 File Offset: 0x00007808
	private void TriggerOverrideInitiate()
	{
		if (this.controlManager == null || this.settingsManager == null)
		{
			this.controlManager = Object.FindObjectOfType<ControlManager>();
			this.settingsManager = Object.FindObjectOfType<SettingsManager>();
		}
		if (this.triggerOverrideReset)
		{
			this.textBox.text = "RESET";
			if (this.settingsManager.triggerResetOverride != 0f)
			{
				this.triggerValue.text = this.settingsManager.triggerResetOverride.ToString("F2");
				return;
			}
			this.triggerValue.text = "Default";
			return;
		}
		else
		{
			this.textBox.text = "BREAK";
			if (this.settingsManager.triggerBreakOverride != 0f)
			{
				this.triggerValue.text = this.settingsManager.triggerBreakOverride.ToString("F2");
				return;
			}
			this.triggerValue.text = "Default";
			return;
		}
	}

	// Token: 0x060001BB RID: 443 RVA: 0x000096F6 File Offset: 0x000078F6
	private void Update()
	{
		if (this.type == MenuButton.ButtonType.TriggerOverride && this.highlight.activeSelf)
		{
			this.AdjustTriggerOverride();
		}
	}

	// Token: 0x060001BC RID: 444 RVA: 0x00009718 File Offset: 0x00007918
	private void AdjustTriggerOverride()
	{
		float x = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, this.controlManager.controller).x;
		if (OVRInput.GetDown(OVRInput.Button.One, this.controlManager.controller))
		{
			this.settingsManager.triggerResetOverride = 0f;
			this.settingsManager.triggerBreakOverride = 0f;
			GameEvents.current.BroadcastMessage("Trigger Override Reset", false);
			this.TriggerOverrideInitiate();
		}
		if ((double)x < -0.4 || (double)x > 0.4)
		{
			if (this.settingsManager.triggerResetOverride == 0f)
			{
				this.settingsManager.triggerResetOverride = 0.19f;
			}
			if (this.settingsManager.triggerBreakOverride == 0f)
			{
				this.settingsManager.triggerBreakOverride = 0.2f;
			}
			if ((double)x < -0.4)
			{
				if (this.triggerOverrideReset)
				{
					if (this.settingsManager.triggerResetOverride > 0f)
					{
						this.settingsManager.triggerResetOverride -= 0.001f;
					}
				}
				else if (this.settingsManager.triggerBreakOverride > 0f && this.settingsManager.triggerBreakOverride >= this.settingsManager.triggerResetOverride + 0.01f)
				{
					this.settingsManager.triggerBreakOverride -= 0.001f;
				}
			}
			if ((double)x > 0.4)
			{
				if (this.triggerOverrideReset)
				{
					if (this.settingsManager.triggerResetOverride < 1f && this.settingsManager.triggerResetOverride <= this.settingsManager.triggerBreakOverride - 0.01f)
					{
						this.settingsManager.triggerResetOverride += 0.001f;
					}
				}
				else if (this.settingsManager.triggerBreakOverride < 1f)
				{
					this.settingsManager.triggerBreakOverride += 0.001f;
				}
			}
			this.TriggerOverrideInitiate();
		}
	}

	// Token: 0x060001BD RID: 445 RVA: 0x000098FA File Offset: 0x00007AFA
	private void OnEnable()
	{
		if (this.subMenuType == MenuButton.SubMenuType.Delete || this.subMenuType == MenuButton.SubMenuType.DeleteCalibration)
		{
			this.ResetDelete();
		}
	}

	// Token: 0x060001BE RID: 446 RVA: 0x00009915 File Offset: 0x00007B15
	private void FixedUpdate()
	{
		if (this.testActivate)
		{
			this.Select();
			this.testActivate = false;
		}
		if (this.highlight != null && this.highlight.activeSelf)
		{
			this.highlight.SetActive(false);
		}
	}

	// Token: 0x060001BF RID: 447 RVA: 0x00009953 File Offset: 0x00007B53
	public void Highlight()
	{
		if (this.highlight != null && !this.highlight.activeSelf)
		{
			this.highlight.SetActive(true);
		}
	}

	// Token: 0x060001C0 RID: 448 RVA: 0x0000997C File Offset: 0x00007B7C
	public bool HasWeapon()
	{
		HolsterVolume holsterVolume = Object.FindObjectOfType<HolsterVolume>();
		return holsterVolume != null && (holsterVolume.GetComponentInChildren<HolsterControl>() || holsterVolume.GetComponentInChildren<WeaponController>()) && holsterVolume.GetComponentInChildren<HolsterControl>().locked;
	}

	// Token: 0x060001C1 RID: 449 RVA: 0x000099C4 File Offset: 0x00007BC4
	public void Select()
	{
		if (this.type == MenuButton.ButtonType.TriggerOverride)
		{
			this.triggerOverrideReset = !this.triggerOverrideReset;
			if (this.settingsManager.triggerResetOverride == 0f || this.settingsManager.triggerBreakOverride == 0f)
			{
				GameEvents.current.BroadcastMessage("[Joystick] to adjust, [A/X] to reset", false);
			}
			this.TriggerOverrideInitiate();
		}
		if (this.type == MenuButton.ButtonType.Text)
		{
			Object.FindObjectOfType<KeyboardManager>().ActivateKeyboard(true, this.testKeyboard);
		}
		if (this.type == MenuButton.ButtonType.LoadLevel)
		{
			if (this.requireWeapon && !this.HasWeapon())
			{
				this.soundManager.Play(this.soundManager.UIerror);
				GameEvents.current.BroadcastMessage("Equip and lock a firearm before proceeding", false);
				return;
			}
			Object.FindObjectOfType<SceneLoader>().loadMode = this.buttonLoadMode;
			if (this.reload)
			{
				SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
			}
			else
			{
				SceneManager.LoadScene(this.sceneToLoad);
			}
		}
		if (this.type == MenuButton.ButtonType.SaveData && this.filesMenu != null)
		{
			this.filesMenu.ActivateMenu(true, CustomStageMenu.MenuMode.Save);
			this.selectedHighlight.SetActive(true);
		}
		if (this.type == MenuButton.ButtonType.LoadData && this.filesMenu != null)
		{
			this.filesMenu.ActivateMenu(true, CustomStageMenu.MenuMode.Load);
			this.selectedHighlight.SetActive(true);
		}
		if (this.type == MenuButton.ButtonType.Rename && this.filesMenu != null)
		{
			this.filesMenu.ActivateMenu(true, CustomStageMenu.MenuMode.Rename);
			this.selectedHighlight.SetActive(true);
		}
		if (this.type == MenuButton.ButtonType.Delete && this.filesMenu != null)
		{
			this.filesMenu.ActivateMenu(true, CustomStageMenu.MenuMode.Delete);
			this.selectedHighlight.SetActive(true);
		}
		if (this.type == MenuButton.ButtonType.OverWrite)
		{
			if (this.saveManager.currentOpenedFile == "")
			{
				this.saveManager.Save(this.sceneSettings.customStageName + "_Default");
			}
			else
			{
				this.saveManager.Save(this.saveManager.currentOpenedFile);
			}
			if (Object.FindObjectOfType<CustomStageMenu>())
			{
				Object.FindObjectOfType<CustomStageMenu>().ResetList();
			}
			this.soundManager.Play(this.soundManager.UIcorrect);
		}
		if (this.type == MenuButton.ButtonType.Delete && this.filesMenu != null)
		{
			this.filesMenu.ActivateMenu(true, CustomStageMenu.MenuMode.Delete);
			this.selectedHighlight.SetActive(true);
		}
		if (this.type == MenuButton.ButtonType.ResetTargets)
		{
			this.saveManager.ResetCustomStage();
		}
		if (this.type == MenuButton.ButtonType.Settings)
		{
			if (this.subMenuType == MenuButton.SubMenuType.Delete || this.subMenuType == MenuButton.SubMenuType.DeleteCalibration)
			{
				this.soundManager.Play(this.soundManager.UIclick);
				if (this.deleteOriginalText.activeSelf && !this.deleteObjectAreYouSure.activeSelf && !this.deleteObjectReallySure.activeSelf && !this.deleteObjectDeleted.activeSelf)
				{
					this.deleteOriginalText.SetActive(false);
					this.deleteObjectAreYouSure.SetActive(true);
					this.deleteObjectReallySure.SetActive(false);
					this.deleteObjectDeleted.SetActive(false);
					return;
				}
				if (!this.deleteOriginalText.activeSelf && this.deleteObjectAreYouSure.activeSelf && !this.deleteObjectReallySure.activeSelf && !this.deleteObjectDeleted.activeSelf)
				{
					this.deleteOriginalText.SetActive(false);
					this.deleteObjectAreYouSure.SetActive(false);
					this.deleteObjectReallySure.SetActive(true);
					this.deleteObjectDeleted.SetActive(false);
					return;
				}
				if (this.deleteOriginalText.activeSelf || this.deleteObjectAreYouSure.activeSelf || !this.deleteObjectReallySure.activeSelf || this.deleteObjectDeleted.activeSelf)
				{
					this.soundManager.Play(this.soundManager.UIerror);
					return;
				}
				this.deleteOriginalText.SetActive(false);
				this.deleteObjectAreYouSure.SetActive(false);
				this.deleteObjectReallySure.SetActive(false);
				this.deleteObjectDeleted.SetActive(true);
				if (this.subMenuType == MenuButton.SubMenuType.Delete)
				{
					SaveSystem.DeleteResults();
					return;
				}
				if (this.subMenuType == MenuButton.SubMenuType.DeleteCalibration)
				{
					Object.FindObjectOfType<PlayerData>().DeleteCalibration();
				}
				return;
			}
			else if (!this.subMenuOpened)
			{
				this.subMenuAnimator.SetTrigger("ActivateSettings");
				this.subMenuOpened = true;
			}
			else
			{
				this.subMenuAnimator.SetTrigger("DeactivateSettings");
				this.subMenuOpened = false;
			}
		}
		if (this.type == MenuButton.ButtonType.SubMenu)
		{
			if (this.subMenuType == MenuButton.SubMenuType.FreeRanges)
			{
				if (!this.subMenuOpened)
				{
					this.subMenuAnimator.SetTrigger("ActivateFreeRanges");
					this.subMenuOpened = true;
				}
				else
				{
					this.subMenuAnimator.SetTrigger("DeactivateFreeRanges");
					this.subMenuOpened = false;
				}
			}
			if (this.subMenuType == MenuButton.SubMenuType.CompMode)
			{
				if (!this.subMenuOpened)
				{
					this.subMenuAnimator.SetTrigger("ActivateCompStages");
					this.subMenuOpened = true;
				}
				else
				{
					this.subMenuAnimator.SetTrigger("DeactivateCompStages");
					this.subMenuOpened = false;
				}
			}
			if (this.subMenuType == MenuButton.SubMenuType.Tutorials)
			{
				if (!this.subMenuOpened)
				{
					this.subMenuAnimator.SetTrigger("ActivateTutorials");
					this.subMenuOpened = true;
				}
				else
				{
					this.subMenuAnimator.SetTrigger("DeactivateTutorials");
					this.subMenuOpened = false;
				}
			}
			if (this.subMenuType == MenuButton.SubMenuType.CustomiseStage)
			{
				if (!this.subMenuOpened)
				{
					this.subMenuAnimator.SetTrigger("ActivateCustomStages");
					this.subMenuOpened = true;
				}
				else
				{
					this.subMenuAnimator.SetTrigger("DeactivateCustomStages");
					this.subMenuOpened = false;
				}
			}
			if (this.subMenuType == MenuButton.SubMenuType.ExtraInfo)
			{
				if (!this.subMenuOpened)
				{
					this.subMenuAnimator.SetTrigger("ActivateInfo");
					this.subMenuOpened = true;
				}
				else
				{
					this.subMenuAnimator.SetTrigger("DeactivateInfo");
					this.subMenuOpened = false;
				}
			}
			if (this.subMenuType == MenuButton.SubMenuType.FAQ)
			{
				if (!this.subMenuOpened)
				{
					this.subMenuAnimator.SetTrigger("ActivateFAQ");
					this.subMenuOpened = true;
				}
				else
				{
					this.subMenuAnimator.SetTrigger("DeactivateFAQ");
					this.subMenuOpened = false;
				}
			}
			if (this.subMenuType == MenuButton.SubMenuType.CompSubMenu)
			{
				if (!this.subMenuOpened)
				{
					this.subMenuAnimator.SetTrigger(this.subMenuActivateTrigger);
					this.subMenuOpened = true;
				}
				else
				{
					this.subMenuAnimator.SetTrigger(this.subMenuDeactivateTrigger);
					this.subMenuOpened = false;
				}
			}
		}
		this.soundManager.Play(this.soundManager.UIclick);
	}

	// Token: 0x060001C2 RID: 450 RVA: 0x0000A003 File Offset: 0x00008203
	private void OnSaveMenuDisabled()
	{
		if (this.selectedHighlight != null)
		{
			this.selectedHighlight.SetActive(false);
		}
	}

	// Token: 0x060001C3 RID: 451 RVA: 0x0000A01F File Offset: 0x0000821F
	private void ResetDelete()
	{
		this.deleteOriginalText.SetActive(true);
		this.deleteObjectAreYouSure.SetActive(false);
		this.deleteObjectReallySure.SetActive(false);
		this.deleteObjectDeleted.SetActive(false);
	}

	// Token: 0x060001C4 RID: 452 RVA: 0x0000A051 File Offset: 0x00008251
	private void OnDestroy()
	{
		GameEvents.current.onSaveMenuDisabled -= this.OnSaveMenuDisabled;
	}

	// Token: 0x04000156 RID: 342
	[SerializeField]
	public MenuButton.SubMenuType subMenuType;

	// Token: 0x04000157 RID: 343
	[SerializeField]
	private Animator subMenuAnimator;

	// Token: 0x04000158 RID: 344
	[SerializeField]
	private MenuButton.ButtonType type;

	// Token: 0x04000159 RID: 345
	[SerializeField]
	private int sceneToLoad;

	// Token: 0x0400015A RID: 346
	[SerializeField]
	private bool reload;

	// Token: 0x0400015B RID: 347
	[SerializeField]
	private bool requireWeapon;

	// Token: 0x0400015C RID: 348
	[SerializeField]
	private GameObject highlight;

	// Token: 0x0400015D RID: 349
	[SerializeField]
	private GameObject selectedHighlight;

	// Token: 0x0400015E RID: 350
	[SerializeField]
	private CustomStageMenu filesMenu;

	// Token: 0x0400015F RID: 351
	[SerializeField]
	private string subMenuActivateTrigger;

	// Token: 0x04000160 RID: 352
	[SerializeField]
	private string subMenuDeactivateTrigger;

	// Token: 0x04000161 RID: 353
	[Header("Delete Texts")]
	[SerializeField]
	private GameObject deleteOriginalText;

	// Token: 0x04000162 RID: 354
	[SerializeField]
	private GameObject deleteObjectAreYouSure;

	// Token: 0x04000163 RID: 355
	[SerializeField]
	private GameObject deleteObjectReallySure;

	// Token: 0x04000164 RID: 356
	[SerializeField]
	private GameObject deleteObjectDeleted;

	// Token: 0x04000165 RID: 357
	[SerializeField]
	private bool testActivate;

	// Token: 0x04000166 RID: 358
	[SerializeField]
	private SceneLoader.LoadMode buttonLoadMode;

	// Token: 0x04000167 RID: 359
	[SerializeField]
	private Transform testKeyboard;

	// Token: 0x04000168 RID: 360
	[SerializeField]
	private TMP_Text triggerValue;

	// Token: 0x04000169 RID: 361
	[SerializeField]
	private TMP_Text textBox;

	// Token: 0x0400016A RID: 362
	private bool subMenuOpened;

	// Token: 0x0400016B RID: 363
	private SoundManager soundManager;

	// Token: 0x0400016C RID: 364
	private SaveManager saveManager;

	// Token: 0x0400016D RID: 365
	private SceneSettings sceneSettings;

	// Token: 0x0400016E RID: 366
	private bool triggerOverrideReset;

	// Token: 0x0400016F RID: 367
	private ControlManager controlManager;

	// Token: 0x04000170 RID: 368
	private SettingsManager settingsManager;

	// Token: 0x020001B4 RID: 436
	public enum ButtonType
	{
		// Token: 0x04000D26 RID: 3366
		LoadLevel,
		// Token: 0x04000D27 RID: 3367
		ResetTargets,
		// Token: 0x04000D28 RID: 3368
		SaveData,
		// Token: 0x04000D29 RID: 3369
		OverWrite,
		// Token: 0x04000D2A RID: 3370
		LoadData,
		// Token: 0x04000D2B RID: 3371
		SubMenu,
		// Token: 0x04000D2C RID: 3372
		Info,
		// Token: 0x04000D2D RID: 3373
		Settings,
		// Token: 0x04000D2E RID: 3374
		Text,
		// Token: 0x04000D2F RID: 3375
		Rename,
		// Token: 0x04000D30 RID: 3376
		Delete,
		// Token: 0x04000D31 RID: 3377
		TriggerOverride
	}

	// Token: 0x020001B5 RID: 437
	public enum SubMenuType
	{
		// Token: 0x04000D33 RID: 3379
		FreeRanges,
		// Token: 0x04000D34 RID: 3380
		CompMode,
		// Token: 0x04000D35 RID: 3381
		Tutorials,
		// Token: 0x04000D36 RID: 3382
		CustomiseWeapon,
		// Token: 0x04000D37 RID: 3383
		CustomiseStage,
		// Token: 0x04000D38 RID: 3384
		ExtraInfo,
		// Token: 0x04000D39 RID: 3385
		Settings,
		// Token: 0x04000D3A RID: 3386
		Delete,
		// Token: 0x04000D3B RID: 3387
		CompSubMenu,
		// Token: 0x04000D3C RID: 3388
		FAQ,
		// Token: 0x04000D3D RID: 3389
		DeleteCalibration
	}
}
