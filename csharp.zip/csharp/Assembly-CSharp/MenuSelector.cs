﻿using System;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x02000032 RID: 50
public class MenuSelector : MonoBehaviour
{
	// Token: 0x060001CC RID: 460 RVA: 0x0000A1B0 File Offset: 0x000083B0
	private void Start()
	{
		this.grabber = base.GetComponent<OVRGrabber>();
		this.lineRenderer = base.GetComponent<LineRenderer>();
		this.control = Object.FindObjectOfType<ControlManager>();
		this.gameManager = base.GetComponent<GameManager>();
		this.ToggleLineRenderer(false);
		SceneManager.sceneLoaded += this.OnSceneLoaded;
	}

	// Token: 0x060001CD RID: 461 RVA: 0x0000A204 File Offset: 0x00008404
	private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
	{
		if (Object.FindObjectOfType<SceneSettings>() && Object.FindObjectOfType<SceneSettings>().isTutorial)
		{
			this.control.status = ControlManager.Status.Hand;
			this.inHolsterVolume = false;
		}
	}

	// Token: 0x060001CE RID: 462 RVA: 0x0000A234 File Offset: 0x00008434
	private void Update()
	{
		if (this.pointerTransform.gameObject.activeSelf)
		{
			if (this.control.status == ControlManager.Status.Hand)
			{
				if (this.grabber.grabbedObject == null && OVRInput.Get(OVRInput.NearTouch.PrimaryIndexTrigger, this.grabber.controllerType) && !this.inHolsterVolume)
				{
					this.ToggleLineRenderer(true);
					this.lineOn = true;
				}
				else
				{
					this.ToggleLineRenderer(false);
					this.lineOn = false;
				}
			}
			this.DrawLine();
		}
		else
		{
			this.DisableLine();
		}
		this.ButtonDetection();
		this.ButtonReset();
	}

	// Token: 0x060001CF RID: 463 RVA: 0x0000A2C7 File Offset: 0x000084C7
	private void DisableLine()
	{
		this.lineRenderer.enabled = false;
	}

	// Token: 0x060001D0 RID: 464 RVA: 0x0000A2D8 File Offset: 0x000084D8
	private void DrawLine()
	{
		if (!this.lineRenderer.enabled)
		{
			this.lineRenderer.enabled = true;
		}
		this.lineRenderer.SetPosition(0, this.CurrentPointerTransform().position);
		Vector3 position;
		if (this.pointPosition != Vector3.zero)
		{
			position = this.pointPosition;
		}
		else
		{
			position = this.CurrentPointerTransform().position + this.CurrentPointerTransform().forward * 5f;
		}
		this.lineRenderer.SetPosition(1, position);
	}

	// Token: 0x060001D1 RID: 465 RVA: 0x0000A364 File Offset: 0x00008564
	public void ToggleLineRenderer(bool on)
	{
		if (on)
		{
			this.lineRenderer.startWidth = 0.005f;
			this.lineRenderer.endWidth = 0.005f;
			return;
		}
		this.lineRenderer.startWidth = 0f;
		this.lineRenderer.endWidth = 0f;
	}

	// Token: 0x060001D2 RID: 466 RVA: 0x0000A3B5 File Offset: 0x000085B5
	private void OnTriggerStay(Collider other)
	{
		if (this.control.status == ControlManager.Status.Hand && other.GetComponent<OVRGrabbable>())
		{
			this.inHolsterVolume = true;
		}
	}

	// Token: 0x060001D3 RID: 467 RVA: 0x0000A3D9 File Offset: 0x000085D9
	private Transform CurrentPointerTransform()
	{
		if (this.control.controllerMode == ControlManager.ControllerMode.ControlAR2)
		{
			return this.pointerTransformStraightStock;
		}
		return this.pointerTransform;
	}

	// Token: 0x060001D4 RID: 468 RVA: 0x0000A3F6 File Offset: 0x000085F6
	private void OnTriggerExit(Collider other)
	{
		if (this.control.status == ControlManager.Status.Hand && other.GetComponent<OVRGrabbable>())
		{
			this.inHolsterVolume = false;
		}
	}

	// Token: 0x060001D5 RID: 469 RVA: 0x0000A41A File Offset: 0x0000861A
	private void DistantGrab()
	{
		this.grabbableRB.useGravity = true;
		GameEvents.current.GrabStart();
		this.grabber.StartGrabBegin();
	}

	// Token: 0x060001D6 RID: 470 RVA: 0x0000A440 File Offset: 0x00008640
	private void ButtonDetection()
	{
		RaycastHit raycastHit;
		if (Physics.Raycast(this.CurrentPointerTransform().position, this.CurrentPointerTransform().forward, out raycastHit, float.PositiveInfinity, this.layerMask))
		{
			if (this.lineOn && raycastHit.transform.GetComponent<OVRGrabbable>() && this.grabber.grabbedObject == null)
			{
				OVRGrabbable component = raycastHit.transform.GetComponent<OVRGrabbable>();
				if (!component.enabled)
				{
					return;
				}
				this.pointPosition = raycastHit.point;
				if (OVRInput.Get(OVRInput.Button.PrimaryHandTrigger, this.grabber.controllerType) && !this.clickRegistered)
				{
					this.clickRegistered = true;
					component.transform.position = base.transform.position + (component.transform.position - component.GetComponent<Collider>().bounds.center);
					MonoBehaviour.print("grabbable center bound distance to hand = " + Vector3.Distance(base.transform.position, component.GetComponent<Collider>().bounds.center));
					component.GetComponent<Rigidbody>().useGravity = false;
					this.grabbableRB = component.GetComponent<Rigidbody>();
					this.DistantGrab();
					base.Invoke("DistantGrab", 0.1f);
					return;
				}
			}
			else if (this.lineOn && raycastHit.transform.tag == "UI-Interactive")
			{
				this.pointPosition = raycastHit.point;
				raycastHit.transform.gameObject.BroadcastMessage("Highlight");
				if (OVRInput.Get(OVRInput.Button.PrimaryIndexTrigger, this.grabber.controllerType) && !this.clickRegistered)
				{
					this.clickRegistered = true;
					raycastHit.transform.gameObject.BroadcastMessage("Select");
					return;
				}
			}
			else if (this.lineOn && raycastHit.transform.GetComponent<MenuButton>())
			{
				this.pointPosition = raycastHit.point;
				MenuButton component2 = raycastHit.transform.GetComponent<MenuButton>();
				component2.Highlight();
				if (OVRInput.Get(OVRInput.Button.PrimaryIndexTrigger, this.grabber.controllerType) && !this.clickRegistered)
				{
					this.clickRegistered = true;
					component2.Select();
					return;
				}
			}
			else if (this.lineOn && raycastHit.transform.GetComponent<KeyboardKey>())
			{
				this.pointPosition = raycastHit.point;
				KeyboardKey component3 = raycastHit.transform.GetComponent<KeyboardKey>();
				component3.Highlight();
				if (OVRInput.Get(OVRInput.Button.PrimaryIndexTrigger, this.grabber.controllerType) && !this.clickRegistered)
				{
					this.clickRegistered = true;
					component3.Select();
					return;
				}
			}
			else if (this.lineOn && raycastHit.transform.GetComponent<WeaponModificationButton>())
			{
				this.pointPosition = raycastHit.point;
				WeaponModificationButton component4 = raycastHit.transform.GetComponent<WeaponModificationButton>();
				component4.Highlight();
				if (OVRInput.Get(OVRInput.Button.PrimaryIndexTrigger, this.grabber.controllerType) && !this.clickRegistered)
				{
					this.clickRegistered = true;
					component4.Select();
					return;
				}
			}
			else if (this.lineOn && raycastHit.transform.GetComponent<SettingsButton>())
			{
				this.pointPosition = raycastHit.point;
				SettingsButton component5 = raycastHit.transform.GetComponent<SettingsButton>();
				component5.Highlight();
				if (OVRInput.Get(OVRInput.Button.PrimaryIndexTrigger, this.grabber.controllerType) && !this.clickRegistered)
				{
					component5.Select();
					this.clickRegistered = true;
					return;
				}
			}
			else if (this.lineOn && raycastHit.transform.GetComponent<ControllerButton>())
			{
				this.pointPosition = raycastHit.point;
				ControllerButton component6 = raycastHit.transform.GetComponent<ControllerButton>();
				component6.Highlight();
				if (OVRInput.Get(OVRInput.Button.PrimaryIndexTrigger, this.grabber.controllerType) && !this.clickRegistered)
				{
					component6.Select();
					this.clickRegistered = true;
					return;
				}
			}
			else
			{
				if (!this.lineOn || !raycastHit.transform.GetComponent<ZeroingTargetButton>())
				{
					this.pointPosition = Vector3.zero;
					return;
				}
				this.pointPosition = raycastHit.point;
				ZeroingTargetButton component7 = raycastHit.transform.GetComponent<ZeroingTargetButton>();
				component7.Highlight();
				if (OVRInput.Get(OVRInput.Button.PrimaryIndexTrigger, this.grabber.controllerType) && !this.clickRegistered)
				{
					component7.Select();
					this.clickRegistered = true;
					return;
				}
			}
		}
		else
		{
			this.pointPosition = Vector3.zero;
		}
	}

	// Token: 0x060001D7 RID: 471 RVA: 0x0000A8E4 File Offset: 0x00008AE4
	private void ButtonReset()
	{
		if (this.clickRegistered && (OVRInput.GetUp(OVRInput.Button.PrimaryIndexTrigger, this.grabber.controllerType) || OVRInput.GetUp(OVRInput.Button.PrimaryHandTrigger, this.grabber.controllerType) || OVRInput.GetUp(OVRInput.Button.One, this.grabber.controllerType)))
		{
			this.clickRegistered = false;
		}
	}

	// Token: 0x04000177 RID: 375
	[SerializeField]
	public Transform pointerTransform;

	// Token: 0x04000178 RID: 376
	[SerializeField]
	public Transform pointerTransformStraightStock;

	// Token: 0x04000179 RID: 377
	private LineRenderer lineRenderer;

	// Token: 0x0400017A RID: 378
	private ControlManager control;

	// Token: 0x0400017B RID: 379
	private OVRGrabber grabber;

	// Token: 0x0400017C RID: 380
	private Vector3 pointPosition;

	// Token: 0x0400017D RID: 381
	[SerializeField]
	private LayerMask layerMask;

	// Token: 0x0400017E RID: 382
	public bool inHolsterVolume;

	// Token: 0x0400017F RID: 383
	private GameManager gameManager;

	// Token: 0x04000180 RID: 384
	private Rigidbody grabbableRB;

	// Token: 0x04000181 RID: 385
	private bool lineOn;

	// Token: 0x04000182 RID: 386
	private bool clickRegistered;
}
