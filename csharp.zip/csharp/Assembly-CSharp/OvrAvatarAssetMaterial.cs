﻿using System;
using Oculus.Avatar;

// Token: 0x020000DE RID: 222
public class OvrAvatarAssetMaterial : OvrAvatarAsset
{
	// Token: 0x06000636 RID: 1590 RVA: 0x00029022 File Offset: 0x00027222
	public OvrAvatarAssetMaterial(ulong id, IntPtr mat)
	{
		this.assetID = id;
		this.material = CAPI.ovrAvatarAsset_GetMaterialState(mat);
	}

	// Token: 0x04000840 RID: 2112
	public ovrAvatarMaterialState material;
}
