﻿using System;
using UnityEngine;

// Token: 0x0200009F RID: 159
public class PoseEditHelper : MonoBehaviour
{
	// Token: 0x0600054A RID: 1354 RVA: 0x00021E34 File Offset: 0x00020034
	private void OnDrawGizmos()
	{
		if (this.poseRoot != null)
		{
			this.DrawJoints(this.poseRoot);
		}
	}

	// Token: 0x0600054B RID: 1355 RVA: 0x00021E50 File Offset: 0x00020050
	private void DrawJoints(Transform joint)
	{
		Gizmos.DrawWireSphere(joint.position, 0.005f);
		for (int i = 0; i < joint.childCount; i++)
		{
			Transform child = joint.GetChild(i);
			if (!child.name.EndsWith("_grip") && !child.name.EndsWith("hand_ignore"))
			{
				Gizmos.DrawLine(joint.position, child.position);
				this.DrawJoints(child);
			}
		}
	}

	// Token: 0x04000671 RID: 1649
	public Transform poseRoot;
}
