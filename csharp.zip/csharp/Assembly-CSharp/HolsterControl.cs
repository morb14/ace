﻿using System;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x0200002E RID: 46
public class HolsterControl : MonoBehaviour
{
	// Token: 0x06000193 RID: 403 RVA: 0x000086FC File Offset: 0x000068FC
	private void Start()
	{
		this.originalPosition = base.transform.position;
		this.originalRotation = base.transform.rotation;
		this.controlManager = Object.FindObjectOfType<ControlManager>();
		this.settingsManager = Object.FindObjectOfType<SettingsManager>();
		this.thisCollider = base.GetComponent<Collider>();
		this.grabbable = base.GetComponent<OVRGrabbable>();
		this.defaultHolster = this.holsterMR.materials[1];
		this.hapticManager = Object.FindObjectOfType<HapticManager>();
		base.GetComponentInChildren<WeaponController>().Holster();
		this.weaponController = base.GetComponentInChildren<WeaponController>();
		this.weapon = this.weaponController.gameObject;
		GameEvents.current.onControllerModeChange += this.CompatibilityCheck;
		this.CompatibilityCheck();
		SceneManager.sceneLoaded += this.UpdateSceneInfo;
		this.returnWeaponToSpawn = Object.FindObjectOfType<SceneSettings>().returnWeaponToSpawn;
	}

	// Token: 0x06000194 RID: 404 RVA: 0x000087DC File Offset: 0x000069DC
	private void UpdateSceneInfo(Scene scene, LoadSceneMode mode)
	{
		this.returnWeaponToSpawn = Object.FindObjectOfType<SceneSettings>().returnWeaponToSpawn;
	}

	// Token: 0x06000195 RID: 405 RVA: 0x000087EE File Offset: 0x000069EE
	private void Update()
	{
		this.CheckGrabbed();
		this.CheckDrawHolster();
		this.PositionReset();
	}

	// Token: 0x06000196 RID: 406 RVA: 0x00008804 File Offset: 0x00006A04
	private void CheckGrabbed()
	{
		if (!this.hasBeenGrabbed && this.grabbable.isGrabbed)
		{
			this.hasBeenGrabbed = true;
		}
		if (this.hasBeenGrabbed && !this.grabbable.isGrabbed)
		{
			this.hasBeenGrabbed = false;
			this.dropReset = true;
		}
	}

	// Token: 0x06000197 RID: 407 RVA: 0x00008850 File Offset: 0x00006A50
	private void PositionReset()
	{
		if (this.dropReset && this.returnWeaponToSpawn)
		{
			MonoBehaviour.print("DROP RESET TRUE");
			if (base.transform.position != this.lastPosition && base.transform.rotation != this.lastRotation)
			{
				this.lastPosition = base.transform.position;
				this.lastRotation = base.transform.rotation;
				return;
			}
			base.Invoke("ResetToSpawn", 2.5f);
			this.dropReset = false;
		}
	}

	// Token: 0x06000198 RID: 408 RVA: 0x000088E4 File Offset: 0x00006AE4
	private void ResetToSpawn()
	{
		if (this.hasBeenGrabbed || base.transform.parent != null)
		{
			return;
		}
		if (base.transform.position == this.lastPosition && base.transform.rotation == this.lastRotation)
		{
			base.transform.position = this.originalPosition;
			base.transform.rotation = this.originalRotation;
			return;
		}
		this.lastPosition = base.transform.position;
		this.lastRotation = base.transform.rotation;
		this.dropReset = true;
	}

	// Token: 0x06000199 RID: 409 RVA: 0x00008989 File Offset: 0x00006B89
	private void CompatibilityCheck()
	{
		if (this.controlManager.controllerMode == ControlManager.ControllerMode.TwoHand && this.preferredMode != ControlManager.ControllerMode.OneHand)
		{
			this.Activate(true);
			return;
		}
		if (!this.Compatible())
		{
			this.Activate(false);
			return;
		}
		this.Activate(true);
	}

	// Token: 0x0600019A RID: 410 RVA: 0x000089C0 File Offset: 0x00006BC0
	private bool Compatible()
	{
		return this.controlManager.controllerMode == this.preferredMode || (this.controlManager.controllerMode == ControlManager.ControllerMode.ControlARPro && this.preferredMode == ControlManager.ControllerMode.ControlAR);
	}

	// Token: 0x0600019B RID: 411 RVA: 0x000089F1 File Offset: 0x00006BF1
	private void Activate(bool status)
	{
		this.grabbable.enabled = status;
		if (base.GetComponent<MaterialAssigner>())
		{
			base.GetComponent<MaterialAssigner>().SwitchMaterial(status, null);
		}
	}

	// Token: 0x0600019C RID: 412 RVA: 0x00008A1C File Offset: 0x00006C1C
	public void InVolume(bool inVolume)
	{
		if (!this.holsterInVolume)
		{
			if (inVolume && !this.locked)
			{
				Material[] materials = this.holsterMR.materials;
				materials[0] = this.holsterMR.materials[0];
				materials[1] = this.holsterInvolume;
				this.holsterMR.materials = materials;
				this.holsterInVolume = true;
				MonoBehaviour.print("YELLOW BUTTON");
				return;
			}
		}
		else if (!inVolume && !this.locked)
		{
			Material[] materials2 = this.holsterMR.materials;
			materials2[0] = this.holsterMR.materials[0];
			materials2[1] = this.holsterUnlocked;
			this.holsterMR.materials = materials2;
			this.holsterInVolume = false;
		}
	}

	// Token: 0x0600019D RID: 413 RVA: 0x00008AC8 File Offset: 0x00006CC8
	public void Lock()
	{
		this.locked = true;
		this.grabbable.isGrabbable = false;
		Material[] materials = this.holsterMR.materials;
		materials[0] = this.holsterMR.materials[0];
		materials[1] = this.holsterLocked;
		GameEvents.current.HolsterLock();
		this.controlManager.currentWeapon = this.weaponController;
		this.holsterMR.materials = materials;
	}

	// Token: 0x0600019E RID: 414 RVA: 0x00008B34 File Offset: 0x00006D34
	private void CheckDrawHolster()
	{
		if (this.colliding && this.grabber != null && this.controlManager.EngagedByCollider() == this.thisCollider && (base.GetComponentInParent<HolsterVolume>() || this.drawOverRide))
		{
			if (OVRInput.GetDown(OVRInput.Button.PrimaryIndexTrigger, this.grabber.controllerType) && !this.gunDrawn && !this.drawOverRide)
			{
				this.locked = !this.locked;
				if (this.grabbable != null)
				{
					this.grabbable.isGrabbable = !this.locked;
				}
				else
				{
					this.grabbable.isGrabbable = !this.locked;
				}
				this.hapticManager.VibrateStandard(0.8f, 0.8f, 0.05f, this.grabber.controllerType);
				if (this.locked)
				{
					Material[] materials = this.holsterMR.materials;
					materials[0] = this.holsterMR.materials[0];
					materials[1] = this.holsterLocked;
					GameEvents.current.HolsterLock();
					this.controlManager.currentWeapon = this.weaponController;
					this.holsterMR.materials = materials;
				}
				if (!this.locked)
				{
					Material[] materials2 = this.holsterMR.materials;
					materials2[0] = this.holsterMR.materials[0];
					materials2[1] = this.holsterUnlocked;
					GameEvents.current.HolsterUnlock();
					this.controlManager.currentWeapon = null;
					this.holsterMR.materials = materials2;
				}
			}
			if (this.locked && OVRInput.Get(OVRInput.Button.PrimaryHandTrigger, this.grabber.controllerType) && !this.gunDrawn && !this.drawError)
			{
				if (OVRInput.Get(OVRInput.NearTouch.PrimaryIndexTrigger, this.grabber.controllerType) && !this.settingsManager.doNotDetectTrigger)
				{
					this.drawError = true;
					base.Invoke("ResetDrawError", 0.2f);
					GameEvents.current.BroadcastMessage("Keep your finger clear of the trigger while drawing", true);
				}
				else
				{
					this.Draw();
				}
			}
			if (this.gunDrawn && OVRInput.GetUp(OVRInput.Button.PrimaryHandTrigger, this.grabber.controllerType))
			{
				this.hapticManager.VibrateStandard(0.8f, 0.4f, 0.05f, this.grabber.controllerType);
				this.Holster(null);
			}
		}
	}

	// Token: 0x0600019F RID: 415 RVA: 0x00008D98 File Offset: 0x00006F98
	private void ResetDrawError()
	{
		this.drawError = false;
	}

	// Token: 0x060001A0 RID: 416 RVA: 0x00008DA1 File Offset: 0x00006FA1
	public void Draw()
	{
		this.gunDrawn = true;
		this.grabber.GetComponent<WeaponEquiper>().Draw(this.weapon);
	}

	// Token: 0x060001A1 RID: 417 RVA: 0x00008DC0 File Offset: 0x00006FC0
	public void Holster(GameObject weaponObject = null)
	{
		if (weaponObject != null)
		{
			this.weapon = weaponObject;
		}
		else
		{
			this.weapon = this.grabber.GetComponent<WeaponEquiper>().Holster(this);
		}
		this.gunDrawn = false;
		this.weapon.transform.parent = this.weaponTransform;
		this.weapon.transform.localPosition = Vector3.zero;
		this.weapon.transform.localEulerAngles = Vector3.zero;
		this.weapon.transform.localScale = Vector3.one;
	}

	// Token: 0x060001A2 RID: 418 RVA: 0x00008E54 File Offset: 0x00007054
	private void OnTriggerEnter(Collider other)
	{
		if (other.GetComponent<OVRGrabber>())
		{
			this.grabber = other.GetComponent<OVRGrabber>();
			if (this.controlManager.controllerMode == ControlManager.ControllerMode.ControlAR2 && this.grabber.controllerType == OVRInput.Controller.LTouch)
			{
				MonoBehaviour.print("IGNORE INVISIBLE HAND COLLIDER");
				return;
			}
			if (this.controlManager.EngagedByCollider() != null && this.controlManager.EngagedByCollider() != this.thisCollider)
			{
				this.controlManager.Engage(true, this.thisCollider);
				this.colliding = true;
				if (this.locked)
				{
					this.hapticManager.VibrateStandard(0.8f, 1f, 0.1f, other.GetComponent<OVRGrabber>().controllerType);
				}
			}
			if (this.controlManager.EngagedByCollider() == null)
			{
				this.controlManager.Engage(true, this.thisCollider);
				this.colliding = true;
				if (this.locked)
				{
					this.hapticManager.VibrateStandard(0.8f, 1f, 0.1f, other.GetComponent<OVRGrabber>().controllerType);
				}
			}
		}
		if (other.GetComponent<HolsterVolume>())
		{
			this.dropReset = false;
		}
	}

	// Token: 0x060001A3 RID: 419 RVA: 0x00008F84 File Offset: 0x00007184
	private void OnTriggerExit(Collider other)
	{
		if (other.GetComponent<OVRGrabber>() && this.controlManager.EngagedByCollider() == this.thisCollider)
		{
			this.controlManager.Engage(false, this.thisCollider);
			this.colliding = false;
			this.grabber = null;
		}
		if (other.GetComponent<HolsterVolume>())
		{
			this.dropReset = true;
		}
	}

	// Token: 0x060001A4 RID: 420 RVA: 0x00008FEC File Offset: 0x000071EC
	public void Reset()
	{
		this.thisCollider.isTrigger = false;
		Material[] materials = this.holsterMR.materials;
		materials[0] = this.holsterMR.materials[0];
		materials[1] = this.defaultHolster;
		this.holsterMR.materials = materials;
		this.holsterInVolume = false;
		this.colliding = false;
	}

	// Token: 0x060001A5 RID: 421 RVA: 0x00009044 File Offset: 0x00007244
	private void OnDestroy()
	{
		GameEvents.current.onControllerModeChange -= this.CompatibilityCheck;
	}

	// Token: 0x0400012B RID: 299
	[SerializeField]
	private Transform weaponTransform;

	// Token: 0x0400012C RID: 300
	[SerializeField]
	private Renderer holsterMR;

	// Token: 0x0400012D RID: 301
	[SerializeField]
	private Material holsterLocked;

	// Token: 0x0400012E RID: 302
	[SerializeField]
	private Material holsterUnlocked;

	// Token: 0x0400012F RID: 303
	[SerializeField]
	private Material holsterInvolume;

	// Token: 0x04000130 RID: 304
	[SerializeField]
	private OVRGrabbable grabbable;

	// Token: 0x04000131 RID: 305
	[SerializeField]
	private ControlManager.ControllerMode preferredMode;

	// Token: 0x04000132 RID: 306
	[SerializeField]
	public bool drawOverRide;

	// Token: 0x04000133 RID: 307
	private Material defaultHolster;

	// Token: 0x04000134 RID: 308
	private HapticManager hapticManager;

	// Token: 0x04000135 RID: 309
	private WeaponController weaponController;

	// Token: 0x04000136 RID: 310
	private SettingsManager settingsManager;

	// Token: 0x04000137 RID: 311
	public bool locked;

	// Token: 0x04000138 RID: 312
	private bool dropReset;

	// Token: 0x04000139 RID: 313
	private bool hasBeenGrabbed;

	// Token: 0x0400013A RID: 314
	private bool returnWeaponToSpawn;

	// Token: 0x0400013B RID: 315
	private bool drawError;

	// Token: 0x0400013C RID: 316
	private Vector3 originalPosition;

	// Token: 0x0400013D RID: 317
	private Vector3 lastPosition;

	// Token: 0x0400013E RID: 318
	private Quaternion originalRotation;

	// Token: 0x0400013F RID: 319
	private Quaternion lastRotation;

	// Token: 0x04000140 RID: 320
	private ControlManager controlManager;

	// Token: 0x04000141 RID: 321
	public bool gunDrawn;

	// Token: 0x04000142 RID: 322
	public bool colliding;

	// Token: 0x04000143 RID: 323
	public bool holsterInVolume;

	// Token: 0x04000144 RID: 324
	private OVRGrabber grabber;

	// Token: 0x04000145 RID: 325
	private Collider thisCollider;

	// Token: 0x04000146 RID: 326
	[SerializeField]
	private GameObject weapon;
}
