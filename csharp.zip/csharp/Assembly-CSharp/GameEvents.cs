﻿using System;
using UnityEngine;

// Token: 0x0200002B RID: 43
public class GameEvents : MonoBehaviour
{
	// Token: 0x060000DB RID: 219 RVA: 0x000065CE File Offset: 0x000047CE
	private void Awake()
	{
		GameEvents.current = this;
	}

	// Token: 0x14000001 RID: 1
	// (add) Token: 0x060000DC RID: 220 RVA: 0x000065D8 File Offset: 0x000047D8
	// (remove) Token: 0x060000DD RID: 221 RVA: 0x00006610 File Offset: 0x00004810
	public event Action onHolster;

	// Token: 0x14000002 RID: 2
	// (add) Token: 0x060000DE RID: 222 RVA: 0x00006648 File Offset: 0x00004848
	// (remove) Token: 0x060000DF RID: 223 RVA: 0x00006680 File Offset: 0x00004880
	public event Action onHolsterDraw;

	// Token: 0x14000003 RID: 3
	// (add) Token: 0x060000E0 RID: 224 RVA: 0x000066B8 File Offset: 0x000048B8
	// (remove) Token: 0x060000E1 RID: 225 RVA: 0x000066F0 File Offset: 0x000048F0
	public event Action onShotFired;

	// Token: 0x14000004 RID: 4
	// (add) Token: 0x060000E2 RID: 226 RVA: 0x00006728 File Offset: 0x00004928
	// (remove) Token: 0x060000E3 RID: 227 RVA: 0x00006760 File Offset: 0x00004960
	public event Action onShotThroughProcedural;

	// Token: 0x14000005 RID: 5
	// (add) Token: 0x060000E4 RID: 228 RVA: 0x00006798 File Offset: 0x00004998
	// (remove) Token: 0x060000E5 RID: 229 RVA: 0x000067D0 File Offset: 0x000049D0
	public event Action onGunEmpty;

	// Token: 0x14000006 RID: 6
	// (add) Token: 0x060000E6 RID: 230 RVA: 0x00006808 File Offset: 0x00004A08
	// (remove) Token: 0x060000E7 RID: 231 RVA: 0x00006840 File Offset: 0x00004A40
	public event Action onChamberEmpty;

	// Token: 0x14000007 RID: 7
	// (add) Token: 0x060000E8 RID: 232 RVA: 0x00006878 File Offset: 0x00004A78
	// (remove) Token: 0x060000E9 RID: 233 RVA: 0x000068B0 File Offset: 0x00004AB0
	public event Action onShootingAreaEnter;

	// Token: 0x14000008 RID: 8
	// (add) Token: 0x060000EA RID: 234 RVA: 0x000068E8 File Offset: 0x00004AE8
	// (remove) Token: 0x060000EB RID: 235 RVA: 0x00006920 File Offset: 0x00004B20
	public event Action onShootingAreaExit;

	// Token: 0x14000009 RID: 9
	// (add) Token: 0x060000EC RID: 236 RVA: 0x00006958 File Offset: 0x00004B58
	// (remove) Token: 0x060000ED RID: 237 RVA: 0x00006990 File Offset: 0x00004B90
	public event Action onShootingAreaCheck;

	// Token: 0x1400000A RID: 10
	// (add) Token: 0x060000EE RID: 238 RVA: 0x000069C8 File Offset: 0x00004BC8
	// (remove) Token: 0x060000EF RID: 239 RVA: 0x00006A00 File Offset: 0x00004C00
	public event Action onStartingAreaExit;

	// Token: 0x1400000B RID: 11
	// (add) Token: 0x060000F0 RID: 240 RVA: 0x00006A38 File Offset: 0x00004C38
	// (remove) Token: 0x060000F1 RID: 241 RVA: 0x00006A70 File Offset: 0x00004C70
	public event Action onStartingAreaEnter;

	// Token: 0x1400000C RID: 12
	// (add) Token: 0x060000F2 RID: 242 RVA: 0x00006AA8 File Offset: 0x00004CA8
	// (remove) Token: 0x060000F3 RID: 243 RVA: 0x00006AE0 File Offset: 0x00004CE0
	public event Action onStickForward;

	// Token: 0x1400000D RID: 13
	// (add) Token: 0x060000F4 RID: 244 RVA: 0x00006B18 File Offset: 0x00004D18
	// (remove) Token: 0x060000F5 RID: 245 RVA: 0x00006B50 File Offset: 0x00004D50
	public event Action onStickRelease;

	// Token: 0x1400000E RID: 14
	// (add) Token: 0x060000F6 RID: 246 RVA: 0x00006B88 File Offset: 0x00004D88
	// (remove) Token: 0x060000F7 RID: 247 RVA: 0x00006BC0 File Offset: 0x00004DC0
	public event Action onStageConditionMet;

	// Token: 0x1400000F RID: 15
	// (add) Token: 0x060000F8 RID: 248 RVA: 0x00006BF8 File Offset: 0x00004DF8
	// (remove) Token: 0x060000F9 RID: 249 RVA: 0x00006C30 File Offset: 0x00004E30
	public event Action onStageConditionUnmet;

	// Token: 0x14000010 RID: 16
	// (add) Token: 0x060000FA RID: 250 RVA: 0x00006C68 File Offset: 0x00004E68
	// (remove) Token: 0x060000FB RID: 251 RVA: 0x00006CA0 File Offset: 0x00004EA0
	public event Action onDisqualify;

	// Token: 0x14000011 RID: 17
	// (add) Token: 0x060000FC RID: 252 RVA: 0x00006CD8 File Offset: 0x00004ED8
	// (remove) Token: 0x060000FD RID: 253 RVA: 0x00006D10 File Offset: 0x00004F10
	public event Action onBreaking90;

	// Token: 0x14000012 RID: 18
	// (add) Token: 0x060000FE RID: 254 RVA: 0x00006D48 File Offset: 0x00004F48
	// (remove) Token: 0x060000FF RID: 255 RVA: 0x00006D80 File Offset: 0x00004F80
	public event Action onGrabStart;

	// Token: 0x14000013 RID: 19
	// (add) Token: 0x06000100 RID: 256 RVA: 0x00006DB8 File Offset: 0x00004FB8
	// (remove) Token: 0x06000101 RID: 257 RVA: 0x00006DF0 File Offset: 0x00004FF0
	public event Action onGrabEnd;

	// Token: 0x14000014 RID: 20
	// (add) Token: 0x06000102 RID: 258 RVA: 0x00006E28 File Offset: 0x00005028
	// (remove) Token: 0x06000103 RID: 259 RVA: 0x00006E60 File Offset: 0x00005060
	public event Action onControllerModeChange;

	// Token: 0x14000015 RID: 21
	// (add) Token: 0x06000104 RID: 260 RVA: 0x00006E98 File Offset: 0x00005098
	// (remove) Token: 0x06000105 RID: 261 RVA: 0x00006ED0 File Offset: 0x000050D0
	public event Action onHolsterLock;

	// Token: 0x14000016 RID: 22
	// (add) Token: 0x06000106 RID: 262 RVA: 0x00006F08 File Offset: 0x00005108
	// (remove) Token: 0x06000107 RID: 263 RVA: 0x00006F40 File Offset: 0x00005140
	public event Action onHolsterUnlock;

	// Token: 0x14000017 RID: 23
	// (add) Token: 0x06000108 RID: 264 RVA: 0x00006F78 File Offset: 0x00005178
	// (remove) Token: 0x06000109 RID: 265 RVA: 0x00006FB0 File Offset: 0x000051B0
	public event Action onMagazineLoad;

	// Token: 0x14000018 RID: 24
	// (add) Token: 0x0600010A RID: 266 RVA: 0x00006FE8 File Offset: 0x000051E8
	// (remove) Token: 0x0600010B RID: 267 RVA: 0x00007020 File Offset: 0x00005220
	public event Action onMagazineUnload;

	// Token: 0x14000019 RID: 25
	// (add) Token: 0x0600010C RID: 268 RVA: 0x00007058 File Offset: 0x00005258
	// (remove) Token: 0x0600010D RID: 269 RVA: 0x00007090 File Offset: 0x00005290
	public event Action onSafetyOn;

	// Token: 0x1400001A RID: 26
	// (add) Token: 0x0600010E RID: 270 RVA: 0x000070C8 File Offset: 0x000052C8
	// (remove) Token: 0x0600010F RID: 271 RVA: 0x00007100 File Offset: 0x00005300
	public event Action onSafetyOff;

	// Token: 0x1400001B RID: 27
	// (add) Token: 0x06000110 RID: 272 RVA: 0x00007138 File Offset: 0x00005338
	// (remove) Token: 0x06000111 RID: 273 RVA: 0x00007170 File Offset: 0x00005370
	public event Action onRoundChambered;

	// Token: 0x1400001C RID: 28
	// (add) Token: 0x06000112 RID: 274 RVA: 0x000071A8 File Offset: 0x000053A8
	// (remove) Token: 0x06000113 RID: 275 RVA: 0x000071E0 File Offset: 0x000053E0
	public event Action onSlideRelease;

	// Token: 0x1400001D RID: 29
	// (add) Token: 0x06000114 RID: 276 RVA: 0x00007218 File Offset: 0x00005418
	// (remove) Token: 0x06000115 RID: 277 RVA: 0x00007250 File Offset: 0x00005450
	public event Action onTutorialStageAdvanced;

	// Token: 0x1400001E RID: 30
	// (add) Token: 0x06000116 RID: 278 RVA: 0x00007288 File Offset: 0x00005488
	// (remove) Token: 0x06000117 RID: 279 RVA: 0x000072C0 File Offset: 0x000054C0
	public event Action onStageStart;

	// Token: 0x1400001F RID: 31
	// (add) Token: 0x06000118 RID: 280 RVA: 0x000072F8 File Offset: 0x000054F8
	// (remove) Token: 0x06000119 RID: 281 RVA: 0x00007330 File Offset: 0x00005530
	public event Action onStageFinish;

	// Token: 0x14000020 RID: 32
	// (add) Token: 0x0600011A RID: 282 RVA: 0x00007368 File Offset: 0x00005568
	// (remove) Token: 0x0600011B RID: 283 RVA: 0x000073A0 File Offset: 0x000055A0
	public event Action onTeleported;

	// Token: 0x14000021 RID: 33
	// (add) Token: 0x0600011C RID: 284 RVA: 0x000073D8 File Offset: 0x000055D8
	// (remove) Token: 0x0600011D RID: 285 RVA: 0x00007410 File Offset: 0x00005610
	public event Action onTargetTypeChange;

	// Token: 0x14000022 RID: 34
	// (add) Token: 0x0600011E RID: 286 RVA: 0x00007448 File Offset: 0x00005648
	// (remove) Token: 0x0600011F RID: 287 RVA: 0x00007480 File Offset: 0x00005680
	public event Action onBreakRecordPlayed;

	// Token: 0x14000023 RID: 35
	// (add) Token: 0x06000120 RID: 288 RVA: 0x000074B8 File Offset: 0x000056B8
	// (remove) Token: 0x06000121 RID: 289 RVA: 0x000074F0 File Offset: 0x000056F0
	public event Action onBreakRecordVirginiaCount;

	// Token: 0x14000024 RID: 36
	// (add) Token: 0x06000122 RID: 290 RVA: 0x00007528 File Offset: 0x00005728
	// (remove) Token: 0x06000123 RID: 291 RVA: 0x00007560 File Offset: 0x00005760
	public event Action onBreakRecordBronze;

	// Token: 0x14000025 RID: 37
	// (add) Token: 0x06000124 RID: 292 RVA: 0x00007598 File Offset: 0x00005798
	// (remove) Token: 0x06000125 RID: 293 RVA: 0x000075D0 File Offset: 0x000057D0
	public event Action onBreakRecordSilver;

	// Token: 0x14000026 RID: 38
	// (add) Token: 0x06000126 RID: 294 RVA: 0x00007608 File Offset: 0x00005808
	// (remove) Token: 0x06000127 RID: 295 RVA: 0x00007640 File Offset: 0x00005840
	public event Action onBreakRecordGold;

	// Token: 0x14000027 RID: 39
	// (add) Token: 0x06000128 RID: 296 RVA: 0x00007678 File Offset: 0x00005878
	// (remove) Token: 0x06000129 RID: 297 RVA: 0x000076B0 File Offset: 0x000058B0
	public event Action onSceneSettingsTransferred;

	// Token: 0x14000028 RID: 40
	// (add) Token: 0x0600012A RID: 298 RVA: 0x000076E8 File Offset: 0x000058E8
	// (remove) Token: 0x0600012B RID: 299 RVA: 0x00007720 File Offset: 0x00005920
	public event Action onEnableKeyboard;

	// Token: 0x14000029 RID: 41
	// (add) Token: 0x0600012C RID: 300 RVA: 0x00007758 File Offset: 0x00005958
	// (remove) Token: 0x0600012D RID: 301 RVA: 0x00007790 File Offset: 0x00005990
	public event Action onDisableKeyboard;

	// Token: 0x1400002A RID: 42
	// (add) Token: 0x0600012E RID: 302 RVA: 0x000077C8 File Offset: 0x000059C8
	// (remove) Token: 0x0600012F RID: 303 RVA: 0x00007800 File Offset: 0x00005A00
	public event Action onKeyboardKeyPressed;

	// Token: 0x1400002B RID: 43
	// (add) Token: 0x06000130 RID: 304 RVA: 0x00007838 File Offset: 0x00005A38
	// (remove) Token: 0x06000131 RID: 305 RVA: 0x00007870 File Offset: 0x00005A70
	public event Action onKeyboardHighlighted;

	// Token: 0x1400002C RID: 44
	// (add) Token: 0x06000132 RID: 306 RVA: 0x000078A8 File Offset: 0x00005AA8
	// (remove) Token: 0x06000133 RID: 307 RVA: 0x000078E0 File Offset: 0x00005AE0
	public event Action onKeyboardCaseToggle;

	// Token: 0x1400002D RID: 45
	// (add) Token: 0x06000134 RID: 308 RVA: 0x00007918 File Offset: 0x00005B18
	// (remove) Token: 0x06000135 RID: 309 RVA: 0x00007950 File Offset: 0x00005B50
	public event Action onKeyboardReturnPressed;

	// Token: 0x1400002E RID: 46
	// (add) Token: 0x06000136 RID: 310 RVA: 0x00007988 File Offset: 0x00005B88
	// (remove) Token: 0x06000137 RID: 311 RVA: 0x000079C0 File Offset: 0x00005BC0
	public event Action onNewCustomStageLoad;

	// Token: 0x1400002F RID: 47
	// (add) Token: 0x06000138 RID: 312 RVA: 0x000079F8 File Offset: 0x00005BF8
	// (remove) Token: 0x06000139 RID: 313 RVA: 0x00007A30 File Offset: 0x00005C30
	public event Action onStagePlannerCompStart;

	// Token: 0x14000030 RID: 48
	// (add) Token: 0x0600013A RID: 314 RVA: 0x00007A68 File Offset: 0x00005C68
	// (remove) Token: 0x0600013B RID: 315 RVA: 0x00007AA0 File Offset: 0x00005CA0
	public event Action onStagePlannerCompEnd;

	// Token: 0x14000031 RID: 49
	// (add) Token: 0x0600013C RID: 316 RVA: 0x00007AD8 File Offset: 0x00005CD8
	// (remove) Token: 0x0600013D RID: 317 RVA: 0x00007B10 File Offset: 0x00005D10
	public event Action onSaveMenuDisabled;

	// Token: 0x14000032 RID: 50
	// (add) Token: 0x0600013E RID: 318 RVA: 0x00007B48 File Offset: 0x00005D48
	// (remove) Token: 0x0600013F RID: 319 RVA: 0x00007B80 File Offset: 0x00005D80
	public event Action onScenePopulated;

	// Token: 0x14000033 RID: 51
	// (add) Token: 0x06000140 RID: 320 RVA: 0x00007BB8 File Offset: 0x00005DB8
	// (remove) Token: 0x06000141 RID: 321 RVA: 0x00007BF0 File Offset: 0x00005DF0
	public event Action onWeaponModified;

	// Token: 0x14000034 RID: 52
	// (add) Token: 0x06000142 RID: 322 RVA: 0x00007C28 File Offset: 0x00005E28
	// (remove) Token: 0x06000143 RID: 323 RVA: 0x00007C60 File Offset: 0x00005E60
	public event Action onMessageBroadcast;

	// Token: 0x14000035 RID: 53
	// (add) Token: 0x06000144 RID: 324 RVA: 0x00007C98 File Offset: 0x00005E98
	// (remove) Token: 0x06000145 RID: 325 RVA: 0x00007CD0 File Offset: 0x00005ED0
	public event Action onStopPlateHit;

	// Token: 0x14000036 RID: 54
	// (add) Token: 0x06000146 RID: 326 RVA: 0x00007D08 File Offset: 0x00005F08
	// (remove) Token: 0x06000147 RID: 327 RVA: 0x00007D40 File Offset: 0x00005F40
	public event Action onSteelHit;

	// Token: 0x14000037 RID: 55
	// (add) Token: 0x06000148 RID: 328 RVA: 0x00007D78 File Offset: 0x00005F78
	// (remove) Token: 0x06000149 RID: 329 RVA: 0x00007DB0 File Offset: 0x00005FB0
	public event Action onEnterVehicle;

	// Token: 0x14000038 RID: 56
	// (add) Token: 0x0600014A RID: 330 RVA: 0x00007DE8 File Offset: 0x00005FE8
	// (remove) Token: 0x0600014B RID: 331 RVA: 0x00007E20 File Offset: 0x00006020
	public event Action onExitVehicle;

	// Token: 0x0600014C RID: 332 RVA: 0x00007E55 File Offset: 0x00006055
	public void Disqualify()
	{
		if (this.onDisqualify != null)
		{
			this.onDisqualify();
		}
	}

	// Token: 0x0600014D RID: 333 RVA: 0x00007E6A File Offset: 0x0000606A
	public void Teleported()
	{
		if (this.onTeleported != null)
		{
			this.onTeleported();
		}
	}

	// Token: 0x0600014E RID: 334 RVA: 0x00007E7F File Offset: 0x0000607F
	public void MagazineLoad()
	{
		if (this.onMagazineLoad != null)
		{
			this.onMagazineLoad();
		}
	}

	// Token: 0x0600014F RID: 335 RVA: 0x00007E94 File Offset: 0x00006094
	public void MagazineUnload()
	{
		if (this.onMagazineUnload != null)
		{
			this.onMagazineUnload();
		}
	}

	// Token: 0x06000150 RID: 336 RVA: 0x00007EA9 File Offset: 0x000060A9
	public void SceneManagerTransferred()
	{
		if (this.onSceneSettingsTransferred != null)
		{
			this.onSceneSettingsTransferred();
		}
	}

	// Token: 0x06000151 RID: 337 RVA: 0x00007EBE File Offset: 0x000060BE
	public void Breaking90()
	{
		if (this.onBreaking90 != null)
		{
			this.onBreaking90();
		}
	}

	// Token: 0x06000152 RID: 338 RVA: 0x00007ED3 File Offset: 0x000060D3
	public void StageConditionMet()
	{
		if (this.onStageConditionMet != null)
		{
			this.onStageConditionMet();
		}
	}

	// Token: 0x06000153 RID: 339 RVA: 0x00007EE8 File Offset: 0x000060E8
	public void StageConditionUnMet()
	{
		if (this.onStageConditionUnmet != null)
		{
			this.onStageConditionUnmet();
		}
	}

	// Token: 0x06000154 RID: 340 RVA: 0x00007EFD File Offset: 0x000060FD
	public void StickForward()
	{
		if (this.onStickForward != null)
		{
			this.onStickForward();
		}
	}

	// Token: 0x06000155 RID: 341 RVA: 0x00007F12 File Offset: 0x00006112
	public void StickRelease()
	{
		if (this.onStickRelease != null)
		{
			this.onStickRelease();
		}
	}

	// Token: 0x06000156 RID: 342 RVA: 0x00007F27 File Offset: 0x00006127
	public void ShootingAreaEnter()
	{
		if (this.onShootingAreaEnter != null)
		{
			this.onShootingAreaEnter();
		}
	}

	// Token: 0x06000157 RID: 343 RVA: 0x00007F3C File Offset: 0x0000613C
	public void ShootingAreaCheck()
	{
		if (this.onShootingAreaCheck != null)
		{
			this.onShootingAreaCheck();
		}
	}

	// Token: 0x06000158 RID: 344 RVA: 0x00007F51 File Offset: 0x00006151
	public void ChangeControllerMode()
	{
		if (this.onControllerModeChange != null)
		{
			this.onControllerModeChange();
		}
	}

	// Token: 0x06000159 RID: 345 RVA: 0x00007F66 File Offset: 0x00006166
	public void ShootingAreaExit()
	{
		if (this.onShootingAreaExit != null)
		{
			this.onShootingAreaExit();
		}
	}

	// Token: 0x0600015A RID: 346 RVA: 0x00007F7B File Offset: 0x0000617B
	public void StartingAreaEnter()
	{
		if (this.onShootingAreaEnter != null)
		{
			this.onStartingAreaEnter();
		}
	}

	// Token: 0x0600015B RID: 347 RVA: 0x00007F90 File Offset: 0x00006190
	public void StartingAreaExit()
	{
		if (this.onShootingAreaExit != null)
		{
			this.onStartingAreaExit();
		}
	}

	// Token: 0x0600015C RID: 348 RVA: 0x00007FA5 File Offset: 0x000061A5
	public void GrabStart()
	{
		MonoBehaviour.print("GRAB START CALL SUCCESS");
		if (this.onGrabStart != null)
		{
			this.onGrabStart();
		}
	}

	// Token: 0x0600015D RID: 349 RVA: 0x00007FC4 File Offset: 0x000061C4
	public void GunEmpty()
	{
		if (this.onGunEmpty != null)
		{
			this.onGunEmpty();
		}
	}

	// Token: 0x0600015E RID: 350 RVA: 0x00007FD9 File Offset: 0x000061D9
	public void ChamberEmpty()
	{
		if (this.onChamberEmpty != null)
		{
			this.onChamberEmpty();
		}
	}

	// Token: 0x0600015F RID: 351 RVA: 0x00007FEE File Offset: 0x000061EE
	public void ShotFired()
	{
		if (this.onShotFired != null)
		{
			this.onShotFired();
		}
	}

	// Token: 0x06000160 RID: 352 RVA: 0x00008003 File Offset: 0x00006203
	public void Holster()
	{
		if (this.onHolster != null)
		{
			this.onHolster();
		}
	}

	// Token: 0x06000161 RID: 353 RVA: 0x00008018 File Offset: 0x00006218
	public void HolsterDraw()
	{
		if (this.onHolsterDraw != null)
		{
			this.onHolsterDraw();
		}
	}

	// Token: 0x06000162 RID: 354 RVA: 0x0000802D File Offset: 0x0000622D
	public void HolsterLock()
	{
		if (this.onHolsterLock != null)
		{
			this.onHolsterLock();
		}
	}

	// Token: 0x06000163 RID: 355 RVA: 0x00008042 File Offset: 0x00006242
	public void HolsterUnlock()
	{
		if (this.onHolsterUnlock != null)
		{
			this.onHolsterUnlock();
		}
	}

	// Token: 0x06000164 RID: 356 RVA: 0x00008057 File Offset: 0x00006257
	public void SafetyOn()
	{
		if (this.onSafetyOn != null)
		{
			this.onSafetyOn();
		}
	}

	// Token: 0x06000165 RID: 357 RVA: 0x0000806C File Offset: 0x0000626C
	public void SafetyOff()
	{
		if (this.onSafetyOff != null)
		{
			this.onSafetyOff();
		}
	}

	// Token: 0x06000166 RID: 358 RVA: 0x00008081 File Offset: 0x00006281
	public void RoundChambered()
	{
		if (this.onRoundChambered != null)
		{
			this.onRoundChambered();
		}
	}

	// Token: 0x06000167 RID: 359 RVA: 0x00008096 File Offset: 0x00006296
	public void SlideRelease()
	{
		if (this.onSlideRelease != null)
		{
			this.onSlideRelease();
		}
	}

	// Token: 0x06000168 RID: 360 RVA: 0x000080AB File Offset: 0x000062AB
	public void TutorialStageAdvanced()
	{
		if (this.onTutorialStageAdvanced != null)
		{
			this.onTutorialStageAdvanced();
		}
	}

	// Token: 0x06000169 RID: 361 RVA: 0x000080C0 File Offset: 0x000062C0
	public void StageStart()
	{
		if (this.onStageStart != null)
		{
			this.onStageStart();
		}
	}

	// Token: 0x0600016A RID: 362 RVA: 0x000080D5 File Offset: 0x000062D5
	public void StageFinish()
	{
		if (this.onStageFinish != null)
		{
			this.onStageFinish();
		}
	}

	// Token: 0x0600016B RID: 363 RVA: 0x000080EA File Offset: 0x000062EA
	public void TargetTypeChange()
	{
		if (this.onTargetTypeChange != null)
		{
			this.onTargetTypeChange();
		}
	}

	// Token: 0x0600016C RID: 364 RVA: 0x000080FF File Offset: 0x000062FF
	public void EnableKeyboard(Transform spawnTransform)
	{
		if (this.onEnableKeyboard != null)
		{
			this.onEnableKeyboard();
		}
	}

	// Token: 0x0600016D RID: 365 RVA: 0x00008114 File Offset: 0x00006314
	public void DisableKeyboard()
	{
		if (this.onDisableKeyboard != null)
		{
			this.onDisableKeyboard();
		}
	}

	// Token: 0x0600016E RID: 366 RVA: 0x00008129 File Offset: 0x00006329
	public void KeyboardKeyPressed()
	{
		if (this.onKeyboardKeyPressed != null)
		{
			this.onKeyboardKeyPressed();
		}
	}

	// Token: 0x0600016F RID: 367 RVA: 0x0000813E File Offset: 0x0000633E
	public void KeyboardCaseToggle()
	{
		if (this.onKeyboardCaseToggle != null)
		{
			this.onKeyboardCaseToggle();
		}
	}

	// Token: 0x06000170 RID: 368 RVA: 0x00008153 File Offset: 0x00006353
	public void KeyboardHighlighted()
	{
		if (this.onKeyboardHighlighted != null)
		{
			this.onKeyboardHighlighted();
		}
	}

	// Token: 0x06000171 RID: 369 RVA: 0x00008168 File Offset: 0x00006368
	public void KeyboardReturnPressed()
	{
		if (this.onKeyboardReturnPressed != null)
		{
			this.onKeyboardReturnPressed();
		}
	}

	// Token: 0x06000172 RID: 370 RVA: 0x0000817D File Offset: 0x0000637D
	public void SaveMenuDisabled()
	{
		if (this.onSaveMenuDisabled != null)
		{
			this.onSaveMenuDisabled();
		}
	}

	// Token: 0x06000173 RID: 371 RVA: 0x00008192 File Offset: 0x00006392
	public void NewCustomStageLoad()
	{
		if (this.onNewCustomStageLoad != null)
		{
			this.onNewCustomStageLoad();
		}
	}

	// Token: 0x06000174 RID: 372 RVA: 0x000081A7 File Offset: 0x000063A7
	public void StagePlannerCompStart()
	{
		if (this.onStagePlannerCompStart != null)
		{
			this.onStagePlannerCompStart();
		}
	}

	// Token: 0x06000175 RID: 373 RVA: 0x000081BC File Offset: 0x000063BC
	public void StagePlannerCompEnd()
	{
		if (this.onStagePlannerCompEnd != null)
		{
			this.onStagePlannerCompEnd();
		}
	}

	// Token: 0x06000176 RID: 374 RVA: 0x000081D1 File Offset: 0x000063D1
	public void ScenePopulated()
	{
		if (this.onScenePopulated != null)
		{
			this.onScenePopulated();
		}
	}

	// Token: 0x06000177 RID: 375 RVA: 0x000081E6 File Offset: 0x000063E6
	public void WeaponModified()
	{
		if (this.onWeaponModified != null)
		{
			this.onWeaponModified();
		}
	}

	// Token: 0x06000178 RID: 376 RVA: 0x000081FB File Offset: 0x000063FB
	public void StopPlateHit()
	{
		if (this.onStopPlateHit != null)
		{
			this.onStopPlateHit();
		}
	}

	// Token: 0x06000179 RID: 377 RVA: 0x00008210 File Offset: 0x00006410
	public void SteelHit()
	{
		if (this.onSteelHit != null)
		{
			this.onSteelHit();
		}
	}

	// Token: 0x0600017A RID: 378 RVA: 0x00008228 File Offset: 0x00006428
	public void RecordBreak(int recordType)
	{
		switch (recordType)
		{
		case 0:
			if (this.onBreakRecordPlayed != null)
			{
				this.onBreakRecordPlayed();
				MonoBehaviour.print("RECORD BREAK FIRST TIME");
				return;
			}
			break;
		case 1:
			if (this.onBreakRecordVirginiaCount != null)
			{
				this.onBreakRecordVirginiaCount();
				MonoBehaviour.print("RECORD BREAK V COUNT");
				return;
			}
			break;
		case 2:
			if (this.onBreakRecordBronze != null)
			{
				this.onBreakRecordBronze();
				MonoBehaviour.print("RECORD BREAK BRONZE");
				return;
			}
			break;
		case 3:
			if (this.onBreakRecordSilver != null)
			{
				this.onBreakRecordSilver();
				MonoBehaviour.print("RECORD BREAK SILVER");
				return;
			}
			break;
		case 4:
			if (this.onBreakRecordGold != null)
			{
				this.onBreakRecordGold();
				MonoBehaviour.print("RECORD BREAK GOLD");
			}
			break;
		default:
			return;
		}
	}

	// Token: 0x0600017B RID: 379 RVA: 0x000082E8 File Offset: 0x000064E8
	public void ShotThroughProcedural()
	{
		if (this.onShotThroughProcedural != null)
		{
			this.onShotThroughProcedural();
		}
	}

	// Token: 0x0600017C RID: 380 RVA: 0x000082FD File Offset: 0x000064FD
	public void EnterVehicle()
	{
		if (this.onEnterVehicle != null)
		{
			this.onEnterVehicle();
		}
	}

	// Token: 0x0600017D RID: 381 RVA: 0x00008312 File Offset: 0x00006512
	public void ExitVehicle()
	{
		if (this.onExitVehicle != null)
		{
			this.onExitVehicle();
		}
	}

	// Token: 0x0600017E RID: 382 RVA: 0x00008327 File Offset: 0x00006527
	public void BroadcastMessage(string message, bool errorNoise = false)
	{
		Object.FindObjectOfType<GameManager>().PassMessage(message, errorNoise);
		if (this.onMessageBroadcast != null)
		{
			this.onMessageBroadcast();
		}
	}

	// Token: 0x040000E5 RID: 229
	public static GameEvents current;
}
