﻿using System;
using UnityEngine;

// Token: 0x02000079 RID: 121
public class MuzzleFlashControl : MonoBehaviour
{
	// Token: 0x0600046D RID: 1133 RVA: 0x00003297 File Offset: 0x00001497
	private void Start()
	{
	}

	// Token: 0x0600046E RID: 1134 RVA: 0x00003297 File Offset: 0x00001497
	private void Update()
	{
	}
}
