﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000120 RID: 288
public abstract class TeleportInputHandler : TeleportSupport
{
	// Token: 0x0600077F RID: 1919 RVA: 0x0002EBF5 File Offset: 0x0002CDF5
	protected TeleportInputHandler()
	{
		this._startReadyAction = delegate()
		{
			base.StartCoroutine(this.TeleportReadyCoroutine());
		};
		this._startAimAction = delegate()
		{
			base.StartCoroutine(this.TeleportAimCoroutine());
		};
	}

	// Token: 0x06000780 RID: 1920 RVA: 0x0002EC21 File Offset: 0x0002CE21
	protected override void AddEventHandlers()
	{
		base.LocomotionTeleport.InputHandler = this;
		base.AddEventHandlers();
		base.LocomotionTeleport.EnterStateReady += this._startReadyAction;
		base.LocomotionTeleport.EnterStateAim += this._startAimAction;
	}

	// Token: 0x06000781 RID: 1921 RVA: 0x0002EC58 File Offset: 0x0002CE58
	protected override void RemoveEventHandlers()
	{
		if (base.LocomotionTeleport.InputHandler == this)
		{
			base.LocomotionTeleport.InputHandler = null;
		}
		base.LocomotionTeleport.EnterStateReady -= this._startReadyAction;
		base.LocomotionTeleport.EnterStateAim -= this._startAimAction;
		base.RemoveEventHandlers();
	}

	// Token: 0x06000782 RID: 1922 RVA: 0x0002ECAC File Offset: 0x0002CEAC
	private IEnumerator TeleportReadyCoroutine()
	{
		while (this.GetIntention() != LocomotionTeleport.TeleportIntentions.Aim)
		{
			yield return null;
		}
		base.LocomotionTeleport.CurrentIntention = LocomotionTeleport.TeleportIntentions.Aim;
		yield break;
	}

	// Token: 0x06000783 RID: 1923 RVA: 0x0002ECBB File Offset: 0x0002CEBB
	private IEnumerator TeleportAimCoroutine()
	{
		LocomotionTeleport.TeleportIntentions intention = this.GetIntention();
		while (intention == LocomotionTeleport.TeleportIntentions.Aim || intention == LocomotionTeleport.TeleportIntentions.PreTeleport)
		{
			base.LocomotionTeleport.CurrentIntention = intention;
			yield return null;
			intention = this.GetIntention();
		}
		base.LocomotionTeleport.CurrentIntention = intention;
		yield break;
	}

	// Token: 0x06000784 RID: 1924
	public abstract LocomotionTeleport.TeleportIntentions GetIntention();

	// Token: 0x06000785 RID: 1925
	public abstract void GetAimData(out Ray aimRay);

	// Token: 0x040009A2 RID: 2466
	private readonly Action _startReadyAction;

	// Token: 0x040009A3 RID: 2467
	private readonly Action _startAimAction;
}
