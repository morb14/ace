﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000129 RID: 297
public abstract class TeleportTargetHandler : TeleportSupport
{
	// Token: 0x060007B0 RID: 1968 RVA: 0x0002F65A File Offset: 0x0002D85A
	protected TeleportTargetHandler()
	{
		this._startAimAction = delegate()
		{
			base.StartCoroutine(this.TargetAimCoroutine());
		};
	}

	// Token: 0x060007B1 RID: 1969 RVA: 0x0002F68A File Offset: 0x0002D88A
	protected override void AddEventHandlers()
	{
		base.AddEventHandlers();
		base.LocomotionTeleport.EnterStateAim += this._startAimAction;
	}

	// Token: 0x060007B2 RID: 1970 RVA: 0x0002F6A3 File Offset: 0x0002D8A3
	protected override void RemoveEventHandlers()
	{
		base.RemoveEventHandlers();
		base.LocomotionTeleport.EnterStateAim -= this._startAimAction;
	}

	// Token: 0x060007B3 RID: 1971 RVA: 0x0002F6BC File Offset: 0x0002D8BC
	private IEnumerator TargetAimCoroutine()
	{
		while (base.LocomotionTeleport.CurrentState == LocomotionTeleport.States.Aim)
		{
			this.ResetAimData();
			Vector3 start = base.LocomotionTeleport.transform.position;
			this._aimPoints.Clear();
			base.LocomotionTeleport.AimHandler.GetPoints(this._aimPoints);
			for (int i = 0; i < this._aimPoints.Count; i++)
			{
				Vector3 vector = this._aimPoints[i];
				this.AimData.TargetValid = this.ConsiderTeleport(start, ref vector);
				this.AimData.Points.Add(vector);
				if (this.AimData.TargetValid)
				{
					this.AimData.Destination = this.ConsiderDestination(vector);
					this.AimData.TargetValid = (this.AimData.Destination != null);
					break;
				}
				start = this._aimPoints[i];
			}
			base.LocomotionTeleport.OnUpdateAimData(this.AimData);
			yield return null;
		}
		yield break;
	}

	// Token: 0x060007B4 RID: 1972 RVA: 0x0002F6CB File Offset: 0x0002D8CB
	protected virtual void ResetAimData()
	{
		this.AimData.Reset();
	}

	// Token: 0x060007B5 RID: 1973
	protected abstract bool ConsiderTeleport(Vector3 start, ref Vector3 end);

	// Token: 0x060007B6 RID: 1974 RVA: 0x0002F6D8 File Offset: 0x0002D8D8
	public virtual Vector3? ConsiderDestination(Vector3 location)
	{
		CapsuleCollider characterController = base.LocomotionTeleport.LocomotionController.CharacterController;
		float num = characterController.radius - 0.1f;
		Vector3 vector = location;
		vector.y += num + 0.1f;
		Vector3 end = vector;
		end.y += characterController.height - 0.1f;
		if (Physics.CheckCapsule(vector, end, num, this.AimCollisionLayerMask, QueryTriggerInteraction.Ignore))
		{
			return null;
		}
		return new Vector3?(location);
	}

	// Token: 0x040009C6 RID: 2502
	[Tooltip("This bitmask controls which game object layers will be included in the targeting collision tests.")]
	public LayerMask AimCollisionLayerMask;

	// Token: 0x040009C7 RID: 2503
	protected readonly LocomotionTeleport.AimData AimData = new LocomotionTeleport.AimData();

	// Token: 0x040009C8 RID: 2504
	private readonly Action _startAimAction;

	// Token: 0x040009C9 RID: 2505
	private readonly List<Vector3> _aimPoints = new List<Vector3>();

	// Token: 0x040009CA RID: 2506
	private const float ERROR_MARGIN = 0.1f;
}
