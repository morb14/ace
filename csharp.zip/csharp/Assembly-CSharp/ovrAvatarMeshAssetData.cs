﻿using System;

// Token: 0x020000C3 RID: 195
public struct ovrAvatarMeshAssetData
{
	// Token: 0x0400079E RID: 1950
	public uint vertexCount;

	// Token: 0x0400079F RID: 1951
	public IntPtr vertexBuffer;

	// Token: 0x040007A0 RID: 1952
	public uint indexCount;

	// Token: 0x040007A1 RID: 1953
	public IntPtr indexBuffer;

	// Token: 0x040007A2 RID: 1954
	public ovrAvatarSkinnedMeshPose skinnedBindPose;
}
