﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200003D RID: 61
public class MaterialReplacer : MonoBehaviour
{
	// Token: 0x06000207 RID: 519 RVA: 0x0000B5A0 File Offset: 0x000097A0
	public void SwitchMaterial(Material material)
	{
		foreach (Renderer renderer in base.GetComponentsInChildren<Renderer>())
		{
			renderer.material = material;
			if (renderer.materials.Length > 1)
			{
				Material[] materials = renderer.materials;
				for (int j = 0; j < materials.Length; j++)
				{
					materials[j] = material;
				}
				renderer.materials = materials;
			}
		}
	}

	// Token: 0x040001C3 RID: 451
	public List<Renderer> Renderers;
}
