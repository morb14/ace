﻿using System;

// Token: 0x020000D9 RID: 217
public enum ovrAvatarLookAndFeelVersion
{
	// Token: 0x0400080F RID: 2063
	Unknown = -1,
	// Token: 0x04000810 RID: 2064
	One,
	// Token: 0x04000811 RID: 2065
	Two
}
