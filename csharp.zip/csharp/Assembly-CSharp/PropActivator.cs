﻿using System;
using UnityEngine;

// Token: 0x02000048 RID: 72
public class PropActivator : MonoBehaviour
{
	// Token: 0x06000247 RID: 583 RVA: 0x0000CDD4 File Offset: 0x0000AFD4
	private void Awake()
	{
		this.inputManager = Object.FindObjectOfType<InputManager>();
		if (base.GetComponent<Animator>())
		{
			this.animator = base.GetComponent<Animator>();
		}
		else
		{
			this.animator = this.animatorManual;
		}
		this.outline = this.animator.GetComponentInChildren<Outline>();
		if (this.outline == null)
		{
			this.outline = this.animator.gameObject.AddComponent<Outline>();
		}
		this.outline.OutlineColor = Color.cyan;
		this.outline.OutlineWidth = 4f;
		this.outline.enabled = false;
	}

	// Token: 0x06000248 RID: 584 RVA: 0x0000CE74 File Offset: 0x0000B074
	private void OnTriggerStay(Collider other)
	{
		if (this.coolDown)
		{
			return;
		}
		if (!other.transform.GetComponentInParent<HandGrabbingBehaviour>() && !other.transform.GetComponentInParent<OVRGrabber>())
		{
			return;
		}
		this.outline.enabled = true;
		if (this.inputManager.controllerMode == ControllerMode.Hands && other.GetComponent<HandGrabbingBehaviour>() && other.GetComponent<OVRHand>().GetFingerIsPinching(OVRHand.HandFinger.Index))
		{
			MonoBehaviour.print(base.gameObject + " has been activated by hand " + other.gameObject);
			this.Toggle();
		}
		if (this.inputManager.controllerMode == ControllerMode.Controllers && OVRInput.Get(OVRInput.Button.PrimaryIndexTrigger, other.transform.GetComponentInParent<OVRGrabber>().ControllerType()))
		{
			MonoBehaviour.print(base.gameObject + " has been activated by " + other.transform.GetComponentInParent<OVRGrabber>().ControllerType());
			this.Toggle();
		}
	}

	// Token: 0x06000249 RID: 585 RVA: 0x0000CF60 File Offset: 0x0000B160
	private void Toggle()
	{
		this.ToggleColliders(false);
		if (!this.isActivated)
		{
			this.animator.SetTrigger("Activate");
			this.isActivated = true;
		}
		else
		{
			this.animator.SetTrigger("Deactivate");
			this.isActivated = false;
		}
		this.coolDown = true;
		this.outline.enabled = false;
		base.Invoke("CancelCoolDown", this.coolDownDuration);
	}

	// Token: 0x0600024A RID: 586 RVA: 0x0000CFD0 File Offset: 0x0000B1D0
	private void ToggleColliders(bool state)
	{
		if (this.collidersToDisable.Length != 0)
		{
			Collider[] array = this.collidersToDisable;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].GetComponent<Rigidbody>().isKinematic = state;
			}
		}
	}

	// Token: 0x0600024B RID: 587 RVA: 0x0000D009 File Offset: 0x0000B209
	private void OnTriggerExit(Collider other)
	{
		if (!other.transform.GetComponentInParent<OVRGrabber>())
		{
			return;
		}
		this.outline.enabled = false;
	}

	// Token: 0x0600024C RID: 588 RVA: 0x0000D02A File Offset: 0x0000B22A
	private void CancelCoolDown()
	{
		this.ToggleColliders(true);
		this.coolDown = false;
	}

	// Token: 0x0400022A RID: 554
	private bool isActivated;

	// Token: 0x0400022B RID: 555
	private bool coolDown;

	// Token: 0x0400022C RID: 556
	[SerializeField]
	private float coolDownDuration = 1f;

	// Token: 0x0400022D RID: 557
	[SerializeField]
	private Animator animatorManual;

	// Token: 0x0400022E RID: 558
	[SerializeField]
	private Collider[] collidersToDisable;

	// Token: 0x0400022F RID: 559
	private Outline outline;

	// Token: 0x04000230 RID: 560
	private Animator animator;

	// Token: 0x04000231 RID: 561
	private InputManager inputManager;
}
