﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000136 RID: 310
[ExecuteInEditMode]
[RequireComponent(typeof(OVROverlay))]
public class OVROverlayMeshGenerator : MonoBehaviour
{
	// Token: 0x06000800 RID: 2048 RVA: 0x000317A8 File Offset: 0x0002F9A8
	protected void Awake()
	{
		this._Overlay = base.GetComponent<OVROverlay>();
		this._MeshFilter = base.GetComponent<MeshFilter>();
		this._MeshCollider = base.GetComponent<MeshCollider>();
		this._Transform = base.transform;
		if (Camera.main && Camera.main.transform.parent)
		{
			this._CameraRoot = Camera.main.transform.parent;
		}
		this._Awake = true;
	}

	// Token: 0x06000801 RID: 2049 RVA: 0x00031824 File Offset: 0x0002FA24
	private Rect GetBoundingRect(Rect a, Rect b)
	{
		float num = Mathf.Min(a.x, b.x);
		float num2 = Mathf.Max(a.x + a.width, b.x + b.width);
		float num3 = Mathf.Min(a.y, b.y);
		float num4 = Mathf.Max(a.y + a.height, b.y + b.height);
		return new Rect(num, num3, num2 - num, num4 - num3);
	}

	// Token: 0x06000802 RID: 2050 RVA: 0x000318B0 File Offset: 0x0002FAB0
	private void Update()
	{
		if (!this._Awake)
		{
			this.Awake();
		}
		if (this._Overlay)
		{
			OVROverlay.OverlayShape currentOverlayShape = this._Overlay.currentOverlayShape;
			Vector3 vector = this._CameraRoot ? (this._Transform.position - this._CameraRoot.position) : this._Transform.position;
			Quaternion rotation = this._Transform.rotation;
			Vector3 lossyScale = this._Transform.lossyScale;
			Rect rect = this._Overlay.overrideTextureRectMatrix ? this._Overlay.destRectLeft : new Rect(0f, 0f, 1f, 1f);
			Rect rect2 = this._Overlay.overrideTextureRectMatrix ? this._Overlay.destRectRight : new Rect(0f, 0f, 1f, 1f);
			if (this._Mesh == null || this._LastShape != currentOverlayShape || this._LastPosition != vector || this._LastRotation != rotation || this._LastScale != lossyScale || this._LastRectLeft != rect || this._LastRectRight != rect2)
			{
				this.UpdateMesh(currentOverlayShape, vector, rotation, lossyScale, this.GetBoundingRect(rect, rect2));
				this._LastShape = currentOverlayShape;
				this._LastPosition = vector;
				this._LastRotation = rotation;
				this._LastScale = lossyScale;
				this._LastRectLeft = rect;
				this._LastRectRight = rect2;
			}
		}
	}

	// Token: 0x06000803 RID: 2051 RVA: 0x00031A40 File Offset: 0x0002FC40
	private void UpdateMesh(OVROverlay.OverlayShape shape, Vector3 position, Quaternion rotation, Vector3 scale, Rect rect)
	{
		if (this._MeshFilter)
		{
			if (this._Mesh == null)
			{
				this._Mesh = new Mesh
				{
					name = "Overlay"
				};
				this._Mesh.hideFlags = (HideFlags.DontSaveInEditor | HideFlags.DontSaveInBuild);
			}
			this._Mesh.Clear();
			this._Verts.Clear();
			this._UV.Clear();
			this._Tris.Clear();
			OVROverlayMeshGenerator.GenerateMesh(this._Verts, this._UV, this._Tris, shape, position, rotation, scale, rect);
			this._Mesh.SetVertices(this._Verts);
			this._Mesh.SetUVs(0, this._UV);
			this._Mesh.SetTriangles(this._Tris, 0);
			this._Mesh.UploadMeshData(false);
			this._MeshFilter.sharedMesh = this._Mesh;
			if (this._MeshCollider)
			{
				this._MeshCollider.sharedMesh = this._Mesh;
			}
		}
	}

	// Token: 0x06000804 RID: 2052 RVA: 0x00031B48 File Offset: 0x0002FD48
	public static void GenerateMesh(List<Vector3> verts, List<Vector2> uvs, List<int> tris, OVROverlay.OverlayShape shape, Vector3 position, Quaternion rotation, Vector3 scale, Rect rect)
	{
		switch (shape)
		{
		case OVROverlay.OverlayShape.Quad:
			OVROverlayMeshGenerator.BuildQuad(verts, uvs, tris, rect);
			return;
		case OVROverlay.OverlayShape.Cylinder:
			OVROverlayMeshGenerator.BuildHemicylinder(verts, uvs, tris, scale, rect, 128);
			break;
		case OVROverlay.OverlayShape.Cubemap:
		case OVROverlay.OverlayShape.OffcenterCubemap:
			OVROverlayMeshGenerator.BuildCube(verts, uvs, tris, position, rotation, scale, 800f, 1, 1.01f);
			return;
		case (OVROverlay.OverlayShape)3:
			break;
		case OVROverlay.OverlayShape.Equirect:
			OVROverlayMeshGenerator.BuildSphere(verts, uvs, tris, position, rotation, scale, rect, 800f, 128, 128, 1f);
			return;
		default:
			return;
		}
	}

	// Token: 0x06000805 RID: 2053 RVA: 0x00031BD0 File Offset: 0x0002FDD0
	private static Vector2 GetSphereUV(float theta, float phi, float expand_coef)
	{
		float x = (theta / 6.2831855f - 0.5f) / expand_coef + 0.5f;
		float y = phi / 3.1415927f / expand_coef + 0.5f;
		return new Vector2(x, y);
	}

	// Token: 0x06000806 RID: 2054 RVA: 0x00031C08 File Offset: 0x0002FE08
	private static Vector3 GetSphereVert(float theta, float phi)
	{
		return new Vector3(-Mathf.Sin(theta) * Mathf.Cos(phi), Mathf.Sin(phi), -Mathf.Cos(theta) * Mathf.Cos(phi));
	}

	// Token: 0x06000807 RID: 2055 RVA: 0x00031C34 File Offset: 0x0002FE34
	public static void BuildSphere(List<Vector3> verts, List<Vector2> uv, List<int> triangles, Vector3 position, Quaternion rotation, Vector3 scale, Rect rect, float worldScale = 800f, int latitudes = 128, int longitudes = 128, float expand_coef = 1f)
	{
		position = Quaternion.Inverse(rotation) * position;
		latitudes = Mathf.CeilToInt((float)latitudes * rect.height);
		longitudes = Mathf.CeilToInt((float)longitudes * rect.width);
		float num = 6.2831855f * rect.x;
		float num2 = 3.1415927f * (0.5f - rect.y - rect.height);
		float num3 = 6.2831855f * rect.width / (float)longitudes;
		float num4 = 3.1415927f * rect.height / (float)latitudes;
		for (int i = 0; i < latitudes + 1; i++)
		{
			for (int j = 0; j < longitudes + 1; j++)
			{
				float theta = num + (float)j * num3;
				float phi = num2 + (float)i * num4;
				Vector2 sphereUV = OVROverlayMeshGenerator.GetSphereUV(theta, phi, expand_coef);
				uv.Add(new Vector2((sphereUV.x - rect.x) / rect.width, (sphereUV.y - rect.y) / rect.height));
				Vector3 sphereVert = OVROverlayMeshGenerator.GetSphereVert(theta, phi);
				sphereVert.x = (worldScale * sphereVert.x - position.x) / scale.x;
				sphereVert.y = (worldScale * sphereVert.y - position.y) / scale.y;
				sphereVert.z = (worldScale * sphereVert.z - position.z) / scale.z;
				verts.Add(sphereVert);
			}
		}
		for (int k = 0; k < latitudes; k++)
		{
			for (int l = 0; l < longitudes; l++)
			{
				triangles.Add(k * (longitudes + 1) + l);
				triangles.Add((k + 1) * (longitudes + 1) + l);
				triangles.Add((k + 1) * (longitudes + 1) + l + 1);
				triangles.Add((k + 1) * (longitudes + 1) + l + 1);
				triangles.Add(k * (longitudes + 1) + l + 1);
				triangles.Add(k * (longitudes + 1) + l);
			}
		}
	}

	// Token: 0x06000808 RID: 2056 RVA: 0x00031E50 File Offset: 0x00030050
	private static Vector2 GetCubeUV(OVROverlayMeshGenerator.CubeFace face, Vector2 sideUV, float expand_coef)
	{
		sideUV = (sideUV - 0.5f * Vector2.one) / expand_coef + 0.5f * Vector2.one;
		switch (face)
		{
		case OVROverlayMeshGenerator.CubeFace.Right:
			return new Vector2(sideUV.x / 3f, (1f + sideUV.y) / 2f);
		case OVROverlayMeshGenerator.CubeFace.Left:
			return new Vector2((1f + sideUV.x) / 3f, (1f + sideUV.y) / 2f);
		case OVROverlayMeshGenerator.CubeFace.Top:
			return new Vector2((2f + sideUV.x) / 3f, (1f + sideUV.y) / 2f);
		case OVROverlayMeshGenerator.CubeFace.Bottom:
			return new Vector2(sideUV.x / 3f, sideUV.y / 2f);
		case OVROverlayMeshGenerator.CubeFace.Front:
			return new Vector2((1f + sideUV.x) / 3f, sideUV.y / 2f);
		case OVROverlayMeshGenerator.CubeFace.Back:
			return new Vector2((2f + sideUV.x) / 3f, sideUV.y / 2f);
		default:
			return Vector2.zero;
		}
	}

	// Token: 0x06000809 RID: 2057 RVA: 0x00031F94 File Offset: 0x00030194
	private static Vector3 GetCubeVert(OVROverlayMeshGenerator.CubeFace face, Vector2 sideUV, float expand_coef)
	{
		return OVROverlayMeshGenerator.BottomLeft[(int)face] + sideUV.x * OVROverlayMeshGenerator.RightVector[(int)face] + sideUV.y * OVROverlayMeshGenerator.UpVector[(int)face];
	}

	// Token: 0x0600080A RID: 2058 RVA: 0x00031FE4 File Offset: 0x000301E4
	public static void BuildCube(List<Vector3> verts, List<Vector2> uv, List<int> triangles, Vector3 position, Quaternion rotation, Vector3 scale, float worldScale = 800f, int subQuads = 1, float expand_coef = 1.01f)
	{
		position = Quaternion.Inverse(rotation) * position;
		int num = (subQuads + 1) * (subQuads + 1);
		for (int i = 0; i < 6; i++)
		{
			for (int j = 0; j < subQuads + 1; j++)
			{
				for (int k = 0; k < subQuads + 1; k++)
				{
					float x = (float)j / (float)subQuads;
					float y = (float)k / (float)subQuads;
					uv.Add(OVROverlayMeshGenerator.GetCubeUV((OVROverlayMeshGenerator.CubeFace)i, new Vector2(x, y), expand_coef));
					Vector3 cubeVert = OVROverlayMeshGenerator.GetCubeVert((OVROverlayMeshGenerator.CubeFace)i, new Vector2(x, y), expand_coef);
					cubeVert.x = (worldScale * cubeVert.x - position.x) / scale.x;
					cubeVert.y = (worldScale * cubeVert.y - position.y) / scale.y;
					cubeVert.z = (worldScale * cubeVert.z - position.z) / scale.z;
					verts.Add(cubeVert);
				}
			}
			for (int l = 0; l < subQuads; l++)
			{
				for (int m = 0; m < subQuads; m++)
				{
					triangles.Add(num * i + (l + 1) * (subQuads + 1) + m);
					triangles.Add(num * i + l * (subQuads + 1) + m);
					triangles.Add(num * i + (l + 1) * (subQuads + 1) + m + 1);
					triangles.Add(num * i + (l + 1) * (subQuads + 1) + m + 1);
					triangles.Add(num * i + l * (subQuads + 1) + m);
					triangles.Add(num * i + l * (subQuads + 1) + m + 1);
				}
			}
		}
	}

	// Token: 0x0600080B RID: 2059 RVA: 0x0003219C File Offset: 0x0003039C
	public static void BuildQuad(List<Vector3> verts, List<Vector2> uv, List<int> triangles, Rect rect)
	{
		verts.Add(new Vector3(rect.x - 0.5f, 1f - rect.y - rect.height - 0.5f, 0f));
		verts.Add(new Vector3(rect.x - 0.5f, 1f - rect.y - 0.5f, 0f));
		verts.Add(new Vector3(rect.x + rect.width - 0.5f, 1f - rect.y - 0.5f, 0f));
		verts.Add(new Vector3(rect.x + rect.width - 0.5f, 1f - rect.y - rect.height - 0.5f, 0f));
		uv.Add(new Vector2(0f, 0f));
		uv.Add(new Vector2(0f, 1f));
		uv.Add(new Vector2(1f, 1f));
		uv.Add(new Vector2(1f, 0f));
		triangles.Add(0);
		triangles.Add(1);
		triangles.Add(2);
		triangles.Add(2);
		triangles.Add(3);
		triangles.Add(0);
	}

	// Token: 0x0600080C RID: 2060 RVA: 0x00032308 File Offset: 0x00030508
	public static void BuildHemicylinder(List<Vector3> verts, List<Vector2> uv, List<int> triangles, Vector3 scale, Rect rect, int longitudes = 128)
	{
		float num = Mathf.Abs(scale.y) * rect.height;
		float z = scale.z;
		float num2 = scale.x * rect.width;
		float num3 = num2 / z;
		float num4 = scale.x * (-0.5f + rect.x) / z;
		int num5 = Mathf.CeilToInt((float)longitudes * num3 / 6.2831855f);
		float num6 = num2 / (float)num5;
		int num7 = Mathf.CeilToInt(num / num6 / 2f);
		for (int i = 0; i < num7 + 1; i++)
		{
			for (int j = 0; j < num5 + 1; j++)
			{
				uv.Add(new Vector2((float)j / (float)num5, 1f - (float)i / (float)num7));
				Vector3 zero = Vector3.zero;
				zero.x = Mathf.Sin(num4 + (float)j * num3 / (float)num5) * z / scale.x;
				zero.y = 0.5f - rect.y - rect.height + rect.height * (1f - (float)i / (float)num7);
				zero.z = Mathf.Cos(num4 + (float)j * num3 / (float)num5) * z / scale.z;
				verts.Add(zero);
			}
		}
		for (int k = 0; k < num7; k++)
		{
			for (int l = 0; l < num5; l++)
			{
				triangles.Add(k * (num5 + 1) + l);
				triangles.Add((k + 1) * (num5 + 1) + l + 1);
				triangles.Add((k + 1) * (num5 + 1) + l);
				triangles.Add((k + 1) * (num5 + 1) + l + 1);
				triangles.Add(k * (num5 + 1) + l);
				triangles.Add(k * (num5 + 1) + l + 1);
			}
		}
	}

	// Token: 0x04000A10 RID: 2576
	private Mesh _Mesh;

	// Token: 0x04000A11 RID: 2577
	private List<Vector3> _Verts = new List<Vector3>();

	// Token: 0x04000A12 RID: 2578
	private List<Vector2> _UV = new List<Vector2>();

	// Token: 0x04000A13 RID: 2579
	private List<int> _Tris = new List<int>();

	// Token: 0x04000A14 RID: 2580
	private OVROverlay _Overlay;

	// Token: 0x04000A15 RID: 2581
	private MeshFilter _MeshFilter;

	// Token: 0x04000A16 RID: 2582
	private MeshCollider _MeshCollider;

	// Token: 0x04000A17 RID: 2583
	private Transform _CameraRoot;

	// Token: 0x04000A18 RID: 2584
	private Transform _Transform;

	// Token: 0x04000A19 RID: 2585
	private OVROverlay.OverlayShape _LastShape;

	// Token: 0x04000A1A RID: 2586
	private Vector3 _LastPosition;

	// Token: 0x04000A1B RID: 2587
	private Quaternion _LastRotation;

	// Token: 0x04000A1C RID: 2588
	private Vector3 _LastScale;

	// Token: 0x04000A1D RID: 2589
	private Rect _LastRectLeft;

	// Token: 0x04000A1E RID: 2590
	private Rect _LastRectRight;

	// Token: 0x04000A1F RID: 2591
	private bool _Awake;

	// Token: 0x04000A20 RID: 2592
	private static readonly Vector3[] BottomLeft = new Vector3[]
	{
		new Vector3(-0.5f, -0.5f, -0.5f),
		new Vector3(0.5f, -0.5f, 0.5f),
		new Vector3(0.5f, 0.5f, -0.5f),
		new Vector3(0.5f, -0.5f, 0.5f),
		new Vector3(0.5f, -0.5f, -0.5f),
		new Vector3(-0.5f, -0.5f, 0.5f)
	};

	// Token: 0x04000A21 RID: 2593
	private static readonly Vector3[] RightVector = new Vector3[]
	{
		Vector3.forward,
		Vector3.back,
		Vector3.left,
		Vector3.left,
		Vector3.left,
		Vector3.right
	};

	// Token: 0x04000A22 RID: 2594
	private static readonly Vector3[] UpVector = new Vector3[]
	{
		Vector3.up,
		Vector3.up,
		Vector3.forward,
		Vector3.back,
		Vector3.up,
		Vector3.up
	};

	// Token: 0x02000227 RID: 551
	private enum CubeFace
	{
		// Token: 0x04000F40 RID: 3904
		Right,
		// Token: 0x04000F41 RID: 3905
		Left,
		// Token: 0x04000F42 RID: 3906
		Top,
		// Token: 0x04000F43 RID: 3907
		Bottom,
		// Token: 0x04000F44 RID: 3908
		Front,
		// Token: 0x04000F45 RID: 3909
		Back,
		// Token: 0x04000F46 RID: 3910
		COUNT
	}
}
