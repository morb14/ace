﻿using System;
using UnityEngine;

// Token: 0x0200006A RID: 106
public class WeaponAdjustmentArrows : MonoBehaviour
{
	// Token: 0x060003E0 RID: 992 RVA: 0x000199FE File Offset: 0x00017BFE
	private void Start()
	{
		this.allRenderers = base.GetComponentsInChildren<MeshRenderer>();
		this.Reset();
		this.toggleProgressOuter.SetActive(false);
		this.toggleProgressInner.transform.localScale = Vector3.zero;
	}

	// Token: 0x060003E1 RID: 993 RVA: 0x00019A34 File Offset: 0x00017C34
	public void Reset()
	{
		foreach (MeshRenderer meshRenderer in this.allRenderers)
		{
			if ((!(meshRenderer != null) || (!(meshRenderer.gameObject == this.toggleProgressInner) && !(meshRenderer.gameObject == this.toggleProgressOuter))) && !(meshRenderer == null))
			{
				meshRenderer.material = this.greyMat;
				meshRenderer.enabled = false;
			}
		}
	}

	// Token: 0x060003E2 RID: 994 RVA: 0x00019AA8 File Offset: 0x00017CA8
	public void Adjust(int mode, float x, float y)
	{
		if (mode == 1)
		{
			this.Reset();
			this.mode1ArrowFront.enabled = true;
			this.mode1ArrowBack.enabled = true;
			this.mode1ArrowRight.enabled = true;
			this.mode1ArrowLeft.enabled = true;
			if ((double)x < -0.2)
			{
				this.mode1ArrowLeft.material = this.redMat;
				this.mode1ArrowRight.material = this.greyMat;
			}
			else if ((double)x > 0.2)
			{
				this.mode1ArrowRight.material = this.redMat;
				this.mode1ArrowLeft.material = this.greyMat;
			}
			else
			{
				this.mode1ArrowRight.material = this.greyMat;
				this.mode1ArrowLeft.material = this.greyMat;
			}
			if ((double)y < -0.2)
			{
				this.mode1ArrowFront.material = this.greyMat;
				this.mode1ArrowBack.material = this.blueMat;
			}
			else if ((double)y > 0.2)
			{
				this.mode1ArrowFront.material = this.blueMat;
				this.mode1ArrowBack.material = this.greyMat;
			}
			else
			{
				this.mode1ArrowFront.material = this.greyMat;
				this.mode1ArrowBack.material = this.greyMat;
			}
		}
		if (mode == 2)
		{
			this.Reset();
			MeshRenderer[] array = this.mode2ArrowsBack;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].enabled = true;
			}
			array = this.mode2ArrowsLeft;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].enabled = true;
			}
			array = this.mode2ArrowsRight;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].enabled = false;
			}
			array = this.mode2ArrowsFront;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].enabled = false;
			}
			if ((double)x > 0.2)
			{
				foreach (MeshRenderer meshRenderer in this.mode2ArrowsRight)
				{
					meshRenderer.enabled = true;
					meshRenderer.material = this.greenMat;
				}
				array = this.mode2ArrowsLeft;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].enabled = false;
				}
			}
			else if ((double)x < -0.2)
			{
				foreach (MeshRenderer meshRenderer2 in this.mode2ArrowsLeft)
				{
					meshRenderer2.enabled = true;
					meshRenderer2.material = this.greenMat;
				}
				array = this.mode2ArrowsRight;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].enabled = false;
				}
			}
			else if ((double)y < -0.2)
			{
				foreach (MeshRenderer meshRenderer3 in this.mode2ArrowsFront)
				{
					meshRenderer3.enabled = true;
					meshRenderer3.material = this.redMat;
				}
				array = this.mode2ArrowsBack;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].enabled = false;
				}
			}
			else if ((double)y > 0.2)
			{
				foreach (MeshRenderer meshRenderer4 in this.mode2ArrowsBack)
				{
					meshRenderer4.enabled = true;
					meshRenderer4.material = this.redMat;
				}
				array = this.mode2ArrowsFront;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].enabled = false;
				}
			}
			else
			{
				foreach (MeshRenderer meshRenderer5 in this.mode2ArrowsBack)
				{
					meshRenderer5.enabled = true;
					meshRenderer5.material = this.greyMat;
				}
				foreach (MeshRenderer meshRenderer6 in this.mode2ArrowsLeft)
				{
					meshRenderer6.enabled = true;
					meshRenderer6.material = this.greyMat;
				}
				array = this.mode2ArrowsFront;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].enabled = false;
				}
				array = this.mode2ArrowsRight;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].enabled = false;
				}
			}
		}
		if (mode == 3)
		{
			this.Reset();
			MeshRenderer[] array = this.mode3ArrowLeft;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].enabled = true;
			}
			this.mode3ArrowUp.enabled = true;
			this.mode3ArrowDown.enabled = true;
			if ((double)x > 0.2)
			{
				foreach (MeshRenderer meshRenderer7 in this.mode3ArrowRight)
				{
					meshRenderer7.enabled = true;
					meshRenderer7.material = this.blueMat;
				}
				array = this.mode3ArrowLeft;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].enabled = false;
				}
				return;
			}
			if ((double)x < -0.2)
			{
				foreach (MeshRenderer meshRenderer8 in this.mode3ArrowLeft)
				{
					meshRenderer8.enabled = true;
					meshRenderer8.material = this.blueMat;
				}
				array = this.mode3ArrowRight;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].enabled = false;
				}
				return;
			}
			if ((double)y > 0.2)
			{
				this.mode3ArrowUp.material = this.greenMat;
				this.mode3ArrowDown.material = this.greyMat;
				return;
			}
			if ((double)y < -0.2)
			{
				this.mode3ArrowDown.material = this.greenMat;
				this.mode3ArrowUp.material = this.greyMat;
				return;
			}
			this.mode3ArrowDown.material = this.greyMat;
			this.mode3ArrowUp.material = this.greyMat;
			foreach (MeshRenderer meshRenderer9 in this.mode3ArrowLeft)
			{
				meshRenderer9.enabled = true;
				meshRenderer9.material = this.greyMat;
			}
			array = this.mode3ArrowRight;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].enabled = false;
			}
		}
	}

	// Token: 0x060003E3 RID: 995 RVA: 0x00003297 File Offset: 0x00001497
	private void OnDestroy()
	{
	}

	// Token: 0x040004CF RID: 1231
	[SerializeField]
	public GameObject toggleProgressOuter;

	// Token: 0x040004D0 RID: 1232
	[SerializeField]
	public GameObject toggleProgressInner;

	// Token: 0x040004D1 RID: 1233
	[SerializeField]
	public Material redMat;

	// Token: 0x040004D2 RID: 1234
	[SerializeField]
	public Material blueMat;

	// Token: 0x040004D3 RID: 1235
	[SerializeField]
	public Material greenMat;

	// Token: 0x040004D4 RID: 1236
	[SerializeField]
	public Material greyMat;

	// Token: 0x040004D5 RID: 1237
	public MeshRenderer mode1ArrowFront;

	// Token: 0x040004D6 RID: 1238
	public MeshRenderer mode1ArrowBack;

	// Token: 0x040004D7 RID: 1239
	public MeshRenderer mode1ArrowLeft;

	// Token: 0x040004D8 RID: 1240
	public MeshRenderer mode1ArrowRight;

	// Token: 0x040004D9 RID: 1241
	public MeshRenderer[] mode2ArrowsFront;

	// Token: 0x040004DA RID: 1242
	public MeshRenderer[] mode2ArrowsBack;

	// Token: 0x040004DB RID: 1243
	public MeshRenderer[] mode2ArrowsLeft;

	// Token: 0x040004DC RID: 1244
	public MeshRenderer[] mode2ArrowsRight;

	// Token: 0x040004DD RID: 1245
	public MeshRenderer mode3ArrowUp;

	// Token: 0x040004DE RID: 1246
	public MeshRenderer mode3ArrowDown;

	// Token: 0x040004DF RID: 1247
	public MeshRenderer[] mode3ArrowLeft;

	// Token: 0x040004E0 RID: 1248
	public MeshRenderer[] mode3ArrowRight;

	// Token: 0x040004E1 RID: 1249
	private MeshRenderer[] allRenderers;
}
