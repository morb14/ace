﻿using System;
using UnityEngine;

// Token: 0x02000060 RID: 96
public class ForceDampener : MonoBehaviour
{
	// Token: 0x06000391 RID: 913 RVA: 0x00017966 File Offset: 0x00015B66
	public float Dampen()
	{
		return this.multiplier;
	}

	// Token: 0x04000451 RID: 1105
	[SerializeField]
	[Range(0f, 2f)]
	private float multiplier = 1f;
}
