﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000139 RID: 313
public class HandsActiveChecker : MonoBehaviour
{
	// Token: 0x0600081B RID: 2075 RVA: 0x00032948 File Offset: 0x00030B48
	private void Awake()
	{
		this._notification = Object.Instantiate<GameObject>(this._notificationPrefab);
		base.StartCoroutine(this.GetCenterEye());
	}

	// Token: 0x0600081C RID: 2076 RVA: 0x00032968 File Offset: 0x00030B68
	private void Update()
	{
		if (OVRPlugin.GetHandTrackingEnabled())
		{
			this._notification.SetActive(false);
			return;
		}
		this._notification.SetActive(true);
		if (this._centerEye)
		{
			this._notification.transform.position = this._centerEye.position + this._centerEye.forward * 0.5f;
			this._notification.transform.rotation = this._centerEye.rotation;
		}
	}

	// Token: 0x0600081D RID: 2077 RVA: 0x000329F2 File Offset: 0x00030BF2
	private IEnumerator GetCenterEye()
	{
		if ((this._cameraRig = Object.FindObjectOfType<OVRCameraRig>()) != null)
		{
			while (!this._centerEye)
			{
				this._centerEye = this._cameraRig.centerEyeAnchor;
				yield return null;
			}
		}
		yield break;
	}

	// Token: 0x04000A25 RID: 2597
	[SerializeField]
	private GameObject _notificationPrefab;

	// Token: 0x04000A26 RID: 2598
	private GameObject _notification;

	// Token: 0x04000A27 RID: 2599
	private OVRCameraRig _cameraRig;

	// Token: 0x04000A28 RID: 2600
	private Transform _centerEye;
}
