﻿using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x02000068 RID: 104
public class TextFader : MonoBehaviour
{
	// Token: 0x060003CE RID: 974 RVA: 0x000193A8 File Offset: 0x000175A8
	private void Start()
	{
		this.gameManager = Object.FindObjectOfType<GameManager>();
		this.startTime = Time.time;
		this.textMaterial = base.GetComponent<TextMeshProUGUI>();
		this.DisableText();
	}

	// Token: 0x060003CF RID: 975 RVA: 0x000193D4 File Offset: 0x000175D4
	private void Update()
	{
		if (this.displayOnceOnly && this.gameManager.TextCheck(SceneManager.GetActiveScene().buildIndex))
		{
			return;
		}
		this.CountToFade();
	}

	// Token: 0x060003D0 RID: 976 RVA: 0x0001940C File Offset: 0x0001760C
	private void DisableText()
	{
		Color c = this.textMaterial.faceColor;
		c.a = 0f;
		this.textMaterial.faceColor = c;
	}

	// Token: 0x060003D1 RID: 977 RVA: 0x00019448 File Offset: 0x00017648
	private void CountToFade()
	{
		if (Time.time >= this.startTime + this.timeToDisplay && Time.time < this.startTime + this.timeToDisplay - this.timeToFade + this.timeOnScreen)
		{
			base.StartCoroutine(this.FadeTo(1f, this.timeToFade));
			return;
		}
		if (Time.time > this.startTime + this.timeToDisplay + this.timeOnScreen + this.timeToFade)
		{
			base.StartCoroutine(this.FadeTo(0f, this.timeToFade));
		}
	}

	// Token: 0x060003D2 RID: 978 RVA: 0x000194DE File Offset: 0x000176DE
	private IEnumerator FadeTo(float aValue, float aTime)
	{
		Color tempColor = this.textMaterial.faceColor;
		float tempAlpha = tempColor.a;
		for (float t = 0f; t < 1f; t += Time.deltaTime / aTime)
		{
			tempColor.a = Mathf.Lerp(tempAlpha, aValue, t);
			this.textMaterial.faceColor = tempColor;
			yield return null;
		}
		yield break;
	}

	// Token: 0x060003D3 RID: 979 RVA: 0x000194FC File Offset: 0x000176FC
	private void OnDestroy()
	{
		this.gameManager.TextBlock(SceneManager.GetActiveScene().buildIndex);
	}

	// Token: 0x040004B4 RID: 1204
	[SerializeField]
	private float timeToDisplay;

	// Token: 0x040004B5 RID: 1205
	[SerializeField]
	private float timeOnScreen = 3f;

	// Token: 0x040004B6 RID: 1206
	[SerializeField]
	private float timeToFade = 2f;

	// Token: 0x040004B7 RID: 1207
	[SerializeField]
	private bool displayOnceOnly;

	// Token: 0x040004B8 RID: 1208
	private TextMeshProUGUI textMaterial;

	// Token: 0x040004B9 RID: 1209
	private float startTime;

	// Token: 0x040004BA RID: 1210
	private bool stop;

	// Token: 0x040004BB RID: 1211
	private GameManager gameManager;
}
