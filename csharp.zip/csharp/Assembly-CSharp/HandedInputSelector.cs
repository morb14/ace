﻿using System;
using UnityEngine;
using UnityEngine.EventSystems;

// Token: 0x02000112 RID: 274
public class HandedInputSelector : MonoBehaviour
{
	// Token: 0x06000700 RID: 1792 RVA: 0x0002CE61 File Offset: 0x0002B061
	private void Start()
	{
		this.m_CameraRig = Object.FindObjectOfType<OVRCameraRig>();
		this.m_InputModule = Object.FindObjectOfType<OVRInputModule>();
	}

	// Token: 0x06000701 RID: 1793 RVA: 0x0002CE79 File Offset: 0x0002B079
	private void Update()
	{
		if (OVRInput.GetActiveController() == OVRInput.Controller.LTouch)
		{
			this.SetActiveController(OVRInput.Controller.LTouch);
			return;
		}
		this.SetActiveController(OVRInput.Controller.RTouch);
	}

	// Token: 0x06000702 RID: 1794 RVA: 0x0002CE94 File Offset: 0x0002B094
	private void SetActiveController(OVRInput.Controller c)
	{
		Transform rayTransform;
		if (c == OVRInput.Controller.LTouch)
		{
			rayTransform = this.m_CameraRig.leftHandAnchor;
		}
		else
		{
			rayTransform = this.m_CameraRig.rightHandAnchor;
		}
		this.m_InputModule.rayTransform = rayTransform;
	}

	// Token: 0x04000939 RID: 2361
	private OVRCameraRig m_CameraRig;

	// Token: 0x0400093A RID: 2362
	private OVRInputModule m_InputModule;
}
