﻿using System;
using UnityEngine;

// Token: 0x02000145 RID: 325
public class ONSPPropagationSettings : MonoBehaviour
{
	// Token: 0x060008A6 RID: 2214 RVA: 0x00038A82 File Offset: 0x00036C82
	private void Update()
	{
		ONSPPropagation.Interface.SetPropagationQuality(this.quality / 100f);
	}

	// Token: 0x04000A75 RID: 2677
	public float quality = 100f;
}
