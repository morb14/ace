﻿using System;

// Token: 0x020000AC RID: 172
public class OvrAvatarAsset
{
	// Token: 0x04000710 RID: 1808
	public ulong assetID;
}
