﻿using System;

// Token: 0x020000E5 RID: 229
public enum ovrAvatarHandGesture
{
	// Token: 0x0400085E RID: 2142
	Default,
	// Token: 0x0400085F RID: 2143
	GripSphere,
	// Token: 0x04000860 RID: 2144
	GripCube,
	// Token: 0x04000861 RID: 2145
	Count
}
