﻿using System;
using System.Collections.Generic;
using System.IO;
using Oculus.Avatar;
using UnityEngine;

// Token: 0x020000A1 RID: 161
public class RemoteLoopbackManager : MonoBehaviour
{
	// Token: 0x06000552 RID: 1362 RVA: 0x00021FC4 File Offset: 0x000201C4
	private void Start()
	{
		this.LocalAvatar.RecordPackets = true;
		OvrAvatar localAvatar = this.LocalAvatar;
		localAvatar.PacketRecorded = (EventHandler<OvrAvatar.PacketEventArgs>)Delegate.Combine(localAvatar.PacketRecorded, new EventHandler<OvrAvatar.PacketEventArgs>(this.OnLocalAvatarPacketRecorded));
		float num = Random.Range(this.LatencySettings.FakeLatencyMin, this.LatencySettings.FakeLatencyMax);
		this.LatencySettings.LatencyValues.AddFirst(num);
		this.LatencySettings.LatencySum += num;
	}

	// Token: 0x06000553 RID: 1363 RVA: 0x00022048 File Offset: 0x00020248
	private void OnLocalAvatarPacketRecorded(object sender, OvrAvatar.PacketEventArgs args)
	{
		using (MemoryStream memoryStream = new MemoryStream())
		{
			BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
			if (this.LocalAvatar.UseSDKPackets)
			{
				uint num = CAPI.ovrAvatarPacket_GetSize(args.Packet.ovrNativePacket);
				byte[] buffer = new byte[num];
				CAPI.ovrAvatarPacket_Write(args.Packet.ovrNativePacket, num, buffer);
				BinaryWriter binaryWriter2 = binaryWriter;
				int packetSequence = this.PacketSequence;
				this.PacketSequence = packetSequence + 1;
				binaryWriter2.Write(packetSequence);
				binaryWriter.Write(num);
				binaryWriter.Write(buffer);
			}
			else
			{
				BinaryWriter binaryWriter3 = binaryWriter;
				int packetSequence = this.PacketSequence;
				this.PacketSequence = packetSequence + 1;
				binaryWriter3.Write(packetSequence);
				args.Packet.Write(memoryStream);
			}
			this.SendPacketData(memoryStream.ToArray());
		}
	}

	// Token: 0x06000554 RID: 1364 RVA: 0x00022114 File Offset: 0x00020314
	private void Update()
	{
		if (this.packetQueue.Count > 0)
		{
			List<RemoteLoopbackManager.PacketLatencyPair> list = new List<RemoteLoopbackManager.PacketLatencyPair>();
			foreach (RemoteLoopbackManager.PacketLatencyPair packetLatencyPair in this.packetQueue)
			{
				packetLatencyPair.FakeLatency -= Time.deltaTime;
				if (packetLatencyPair.FakeLatency < 0f)
				{
					this.ReceivePacketData(packetLatencyPair.PacketData);
					list.Add(packetLatencyPair);
				}
			}
			foreach (RemoteLoopbackManager.PacketLatencyPair value in list)
			{
				this.packetQueue.Remove(value);
			}
		}
	}

	// Token: 0x06000555 RID: 1365 RVA: 0x000221F0 File Offset: 0x000203F0
	private void SendPacketData(byte[] data)
	{
		RemoteLoopbackManager.PacketLatencyPair packetLatencyPair = new RemoteLoopbackManager.PacketLatencyPair();
		packetLatencyPair.PacketData = data;
		packetLatencyPair.FakeLatency = this.LatencySettings.NextValue();
		this.packetQueue.AddLast(packetLatencyPair);
	}

	// Token: 0x06000556 RID: 1366 RVA: 0x00022228 File Offset: 0x00020428
	private void ReceivePacketData(byte[] data)
	{
		using (MemoryStream memoryStream = new MemoryStream(data))
		{
			BinaryReader binaryReader = new BinaryReader(memoryStream);
			int sequence = binaryReader.ReadInt32();
			OvrAvatarPacket packet;
			if (this.LoopbackAvatar.UseSDKPackets)
			{
				int count = binaryReader.ReadInt32();
				byte[] buffer = binaryReader.ReadBytes(count);
				IntPtr ovrNativePacket = CAPI.ovrAvatarPacket_Read((uint)data.Length, buffer);
				packet = new OvrAvatarPacket
				{
					ovrNativePacket = ovrNativePacket
				};
			}
			else
			{
				packet = OvrAvatarPacket.Read(memoryStream);
			}
			this.LoopbackAvatar.GetComponent<OvrAvatarRemoteDriver>().QueuePacket(sequence, packet);
		}
	}

	// Token: 0x04000676 RID: 1654
	public OvrAvatar LocalAvatar;

	// Token: 0x04000677 RID: 1655
	public OvrAvatar LoopbackAvatar;

	// Token: 0x04000678 RID: 1656
	public RemoteLoopbackManager.SimulatedLatencySettings LatencySettings = new RemoteLoopbackManager.SimulatedLatencySettings();

	// Token: 0x04000679 RID: 1657
	private int PacketSequence;

	// Token: 0x0400067A RID: 1658
	private LinkedList<RemoteLoopbackManager.PacketLatencyPair> packetQueue = new LinkedList<RemoteLoopbackManager.PacketLatencyPair>();

	// Token: 0x020001E4 RID: 484
	private class PacketLatencyPair
	{
		// Token: 0x04000E23 RID: 3619
		public byte[] PacketData;

		// Token: 0x04000E24 RID: 3620
		public float FakeLatency;
	}

	// Token: 0x020001E5 RID: 485
	[Serializable]
	public class SimulatedLatencySettings
	{
		// Token: 0x06000C30 RID: 3120 RVA: 0x00043F84 File Offset: 0x00042184
		public float NextValue()
		{
			this.AverageWindow = this.LatencySum / (float)this.LatencyValues.Count;
			float num = Random.Range(this.FakeLatencyMin, this.FakeLatencyMax);
			float num2 = this.AverageWindow * (1f - this.LatencyWeight) + this.LatencyWeight * num;
			if (this.LatencyValues.Count >= this.MaxSamples)
			{
				this.LatencySum -= this.LatencyValues.First.Value;
				this.LatencyValues.RemoveFirst();
			}
			this.LatencySum += num2;
			this.LatencyValues.AddLast(num2);
			return num2;
		}

		// Token: 0x04000E25 RID: 3621
		[Range(0f, 0.5f)]
		public float FakeLatencyMax = 0.25f;

		// Token: 0x04000E26 RID: 3622
		[Range(0f, 0.5f)]
		public float FakeLatencyMin = 0.002f;

		// Token: 0x04000E27 RID: 3623
		[Range(0f, 1f)]
		public float LatencyWeight = 0.25f;

		// Token: 0x04000E28 RID: 3624
		[Range(0f, 10f)]
		public int MaxSamples = 4;

		// Token: 0x04000E29 RID: 3625
		internal float AverageWindow;

		// Token: 0x04000E2A RID: 3626
		internal float LatencySum;

		// Token: 0x04000E2B RID: 3627
		internal LinkedList<float> LatencyValues = new LinkedList<float>();
	}
}
