﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x02000058 RID: 88
public class StagePlanner : MonoBehaviour
{
	// Token: 0x0600034F RID: 847 RVA: 0x000158A4 File Offset: 0x00013AA4
	private void Start()
	{
		SceneManager.sceneLoaded += this.OnSceneLoaded;
		this.gameManager = Object.FindObjectOfType<GameManager>();
		this.controlManager = this.gameManager.GetComponent<ControlManager>();
		this.hapticManager = this.gameManager.GetComponent<HapticManager>();
		this.soundManager = this.gameManager.GetComponent<SoundManager>();
		GameEvents.current.onStagePlannerCompStart += this.UnselectCurrentHighlighted;
		this.LookForHands();
		this.SpawnDeck(this.steelTargets);
		this.ToggleStagePlanner(true);
	}

	// Token: 0x06000350 RID: 848 RVA: 0x00015930 File Offset: 0x00013B30
	private void LookForHands()
	{
		this.leftHand = this.gameManager.handObjectLeft.transform;
		this.menuSelectorLeft = this.leftHand.GetComponent<MenuSelector>();
		this.leftLineTransform = this.menuSelectorLeft.pointerTransform;
		this.menuSelectorLeft.enabled = false;
		this.rightHand = this.gameManager.handObjectRight.transform;
		this.menuSelectorRight = this.rightHand.GetComponent<MenuSelector>();
		this.rightLineTransform = this.menuSelectorRight.pointerTransform;
		this.menuSelectorRight.enabled = false;
	}

	// Token: 0x06000351 RID: 849 RVA: 0x000159C5 File Offset: 0x00013BC5
	private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
	{
		this.currentSpawner = null;
		if (Object.FindObjectOfType<SceneSettings>() && Object.FindObjectOfType<SceneSettings>().sceneType != SceneSettings.SceneType.StagePlanner)
		{
			Object.Destroy(base.gameObject);
		}
		base.Invoke("DelayPlannerDisable", 0.1f);
	}

	// Token: 0x06000352 RID: 850 RVA: 0x00015A02 File Offset: 0x00013C02
	private void DelayPlannerDisable()
	{
		MonoBehaviour.print("DelayPlannerDisable");
		if (Object.FindObjectOfType<SceneSettings>().inStageDesigner)
		{
			this.ToggleStagePlanner(true);
			MonoBehaviour.print("toggle off");
		}
	}

	// Token: 0x06000353 RID: 851 RVA: 0x00015A2C File Offset: 0x00013C2C
	private void SpawnDeck(GameObject[] targets)
	{
		string text = "";
		this.currentTargets = targets;
		if (targets == this.paperTargets)
		{
			text = "Paper";
		}
		else if (targets == this.steelTargets)
		{
			text = "Steel";
		}
		else if (targets == this.miscTargets)
		{
			text = "Misc";
		}
		else if (targets == this.dynamicTargets)
		{
			text = "Dynamic Targets";
		}
		else if (targets == this.barricades)
		{
			text = "Environment";
		}
		else if (targets == this.system)
		{
			text = "System";
		}
		this.currentTargets = targets;
		if (!this.deckInitiated)
		{
			if (this.controlManager.handedness == ControlManager.Handedness.Right)
			{
				this.spawnTargetDeck = Object.Instantiate<GameObject>(this.spawnerDeck, this.rightHand);
				this.activeController = OVRInput.Controller.RTouch;
				this.controlManager.ShowController(this.activeController);
			}
			else
			{
				this.spawnTargetDeck = Object.Instantiate<GameObject>(this.spawnerDeck, this.leftHand);
				this.activeController = OVRInput.Controller.LTouch;
				this.controlManager.ShowController(this.activeController);
			}
			if (this.controlManager.controllerMode == ControlManager.ControllerMode.TwoHand)
			{
				this.controlManager.ShowController(OVRInput.Controller.All);
			}
			this.deck = this.spawnTargetDeck.GetComponent<StagePlannerTargetDeck>();
			this.sphereOriginalScale = this.deck.spheres[0].transform.localScale;
			if (this.controlManager.handedness == ControlManager.Handedness.Right)
			{
				this.spawnTargetDeck.transform.Rotate(0f, 0f, 180f);
			}
			this.spawnTargetDeck.SetActive(false);
			this.deckInitiated = true;
		}
		this.deck.targetTypeTMP.text = text;
		if (this.spawnedDeckList.Count > 0)
		{
			foreach (GameObject obj in this.spawnedDeckList)
			{
				Object.Destroy(obj);
			}
			this.deckList.Clear();
			this.spawnedDeckList.Clear();
		}
		for (int i = 0; i < this.currentTargets.Length; i++)
		{
			if (i < this.deck.spheres.Length)
			{
				GameObject item = Object.Instantiate<GameObject>(this.currentTargets[i], this.deck.spheres[i].transform);
				this.spawnedDeckList.Add(item);
			}
			else
			{
				GameObject gameObject = Object.Instantiate<GameObject>(this.currentTargets[i], Vector3.zero, Quaternion.identity);
				gameObject.SetActive(false);
				this.spawnedDeckList.Add(gameObject);
				this.deckList.Add(gameObject);
			}
		}
		this.spawnerDeck.transform.localPosition = Vector3.zero;
		this.ObjectHighlight();
	}

	// Token: 0x06000354 RID: 852 RVA: 0x00015CD4 File Offset: 0x00013ED4
	private void Update()
	{
		if (!this.disabled)
		{
			this.DeckStatus();
			this.DeckInteraction();
			this.DrawLine();
			this.ObjectRayCast();
			this.CheckDelete();
			this.CheckLink();
		}
		this.ToggleOffOn();
		this.ToggleCompModeInput();
	}

	// Token: 0x06000355 RID: 853 RVA: 0x00015D10 File Offset: 0x00013F10
	private void SwitchDeck()
	{
		if (this.currentTargets == this.steelTargets)
		{
			this.SpawnDeck(this.paperTargets);
			return;
		}
		if (this.currentTargets == this.paperTargets)
		{
			this.SpawnDeck(this.dynamicTargets);
			return;
		}
		if (this.currentTargets == this.dynamicTargets)
		{
			this.SpawnDeck(this.barricades);
			return;
		}
		if (this.currentTargets == this.barricades)
		{
			this.SpawnDeck(this.miscTargets);
			return;
		}
		if (this.currentTargets == this.miscTargets)
		{
			this.SpawnDeck(this.system);
			return;
		}
		if (this.currentTargets == this.system)
		{
			this.SpawnDeck(this.steelTargets);
		}
	}

	// Token: 0x06000356 RID: 854 RVA: 0x00015DC0 File Offset: 0x00013FC0
	private void DeckStatus()
	{
		if (!this.spawnTargetDeck.activeSelf && !this.disabled && (OVRInput.Get(OVRInput.NearTouch.Any, OVRInput.Controller.LTouch) || OVRInput.Get(OVRInput.NearTouch.Any, OVRInput.Controller.RTouch)))
		{
			this.spawnTargetDeck.SetActive(true);
		}
		if (!this.deckOnLeftHand)
		{
			if (OVRInput.Get(OVRInput.NearTouch.Any, OVRInput.Controller.LTouch) && !OVRInput.Get(OVRInput.NearTouch.Any, OVRInput.Controller.RTouch))
			{
				this.SwitchHand();
				this.deckOnLeftHand = true;
				return;
			}
		}
		else if (OVRInput.Get(OVRInput.NearTouch.Any, OVRInput.Controller.RTouch) && !OVRInput.Get(OVRInput.NearTouch.Any, OVRInput.Controller.LTouch))
		{
			this.SwitchHand();
			this.deckOnLeftHand = false;
		}
	}

	// Token: 0x06000357 RID: 855 RVA: 0x00015E48 File Offset: 0x00014048
	private void ObjectRayCast()
	{
		bool flag = false;
		LayerMask mask;
		if (OVRInput.Get(OVRInput.NearTouch.PrimaryIndexTrigger, this.activeController))
		{
			mask = this.layerMask;
			flag = true;
		}
		else if (OVRInput.Get(OVRInput.Touch.Two, this.activeController))
		{
			mask = this.noBarricadeLayerMask;
		}
		else
		{
			mask = this.editLayerMask;
		}
		RaycastHit raycastHit;
		if (Physics.Raycast(this.currentHandTransform.position, this.currentPointerTransform.forward, out raycastHit, float.PositiveInfinity, mask) && !this.adjusting)
		{
			this.pointPosition = raycastHit.point;
			if (raycastHit.transform.root.GetComponent<TargetInfo>() && !flag)
			{
				if (this.currentHighlighted != null && raycastHit.transform.root.gameObject != this.currentHighlighted)
				{
					this.UnselectCurrentHighlighted();
				}
				MonoBehaviour.print(raycastHit.transform.root.name);
				this.currentHighlighted = raycastHit.transform.root.gameObject;
				if (this.currentHighlighted.GetComponent<MaterialAssigner>() && OVRInput.Get(OVRInput.Touch.One, this.activeController) && !OVRInput.Get(OVRInput.Touch.Two, this.activeController))
				{
					this.currentHighlighted.GetComponent<MaterialAssigner>().SwitchMaterial(false, this.deleteMaterial);
					return;
				}
				if (this.currentHighlighted.GetComponent<MaterialAssigner>() && OVRInput.Get(OVRInput.Touch.Two, this.activeController))
				{
					Material toMaterial = this.linkFailMaterial;
					if (this.currentHighlighted.GetComponent<TargetActivator>() || this.currentHighlighted.GetComponent<ActiveTarget>())
					{
						toMaterial = this.linkMaterial;
					}
					this.currentHighlighted.GetComponent<MaterialAssigner>().SwitchMaterial(false, toMaterial);
					return;
				}
			}
			else if (this.currentHighlighted != null)
			{
				this.UnselectCurrentHighlighted();
			}
		}
	}

	// Token: 0x06000358 RID: 856 RVA: 0x00016014 File Offset: 0x00014214
	private void UnselectCurrentHighlighted()
	{
		if (this.currentHighlighted == null)
		{
			return;
		}
		if (this.currentHighlighted.GetComponent<MaterialAssigner>())
		{
			this.currentHighlighted.GetComponent<MaterialAssigner>().SwitchMaterial(true, null);
		}
		if (this.tempColliderList.Count > 0)
		{
			foreach (Collider collider in this.tempColliderList)
			{
				collider.enabled = true;
			}
		}
		this.currentHighlighted = null;
	}

	// Token: 0x06000359 RID: 857 RVA: 0x000160B0 File Offset: 0x000142B0
	private void CheckDelete()
	{
		if (this.currentHighlighted != null && OVRInput.GetDown(OVRInput.Button.One, this.activeController))
		{
			Object.Destroy(this.currentHighlighted);
			this.hapticManager.VibrateStandard(0.5f, 0.5f, 0.1f, this.activeController);
			this.currentHighlighted = null;
		}
	}

	// Token: 0x0600035A RID: 858 RVA: 0x0001610C File Offset: 0x0001430C
	private void CheckLink()
	{
		if (this.currentHighlighted != null && OVRInput.GetDown(OVRInput.Button.Two, this.activeController) && (this.currentHighlighted.GetComponent<TargetActivator>() || this.currentHighlighted.GetComponent<ActiveTarget>()))
		{
			if (this.currentSelected != null)
			{
				if (this.currentHighlighted != this.currentSelected)
				{
					GameObject gameObject = null;
					GameObject gameObject2 = null;
					if (this.currentHighlighted.GetComponent<TargetActivator>() && this.currentSelected.GetComponent<ActiveTarget>())
					{
						gameObject = this.currentSelected;
						gameObject2 = this.currentHighlighted;
					}
					else if (this.currentHighlighted.GetComponent<ActiveTarget>() && this.currentSelected.GetComponent<TargetActivator>())
					{
						gameObject = this.currentHighlighted;
						gameObject2 = this.currentSelected;
					}
					if (gameObject != null)
					{
						gameObject.GetComponent<ActiveTarget>().Link(gameObject2.GetComponent<TargetActivator>(), this.linkLineMaterial, true);
						gameObject2.GetComponent<TargetActivator>().Link(gameObject.GetComponent<ActiveTarget>(), true);
						this.currentSelected = null;
					}
				}
			}
			else
			{
				this.currentSelected = this.currentHighlighted;
			}
			this.hapticManager.VibrateStandard(0.5f, 0.5f, 0.1f, this.activeController);
		}
	}

	// Token: 0x0600035B RID: 859 RVA: 0x0001625C File Offset: 0x0001445C
	private void DrawLine()
	{
		if (this.activeController == OVRInput.Controller.RTouch)
		{
			this.currentHandTransform = this.rightHand.transform;
			this.currentPointerTransform = this.rightLineTransform;
		}
		else
		{
			this.currentHandTransform = this.leftHand.transform;
			this.currentPointerTransform = this.leftLineTransform;
		}
		if (!this.lineRenderer.enabled)
		{
			this.lineRenderer.enabled = true;
		}
		this.lineRenderer.SetPosition(0, this.currentHandTransform.position + this.currentPointerTransform.forward * 0.15f);
		Vector3 position;
		if (this.pointPosition != Vector3.zero)
		{
			position = this.pointPosition;
		}
		else
		{
			position = this.currentHandTransform.position + this.currentPointerTransform.forward * 15f;
		}
		this.lineRenderer.SetPosition(1, position);
	}

	// Token: 0x0600035C RID: 860 RVA: 0x00016348 File Offset: 0x00014548
	private void ShowDistance(bool show)
	{
		if (show && this.currentHandTransform != null)
		{
			float num = Vector3.Distance(this.currentHandTransform.position, this.pointPosition);
			float num2 = num * 1.09361f;
			string text = num.ToString("F1");
			string text2 = num2.ToString("F1");
			this.deck.distanceTMP.text = string.Concat(new string[]
			{
				"Distance: ",
				text,
				"m / ",
				text2,
				"yd"
			});
			return;
		}
		this.deck.distanceTMP.text = "";
	}

	// Token: 0x0600035D RID: 861 RVA: 0x00003297 File Offset: 0x00001497
	private void SwitchHand()
	{
	}

	// Token: 0x0600035E RID: 862 RVA: 0x000163F4 File Offset: 0x000145F4
	private void DeckInteraction()
	{
		float num = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, this.activeController).x;
		num *= this.deckSpinMultipler;
		if (this.deck != null)
		{
			this.deck.deckSpin.Rotate(0f, -num, 0f);
		}
		this.ObjectHighlight();
		if (OVRInput.GetDown(OVRInput.Button.PrimaryIndexTrigger, this.activeController))
		{
			this.SpawnObject();
		}
		if (OVRInput.GetDown(OVRInput.Button.PrimaryThumbstick, this.activeController))
		{
			this.SwitchDeck();
		}
		if (OVRInput.Get(OVRInput.NearTouch.PrimaryIndexTrigger, this.activeController))
		{
			this.lineRenderer.enabled = true;
			this.DrawBluePrint(true);
			this.ShowDistance(true);
		}
		else if (!OVRInput.Get(OVRInput.NearTouch.PrimaryIndexTrigger, this.activeController))
		{
			this.lineRenderer.enabled = false;
			this.DrawBluePrint(false);
		}
		if (OVRInput.GetDown(OVRInput.Button.One, this.activeController) && this.adjusting && this.currentSpawner != null)
		{
			this.adjustmentPosDictionary.Remove(this.currentSpawner);
			this.hapticManager.VibrateStandard(0.5f, 0.5f, 0.5f, this.activeController);
		}
		if (OVRInput.Get(OVRInput.Button.PrimaryHandTrigger, this.activeController) && this.drawing)
		{
			if (!this.adjusting)
			{
				this.adjustOrigins = this.currentHandTransform.position;
				this.adjustOriginalRotation = this.currentHandTransform.rotation;
				this.currentSpawner.Adjusting(true);
				this.adjusting = true;
				return;
			}
		}
		else
		{
			this.TrySaveDictionary();
			this.adjusting = false;
			this.currentSpawner.Adjusting(false);
		}
	}

	// Token: 0x0600035F RID: 863 RVA: 0x00016590 File Offset: 0x00014790
	private void ToggleOffOn()
	{
		if (Object.FindObjectOfType<SceneSettings>().sceneType != SceneSettings.SceneType.StagePlanner)
		{
			return;
		}
		if (OVRInput.Get(OVRInput.Button.Two, this.activeController))
		{
			if (this.toggleStartTime == 1E-45f)
			{
				this.toggleStartTime = Time.time;
			}
			if (Time.time > this.toggleStartTime + this.timeToDisable && !this.disabledCoolDown)
			{
				this.ToggleStagePlanner(!this.disabled);
				this.hapticManager.VibrateStandard(0.5f, 0.5f, 0.2f, this.activeController);
				this.disabledCoolDown = true;
				return;
			}
		}
		else if (this.toggleStartTime != 1E-45f)
		{
			this.toggleStartTime = float.Epsilon;
			this.disabledCoolDown = false;
		}
	}

	// Token: 0x06000360 RID: 864 RVA: 0x00016644 File Offset: 0x00014844
	private void ToggleCompModeInput()
	{
		if (!this.disabled)
		{
			return;
		}
		if (Object.FindObjectOfType<HolsterControl>() && Object.FindObjectOfType<HolsterControl>().gunDrawn)
		{
			return;
		}
		if (OVRInput.Get(OVRInput.Button.One, this.activeController))
		{
			if (this.toggleCompStartTime == 1E-45f)
			{
				this.toggleCompStartTime = Time.time;
			}
			if (Time.time > this.toggleCompStartTime + this.timeToDisable && !this.disabledCoolDown)
			{
				this.ToggleCompMode(!this.compMode);
				this.disabledCoolDown = true;
				return;
			}
		}
		else if (this.toggleCompStartTime != 1E-45f)
		{
			this.toggleCompStartTime = float.Epsilon;
			this.disabledCoolDown = false;
		}
	}

	// Token: 0x06000361 RID: 865 RVA: 0x000166EC File Offset: 0x000148EC
	private void ToggleCompMode(bool on)
	{
		if (Object.FindObjectsOfType<TargetInfo>().Length <= 1)
		{
			GameEvents.current.BroadcastMessage("Spawn some targets before starting comp mode!", false);
			this.soundManager.Play(this.soundManager.UIerror);
			return;
		}
		this.compMode = !this.compMode;
		SceneSettings sceneSettings = Object.FindObjectOfType<SceneSettings>();
		if (sceneSettings.sceneType == SceneSettings.SceneType.StagePlanner && !this.disabled)
		{
			GameEvents.current.BroadcastMessage("Disable the spawner before starting comp mode", false);
			this.soundManager.Play(this.soundManager.UIerror);
			return;
		}
		this.hapticManager.VibrateStandard(0.5f, 0.5f, 0.1f, this.activeController);
		if (on)
		{
			sceneSettings.sceneType = SceneSettings.SceneType.Comp;
			GameEvents.current.StagePlannerCompStart();
			sceneSettings.StartComp();
			return;
		}
		if (Object.FindObjectOfType<Results>() && Object.FindObjectOfType<Results>().IsScored())
		{
			Object.FindObjectOfType<SaveManager>().ResetCustomStage();
			return;
		}
		sceneSettings.sceneType = SceneSettings.SceneType.StagePlanner;
		GameEvents.current.StagePlannerCompEnd();
	}

	// Token: 0x06000362 RID: 866 RVA: 0x000167E8 File Offset: 0x000149E8
	public void ToggleStagePlanner(bool toDisable)
	{
		if (toDisable)
		{
			this.UnselectCurrentHighlighted();
		}
		Object.FindObjectOfType<HolsterControl>().enabled = toDisable;
		this.lineRenderer.enabled = !toDisable;
		this.spawnTargetDeck.SetActive(!toDisable);
		this.disabled = toDisable;
		if (this.activeController == OVRInput.Controller.RTouch)
		{
			this.menuSelectorRight.enabled = this.disabled;
		}
		else
		{
			this.menuSelectorLeft.enabled = this.disabled;
		}
		this.DisableBluePrintInSwitch();
	}

	// Token: 0x06000363 RID: 867 RVA: 0x00016861 File Offset: 0x00014A61
	private Vector3 AdjustmentPosDifference()
	{
		if (this.adjusting)
		{
			return (this.currentHandTransform.position - this.adjustOrigins) * 5f;
		}
		return Vector3.zero;
	}

	// Token: 0x06000364 RID: 868 RVA: 0x00016894 File Offset: 0x00014A94
	private Vector3 SpawnPosition()
	{
		Vector3 zero = Vector3.zero;
		float x = 0f;
		float z = 0f;
		if (this.currentSpawner.adjustHeight)
		{
			this.adjustmentPosDictionary.TryGetValue(this.currentSpawner, out zero);
			if (this.currentSpawner.adjustFineTune)
			{
				x = this.AdjustmentPosDifference().x / 5f;
				z = this.AdjustmentPosDifference().z / 5f;
			}
			return this.pointPosition + new Vector3(x, this.AdjustmentPosDifference().y + zero.y, z);
		}
		return this.pointPosition + new Vector3(0f, 0f, 0f);
	}

	// Token: 0x06000365 RID: 869 RVA: 0x00016949 File Offset: 0x00014B49
	private float Snap()
	{
		return 0f;
	}

	// Token: 0x06000366 RID: 870 RVA: 0x00016950 File Offset: 0x00014B50
	private Quaternion SpawnRotation()
	{
		if (this.currentHandTransform == null)
		{
			return Quaternion.identity;
		}
		Vector3 vector = this.currentHandTransform.forward;
		Quaternion quaternion;
		if (this.currentSpawner.adjustYaw || !this.adjusting)
		{
			vector = new Vector3(vector.x, 0f, vector.z);
			quaternion = Quaternion.LookRotation(vector, Vector3.up);
		}
		else
		{
			vector = this.adjustOriginalRotation * Vector3.forward;
			vector = new Vector3(vector.x, 0f, vector.z);
			quaternion = Quaternion.LookRotation(vector, Vector3.up);
		}
		if (this.currentSpawner.adjustRoll && this.adjusting)
		{
			Quaternion quaternion2 = quaternion * this.currentHandTransform.rotation * Quaternion.Inverse(this.adjustOriginalRotation);
			quaternion2 = new Quaternion(0f, quaternion2.y, quaternion2.z, quaternion2.w);
			quaternion = quaternion2;
		}
		if (this.currentSpawner.adjustPitch)
		{
			bool flag = this.adjusting;
		}
		if (this.currentSpawner.flipped)
		{
			Vector3 eulerAngles = quaternion.eulerAngles;
			eulerAngles = new Vector3(eulerAngles.x, eulerAngles.y, eulerAngles.z + 180f);
			quaternion = Quaternion.Euler(eulerAngles);
		}
		return quaternion;
	}

	// Token: 0x06000367 RID: 871 RVA: 0x00016A94 File Offset: 0x00014C94
	private void DrawBluePrint(bool draw)
	{
		if (draw)
		{
			if (this.currentSpawner != null && this.currentSpawner.indicatorSpawned)
			{
				this.currentSpawner.spawnerIndicator.SetActive(true);
				this.currentSpawner.spawnerIndicator.transform.position = this.SpawnPosition();
				this.currentSpawner.spawnerIndicator.transform.rotation = this.SpawnRotation();
			}
			if (this.currentSpawner.flippable && OVRInput.GetDown(OVRInput.Button.Two, this.controlManager.controller))
			{
				this.currentSpawner.flipped = !this.currentSpawner.flipped;
				MonoBehaviour.print("TARGET FLIPPED");
			}
			this.drawing = true;
			return;
		}
		if (this.currentSpawner != null && this.currentSpawner.indicatorSpawned)
		{
			this.currentSpawner.spawnerIndicator.SetActive(false);
		}
		this.drawing = false;
	}

	// Token: 0x06000368 RID: 872 RVA: 0x00016B88 File Offset: 0x00014D88
	private void TrySaveDictionary()
	{
		if (this.adjusting)
		{
			if (this.adjustmentPosDictionary.ContainsKey(this.currentSpawner))
			{
				this.adjustmentPosDictionary.Remove(this.currentSpawner);
			}
			this.adjustmentPosDictionary.Add(this.currentSpawner, this.currentSpawner.spawnerIndicator.transform.position);
		}
	}

	// Token: 0x06000369 RID: 873 RVA: 0x00016BE8 File Offset: 0x00014DE8
	private void SpawnObject()
	{
		Object.Instantiate<GameObject>(this.currentSpawner.objectToSpawn, this.SpawnPosition(), this.SpawnRotation());
		this.hapticManager.VibrateStandard(0.5f, 0.5f, 0.1f, this.activeController);
		if (this.currentSpawner.spawnSoundEffect != null)
		{
			AudioSource.PlayClipAtPoint(this.currentSpawner.spawnSoundEffect, this.currentSpawner.transform.position);
		}
	}

	// Token: 0x0600036A RID: 874 RVA: 0x00016C65 File Offset: 0x00014E65
	private void SelectCurrentSpawner(bool state)
	{
		if (this.currentSpawner != null)
		{
			this.currentSpawner.GetComponent<MaterialAssigner>().SwitchMaterial(state, null);
			if (!this.currentSpawner.indicatorSpawned)
			{
				this.currentSpawner.SpawnIndicator();
			}
		}
	}

	// Token: 0x0600036B RID: 875 RVA: 0x00016C9F File Offset: 0x00014E9F
	private void DisableBluePrintInSwitch()
	{
		if (this.currentSpawner != null && this.currentSpawner.spawnerIndicator != null)
		{
			this.currentSpawner.spawnerIndicator.SetActive(false);
		}
	}

	// Token: 0x0600036C RID: 876 RVA: 0x00016CD4 File Offset: 0x00014ED4
	private void ObjectHighlight()
	{
		float y = this.deck.deckSpin.localEulerAngles.y;
		if ((y > 290f && y < 360f) || (y >= 0f && y < 10f))
		{
			this.deck.spheres[0].transform.localScale = this.sphereOriginalScale * 1.25f;
			this.DisableBluePrintInSwitch();
			this.currentSpawner = this.deck.spheres[0].GetComponentInChildren<ObjectSpawner>();
			this.SelectCurrentSpawner(true);
			return;
		}
		if (y > 165f && y < 250f)
		{
			this.deck.spheres[1].transform.localScale = this.sphereOriginalScale * 1.25f;
			this.DisableBluePrintInSwitch();
			this.currentSpawner = this.deck.spheres[1].GetComponentInChildren<ObjectSpawner>();
			this.SelectCurrentSpawner(true);
			return;
		}
		if (y > 55f && y < 125f)
		{
			this.deck.spheres[2].transform.localScale = this.sphereOriginalScale * 1.25f;
			this.DisableBluePrintInSwitch();
			this.currentSpawner = this.deck.spheres[2].GetComponentInChildren<ObjectSpawner>();
			this.SelectCurrentSpawner(true);
			return;
		}
		this.deck.spheres[0].transform.localScale = this.sphereOriginalScale;
		this.deck.spheres[1].transform.localScale = this.sphereOriginalScale;
		this.deck.spheres[2].transform.localScale = this.sphereOriginalScale;
		this.SelectCurrentSpawner(false);
	}

	// Token: 0x0600036D RID: 877 RVA: 0x00016E7C File Offset: 0x0001507C
	public void BackSpawnnerHotSwap(ObjectSpawner spawner)
	{
		Vector3 localEulerAngles = this.deck.deckSpin.localEulerAngles;
		float x = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, this.activeController).x;
		if (this.currentTargets.Length > this.deck.spheres.Length)
		{
			spawner.gameObject.SetActive(false);
		}
		if (x > 0f)
		{
			this.deckToLoadIndex--;
		}
		else
		{
			this.deckToLoadIndex++;
		}
		if (this.deckToLoadIndex >= this.deckList.Count)
		{
			this.deckToLoadIndex = 0;
		}
		else if (this.deckToLoadIndex < 0)
		{
			this.deckToLoadIndex = this.deckList.Count - 1;
		}
		this.deckList[this.deckToLoadIndex].transform.parent = spawner.gameObject.transform.parent;
		this.deckList[this.deckToLoadIndex].transform.localScale = Vector3.one;
		this.deckList[this.deckToLoadIndex].transform.localPosition = Vector3.zero;
		this.deckList[this.deckToLoadIndex].transform.localRotation = Quaternion.identity;
		this.deckList[this.deckToLoadIndex].SetActive(true);
		this.deckList[this.deckToLoadIndex] = spawner.gameObject;
	}

	// Token: 0x0600036E RID: 878 RVA: 0x00016FE4 File Offset: 0x000151E4
	private void OnDestroy()
	{
		GameEvents.current.onStagePlannerCompStart -= this.UnselectCurrentHighlighted;
		SceneManager.sceneLoaded -= this.OnSceneLoaded;
	}

	// Token: 0x040003FC RID: 1020
	[SerializeField]
	private GameObject[] paperTargets;

	// Token: 0x040003FD RID: 1021
	[SerializeField]
	private GameObject[] steelTargets;

	// Token: 0x040003FE RID: 1022
	[SerializeField]
	private GameObject[] miscTargets;

	// Token: 0x040003FF RID: 1023
	[SerializeField]
	private GameObject[] dynamicTargets;

	// Token: 0x04000400 RID: 1024
	[SerializeField]
	private GameObject[] barricades;

	// Token: 0x04000401 RID: 1025
	[SerializeField]
	private GameObject[] system;

	// Token: 0x04000402 RID: 1026
	[SerializeField]
	private GameObject spawnerDeck;

	// Token: 0x04000403 RID: 1027
	[SerializeField]
	private float deckSpinMultipler = 10f;

	// Token: 0x04000404 RID: 1028
	[SerializeField]
	private Material lineRendererSpawn;

	// Token: 0x04000405 RID: 1029
	[SerializeField]
	private Material lineRendererAdjust;

	// Token: 0x04000406 RID: 1030
	[SerializeField]
	private LayerMask layerMask;

	// Token: 0x04000407 RID: 1031
	[SerializeField]
	private LayerMask editLayerMask;

	// Token: 0x04000408 RID: 1032
	[SerializeField]
	private LayerMask noBarricadeLayerMask;

	// Token: 0x04000409 RID: 1033
	[SerializeField]
	private Material deleteMaterial;

	// Token: 0x0400040A RID: 1034
	[SerializeField]
	private Material linkMaterial;

	// Token: 0x0400040B RID: 1035
	[SerializeField]
	private Material linkFailMaterial;

	// Token: 0x0400040C RID: 1036
	[SerializeField]
	public Material linkLineMaterial;

	// Token: 0x0400040D RID: 1037
	private Transform leftHand;

	// Token: 0x0400040E RID: 1038
	private Transform rightHand;

	// Token: 0x0400040F RID: 1039
	private Transform pointerTransform;

	// Token: 0x04000410 RID: 1040
	private GameObject spawnTargetDeck;

	// Token: 0x04000411 RID: 1041
	private StagePlannerTargetDeck deck;

	// Token: 0x04000412 RID: 1042
	private Vector3 sphereOriginalScale;

	// Token: 0x04000413 RID: 1043
	public OVRInput.Controller activeController;

	// Token: 0x04000414 RID: 1044
	private bool deckInitiated;

	// Token: 0x04000415 RID: 1045
	private bool deckOnLeftHand;

	// Token: 0x04000416 RID: 1046
	private bool disabled;

	// Token: 0x04000417 RID: 1047
	private bool drawing;

	// Token: 0x04000418 RID: 1048
	private bool adjusting;

	// Token: 0x04000419 RID: 1049
	private bool disabledCoolDown;

	// Token: 0x0400041A RID: 1050
	private bool compMode;

	// Token: 0x0400041B RID: 1051
	private ObjectSpawner currentSpawner;

	// Token: 0x0400041C RID: 1052
	private ObjectSpawner backSpawner;

	// Token: 0x0400041D RID: 1053
	private GameObject objectToSpawn;

	// Token: 0x0400041E RID: 1054
	private MenuSelector menuSelectorLeft;

	// Token: 0x0400041F RID: 1055
	private MenuSelector menuSelectorRight;

	// Token: 0x04000420 RID: 1056
	private Transform leftLineTransform;

	// Token: 0x04000421 RID: 1057
	private Transform rightLineTransform;

	// Token: 0x04000422 RID: 1058
	private Transform currentPointerTransform;

	// Token: 0x04000423 RID: 1059
	private Transform currentHandTransform;

	// Token: 0x04000424 RID: 1060
	private Vector3 pointPosition;

	// Token: 0x04000425 RID: 1061
	private Vector3 adjustOrigins;

	// Token: 0x04000426 RID: 1062
	private Quaternion adjustOriginalRotation;

	// Token: 0x04000427 RID: 1063
	public List<GameObject> spawnedDeckList = new List<GameObject>();

	// Token: 0x04000428 RID: 1064
	public List<GameObject> deckList = new List<GameObject>();

	// Token: 0x04000429 RID: 1065
	public int deckToLoadIndex;

	// Token: 0x0400042A RID: 1066
	private Dictionary<ObjectSpawner, Vector3> adjustmentPosDictionary = new Dictionary<ObjectSpawner, Vector3>();

	// Token: 0x0400042B RID: 1067
	private HapticManager hapticManager;

	// Token: 0x0400042C RID: 1068
	private float toggleStartTime;

	// Token: 0x0400042D RID: 1069
	private float toggleCompStartTime;

	// Token: 0x0400042E RID: 1070
	[SerializeField]
	private float timeToDisable = 2f;

	// Token: 0x0400042F RID: 1071
	[SerializeField]
	private LineRenderer lineRenderer;

	// Token: 0x04000430 RID: 1072
	private GameObject[] currentTargets;

	// Token: 0x04000431 RID: 1073
	private GameObject currentHighlighted;

	// Token: 0x04000432 RID: 1074
	private GameObject currentSelected;

	// Token: 0x04000433 RID: 1075
	private List<Collider> tempColliderList = new List<Collider>();

	// Token: 0x04000434 RID: 1076
	private SoundManager soundManager;

	// Token: 0x04000435 RID: 1077
	private GameManager gameManager;

	// Token: 0x04000436 RID: 1078
	private ControlManager controlManager;
}
