﻿using System;
using UnityEngine;

// Token: 0x02000117 RID: 279
[RequireComponent(typeof(CharacterController))]
[RequireComponent(typeof(OVRPlayerController))]
public class CharacterCameraConstraint : MonoBehaviour
{
	// Token: 0x0600071E RID: 1822 RVA: 0x0002D640 File Offset: 0x0002B840
	private CharacterCameraConstraint()
	{
		this._cameraUpdateAction = new Action(this.CameraUpdate);
		this._preCharacterMovementAction = new Action(this.PreCharacterMovement);
	}

	// Token: 0x0600071F RID: 1823 RVA: 0x0002D698 File Offset: 0x0002B898
	private void Awake()
	{
		this._character = base.GetComponent<CharacterController>();
		this._playerController = base.GetComponent<OVRPlayerController>();
	}

	// Token: 0x06000720 RID: 1824 RVA: 0x0002D6B2 File Offset: 0x0002B8B2
	private void OnEnable()
	{
		this._playerController.CameraUpdated += this._cameraUpdateAction;
		this._playerController.PreCharacterMove += this._preCharacterMovementAction;
	}

	// Token: 0x06000721 RID: 1825 RVA: 0x0002D6D6 File Offset: 0x0002B8D6
	private void OnDisable()
	{
		this._playerController.PreCharacterMove -= this._preCharacterMovementAction;
		this._playerController.CameraUpdated -= this._cameraUpdateAction;
	}

	// Token: 0x06000722 RID: 1826 RVA: 0x0002D6FC File Offset: 0x0002B8FC
	private void CameraUpdate()
	{
		if (this.DynamicHeight)
		{
			float cameraHeight = this._playerController.CameraHeight;
			if (cameraHeight <= this._character.height)
			{
				this._character.height = cameraHeight - this._character.skinWidth;
				return;
			}
			Vector3 vector = this._character.transform.position;
			vector += this._character.center;
			vector.y -= this._character.height / 2f + this._character.radius;
			float num = this._character.radius - this._character.skinWidth;
			RaycastHit raycastHit;
			if (this.EnableCollision && Physics.SphereCast(vector, this._character.radius, Vector3.up, out raycastHit, cameraHeight + num, this._character.gameObject.layer, QueryTriggerInteraction.Ignore))
			{
				this._character.height = raycastHit.distance - this._character.radius - this._character.skinWidth;
				Transform transform = this._character.transform;
				Vector3 position = transform.position;
				position.y -= cameraHeight - raycastHit.distance + num;
				transform.position = position;
				return;
			}
			this._character.height = cameraHeight - this._character.skinWidth;
		}
	}

	// Token: 0x06000723 RID: 1827 RVA: 0x0002D858 File Offset: 0x0002BA58
	private void PreCharacterMovement()
	{
		if (this._playerController.Teleported)
		{
			return;
		}
		Vector3 position = this.CameraRig.transform.position;
		Vector3 position2 = this.CameraRig.centerEyeAnchor.position;
		Vector3 vector = position2 - base.transform.position;
		vector.y = 0f;
		if (vector.magnitude > 0f)
		{
			this._character.Move(vector);
			Vector3 vector2 = base.transform.position - position2;
			vector2.y = 0f;
			this.CurrentDistance = vector2.magnitude;
			this.CameraRig.transform.position = position;
			if (this.EnableCollision)
			{
				if (this.CurrentDistance > 0f)
				{
					this.CameraRig.transform.position = position - vector;
				}
				return;
			}
		}
		else
		{
			this.CurrentDistance = 0f;
		}
		Vector3 vector3 = base.transform.position;
		vector3 += this._character.center;
		vector3.y -= this._character.height / 2f;
		float cameraHeight = this._playerController.CameraHeight;
		RaycastHit raycastHit;
		if (Physics.SphereCast(vector3, this._character.radius, Vector3.up, out raycastHit, cameraHeight, base.gameObject.layer, QueryTriggerInteraction.Ignore))
		{
			float num = raycastHit.distance;
			num = cameraHeight - num;
			if (num > this.CurrentDistance)
			{
				this.CurrentDistance = num;
			}
		}
	}

	// Token: 0x04000951 RID: 2385
	[Tooltip("This should be a reference to the OVRCameraRig that is usually a child of the PlayerController.")]
	public OVRCameraRig CameraRig;

	// Token: 0x04000952 RID: 2386
	[Tooltip("This value represents the character capsule's distance from the HMD's position. When the player is moving in legal space without collisions, this will be zero.")]
	public float CurrentDistance;

	// Token: 0x04000953 RID: 2387
	[Tooltip("When true, the camera will fade to black when the HMD is moved into collidable geometry.")]
	public bool EnableFadeout;

	// Token: 0x04000954 RID: 2388
	[Tooltip("When true, the camera will be prevented from passing through collidable geometry. This is usually considered uncomfortable for users.")]
	public bool EnableCollision;

	// Token: 0x04000955 RID: 2389
	[Tooltip("When true, adjust the character controller height on the fly to match the HMD's offset from the ground which will allow ducking to go through smaller spaces.")]
	public bool DynamicHeight;

	// Token: 0x04000956 RID: 2390
	[Tooltip("This should be set to 1 to make the screen completely fade out when the HMD is inside world geometry. Lesser values can be useful for testing.")]
	public float MaxFade = 1f;

	// Token: 0x04000957 RID: 2391
	[Tooltip("This value is used to control how far from the character capsule the HMD must be before the fade to black begins.")]
	public float FadeMinDistance = 0.25f;

	// Token: 0x04000958 RID: 2392
	[Tooltip("This value is used to control how far from the character capsule the HMD must be before the fade to black is complete. This should be tuned so that it is fully faded in before the camera will clip geometry that the player should not be able see beyond.")]
	public float FadeMaxDistance = 0.35f;

	// Token: 0x04000959 RID: 2393
	private readonly Action _cameraUpdateAction;

	// Token: 0x0400095A RID: 2394
	private readonly Action _preCharacterMovementAction;

	// Token: 0x0400095B RID: 2395
	private CharacterController _character;

	// Token: 0x0400095C RID: 2396
	private OVRPlayerController _playerController;
}
