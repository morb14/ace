﻿using System;
using UnityEngine;

// Token: 0x02000094 RID: 148
public class TutorialToDoList : MonoBehaviour
{
	// Token: 0x06000503 RID: 1283 RVA: 0x00003297 File Offset: 0x00001497
	private void Start()
	{
	}

	// Token: 0x06000504 RID: 1284 RVA: 0x00003297 File Offset: 0x00001497
	private void Update()
	{
	}
}
