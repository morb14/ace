﻿using System;
using System.Runtime.InteropServices;

// Token: 0x020000CC RID: 204
public struct ovrAvatarHandInputState
{
	// Token: 0x040007D5 RID: 2005
	public ovrAvatarTransform transform;

	// Token: 0x040007D6 RID: 2006
	public ovrAvatarButton buttonMask;

	// Token: 0x040007D7 RID: 2007
	public ovrAvatarTouch touchMask;

	// Token: 0x040007D8 RID: 2008
	public float joystickX;

	// Token: 0x040007D9 RID: 2009
	public float joystickY;

	// Token: 0x040007DA RID: 2010
	public float indexTrigger;

	// Token: 0x040007DB RID: 2011
	public float handTrigger;

	// Token: 0x040007DC RID: 2012
	[MarshalAs(UnmanagedType.I1)]
	public bool isActive;
}
