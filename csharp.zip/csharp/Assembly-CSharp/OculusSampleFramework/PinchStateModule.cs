﻿using System;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x02000167 RID: 359
	public class PinchStateModule
	{
		// Token: 0x17000068 RID: 104
		// (get) Token: 0x06000988 RID: 2440 RVA: 0x0003BE85 File Offset: 0x0003A085
		public bool PinchUpAndDownOnFocusedObject
		{
			get
			{
				return this._currPinchState == PinchStateModule.PinchState.PinchUp && this._firstFocusedInteractable != null;
			}
		}

		// Token: 0x17000069 RID: 105
		// (get) Token: 0x06000989 RID: 2441 RVA: 0x0003BE9E File Offset: 0x0003A09E
		public bool PinchSteadyOnFocusedObject
		{
			get
			{
				return this._currPinchState == PinchStateModule.PinchState.PinchStay && this._firstFocusedInteractable != null;
			}
		}

		// Token: 0x1700006A RID: 106
		// (get) Token: 0x0600098A RID: 2442 RVA: 0x0003BEB7 File Offset: 0x0003A0B7
		public bool PinchDownOnFocusedObject
		{
			get
			{
				return this._currPinchState == PinchStateModule.PinchState.PinchDown && this._firstFocusedInteractable != null;
			}
		}

		// Token: 0x0600098B RID: 2443 RVA: 0x0003BED0 File Offset: 0x0003A0D0
		public PinchStateModule()
		{
			this._currPinchState = PinchStateModule.PinchState.None;
			this._firstFocusedInteractable = null;
		}

		// Token: 0x0600098C RID: 2444 RVA: 0x0003BEE8 File Offset: 0x0003A0E8
		public void UpdateState(OVRHand hand, Interactable currFocusedInteractable)
		{
			float fingerPinchStrength = hand.GetFingerPinchStrength(OVRHand.HandFinger.Index);
			bool flag = Mathf.Abs(1f - fingerPinchStrength) < Mathf.Epsilon;
			switch (this._currPinchState)
			{
			case PinchStateModule.PinchState.PinchDown:
				this._currPinchState = (flag ? PinchStateModule.PinchState.PinchStay : PinchStateModule.PinchState.PinchUp);
				if (this._firstFocusedInteractable != currFocusedInteractable)
				{
					this._firstFocusedInteractable = null;
					return;
				}
				break;
			case PinchStateModule.PinchState.PinchStay:
				if (!flag)
				{
					this._currPinchState = PinchStateModule.PinchState.PinchUp;
				}
				if (currFocusedInteractable != this._firstFocusedInteractable)
				{
					this._firstFocusedInteractable = null;
					return;
				}
				break;
			case PinchStateModule.PinchState.PinchUp:
				if (!flag)
				{
					this._currPinchState = PinchStateModule.PinchState.None;
					this._firstFocusedInteractable = null;
					return;
				}
				this._currPinchState = PinchStateModule.PinchState.PinchDown;
				if (currFocusedInteractable != this._firstFocusedInteractable)
				{
					this._firstFocusedInteractable = null;
					return;
				}
				break;
			default:
				if (flag)
				{
					this._currPinchState = PinchStateModule.PinchState.PinchDown;
					this._firstFocusedInteractable = currFocusedInteractable;
				}
				break;
			}
		}

		// Token: 0x04000B2A RID: 2858
		private const float PINCH_STRENGTH_THRESHOLD = 1f;

		// Token: 0x04000B2B RID: 2859
		private PinchStateModule.PinchState _currPinchState;

		// Token: 0x04000B2C RID: 2860
		private Interactable _firstFocusedInteractable;

		// Token: 0x02000242 RID: 578
		private enum PinchState
		{
			// Token: 0x04000FD0 RID: 4048
			None,
			// Token: 0x04000FD1 RID: 4049
			PinchDown,
			// Token: 0x04000FD2 RID: 4050
			PinchStay,
			// Token: 0x04000FD3 RID: 4051
			PinchUp
		}
	}
}
