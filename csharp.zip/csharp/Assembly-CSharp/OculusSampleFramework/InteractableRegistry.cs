﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x0200015D RID: 349
	public class InteractableRegistry : MonoBehaviour
	{
		// Token: 0x17000053 RID: 83
		// (get) Token: 0x06000941 RID: 2369 RVA: 0x0003B280 File Offset: 0x00039480
		public static HashSet<Interactable> Interactables
		{
			get
			{
				return InteractableRegistry._interactables;
			}
		}

		// Token: 0x06000942 RID: 2370 RVA: 0x0003B287 File Offset: 0x00039487
		public static void RegisterInteractable(Interactable interactable)
		{
			InteractableRegistry.Interactables.Add(interactable);
		}

		// Token: 0x06000943 RID: 2371 RVA: 0x0003B295 File Offset: 0x00039495
		public static void UnregisterInteractable(Interactable interactable)
		{
			InteractableRegistry.Interactables.Remove(interactable);
		}

		// Token: 0x04000AFB RID: 2811
		public static HashSet<Interactable> _interactables = new HashSet<Interactable>();
	}
}
