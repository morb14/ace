﻿using System;

namespace OculusSampleFramework
{
	// Token: 0x02000162 RID: 354
	[Flags]
	public enum InteractableToolTags
	{
		// Token: 0x04000B15 RID: 2837
		None = 0,
		// Token: 0x04000B16 RID: 2838
		Ray = 1,
		// Token: 0x04000B17 RID: 2839
		Poke = 4,
		// Token: 0x04000B18 RID: 2840
		All = -1
	}
}
