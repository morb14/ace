﻿using System;

namespace OculusSampleFramework
{
	// Token: 0x0200015C RID: 348
	public class InteractableStateArgs : EventArgs
	{
		// Token: 0x06000940 RID: 2368 RVA: 0x0003B253 File Offset: 0x00039453
		public InteractableStateArgs(Interactable interactable, InteractableTool tool, InteractableState newInteractableState, InteractableState oldState, ColliderZoneArgs colliderArgs)
		{
			this.Interactable = interactable;
			this.Tool = tool;
			this.NewInteractableState = newInteractableState;
			this.OldInteractableState = oldState;
			this.ColliderArgs = colliderArgs;
		}

		// Token: 0x04000AF6 RID: 2806
		public readonly Interactable Interactable;

		// Token: 0x04000AF7 RID: 2807
		public readonly InteractableTool Tool;

		// Token: 0x04000AF8 RID: 2808
		public readonly InteractableState OldInteractableState;

		// Token: 0x04000AF9 RID: 2809
		public readonly InteractableState NewInteractableState;

		// Token: 0x04000AFA RID: 2810
		public readonly ColliderZoneArgs ColliderArgs;
	}
}
