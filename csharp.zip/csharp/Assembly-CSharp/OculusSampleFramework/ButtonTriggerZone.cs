﻿using System;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x02000154 RID: 340
	public class ButtonTriggerZone : MonoBehaviour, ColliderZone
	{
		// Token: 0x1700003E RID: 62
		// (get) Token: 0x06000906 RID: 2310 RVA: 0x0003AAF6 File Offset: 0x00038CF6
		// (set) Token: 0x06000907 RID: 2311 RVA: 0x0003AAFE File Offset: 0x00038CFE
		public Collider Collider { get; private set; }

		// Token: 0x1700003F RID: 63
		// (get) Token: 0x06000908 RID: 2312 RVA: 0x0003AB07 File Offset: 0x00038D07
		// (set) Token: 0x06000909 RID: 2313 RVA: 0x0003AB0F File Offset: 0x00038D0F
		public Interactable ParentInteractable { get; private set; }

		// Token: 0x17000040 RID: 64
		// (get) Token: 0x0600090A RID: 2314 RVA: 0x0003AB18 File Offset: 0x00038D18
		public InteractableCollisionDepth CollisionDepth
		{
			get
			{
				if (this.ParentInteractable.ProximityCollider == this)
				{
					return InteractableCollisionDepth.Proximity;
				}
				if (this.ParentInteractable.ContactCollider == this)
				{
					return InteractableCollisionDepth.Contact;
				}
				if (this.ParentInteractable.ActionCollider != this)
				{
					return InteractableCollisionDepth.None;
				}
				return InteractableCollisionDepth.Action;
			}
		}

		// Token: 0x0600090B RID: 2315 RVA: 0x0003AB58 File Offset: 0x00038D58
		private void Awake()
		{
			this.Collider = base.GetComponent<Collider>();
			this.ParentInteractable = this._parentInteractableObj.GetComponent<Interactable>();
		}

		// Token: 0x04000ACA RID: 2762
		[SerializeField]
		private GameObject _parentInteractableObj;
	}
}
