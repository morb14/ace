﻿using System;
using System.Collections;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x0200016D RID: 365
	public class PanelHMDFollower : MonoBehaviour
	{
		// Token: 0x060009BF RID: 2495 RVA: 0x0003CA1D File Offset: 0x0003AC1D
		private void Awake()
		{
			this._cameraRig = Object.FindObjectOfType<OVRCameraRig>();
			this._panelInitialPosition = base.transform.position;
		}

		// Token: 0x060009C0 RID: 2496 RVA: 0x0003CA3C File Offset: 0x0003AC3C
		private void Update()
		{
			Vector3 position = this._cameraRig.centerEyeAnchor.position;
			Vector3 position2 = base.transform.position;
			float num = Vector3.Distance(position, this._lastMovedToPos);
			float num2 = (this._cameraRig.centerEyeAnchor.position - this._prevPos).magnitude / Time.deltaTime;
			Vector3 vector = base.transform.position - position;
			float magnitude = vector.magnitude;
			if ((num > this._maxDistance || this._minZDistance > vector.z || this._minDistance > magnitude) && num2 < 0.3f && this._coroutine == null && this._coroutine == null)
			{
				this._coroutine = base.StartCoroutine(this.LerpToHMD());
			}
			this._prevPos = this._cameraRig.centerEyeAnchor.position;
		}

		// Token: 0x060009C1 RID: 2497 RVA: 0x0003CB16 File Offset: 0x0003AD16
		private Vector3 CalculateIdealAnchorPosition()
		{
			return this._cameraRig.centerEyeAnchor.position + this._panelInitialPosition;
		}

		// Token: 0x060009C2 RID: 2498 RVA: 0x0003CB33 File Offset: 0x0003AD33
		private IEnumerator LerpToHMD()
		{
			Vector3 newPanelPosition = this.CalculateIdealAnchorPosition();
			this._lastMovedToPos = this._cameraRig.centerEyeAnchor.position;
			float startTime = Time.time;
			float endTime = Time.time + 3f;
			while (Time.time < endTime)
			{
				base.transform.position = Vector3.Lerp(base.transform.position, newPanelPosition, (Time.time - startTime) / 3f);
				yield return null;
			}
			base.transform.position = newPanelPosition;
			this._coroutine = null;
			yield break;
		}

		// Token: 0x04000B4E RID: 2894
		private const float TOTAL_DURATION = 3f;

		// Token: 0x04000B4F RID: 2895
		private const float HMD_MOVEMENT_THRESHOLD = 0.3f;

		// Token: 0x04000B50 RID: 2896
		[SerializeField]
		private float _maxDistance = 0.3f;

		// Token: 0x04000B51 RID: 2897
		[SerializeField]
		private float _minDistance = 0.05f;

		// Token: 0x04000B52 RID: 2898
		[SerializeField]
		private float _minZDistance = 0.05f;

		// Token: 0x04000B53 RID: 2899
		private OVRCameraRig _cameraRig;

		// Token: 0x04000B54 RID: 2900
		private Vector3 _panelInitialPosition = Vector3.zero;

		// Token: 0x04000B55 RID: 2901
		private Coroutine _coroutine;

		// Token: 0x04000B56 RID: 2902
		private Vector3 _prevPos = Vector3.zero;

		// Token: 0x04000B57 RID: 2903
		private Vector3 _lastMovedToPos = Vector3.zero;
	}
}
