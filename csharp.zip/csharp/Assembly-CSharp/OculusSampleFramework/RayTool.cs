﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x02000168 RID: 360
	public class RayTool : InteractableTool
	{
		// Token: 0x1700006B RID: 107
		// (get) Token: 0x0600098D RID: 2445 RVA: 0x00018666 File Offset: 0x00016866
		public override InteractableToolTags ToolTags
		{
			get
			{
				return InteractableToolTags.Ray;
			}
		}

		// Token: 0x1700006C RID: 108
		// (get) Token: 0x0600098E RID: 2446 RVA: 0x0003BFB1 File Offset: 0x0003A1B1
		public override ToolInputState ToolInputState
		{
			get
			{
				if (this._pinchStateModule.PinchDownOnFocusedObject)
				{
					return ToolInputState.PrimaryInputDown;
				}
				if (this._pinchStateModule.PinchSteadyOnFocusedObject)
				{
					return ToolInputState.PrimaryInputDownStay;
				}
				if (this._pinchStateModule.PinchUpAndDownOnFocusedObject)
				{
					return ToolInputState.PrimaryInputUp;
				}
				return ToolInputState.Inactive;
			}
		}

		// Token: 0x1700006D RID: 109
		// (get) Token: 0x0600098F RID: 2447 RVA: 0x00018666 File Offset: 0x00016866
		public override bool IsFarFieldTool
		{
			get
			{
				return true;
			}
		}

		// Token: 0x1700006E RID: 110
		// (get) Token: 0x06000990 RID: 2448 RVA: 0x0003BFE1 File Offset: 0x0003A1E1
		// (set) Token: 0x06000991 RID: 2449 RVA: 0x0003BFEE File Offset: 0x0003A1EE
		public override bool EnableState
		{
			get
			{
				return this._rayToolView.EnableState;
			}
			set
			{
				this._rayToolView.EnableState = value;
			}
		}

		// Token: 0x06000992 RID: 2450 RVA: 0x0003BFFC File Offset: 0x0003A1FC
		public override void Initialize()
		{
			InteractableToolsInputRouter.Instance.RegisterInteractableTool(this);
			this._rayToolView.InteractableTool = this;
			this._coneAngleReleaseDegrees = this._coneAngleDegrees * 1.2f;
			this._initialized = true;
		}

		// Token: 0x06000993 RID: 2451 RVA: 0x0003C02E File Offset: 0x0003A22E
		private void OnDestroy()
		{
			if (InteractableToolsInputRouter.Instance != null)
			{
				InteractableToolsInputRouter.Instance.UnregisterInteractableTool(this);
			}
		}

		// Token: 0x06000994 RID: 2452 RVA: 0x0003C048 File Offset: 0x0003A248
		private void Update()
		{
			if (!HandsManager.Instance || !HandsManager.Instance.IsInitialized() || !this._initialized)
			{
				return;
			}
			OVRHand ovrhand = base.IsRightHandedTool ? HandsManager.Instance.RightHand : HandsManager.Instance.LeftHand;
			Transform pointerPose = ovrhand.PointerPose;
			base.transform.position = pointerPose.position;
			base.transform.rotation = pointerPose.rotation;
			Vector3 interactionPosition = base.InteractionPosition;
			Vector3 position = base.transform.position;
			base.Velocity = (position - interactionPosition) / Time.deltaTime;
			base.InteractionPosition = position;
			this._pinchStateModule.UpdateState(ovrhand, this._focusedInteractable);
			this._rayToolView.ToolActivateState = (this._pinchStateModule.PinchSteadyOnFocusedObject || this._pinchStateModule.PinchDownOnFocusedObject);
		}

		// Token: 0x06000995 RID: 2453 RVA: 0x0003C127 File Offset: 0x0003A327
		private Vector3 GetRayCastOrigin()
		{
			return base.transform.position + 0.8f * base.transform.forward;
		}

		// Token: 0x06000996 RID: 2454 RVA: 0x0003C150 File Offset: 0x0003A350
		public override List<InteractableCollisionInfo> GetNextIntersectingObjects()
		{
			if (!this._initialized)
			{
				return this._currentIntersectingObjects;
			}
			if (this._currInteractableCastedAgainst != null && this.HasRayReleasedInteractable(this._currInteractableCastedAgainst))
			{
				this._currInteractableCastedAgainst = null;
			}
			if (this._currInteractableCastedAgainst == null)
			{
				this._currentIntersectingObjects.Clear();
				this._currInteractableCastedAgainst = this.FindTargetInteractable();
				if (this._currInteractableCastedAgainst != null)
				{
					int num = Physics.OverlapSphereNonAlloc(this._currInteractableCastedAgainst.transform.position, 0.01f, this._collidersOverlapped);
					for (int i = 0; i < num; i++)
					{
						ColliderZone component = this._collidersOverlapped[i].GetComponent<ColliderZone>();
						if (component != null)
						{
							Interactable parentInteractable = component.ParentInteractable;
							if (!(parentInteractable == null) && !(parentInteractable != this._currInteractableCastedAgainst))
							{
								InteractableCollisionInfo item = new InteractableCollisionInfo(component, component.CollisionDepth, this);
								this._currentIntersectingObjects.Add(item);
							}
						}
					}
					if (this._currentIntersectingObjects.Count == 0)
					{
						this._currInteractableCastedAgainst = null;
					}
				}
			}
			return this._currentIntersectingObjects;
		}

		// Token: 0x06000997 RID: 2455 RVA: 0x0003C25C File Offset: 0x0003A45C
		private bool HasRayReleasedInteractable(Interactable focusedInteractable)
		{
			Vector3 position = base.transform.position;
			Vector3 forward = base.transform.forward;
			float num = Mathf.Cos(this._coneAngleReleaseDegrees * 0.017453292f);
			Vector3 lhs = focusedInteractable.transform.position - position;
			lhs.Normalize();
			return Vector3.Dot(lhs, forward) < num;
		}

		// Token: 0x06000998 RID: 2456 RVA: 0x0003C2B8 File Offset: 0x0003A4B8
		private Interactable FindTargetInteractable()
		{
			Vector3 rayCastOrigin = this.GetRayCastOrigin();
			Vector3 forward = base.transform.forward;
			Interactable interactable = this.FindPrimaryRaycastHit(rayCastOrigin, forward);
			if (interactable == null)
			{
				interactable = this.FindInteractableViaConeTest(rayCastOrigin, forward);
			}
			return interactable;
		}

		// Token: 0x06000999 RID: 2457 RVA: 0x0003C2F8 File Offset: 0x0003A4F8
		private Interactable FindPrimaryRaycastHit(Vector3 rayOrigin, Vector3 rayDirection)
		{
			Interactable interactable = null;
			int num = Physics.RaycastNonAlloc(new Ray(rayOrigin, rayDirection), this._primaryHits, float.PositiveInfinity);
			float num2 = 0f;
			for (int i = 0; i < num; i++)
			{
				RaycastHit raycastHit = this._primaryHits[i];
				ColliderZone component = raycastHit.transform.GetComponent<ColliderZone>();
				if (component != null)
				{
					Interactable parentInteractable = component.ParentInteractable;
					if (!(parentInteractable == null) && (parentInteractable.ValidToolTagsMask & (int)this.ToolTags) != 0)
					{
						float magnitude = (parentInteractable.transform.position - rayOrigin).magnitude;
						if (interactable == null || magnitude < num2)
						{
							interactable = parentInteractable;
							num2 = magnitude;
						}
					}
				}
			}
			return interactable;
		}

		// Token: 0x0600099A RID: 2458 RVA: 0x0003C3A8 File Offset: 0x0003A5A8
		private Interactable FindInteractableViaConeTest(Vector3 rayOrigin, Vector3 rayDirection)
		{
			Interactable interactable = null;
			float num = 0f;
			float num2 = Mathf.Cos(this._coneAngleDegrees * 0.017453292f);
			float num3 = Mathf.Tan(0.017453292f * this._coneAngleDegrees * 0.5f) * this._farFieldMaxDistance;
			int num4 = Physics.OverlapBoxNonAlloc(rayOrigin + rayDirection * this._farFieldMaxDistance * 0.5f, new Vector3(num3, num3, this._farFieldMaxDistance * 0.5f), this._secondaryOverlapResults, base.transform.rotation);
			for (int i = 0; i < num4; i++)
			{
				ColliderZone component = this._secondaryOverlapResults[i].GetComponent<ColliderZone>();
				if (component != null)
				{
					Interactable parentInteractable = component.ParentInteractable;
					if (!(parentInteractable == null) && (parentInteractable.ValidToolTagsMask & (int)this.ToolTags) != 0)
					{
						Vector3 vector = parentInteractable.transform.position - rayOrigin;
						float magnitude = vector.magnitude;
						vector /= magnitude;
						if (Vector3.Dot(vector, rayDirection) >= num2 && (interactable == null || magnitude < num))
						{
							interactable = parentInteractable;
							num = magnitude;
						}
					}
				}
			}
			return interactable;
		}

		// Token: 0x0600099B RID: 2459 RVA: 0x0003C4CB File Offset: 0x0003A6CB
		public override void FocusOnInteractable(Interactable focusedInteractable, ColliderZone colliderZone)
		{
			this._rayToolView.SetFocusedInteractable(focusedInteractable);
			this._focusedInteractable = focusedInteractable;
		}

		// Token: 0x0600099C RID: 2460 RVA: 0x0003C4E0 File Offset: 0x0003A6E0
		public override void DeFocus()
		{
			this._rayToolView.SetFocusedInteractable(null);
			this._focusedInteractable = null;
		}

		// Token: 0x04000B2D RID: 2861
		private const float MINIMUM_RAY_CAST_DISTANCE = 0.8f;

		// Token: 0x04000B2E RID: 2862
		private const float COLLIDER_RADIUS = 0.01f;

		// Token: 0x04000B2F RID: 2863
		private const int NUM_MAX_PRIMARY_HITS = 10;

		// Token: 0x04000B30 RID: 2864
		private const int NUM_MAX_SECONDARY_HITS = 25;

		// Token: 0x04000B31 RID: 2865
		private const int NUM_COLLIDERS_TO_TEST = 20;

		// Token: 0x04000B32 RID: 2866
		[SerializeField]
		private RayToolView _rayToolView;

		// Token: 0x04000B33 RID: 2867
		[Range(0f, 45f)]
		[SerializeField]
		private float _coneAngleDegrees = 20f;

		// Token: 0x04000B34 RID: 2868
		[SerializeField]
		private float _farFieldMaxDistance = 5f;

		// Token: 0x04000B35 RID: 2869
		private PinchStateModule _pinchStateModule = new PinchStateModule();

		// Token: 0x04000B36 RID: 2870
		private Interactable _focusedInteractable;

		// Token: 0x04000B37 RID: 2871
		private Collider[] _collidersOverlapped = new Collider[20];

		// Token: 0x04000B38 RID: 2872
		private Interactable _currInteractableCastedAgainst;

		// Token: 0x04000B39 RID: 2873
		private float _coneAngleReleaseDegrees;

		// Token: 0x04000B3A RID: 2874
		private RaycastHit[] _primaryHits = new RaycastHit[10];

		// Token: 0x04000B3B RID: 2875
		private Collider[] _secondaryOverlapResults = new Collider[25];

		// Token: 0x04000B3C RID: 2876
		private bool _initialized;
	}
}
