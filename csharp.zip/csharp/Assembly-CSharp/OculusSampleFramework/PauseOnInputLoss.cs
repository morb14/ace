﻿using System;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x02000151 RID: 337
	public class PauseOnInputLoss : MonoBehaviour
	{
		// Token: 0x060008F1 RID: 2289 RVA: 0x0003A430 File Offset: 0x00038630
		private void Start()
		{
			OVRManager.InputFocusAcquired += this.OnInputFocusAcquired;
			OVRManager.InputFocusLost += this.OnInputFocusLost;
		}

		// Token: 0x060008F2 RID: 2290 RVA: 0x0003A454 File Offset: 0x00038654
		private void OnInputFocusLost()
		{
			Time.timeScale = 0f;
		}

		// Token: 0x060008F3 RID: 2291 RVA: 0x0003A460 File Offset: 0x00038660
		private void OnInputFocusAcquired()
		{
			Time.timeScale = 1f;
		}
	}
}
