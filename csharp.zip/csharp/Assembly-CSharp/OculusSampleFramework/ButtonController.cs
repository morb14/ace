﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x02000153 RID: 339
	public class ButtonController : Interactable
	{
		// Token: 0x1700003C RID: 60
		// (get) Token: 0x060008FB RID: 2299 RVA: 0x0003A5E2 File Offset: 0x000387E2
		public override int ValidToolTagsMask
		{
			get
			{
				return this._toolTagsMask;
			}
		}

		// Token: 0x1700003D RID: 61
		// (get) Token: 0x060008FC RID: 2300 RVA: 0x0003A5EA File Offset: 0x000387EA
		public Vector3 LocalButtonDirection
		{
			get
			{
				return this._localButtonDirection;
			}
		}

		// Token: 0x060008FD RID: 2301 RVA: 0x0003A5F4 File Offset: 0x000387F4
		protected override void Awake()
		{
			base.Awake();
			foreach (InteractableToolTags interactableToolTags in this._allValidToolsTags)
			{
				this._toolTagsMask |= (int)interactableToolTags;
			}
			this._proximityZoneCollider = this._proximityZone.GetComponent<ColliderZone>();
			this._contactZoneCollider = this._contactZone.GetComponent<ColliderZone>();
			this._actionZoneCollider = this._actionZone.GetComponent<ColliderZone>();
		}

		// Token: 0x060008FE RID: 2302 RVA: 0x0003A664 File Offset: 0x00038864
		private void CallEventsOnOldDepth(InteractableCollisionDepth oldDepth, InteractableTool collidingTool)
		{
			switch (oldDepth)
			{
			case InteractableCollisionDepth.Proximity:
				this.OnProximityZoneEvent(new ColliderZoneArgs(base.ProximityCollider, (float)Time.frameCount, collidingTool, InteractionType.Exit));
				return;
			case InteractableCollisionDepth.Contact:
				this.OnContactZoneEvent(new ColliderZoneArgs(base.ContactCollider, (float)Time.frameCount, collidingTool, InteractionType.Exit));
				return;
			case InteractableCollisionDepth.Action:
				this.OnActionZoneEvent(new ColliderZoneArgs(base.ActionCollider, (float)Time.frameCount, collidingTool, InteractionType.Exit));
				return;
			default:
				return;
			}
		}

		// Token: 0x060008FF RID: 2303 RVA: 0x0003A6D4 File Offset: 0x000388D4
		private void CallEventsOnNewDepth(InteractableCollisionDepth newDepth, InteractableTool collidingTool)
		{
			switch (newDepth)
			{
			case InteractableCollisionDepth.Proximity:
				this.OnProximityZoneEvent(new ColliderZoneArgs(base.ProximityCollider, (float)Time.frameCount, collidingTool, InteractionType.Enter));
				return;
			case InteractableCollisionDepth.Contact:
				this.OnContactZoneEvent(new ColliderZoneArgs(base.ContactCollider, (float)Time.frameCount, collidingTool, InteractionType.Enter));
				return;
			case InteractableCollisionDepth.Action:
				this.OnActionZoneEvent(new ColliderZoneArgs(base.ActionCollider, (float)Time.frameCount, collidingTool, InteractionType.Enter));
				return;
			default:
				return;
			}
		}

		// Token: 0x06000900 RID: 2304 RVA: 0x0003A744 File Offset: 0x00038944
		private void SustainEventsOnDepth(InteractableCollisionDepth depth, InteractableTool collidingTool)
		{
			switch (depth)
			{
			case InteractableCollisionDepth.Proximity:
				this.OnProximityZoneEvent(new ColliderZoneArgs(base.ProximityCollider, (float)Time.frameCount, collidingTool, InteractionType.Stay));
				return;
			case InteractableCollisionDepth.Contact:
				this.OnContactZoneEvent(new ColliderZoneArgs(base.ContactCollider, (float)Time.frameCount, collidingTool, InteractionType.Stay));
				return;
			case InteractableCollisionDepth.Action:
				this.OnActionZoneEvent(new ColliderZoneArgs(base.ActionCollider, (float)Time.frameCount, collidingTool, InteractionType.Stay));
				return;
			default:
				return;
			}
		}

		// Token: 0x06000901 RID: 2305 RVA: 0x0003A7B4 File Offset: 0x000389B4
		public override void UpdateCollisionDepth(InteractableTool interactableTool, InteractableCollisionDepth oldCollisionDepth, InteractableCollisionDepth collisionDepth, InteractableTool collidingTool)
		{
			bool isFarFieldTool = interactableTool.IsFarFieldTool;
			if (!isFarFieldTool && this._toolToState.Keys.Count > 0 && !this._toolToState.ContainsKey(interactableTool))
			{
				return;
			}
			InteractableState currentButtonState = this._currentButtonState;
			Vector3 vector = base.transform.TransformDirection(this._localButtonDirection);
			bool flag = this.IsValidContact(collidingTool, vector) || collidingTool.IsFarFieldTool;
			bool flag2 = collisionDepth >= InteractableCollisionDepth.Proximity;
			bool flag3 = collisionDepth == InteractableCollisionDepth.Contact;
			bool flag4 = collisionDepth == InteractableCollisionDepth.Action;
			Plane plane = new Plane(-vector, this._buttonPlaneCenter.position);
			bool flag5 = !this._makeSureToolIsOnPositiveSide || plane.GetSide(collidingTool.InteractionPosition);
			bool flag6 = oldCollisionDepth != collisionDepth;
			if (flag6)
			{
				this.CallEventsOnOldDepth(oldCollisionDepth, collidingTool);
				this.CallEventsOnNewDepth(collisionDepth, collidingTool);
			}
			else
			{
				this.SustainEventsOnDepth(collisionDepth, collidingTool);
			}
			InteractableState interactableState = currentButtonState;
			if (collidingTool.IsFarFieldTool)
			{
				interactableState = (flag3 ? InteractableState.ContactState : (flag4 ? InteractableState.ActionState : InteractableState.Default));
			}
			else
			{
				switch (currentButtonState)
				{
				case InteractableState.Default:
					if (flag && flag5 && collisionDepth > InteractableCollisionDepth.Proximity)
					{
						interactableState = ((collisionDepth == InteractableCollisionDepth.Action) ? InteractableState.ActionState : InteractableState.ContactState);
					}
					else if (flag2)
					{
						interactableState = InteractableState.ProximityState;
					}
					break;
				case InteractableState.ProximityState:
					if (collisionDepth < InteractableCollisionDepth.Proximity)
					{
						interactableState = InteractableState.Default;
					}
					else if (flag && flag5 && collisionDepth > InteractableCollisionDepth.Proximity)
					{
						interactableState = ((collisionDepth == InteractableCollisionDepth.Action) ? InteractableState.ActionState : InteractableState.ContactState);
					}
					break;
				case InteractableState.ContactState:
					if (collisionDepth < InteractableCollisionDepth.Contact)
					{
						interactableState = (flag2 ? InteractableState.ProximityState : InteractableState.Default);
					}
					else if (flag4 && flag && flag5)
					{
						interactableState = InteractableState.ActionState;
					}
					break;
				case InteractableState.ActionState:
					if (!flag4)
					{
						if (flag3)
						{
							interactableState = InteractableState.ContactState;
						}
						else if (flag2)
						{
							interactableState = InteractableState.ProximityState;
						}
						else
						{
							interactableState = InteractableState.Default;
						}
					}
					break;
				}
			}
			if (interactableState != InteractableState.Default)
			{
				this._toolToState[interactableTool] = interactableState;
			}
			else
			{
				this._toolToState.Remove(interactableTool);
			}
			if (isFarFieldTool)
			{
				foreach (InteractableState interactableState2 in this._toolToState.Values)
				{
					if (interactableState < interactableState2)
					{
						interactableState = interactableState2;
					}
				}
			}
			if (currentButtonState != interactableState)
			{
				this._currentButtonState = interactableState;
				InteractionType interactionType = (!flag6) ? InteractionType.Stay : ((collisionDepth == InteractableCollisionDepth.None) ? InteractionType.Exit : InteractionType.Enter);
				if (this.InteractableStateChanged != null)
				{
					this.InteractableStateChanged.Invoke(new InteractableStateArgs(this, interactableTool, this._currentButtonState, currentButtonState, new ColliderZoneArgs(base.ContactCollider, (float)Time.frameCount, collidingTool, interactionType)));
				}
			}
		}

		// Token: 0x06000902 RID: 2306 RVA: 0x0003AA04 File Offset: 0x00038C04
		private bool IsValidContact(InteractableTool collidingTool, Vector3 buttonDirection)
		{
			if (this._contactTests == null || collidingTool.IsFarFieldTool)
			{
				return true;
			}
			foreach (ButtonController.ContactTest contactTest in this._contactTests)
			{
				if (contactTest == ButtonController.ContactTest.BackwardsPress)
				{
					if (!this.PassEntryTest(collidingTool, buttonDirection))
					{
						return false;
					}
				}
				else if (!this.PassPerpTest(collidingTool, buttonDirection))
				{
					return false;
				}
			}
			return true;
		}

		// Token: 0x06000903 RID: 2307 RVA: 0x0003AA5C File Offset: 0x00038C5C
		private bool PassEntryTest(InteractableTool collidingTool, Vector3 buttonDirection)
		{
			return Vector3.Dot(collidingTool.Velocity.normalized, buttonDirection) >= 0.8f;
		}

		// Token: 0x06000904 RID: 2308 RVA: 0x0003AA88 File Offset: 0x00038C88
		private bool PassPerpTest(InteractableTool collidingTool, Vector3 buttonDirection)
		{
			Vector3 vector = collidingTool.ToolTransform.right;
			if (collidingTool.IsRightHandedTool)
			{
				vector = -vector;
			}
			return Vector3.Dot(vector, buttonDirection) >= 0.5f;
		}

		// Token: 0x04000ABD RID: 2749
		private const float ENTRY_DOT_THRESHOLD = 0.8f;

		// Token: 0x04000ABE RID: 2750
		private const float PERP_DOT_THRESHOLD = 0.5f;

		// Token: 0x04000ABF RID: 2751
		[SerializeField]
		private GameObject _proximityZone;

		// Token: 0x04000AC0 RID: 2752
		[SerializeField]
		private GameObject _contactZone;

		// Token: 0x04000AC1 RID: 2753
		[SerializeField]
		private GameObject _actionZone;

		// Token: 0x04000AC2 RID: 2754
		[SerializeField]
		private ButtonController.ContactTest[] _contactTests;

		// Token: 0x04000AC3 RID: 2755
		[SerializeField]
		private Transform _buttonPlaneCenter;

		// Token: 0x04000AC4 RID: 2756
		[SerializeField]
		private bool _makeSureToolIsOnPositiveSide = true;

		// Token: 0x04000AC5 RID: 2757
		[SerializeField]
		private Vector3 _localButtonDirection = Vector3.down;

		// Token: 0x04000AC6 RID: 2758
		[SerializeField]
		private InteractableToolTags[] _allValidToolsTags = new InteractableToolTags[]
		{
			InteractableToolTags.All
		};

		// Token: 0x04000AC7 RID: 2759
		private int _toolTagsMask;

		// Token: 0x04000AC8 RID: 2760
		private InteractableState _currentButtonState;

		// Token: 0x04000AC9 RID: 2761
		private Dictionary<InteractableTool, InteractableState> _toolToState = new Dictionary<InteractableTool, InteractableState>();

		// Token: 0x0200023C RID: 572
		public enum ContactTest
		{
			// Token: 0x04000FBA RID: 4026
			PerpenTest,
			// Token: 0x04000FBB RID: 4027
			BackwardsPress
		}
	}
}
