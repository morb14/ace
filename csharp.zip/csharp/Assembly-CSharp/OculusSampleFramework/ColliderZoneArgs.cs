﻿using System;

namespace OculusSampleFramework
{
	// Token: 0x02000156 RID: 342
	public class ColliderZoneArgs : EventArgs
	{
		// Token: 0x06000910 RID: 2320 RVA: 0x0003AB77 File Offset: 0x00038D77
		public ColliderZoneArgs(ColliderZone collider, float frameTime, InteractableTool collidingTool, InteractionType interactionType)
		{
			this.Collider = collider;
			this.FrameTime = frameTime;
			this.CollidingTool = collidingTool;
			this.InteractionT = interactionType;
		}

		// Token: 0x04000ACD RID: 2765
		public readonly ColliderZone Collider;

		// Token: 0x04000ACE RID: 2766
		public readonly float FrameTime;

		// Token: 0x04000ACF RID: 2767
		public readonly InteractableTool CollidingTool;

		// Token: 0x04000AD0 RID: 2768
		public readonly InteractionType InteractionT;
	}
}
