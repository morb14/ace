﻿using System;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x02000169 RID: 361
	public class RayToolView : MonoBehaviour, InteractableToolView
	{
		// Token: 0x1700006F RID: 111
		// (get) Token: 0x0600099E RID: 2462 RVA: 0x0003C553 File Offset: 0x0003A753
		// (set) Token: 0x0600099F RID: 2463 RVA: 0x0003C560 File Offset: 0x0003A760
		public bool EnableState
		{
			get
			{
				return this._lineRenderer.enabled;
			}
			set
			{
				this._targetTransform.gameObject.SetActive(value);
				this._lineRenderer.enabled = value;
			}
		}

		// Token: 0x17000070 RID: 112
		// (get) Token: 0x060009A0 RID: 2464 RVA: 0x0003C57F File Offset: 0x0003A77F
		// (set) Token: 0x060009A1 RID: 2465 RVA: 0x0003C587 File Offset: 0x0003A787
		public bool ToolActivateState
		{
			get
			{
				return this._toolActivateState;
			}
			set
			{
				this._toolActivateState = value;
				this._lineRenderer.colorGradient = (this._toolActivateState ? this._highLightColorGradient : this._oldColorGradient);
			}
		}

		// Token: 0x060009A2 RID: 2466 RVA: 0x0003C5B4 File Offset: 0x0003A7B4
		private void Awake()
		{
			this._lineRenderer.positionCount = 25;
			this._oldColorGradient = this._lineRenderer.colorGradient;
			this._highLightColorGradient = new Gradient();
			this._highLightColorGradient.SetKeys(new GradientColorKey[]
			{
				new GradientColorKey(new Color(0.9f, 0.9f, 0.9f), 0f),
				new GradientColorKey(new Color(0.9f, 0.9f, 0.9f), 1f)
			}, new GradientAlphaKey[]
			{
				new GradientAlphaKey(1f, 0f),
				new GradientAlphaKey(1f, 1f)
			});
		}

		// Token: 0x17000071 RID: 113
		// (get) Token: 0x060009A3 RID: 2467 RVA: 0x0003C677 File Offset: 0x0003A877
		// (set) Token: 0x060009A4 RID: 2468 RVA: 0x0003C67F File Offset: 0x0003A87F
		public InteractableTool InteractableTool { get; set; }

		// Token: 0x060009A5 RID: 2469 RVA: 0x0003C688 File Offset: 0x0003A888
		public void SetFocusedInteractable(Interactable interactable)
		{
			if (interactable == null)
			{
				this._focusedTransform = null;
				return;
			}
			this._focusedTransform = interactable.transform;
		}

		// Token: 0x060009A6 RID: 2470 RVA: 0x0003C6A8 File Offset: 0x0003A8A8
		private void Update()
		{
			Vector3 position = this.InteractableTool.ToolTransform.position;
			Vector3 forward = this.InteractableTool.ToolTransform.forward;
			Vector3 vector = (this._focusedTransform != null) ? this._focusedTransform.position : (position + forward * 3f);
			float magnitude = (vector - position).magnitude;
			Vector3 p = position;
			Vector3 p2 = position + forward * magnitude * 0.3333333f;
			Vector3 p3 = position + forward * magnitude * 0.6666667f;
			Vector3 p4 = vector;
			for (int i = 0; i < 25; i++)
			{
				this.linePositions[i] = RayToolView.GetPointOnBezierCurve(p, p2, p3, p4, (float)i / 25f);
			}
			this._lineRenderer.SetPositions(this.linePositions);
			this._targetTransform.position = vector;
		}

		// Token: 0x060009A7 RID: 2471 RVA: 0x0003C7A0 File Offset: 0x0003A9A0
		public static Vector3 GetPointOnBezierCurve(Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3, float t)
		{
			t = Mathf.Clamp01(t);
			float num = 1f - t;
			float num2 = num * num;
			float num3 = t * t;
			return num * num2 * p0 + 3f * num2 * t * p1 + 3f * num * num3 * p2 + t * num3 * p3;
		}

		// Token: 0x04000B3D RID: 2877
		private const int NUM_RAY_LINE_POSITIONS = 25;

		// Token: 0x04000B3E RID: 2878
		private const float DEFAULT_RAY_CAST_DISTANCE = 3f;

		// Token: 0x04000B3F RID: 2879
		[SerializeField]
		private Transform _targetTransform;

		// Token: 0x04000B40 RID: 2880
		[SerializeField]
		private LineRenderer _lineRenderer;

		// Token: 0x04000B41 RID: 2881
		private bool _toolActivateState;

		// Token: 0x04000B42 RID: 2882
		private Transform _focusedTransform;

		// Token: 0x04000B43 RID: 2883
		private Vector3[] linePositions = new Vector3[25];

		// Token: 0x04000B44 RID: 2884
		private Gradient _oldColorGradient;

		// Token: 0x04000B45 RID: 2885
		private Gradient _highLightColorGradient;
	}
}
