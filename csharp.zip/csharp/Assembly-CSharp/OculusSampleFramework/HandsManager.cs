﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x02000158 RID: 344
	public class HandsManager : MonoBehaviour
	{
		// Token: 0x17000044 RID: 68
		// (get) Token: 0x06000911 RID: 2321 RVA: 0x0003AB9C File Offset: 0x00038D9C
		// (set) Token: 0x06000912 RID: 2322 RVA: 0x0003ABA6 File Offset: 0x00038DA6
		public OVRHand RightHand
		{
			get
			{
				return this._hand[1];
			}
			private set
			{
				this._hand[1] = value;
			}
		}

		// Token: 0x17000045 RID: 69
		// (get) Token: 0x06000913 RID: 2323 RVA: 0x0003ABB1 File Offset: 0x00038DB1
		// (set) Token: 0x06000914 RID: 2324 RVA: 0x0003ABBB File Offset: 0x00038DBB
		public OVRSkeleton RightHandSkeleton
		{
			get
			{
				return this._handSkeleton[1];
			}
			private set
			{
				this._handSkeleton[1] = value;
			}
		}

		// Token: 0x17000046 RID: 70
		// (get) Token: 0x06000915 RID: 2325 RVA: 0x0003ABC6 File Offset: 0x00038DC6
		// (set) Token: 0x06000916 RID: 2326 RVA: 0x0003ABD0 File Offset: 0x00038DD0
		public OVRSkeletonRenderer RightHandSkeletonRenderer
		{
			get
			{
				return this._handSkeletonRenderer[1];
			}
			private set
			{
				this._handSkeletonRenderer[1] = value;
			}
		}

		// Token: 0x17000047 RID: 71
		// (get) Token: 0x06000917 RID: 2327 RVA: 0x0003ABDB File Offset: 0x00038DDB
		// (set) Token: 0x06000918 RID: 2328 RVA: 0x0003ABE5 File Offset: 0x00038DE5
		public OVRMesh RightHandMesh
		{
			get
			{
				return this._handMesh[1];
			}
			private set
			{
				this._handMesh[1] = value;
			}
		}

		// Token: 0x17000048 RID: 72
		// (get) Token: 0x06000919 RID: 2329 RVA: 0x0003ABF0 File Offset: 0x00038DF0
		// (set) Token: 0x0600091A RID: 2330 RVA: 0x0003ABFA File Offset: 0x00038DFA
		public OVRMeshRenderer RightHandMeshRenderer
		{
			get
			{
				return this._handMeshRenderer[1];
			}
			private set
			{
				this._handMeshRenderer[1] = value;
			}
		}

		// Token: 0x17000049 RID: 73
		// (get) Token: 0x0600091B RID: 2331 RVA: 0x0003AC05 File Offset: 0x00038E05
		// (set) Token: 0x0600091C RID: 2332 RVA: 0x0003AC0F File Offset: 0x00038E0F
		public OVRHand LeftHand
		{
			get
			{
				return this._hand[0];
			}
			private set
			{
				this._hand[0] = value;
			}
		}

		// Token: 0x1700004A RID: 74
		// (get) Token: 0x0600091D RID: 2333 RVA: 0x0003AC1A File Offset: 0x00038E1A
		// (set) Token: 0x0600091E RID: 2334 RVA: 0x0003AC24 File Offset: 0x00038E24
		public OVRSkeleton LeftHandSkeleton
		{
			get
			{
				return this._handSkeleton[0];
			}
			private set
			{
				this._handSkeleton[0] = value;
			}
		}

		// Token: 0x1700004B RID: 75
		// (get) Token: 0x0600091F RID: 2335 RVA: 0x0003AC2F File Offset: 0x00038E2F
		// (set) Token: 0x06000920 RID: 2336 RVA: 0x0003AC39 File Offset: 0x00038E39
		public OVRSkeletonRenderer LeftHandSkeletonRenderer
		{
			get
			{
				return this._handSkeletonRenderer[0];
			}
			private set
			{
				this._handSkeletonRenderer[0] = value;
			}
		}

		// Token: 0x1700004C RID: 76
		// (get) Token: 0x06000921 RID: 2337 RVA: 0x0003AC44 File Offset: 0x00038E44
		// (set) Token: 0x06000922 RID: 2338 RVA: 0x0003AC4E File Offset: 0x00038E4E
		public OVRMesh LeftHandMesh
		{
			get
			{
				return this._handMesh[0];
			}
			private set
			{
				this._handMesh[0] = value;
			}
		}

		// Token: 0x1700004D RID: 77
		// (get) Token: 0x06000923 RID: 2339 RVA: 0x0003AC59 File Offset: 0x00038E59
		// (set) Token: 0x06000924 RID: 2340 RVA: 0x0003AC63 File Offset: 0x00038E63
		public OVRMeshRenderer LeftHandMeshRenderer
		{
			get
			{
				return this._handMeshRenderer[0];
			}
			private set
			{
				this._handMeshRenderer[0] = value;
			}
		}

		// Token: 0x1700004E RID: 78
		// (get) Token: 0x06000925 RID: 2341 RVA: 0x0003AC6E File Offset: 0x00038E6E
		// (set) Token: 0x06000926 RID: 2342 RVA: 0x0003AC75 File Offset: 0x00038E75
		public static HandsManager Instance { get; private set; }

		// Token: 0x06000927 RID: 2343 RVA: 0x0003AC80 File Offset: 0x00038E80
		private void Awake()
		{
			if (HandsManager.Instance && HandsManager.Instance != this)
			{
				Object.Destroy(this);
				return;
			}
			HandsManager.Instance = this;
			this.LeftHand = this._leftHand.GetComponent<OVRHand>();
			this.LeftHandSkeleton = this._leftHand.GetComponent<OVRSkeleton>();
			this.LeftHandSkeletonRenderer = this._leftHand.GetComponent<OVRSkeletonRenderer>();
			this.LeftHandMesh = this._leftHand.GetComponent<OVRMesh>();
			this.LeftHandMeshRenderer = this._leftHand.GetComponent<OVRMeshRenderer>();
			this.RightHand = this._rightHand.GetComponent<OVRHand>();
			this.RightHandSkeleton = this._rightHand.GetComponent<OVRSkeleton>();
			this.RightHandSkeletonRenderer = this._rightHand.GetComponent<OVRSkeletonRenderer>();
			this.RightHandMesh = this._rightHand.GetComponent<OVRMesh>();
			this.RightHandMeshRenderer = this._rightHand.GetComponent<OVRMeshRenderer>();
			this._leftMeshRenderer = this.LeftHand.GetComponent<SkinnedMeshRenderer>();
			this._rightMeshRenderer = this.RightHand.GetComponent<SkinnedMeshRenderer>();
			base.StartCoroutine(this.FindSkeletonVisualGameObjects());
		}

		// Token: 0x06000928 RID: 2344 RVA: 0x0003AD8C File Offset: 0x00038F8C
		private void Update()
		{
			HandsManager.HandsVisualMode visualMode = this.VisualMode;
			if (visualMode > HandsManager.HandsVisualMode.Skeleton)
			{
				if (visualMode != HandsManager.HandsVisualMode.Both)
				{
					this._currentHandAlpha = 1f;
				}
				else
				{
					this._currentHandAlpha = 0.6f;
				}
			}
			else
			{
				this._currentHandAlpha = 1f;
			}
			this._rightMeshRenderer.sharedMaterial.SetFloat(this.HandAlphaId, this._currentHandAlpha);
			this._leftMeshRenderer.sharedMaterial.SetFloat(this.HandAlphaId, this._currentHandAlpha);
		}

		// Token: 0x06000929 RID: 2345 RVA: 0x0003AE07 File Offset: 0x00039007
		private IEnumerator FindSkeletonVisualGameObjects()
		{
			while (!this._leftSkeletonVisual || !this._rightSkeletonVisual)
			{
				if (!this._leftSkeletonVisual)
				{
					Transform transform = this.LeftHand.transform.Find("SkeletonRenderer");
					if (transform)
					{
						this._leftSkeletonVisual = transform.gameObject;
					}
				}
				if (!this._rightSkeletonVisual)
				{
					Transform transform2 = this.RightHand.transform.Find("SkeletonRenderer");
					if (transform2)
					{
						this._rightSkeletonVisual = transform2.gameObject;
					}
				}
				yield return null;
			}
			this.SetToCurrentVisualMode();
			yield break;
		}

		// Token: 0x0600092A RID: 2346 RVA: 0x0003AE16 File Offset: 0x00039016
		public void SwitchVisualization()
		{
			if (!this._leftSkeletonVisual || !this._rightSkeletonVisual)
			{
				return;
			}
			this.VisualMode = (this.VisualMode + 1) % (HandsManager.HandsVisualMode)3;
			this.SetToCurrentVisualMode();
		}

		// Token: 0x0600092B RID: 2347 RVA: 0x0003AE4C File Offset: 0x0003904C
		private void SetToCurrentVisualMode()
		{
			switch (this.VisualMode)
			{
			case HandsManager.HandsVisualMode.Mesh:
				this.RightHandMeshRenderer.enabled = true;
				this._rightMeshRenderer.enabled = true;
				this._rightSkeletonVisual.gameObject.SetActive(false);
				this.LeftHandMeshRenderer.enabled = true;
				this._leftMeshRenderer.enabled = true;
				this._leftSkeletonVisual.gameObject.SetActive(false);
				return;
			case HandsManager.HandsVisualMode.Skeleton:
				this.RightHandMeshRenderer.enabled = false;
				this._rightMeshRenderer.enabled = false;
				this._rightSkeletonVisual.gameObject.SetActive(true);
				this.LeftHandMeshRenderer.enabled = false;
				this._leftMeshRenderer.enabled = false;
				this._leftSkeletonVisual.gameObject.SetActive(true);
				return;
			case HandsManager.HandsVisualMode.Both:
				this.RightHandMeshRenderer.enabled = true;
				this._rightMeshRenderer.enabled = true;
				this._rightSkeletonVisual.gameObject.SetActive(true);
				this.LeftHandMeshRenderer.enabled = true;
				this._leftMeshRenderer.enabled = true;
				this._leftSkeletonVisual.gameObject.SetActive(true);
				return;
			default:
				return;
			}
		}

		// Token: 0x0600092C RID: 2348 RVA: 0x0003AF6C File Offset: 0x0003916C
		public static List<OVRBoneCapsule> GetCapsulesPerBone(OVRSkeleton skeleton, OVRSkeleton.BoneId boneId)
		{
			List<OVRBoneCapsule> list = new List<OVRBoneCapsule>();
			IList<OVRBoneCapsule> capsules = skeleton.Capsules;
			for (int i = 0; i < capsules.Count; i++)
			{
				if (capsules[i].BoneIndex == (short)boneId)
				{
					list.Add(capsules[i]);
				}
			}
			return list;
		}

		// Token: 0x0600092D RID: 2349 RVA: 0x0003AFB8 File Offset: 0x000391B8
		public bool IsInitialized()
		{
			return this.LeftHandSkeleton && this.LeftHandSkeleton.IsInitialized && this.RightHandSkeleton && this.RightHandSkeleton.IsInitialized && this.LeftHandMesh && this.LeftHandMesh.IsInitialized && this.RightHandMesh && this.RightHandMesh.IsInitialized;
		}

		// Token: 0x04000AD5 RID: 2773
		private const string SKELETON_VISUALIZER_NAME = "SkeletonRenderer";

		// Token: 0x04000AD6 RID: 2774
		[SerializeField]
		private GameObject _leftHand;

		// Token: 0x04000AD7 RID: 2775
		[SerializeField]
		private GameObject _rightHand;

		// Token: 0x04000AD8 RID: 2776
		public HandsManager.HandsVisualMode VisualMode;

		// Token: 0x04000AD9 RID: 2777
		private OVRHand[] _hand = new OVRHand[2];

		// Token: 0x04000ADA RID: 2778
		private OVRSkeleton[] _handSkeleton = new OVRSkeleton[2];

		// Token: 0x04000ADB RID: 2779
		private OVRSkeletonRenderer[] _handSkeletonRenderer = new OVRSkeletonRenderer[2];

		// Token: 0x04000ADC RID: 2780
		private OVRMesh[] _handMesh = new OVRMesh[2];

		// Token: 0x04000ADD RID: 2781
		private OVRMeshRenderer[] _handMeshRenderer = new OVRMeshRenderer[2];

		// Token: 0x04000ADE RID: 2782
		private SkinnedMeshRenderer _leftMeshRenderer;

		// Token: 0x04000ADF RID: 2783
		private SkinnedMeshRenderer _rightMeshRenderer;

		// Token: 0x04000AE0 RID: 2784
		private GameObject _leftSkeletonVisual;

		// Token: 0x04000AE1 RID: 2785
		private GameObject _rightSkeletonVisual;

		// Token: 0x04000AE2 RID: 2786
		private float _currentHandAlpha = 1f;

		// Token: 0x04000AE3 RID: 2787
		private int HandAlphaId = Shader.PropertyToID("_HandAlpha");

		// Token: 0x0200023D RID: 573
		public enum HandsVisualMode
		{
			// Token: 0x04000FBD RID: 4029
			Mesh,
			// Token: 0x04000FBE RID: 4030
			Skeleton,
			// Token: 0x04000FBF RID: 4031
			Both
		}
	}
}
