﻿using System;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x0200016B RID: 363
	public class ControllerBoxController : MonoBehaviour
	{
		// Token: 0x060009B1 RID: 2481 RVA: 0x00003297 File Offset: 0x00001497
		private void Awake()
		{
		}

		// Token: 0x060009B2 RID: 2482 RVA: 0x0003C93C File Offset: 0x0003AB3C
		public void StartStopStateChanged(InteractableStateArgs obj)
		{
			if (obj.NewInteractableState == InteractableState.ActionState)
			{
				this._locomotive.StartStopStateChanged();
			}
		}

		// Token: 0x060009B3 RID: 2483 RVA: 0x0003C952 File Offset: 0x0003AB52
		public void DecreaseSpeedStateChanged(InteractableStateArgs obj)
		{
			if (obj.NewInteractableState == InteractableState.ActionState)
			{
				this._locomotive.DecreaseSpeedStateChanged();
			}
		}

		// Token: 0x060009B4 RID: 2484 RVA: 0x0003C968 File Offset: 0x0003AB68
		public void IncreaseSpeedStateChanged(InteractableStateArgs obj)
		{
			if (obj.NewInteractableState == InteractableState.ActionState)
			{
				this._locomotive.IncreaseSpeedStateChanged();
			}
		}

		// Token: 0x060009B5 RID: 2485 RVA: 0x0003C97E File Offset: 0x0003AB7E
		public void SmokeButtonStateChanged(InteractableStateArgs obj)
		{
			if (obj.NewInteractableState == InteractableState.ActionState)
			{
				this._locomotive.SmokeButtonStateChanged();
			}
		}

		// Token: 0x060009B6 RID: 2486 RVA: 0x0003C994 File Offset: 0x0003AB94
		public void WhistleButtonStateChanged(InteractableStateArgs obj)
		{
			if (obj.NewInteractableState == InteractableState.ActionState)
			{
				this._locomotive.WhistleButtonStateChanged();
			}
		}

		// Token: 0x060009B7 RID: 2487 RVA: 0x0003C9AA File Offset: 0x0003ABAA
		public void ReverseButtonStateChanged(InteractableStateArgs obj)
		{
			if (obj.NewInteractableState == InteractableState.ActionState)
			{
				this._locomotive.ReverseButtonStateChanged();
			}
		}

		// Token: 0x060009B8 RID: 2488 RVA: 0x0003C9C0 File Offset: 0x0003ABC0
		public void SwitchVisualization(InteractableStateArgs obj)
		{
			if (obj.NewInteractableState == InteractableState.ActionState)
			{
				HandsManager.Instance.SwitchVisualization();
			}
		}

		// Token: 0x060009B9 RID: 2489 RVA: 0x0003C9D5 File Offset: 0x0003ABD5
		public void GoMoo(InteractableStateArgs obj)
		{
			if (obj.NewInteractableState == InteractableState.ActionState)
			{
				this._cowController.GoMooCowGo();
			}
		}

		// Token: 0x04000B4A RID: 2890
		[SerializeField]
		private TrainLocomotive _locomotive;

		// Token: 0x04000B4B RID: 2891
		[SerializeField]
		private CowController _cowController;
	}
}
