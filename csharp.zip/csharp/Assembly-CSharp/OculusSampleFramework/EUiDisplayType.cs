﻿using System;

namespace OculusSampleFramework
{
	// Token: 0x02000179 RID: 377
	public enum EUiDisplayType
	{
		// Token: 0x04000BCA RID: 3018
		EUDT_WorldGeoQuad,
		// Token: 0x04000BCB RID: 3019
		EUDT_OverlayQuad,
		// Token: 0x04000BCC RID: 3020
		EUDT_None,
		// Token: 0x04000BCD RID: 3021
		EUDT_MaxDislayTypes
	}
}
