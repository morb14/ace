﻿using System;

namespace OculusSampleFramework
{
	// Token: 0x0200015B RID: 347
	public enum InteractableState
	{
		// Token: 0x04000AF2 RID: 2802
		Default,
		// Token: 0x04000AF3 RID: 2803
		ProximityState,
		// Token: 0x04000AF4 RID: 2804
		ContactState,
		// Token: 0x04000AF5 RID: 2805
		ActionState
	}
}
