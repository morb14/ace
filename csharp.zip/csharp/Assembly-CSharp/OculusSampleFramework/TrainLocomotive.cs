﻿using System;
using System.Collections;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x02000174 RID: 372
	public class TrainLocomotive : TrainCarBase
	{
		// Token: 0x06000A00 RID: 2560 RVA: 0x0003DC0C File Offset: 0x0003BE0C
		private void Start()
		{
			this._standardRateOverTimeMultiplier = this._smoke1.emission.rateOverTimeMultiplier;
			this._standardMaxParticles = this._smoke1.main.maxParticles;
			base.Distance = 0f;
			this._speedDiv = 2.5f / (float)this._accelerationSounds.Length;
			this._currentSpeed = this._initialSpeed;
			base.UpdateCarPosition();
			this._smoke1.Stop();
			this._startStopTrainCr = base.StartCoroutine(this.StartStopTrain(true));
		}

		// Token: 0x06000A01 RID: 2561 RVA: 0x0003DC9B File Offset: 0x0003BE9B
		private void Update()
		{
			this.UpdatePosition();
		}

		// Token: 0x06000A02 RID: 2562 RVA: 0x0003DCA4 File Offset: 0x0003BEA4
		public override void UpdatePosition()
		{
			if (!this._isMoving)
			{
				return;
			}
			if (this._trainTrack != null)
			{
				this.UpdateDistance();
				base.UpdateCarPosition();
				base.RotateCarWheels();
			}
			TrainCarBase[] childCars = this._childCars;
			for (int i = 0; i < childCars.Length; i++)
			{
				childCars[i].UpdatePosition();
			}
		}

		// Token: 0x06000A03 RID: 2563 RVA: 0x0003DCF7 File Offset: 0x0003BEF7
		public void StartStopStateChanged()
		{
			if (this._startStopTrainCr == null)
			{
				this._startStopTrainCr = base.StartCoroutine(this.StartStopTrain(!this._isMoving));
			}
		}

		// Token: 0x06000A04 RID: 2564 RVA: 0x0003DD1C File Offset: 0x0003BF1C
		private IEnumerator StartStopTrain(bool startTrain)
		{
			float endSpeed = startTrain ? this._initialSpeed : 0f;
			float timePeriodForSpeedChange = 3f;
			if (startTrain)
			{
				this._smoke1.Play();
				this._isMoving = true;
				ParticleSystem.EmissionModule emission = this._smoke1.emission;
				ParticleSystem.MainModule main = this._smoke1.main;
				emission.rateOverTimeMultiplier = this._standardRateOverTimeMultiplier;
				main.maxParticles = this._standardMaxParticles;
				timePeriodForSpeedChange = this.PlayEngineSound(TrainLocomotive.EngineSoundState.Start);
			}
			else
			{
				timePeriodForSpeedChange = this.PlayEngineSound(TrainLocomotive.EngineSoundState.Stop);
			}
			this._engineAudioSource.loop = false;
			timePeriodForSpeedChange *= 0.9f;
			float startTime = Time.time;
			float endTime = Time.time + timePeriodForSpeedChange;
			float startSpeed = this._currentSpeed;
			while (Time.time < endTime)
			{
				float num = (Time.time - startTime) / timePeriodForSpeedChange;
				this._currentSpeed = startSpeed * (1f - num) + endSpeed * num;
				this.UpdateSmokeEmissionBasedOnSpeed();
				yield return null;
			}
			this._currentSpeed = endSpeed;
			this._startStopTrainCr = null;
			this._isMoving = startTrain;
			if (!this._isMoving)
			{
				this._smoke1.Stop();
			}
			else
			{
				this._engineAudioSource.loop = true;
				this.PlayEngineSound(TrainLocomotive.EngineSoundState.AccelerateOrSetProperSpeed);
			}
			yield break;
		}

		// Token: 0x06000A05 RID: 2565 RVA: 0x0003DD34 File Offset: 0x0003BF34
		private float PlayEngineSound(TrainLocomotive.EngineSoundState engineSoundState)
		{
			AudioClip audioClip;
			if (engineSoundState == TrainLocomotive.EngineSoundState.Start)
			{
				audioClip = this._startUpSound;
			}
			else
			{
				AudioClip[] array = (engineSoundState == TrainLocomotive.EngineSoundState.AccelerateOrSetProperSpeed) ? this._accelerationSounds : this._decelerationSounds;
				int num = array.Length;
				int value = (int)Mathf.Round((this._currentSpeed - 0.2f) / this._speedDiv);
				audioClip = array[Mathf.Clamp(value, 0, num - 1)];
			}
			if (this._engineAudioSource.clip == audioClip && this._engineAudioSource.isPlaying && engineSoundState == TrainLocomotive.EngineSoundState.AccelerateOrSetProperSpeed)
			{
				return 0f;
			}
			this._engineAudioSource.clip = audioClip;
			this._engineAudioSource.timeSamples = 0;
			this._engineAudioSource.Play();
			return audioClip.length;
		}

		// Token: 0x06000A06 RID: 2566 RVA: 0x0003DDE0 File Offset: 0x0003BFE0
		private void UpdateDistance()
		{
			float num = this._reverse ? (-this._currentSpeed) : this._currentSpeed;
			base.Distance = (base.Distance + num * Time.deltaTime) % this._trainTrack.TrackLength;
		}

		// Token: 0x06000A07 RID: 2567 RVA: 0x0003DE28 File Offset: 0x0003C028
		public void DecreaseSpeedStateChanged()
		{
			if (this._startStopTrainCr == null && this._isMoving)
			{
				this._currentSpeed = Mathf.Clamp(this._currentSpeed - this._speedDiv, 0.2f, 2.7f);
				this.UpdateSmokeEmissionBasedOnSpeed();
				this.PlayEngineSound(TrainLocomotive.EngineSoundState.AccelerateOrSetProperSpeed);
			}
		}

		// Token: 0x06000A08 RID: 2568 RVA: 0x0003DE78 File Offset: 0x0003C078
		public void IncreaseSpeedStateChanged()
		{
			if (this._startStopTrainCr == null && this._isMoving)
			{
				this._currentSpeed = Mathf.Clamp(this._currentSpeed + this._speedDiv, 0.2f, 2.7f);
				this.UpdateSmokeEmissionBasedOnSpeed();
				this.PlayEngineSound(TrainLocomotive.EngineSoundState.AccelerateOrSetProperSpeed);
			}
		}

		// Token: 0x06000A09 RID: 2569 RVA: 0x0003DEC8 File Offset: 0x0003C0C8
		private void UpdateSmokeEmissionBasedOnSpeed()
		{
			this._smoke1.emission.rateOverTimeMultiplier = this.GetCurrentSmokeEmission();
			this._smoke1.main.maxParticles = (int)Mathf.Lerp((float)this._standardMaxParticles, (float)(this._standardMaxParticles * 3), this._currentSpeed / 2.5f);
		}

		// Token: 0x06000A0A RID: 2570 RVA: 0x0003DF23 File Offset: 0x0003C123
		private float GetCurrentSmokeEmission()
		{
			return Mathf.Lerp(this._standardRateOverTimeMultiplier, this._standardRateOverTimeMultiplier * 8f, this._currentSpeed / 2.5f);
		}

		// Token: 0x06000A0B RID: 2571 RVA: 0x0003DF48 File Offset: 0x0003C148
		public void SmokeButtonStateChanged()
		{
			if (this._isMoving)
			{
				this._smokeStackAudioSource.clip = this._smokeSound;
				this._smokeStackAudioSource.timeSamples = 0;
				this._smokeStackAudioSource.Play();
				this._smoke2.time = 0f;
				this._smoke2.Play();
			}
		}

		// Token: 0x06000A0C RID: 2572 RVA: 0x0003DFA0 File Offset: 0x0003C1A0
		public void WhistleButtonStateChanged()
		{
			if (this._whistleSound != null)
			{
				this._whistleAudioSource.clip = this._whistleSound;
				this._whistleAudioSource.timeSamples = 0;
				this._whistleAudioSource.Play();
			}
		}

		// Token: 0x06000A0D RID: 2573 RVA: 0x0003DFD8 File Offset: 0x0003C1D8
		public void ReverseButtonStateChanged()
		{
			this._reverse = !this._reverse;
		}

		// Token: 0x04000B93 RID: 2963
		private const float MIN_SPEED = 0.2f;

		// Token: 0x04000B94 RID: 2964
		private const float MAX_SPEED = 2.7f;

		// Token: 0x04000B95 RID: 2965
		private const float SMOKE_SPEED_MULTIPLIER = 8f;

		// Token: 0x04000B96 RID: 2966
		private const int MAX_PARTICLES_MULTIPLIER = 3;

		// Token: 0x04000B97 RID: 2967
		[SerializeField]
		[Range(0.2f, 2.7f)]
		protected float _initialSpeed;

		// Token: 0x04000B98 RID: 2968
		[SerializeField]
		private GameObject _startStopButton;

		// Token: 0x04000B99 RID: 2969
		[SerializeField]
		private GameObject _decreaseSpeedButton;

		// Token: 0x04000B9A RID: 2970
		[SerializeField]
		private GameObject _increaseSpeedButton;

		// Token: 0x04000B9B RID: 2971
		[SerializeField]
		private GameObject _smokeButton;

		// Token: 0x04000B9C RID: 2972
		[SerializeField]
		private GameObject _whistleButton;

		// Token: 0x04000B9D RID: 2973
		[SerializeField]
		private GameObject _reverseButton;

		// Token: 0x04000B9E RID: 2974
		[SerializeField]
		private AudioSource _whistleAudioSource;

		// Token: 0x04000B9F RID: 2975
		[SerializeField]
		private AudioClip _whistleSound;

		// Token: 0x04000BA0 RID: 2976
		[SerializeField]
		private AudioSource _engineAudioSource;

		// Token: 0x04000BA1 RID: 2977
		[SerializeField]
		private AudioClip[] _accelerationSounds;

		// Token: 0x04000BA2 RID: 2978
		[SerializeField]
		private AudioClip[] _decelerationSounds;

		// Token: 0x04000BA3 RID: 2979
		[SerializeField]
		private AudioClip _startUpSound;

		// Token: 0x04000BA4 RID: 2980
		[SerializeField]
		private AudioSource _smokeStackAudioSource;

		// Token: 0x04000BA5 RID: 2981
		[SerializeField]
		private AudioClip _smokeSound;

		// Token: 0x04000BA6 RID: 2982
		[SerializeField]
		private ParticleSystem _smoke1;

		// Token: 0x04000BA7 RID: 2983
		[SerializeField]
		private ParticleSystem _smoke2;

		// Token: 0x04000BA8 RID: 2984
		[SerializeField]
		private TrainCarBase[] _childCars;

		// Token: 0x04000BA9 RID: 2985
		private bool _isMoving = true;

		// Token: 0x04000BAA RID: 2986
		private bool _reverse;

		// Token: 0x04000BAB RID: 2987
		private float _currentSpeed;

		// Token: 0x04000BAC RID: 2988
		private float _speedDiv;

		// Token: 0x04000BAD RID: 2989
		private float _standardRateOverTimeMultiplier;

		// Token: 0x04000BAE RID: 2990
		private int _standardMaxParticles;

		// Token: 0x04000BAF RID: 2991
		private Coroutine _startStopTrainCr;

		// Token: 0x02000248 RID: 584
		private enum EngineSoundState
		{
			// Token: 0x04000FF5 RID: 4085
			Start,
			// Token: 0x04000FF6 RID: 4086
			AccelerateOrSetProperSpeed,
			// Token: 0x04000FF7 RID: 4087
			Stop
		}
	}
}
