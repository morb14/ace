﻿using System;
using System.Collections;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x02000173 RID: 371
	public class TrainCrossingController : MonoBehaviour
	{
		// Token: 0x060009F7 RID: 2551 RVA: 0x0003DA36 File Offset: 0x0003BC36
		private void Awake()
		{
			this._lightsSide1Mat = this._lightSide1Renderer.material;
			this._lightsSide2Mat = this._lightSide2Renderer.material;
		}

		// Token: 0x060009F8 RID: 2552 RVA: 0x0003DA5A File Offset: 0x0003BC5A
		private void OnDestroy()
		{
			if (this._lightsSide1Mat != null)
			{
				Object.Destroy(this._lightsSide1Mat);
			}
			if (this._lightsSide2Mat != null)
			{
				Object.Destroy(this._lightsSide2Mat);
			}
		}

		// Token: 0x060009F9 RID: 2553 RVA: 0x0003DA8E File Offset: 0x0003BC8E
		public void CrossingButtonStateChanged(InteractableStateArgs obj)
		{
			if (obj.NewInteractableState == InteractableState.ActionState)
			{
				this.ActivateTrainCrossing();
			}
			this._toolInteractingWithMe = ((obj.NewInteractableState > InteractableState.Default) ? obj.Tool : null);
		}

		// Token: 0x060009FA RID: 2554 RVA: 0x0003DABC File Offset: 0x0003BCBC
		private void Update()
		{
			if (this._toolInteractingWithMe == null)
			{
				this._selectionCylinder.CurrSelectionState = SelectionCylinder.SelectionState.Off;
				return;
			}
			this._selectionCylinder.CurrSelectionState = ((this._toolInteractingWithMe.ToolInputState == ToolInputState.PrimaryInputDown || this._toolInteractingWithMe.ToolInputState == ToolInputState.PrimaryInputDownStay) ? SelectionCylinder.SelectionState.Highlighted : SelectionCylinder.SelectionState.Selected);
		}

		// Token: 0x060009FB RID: 2555 RVA: 0x0003DB10 File Offset: 0x0003BD10
		private void ActivateTrainCrossing()
		{
			int num = this._crossingSounds.Length - 1;
			AudioClip audioClip = this._crossingSounds[(int)(Random.value * (float)num)];
			this._audioSource.clip = audioClip;
			this._audioSource.timeSamples = 0;
			this._audioSource.Play();
			if (this._xingAnimationCr != null)
			{
				base.StopCoroutine(this._xingAnimationCr);
			}
			this._xingAnimationCr = base.StartCoroutine(this.AnimateCrossing(audioClip.length * 0.75f));
		}

		// Token: 0x060009FC RID: 2556 RVA: 0x0003DB8E File Offset: 0x0003BD8E
		private IEnumerator AnimateCrossing(float animationLength)
		{
			this.ToggleLightObjects(true);
			float animationEndTime = Time.time + animationLength;
			float lightBlinkDuration = animationLength * 0.1f;
			float lightBlinkStartTime = Time.time;
			float lightBlinkEndTime = Time.time + lightBlinkDuration;
			Material lightToBlinkOn = this._lightsSide1Mat;
			Material lightToBlinkOff = this._lightsSide2Mat;
			Color onColor = new Color(1f, 1f, 1f, 1f);
			Color offColor = new Color(1f, 1f, 1f, 0f);
			while (Time.time < animationEndTime)
			{
				float t = (Time.time - lightBlinkStartTime) / lightBlinkDuration;
				lightToBlinkOn.SetColor(this._colorId, Color.Lerp(offColor, onColor, t));
				lightToBlinkOff.SetColor(this._colorId, Color.Lerp(onColor, offColor, t));
				if (Time.time > lightBlinkEndTime)
				{
					Material material = lightToBlinkOn;
					lightToBlinkOn = lightToBlinkOff;
					lightToBlinkOff = material;
					lightBlinkStartTime = Time.time;
					lightBlinkEndTime = Time.time + lightBlinkDuration;
				}
				yield return null;
			}
			this.ToggleLightObjects(false);
			yield break;
		}

		// Token: 0x060009FD RID: 2557 RVA: 0x0003DBA4 File Offset: 0x0003BDA4
		private void AffectMaterials(Material[] materials, Color newColor)
		{
			for (int i = 0; i < materials.Length; i++)
			{
				materials[i].SetColor(this._colorId, newColor);
			}
		}

		// Token: 0x060009FE RID: 2558 RVA: 0x0003DBD0 File Offset: 0x0003BDD0
		private void ToggleLightObjects(bool enableState)
		{
			this._lightSide1Renderer.gameObject.SetActive(enableState);
			this._lightSide2Renderer.gameObject.SetActive(enableState);
		}

		// Token: 0x04000B89 RID: 2953
		[SerializeField]
		private AudioSource _audioSource;

		// Token: 0x04000B8A RID: 2954
		[SerializeField]
		private AudioClip[] _crossingSounds;

		// Token: 0x04000B8B RID: 2955
		[SerializeField]
		private MeshRenderer _lightSide1Renderer;

		// Token: 0x04000B8C RID: 2956
		[SerializeField]
		private MeshRenderer _lightSide2Renderer;

		// Token: 0x04000B8D RID: 2957
		[SerializeField]
		private SelectionCylinder _selectionCylinder;

		// Token: 0x04000B8E RID: 2958
		private Material _lightsSide1Mat;

		// Token: 0x04000B8F RID: 2959
		private Material _lightsSide2Mat;

		// Token: 0x04000B90 RID: 2960
		private int _colorId = Shader.PropertyToID("_Color");

		// Token: 0x04000B91 RID: 2961
		private Coroutine _xingAnimationCr;

		// Token: 0x04000B92 RID: 2962
		private InteractableTool _toolInteractingWithMe;
	}
}
