﻿using System;

namespace OculusSampleFramework
{
	// Token: 0x02000163 RID: 355
	public enum ToolInputState
	{
		// Token: 0x04000B1A RID: 2842
		Inactive,
		// Token: 0x04000B1B RID: 2843
		PrimaryInputDown,
		// Token: 0x04000B1C RID: 2844
		PrimaryInputDownStay,
		// Token: 0x04000B1D RID: 2845
		PrimaryInputUp
	}
}
