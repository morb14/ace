﻿using System;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x02000161 RID: 353
	public class FingerTipPokeToolView : MonoBehaviour, InteractableToolView
	{
		// Token: 0x17000059 RID: 89
		// (get) Token: 0x06000960 RID: 2400 RVA: 0x0003BA36 File Offset: 0x00039C36
		// (set) Token: 0x06000961 RID: 2401 RVA: 0x0003BA3E File Offset: 0x00039C3E
		public InteractableTool InteractableTool { get; set; }

		// Token: 0x1700005A RID: 90
		// (get) Token: 0x06000962 RID: 2402 RVA: 0x0003BA47 File Offset: 0x00039C47
		// (set) Token: 0x06000963 RID: 2403 RVA: 0x0003BA54 File Offset: 0x00039C54
		public bool EnableState
		{
			get
			{
				return this._sphereMeshRenderer.enabled;
			}
			set
			{
				this._sphereMeshRenderer.enabled = value;
			}
		}

		// Token: 0x1700005B RID: 91
		// (get) Token: 0x06000964 RID: 2404 RVA: 0x0003BA62 File Offset: 0x00039C62
		// (set) Token: 0x06000965 RID: 2405 RVA: 0x0003BA6A File Offset: 0x00039C6A
		public bool ToolActivateState { get; set; }

		// Token: 0x1700005C RID: 92
		// (get) Token: 0x06000966 RID: 2406 RVA: 0x0003BA73 File Offset: 0x00039C73
		// (set) Token: 0x06000967 RID: 2407 RVA: 0x0003BA7B File Offset: 0x00039C7B
		public float SphereRadius { get; private set; }

		// Token: 0x06000968 RID: 2408 RVA: 0x0003BA84 File Offset: 0x00039C84
		private void Awake()
		{
			this.SphereRadius = this._sphereMeshRenderer.transform.localScale.z * 0.5f;
		}

		// Token: 0x06000969 RID: 2409 RVA: 0x00003297 File Offset: 0x00001497
		public void SetFocusedInteractable(Interactable interactable)
		{
		}

		// Token: 0x04000B10 RID: 2832
		[SerializeField]
		private MeshRenderer _sphereMeshRenderer;
	}
}
