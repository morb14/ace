﻿using System;
using UnityEngine;
using UnityEngine.Events;

namespace OculusSampleFramework
{
	// Token: 0x02000159 RID: 345
	public abstract class Interactable : MonoBehaviour
	{
		// Token: 0x1700004F RID: 79
		// (get) Token: 0x0600092F RID: 2351 RVA: 0x0003B09A File Offset: 0x0003929A
		public ColliderZone ProximityCollider
		{
			get
			{
				return this._proximityZoneCollider;
			}
		}

		// Token: 0x17000050 RID: 80
		// (get) Token: 0x06000930 RID: 2352 RVA: 0x0003B0A2 File Offset: 0x000392A2
		public ColliderZone ContactCollider
		{
			get
			{
				return this._contactZoneCollider;
			}
		}

		// Token: 0x17000051 RID: 81
		// (get) Token: 0x06000931 RID: 2353 RVA: 0x0003B0AA File Offset: 0x000392AA
		public ColliderZone ActionCollider
		{
			get
			{
				return this._actionZoneCollider;
			}
		}

		// Token: 0x17000052 RID: 82
		// (get) Token: 0x06000932 RID: 2354 RVA: 0x0003B0B2 File Offset: 0x000392B2
		public virtual int ValidToolTagsMask
		{
			get
			{
				return -1;
			}
		}

		// Token: 0x14000049 RID: 73
		// (add) Token: 0x06000933 RID: 2355 RVA: 0x0003B0B8 File Offset: 0x000392B8
		// (remove) Token: 0x06000934 RID: 2356 RVA: 0x0003B0F0 File Offset: 0x000392F0
		public event Action<ColliderZoneArgs> ProximityZoneEvent;

		// Token: 0x06000935 RID: 2357 RVA: 0x0003B125 File Offset: 0x00039325
		protected virtual void OnProximityZoneEvent(ColliderZoneArgs args)
		{
			if (this.ProximityZoneEvent != null)
			{
				this.ProximityZoneEvent(args);
			}
		}

		// Token: 0x1400004A RID: 74
		// (add) Token: 0x06000936 RID: 2358 RVA: 0x0003B13C File Offset: 0x0003933C
		// (remove) Token: 0x06000937 RID: 2359 RVA: 0x0003B174 File Offset: 0x00039374
		public event Action<ColliderZoneArgs> ContactZoneEvent;

		// Token: 0x06000938 RID: 2360 RVA: 0x0003B1A9 File Offset: 0x000393A9
		protected virtual void OnContactZoneEvent(ColliderZoneArgs args)
		{
			if (this.ContactZoneEvent != null)
			{
				this.ContactZoneEvent(args);
			}
		}

		// Token: 0x1400004B RID: 75
		// (add) Token: 0x06000939 RID: 2361 RVA: 0x0003B1C0 File Offset: 0x000393C0
		// (remove) Token: 0x0600093A RID: 2362 RVA: 0x0003B1F8 File Offset: 0x000393F8
		public event Action<ColliderZoneArgs> ActionZoneEvent;

		// Token: 0x0600093B RID: 2363 RVA: 0x0003B22D File Offset: 0x0003942D
		protected virtual void OnActionZoneEvent(ColliderZoneArgs args)
		{
			if (this.ActionZoneEvent != null)
			{
				this.ActionZoneEvent(args);
			}
		}

		// Token: 0x0600093C RID: 2364
		public abstract void UpdateCollisionDepth(InteractableTool interactableTool, InteractableCollisionDepth oldCollisionDepth, InteractableCollisionDepth collisionDepth, InteractableTool collidingTool);

		// Token: 0x0600093D RID: 2365 RVA: 0x0003B243 File Offset: 0x00039443
		protected virtual void Awake()
		{
			InteractableRegistry.RegisterInteractable(this);
		}

		// Token: 0x0600093E RID: 2366 RVA: 0x0003B24B File Offset: 0x0003944B
		protected virtual void OnDestroy()
		{
			InteractableRegistry.UnregisterInteractable(this);
		}

		// Token: 0x04000AE5 RID: 2789
		protected ColliderZone _proximityZoneCollider;

		// Token: 0x04000AE6 RID: 2790
		protected ColliderZone _contactZoneCollider;

		// Token: 0x04000AE7 RID: 2791
		protected ColliderZone _actionZoneCollider;

		// Token: 0x04000AEB RID: 2795
		public Interactable.InteractableStateArgsEvent InteractableStateChanged;

		// Token: 0x0200023F RID: 575
		[Serializable]
		public class InteractableStateArgsEvent : UnityEvent<InteractableStateArgs>
		{
		}
	}
}
