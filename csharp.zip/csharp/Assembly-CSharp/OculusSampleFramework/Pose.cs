﻿using System;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x02000176 RID: 374
	public class Pose
	{
		// Token: 0x06000A16 RID: 2582 RVA: 0x0003E1CE File Offset: 0x0003C3CE
		public Pose()
		{
			this.Position = Vector3.zero;
			this.Rotation = Quaternion.identity;
		}

		// Token: 0x06000A17 RID: 2583 RVA: 0x0003E1EC File Offset: 0x0003C3EC
		public Pose(Vector3 position, Quaternion rotation)
		{
			this.Position = position;
			this.Rotation = rotation;
		}

		// Token: 0x04000BB7 RID: 2999
		public Vector3 Position;

		// Token: 0x04000BB8 RID: 3000
		public Quaternion Rotation;
	}
}
