﻿using System;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x02000171 RID: 369
	public class TrainCar : TrainCarBase
	{
		// Token: 0x1700007C RID: 124
		// (get) Token: 0x060009E8 RID: 2536 RVA: 0x0003D7B8 File Offset: 0x0003B9B8
		public float DistanceBehindParentScaled
		{
			get
			{
				return this.scale * this._distanceBehindParent;
			}
		}

		// Token: 0x060009E9 RID: 2537 RVA: 0x0003D7C7 File Offset: 0x0003B9C7
		protected override void Awake()
		{
			base.Awake();
		}

		// Token: 0x060009EA RID: 2538 RVA: 0x0003D7CF File Offset: 0x0003B9CF
		public override void UpdatePosition()
		{
			base.Distance = this._parentLocomotive.Distance - this.DistanceBehindParentScaled;
			base.UpdateCarPosition();
			base.RotateCarWheels();
		}

		// Token: 0x04000B7C RID: 2940
		[SerializeField]
		private TrainCarBase _parentLocomotive;

		// Token: 0x04000B7D RID: 2941
		[SerializeField]
		protected float _distanceBehindParent = 0.1f;
	}
}
