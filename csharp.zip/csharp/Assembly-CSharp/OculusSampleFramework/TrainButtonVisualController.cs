﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Events;

namespace OculusSampleFramework
{
	// Token: 0x02000170 RID: 368
	public class TrainButtonVisualController : MonoBehaviour
	{
		// Token: 0x060009DD RID: 2525 RVA: 0x0003D3FC File Offset: 0x0003B5FC
		private void Awake()
		{
			this._materialColorId = Shader.PropertyToID("_Color");
			this._buttonMaterial = this._meshRenderer.material;
			this._buttonDefaultColor = this._buttonMaterial.GetColor(this._materialColorId);
			this._oldPosition = base.transform.localPosition;
		}

		// Token: 0x060009DE RID: 2526 RVA: 0x0003D452 File Offset: 0x0003B652
		private void OnDestroy()
		{
			if (this._buttonMaterial != null)
			{
				Object.Destroy(this._buttonMaterial);
			}
		}

		// Token: 0x060009DF RID: 2527 RVA: 0x0003D470 File Offset: 0x0003B670
		private void OnEnable()
		{
			this._buttonController.InteractableStateChanged.AddListener(new UnityAction<InteractableStateArgs>(this.InteractableStateChanged));
			this._buttonController.ContactZoneEvent += this.ActionOrInContactZoneStayEvent;
			this._buttonController.ActionZoneEvent += this.ActionOrInContactZoneStayEvent;
			this._buttonInContactOrActionStates = false;
		}

		// Token: 0x060009E0 RID: 2528 RVA: 0x0003D4D0 File Offset: 0x0003B6D0
		private void OnDisable()
		{
			if (this._buttonController != null)
			{
				this._buttonController.InteractableStateChanged.RemoveListener(new UnityAction<InteractableStateArgs>(this.InteractableStateChanged));
				this._buttonController.ContactZoneEvent -= this.ActionOrInContactZoneStayEvent;
				this._buttonController.ActionZoneEvent -= this.ActionOrInContactZoneStayEvent;
			}
		}

		// Token: 0x060009E1 RID: 2529 RVA: 0x0003D538 File Offset: 0x0003B738
		private void ActionOrInContactZoneStayEvent(ColliderZoneArgs collisionArgs)
		{
			if (!this._buttonInContactOrActionStates || collisionArgs.CollidingTool.IsFarFieldTool)
			{
				return;
			}
			Vector3 localScale = this._buttonContactTransform.localScale;
			Vector3 interactionPosition = collisionArgs.CollidingTool.InteractionPosition;
			float num = (this._buttonContactTransform.InverseTransformPoint(interactionPosition) - 0.5f * Vector3.one).y * localScale.y;
			if (num > -this._contactMaxDisplacementDistance && num <= 0f)
			{
				base.transform.localPosition = new Vector3(this._oldPosition.x, this._oldPosition.y + num, this._oldPosition.z);
			}
		}

		// Token: 0x060009E2 RID: 2530 RVA: 0x0003D5E8 File Offset: 0x0003B7E8
		private void InteractableStateChanged(InteractableStateArgs obj)
		{
			this._buttonInContactOrActionStates = false;
			this._glowRenderer.gameObject.SetActive(obj.NewInteractableState > InteractableState.Default);
			switch (obj.NewInteractableState)
			{
			case InteractableState.ProximityState:
				this._buttonMaterial.SetColor(this._materialColorId, this._buttonDefaultColor);
				this.LerpToOldPosition();
				return;
			case InteractableState.ContactState:
				this.StopResetLerping();
				this._buttonMaterial.SetColor(this._materialColorId, this._buttonContactColor);
				this._buttonInContactOrActionStates = true;
				return;
			case InteractableState.ActionState:
				this.StopResetLerping();
				this._buttonMaterial.SetColor(this._materialColorId, this._buttonActionColor);
				this.PlaySound(this._actionSoundEffect);
				this._buttonInContactOrActionStates = true;
				return;
			default:
				this._buttonMaterial.SetColor(this._materialColorId, this._buttonDefaultColor);
				this.LerpToOldPosition();
				return;
			}
		}

		// Token: 0x060009E3 RID: 2531 RVA: 0x0003D6C3 File Offset: 0x0003B8C3
		private void PlaySound(AudioClip clip)
		{
			this._audioSource.timeSamples = 0;
			this._audioSource.clip = clip;
			this._audioSource.Play();
		}

		// Token: 0x060009E4 RID: 2532 RVA: 0x0003D6E8 File Offset: 0x0003B8E8
		private void StopResetLerping()
		{
			if (this._lerpToOldPositionCr != null)
			{
				base.StopCoroutine(this._lerpToOldPositionCr);
			}
		}

		// Token: 0x060009E5 RID: 2533 RVA: 0x0003D700 File Offset: 0x0003B900
		private void LerpToOldPosition()
		{
			if ((base.transform.localPosition - this._oldPosition).sqrMagnitude < Mathf.Epsilon)
			{
				return;
			}
			this.StopResetLerping();
			this._lerpToOldPositionCr = base.StartCoroutine(this.ResetPosition());
		}

		// Token: 0x060009E6 RID: 2534 RVA: 0x0003D74B File Offset: 0x0003B94B
		private IEnumerator ResetPosition()
		{
			float startTime = Time.time;
			float endTime = Time.time + 1f;
			while (Time.time < endTime)
			{
				base.transform.localPosition = Vector3.Lerp(base.transform.localPosition, this._oldPosition, (Time.time - startTime) / 1f);
				yield return null;
			}
			base.transform.localPosition = this._oldPosition;
			this._lerpToOldPositionCr = null;
			yield break;
		}

		// Token: 0x04000B6B RID: 2923
		private const float LERP_TO_OLD_POS_DURATION = 1f;

		// Token: 0x04000B6C RID: 2924
		private const float LOCAL_SIZE_HALVED = 0.5f;

		// Token: 0x04000B6D RID: 2925
		[SerializeField]
		private MeshRenderer _meshRenderer;

		// Token: 0x04000B6E RID: 2926
		[SerializeField]
		private MeshRenderer _glowRenderer;

		// Token: 0x04000B6F RID: 2927
		[SerializeField]
		private ButtonController _buttonController;

		// Token: 0x04000B70 RID: 2928
		[SerializeField]
		private Color _buttonContactColor = new Color(0.51f, 0.78f, 0.92f, 1f);

		// Token: 0x04000B71 RID: 2929
		[SerializeField]
		private Color _buttonActionColor = new Color(0.24f, 0.72f, 0.98f, 1f);

		// Token: 0x04000B72 RID: 2930
		[SerializeField]
		private AudioSource _audioSource;

		// Token: 0x04000B73 RID: 2931
		[SerializeField]
		private AudioClip _actionSoundEffect;

		// Token: 0x04000B74 RID: 2932
		[SerializeField]
		private Transform _buttonContactTransform;

		// Token: 0x04000B75 RID: 2933
		[SerializeField]
		private float _contactMaxDisplacementDistance = 0.0141f;

		// Token: 0x04000B76 RID: 2934
		private Material _buttonMaterial;

		// Token: 0x04000B77 RID: 2935
		private Color _buttonDefaultColor;

		// Token: 0x04000B78 RID: 2936
		private int _materialColorId;

		// Token: 0x04000B79 RID: 2937
		private bool _buttonInContactOrActionStates;

		// Token: 0x04000B7A RID: 2938
		private Coroutine _lerpToOldPositionCr;

		// Token: 0x04000B7B RID: 2939
		private Vector3 _oldPosition;
	}
}
