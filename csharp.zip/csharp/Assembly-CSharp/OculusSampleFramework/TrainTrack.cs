﻿using System;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x02000175 RID: 373
	public class TrainTrack : MonoBehaviour
	{
		// Token: 0x1700007F RID: 127
		// (get) Token: 0x06000A0F RID: 2575 RVA: 0x0003DFF8 File Offset: 0x0003C1F8
		// (set) Token: 0x06000A10 RID: 2576 RVA: 0x0003E000 File Offset: 0x0003C200
		public float TrackLength
		{
			get
			{
				return this._trainLength;
			}
			private set
			{
				this._trainLength = value;
			}
		}

		// Token: 0x06000A11 RID: 2577 RVA: 0x0003E009 File Offset: 0x0003C209
		private void Awake()
		{
			this.Regenerate();
		}

		// Token: 0x06000A12 RID: 2578 RVA: 0x0003E014 File Offset: 0x0003C214
		public TrackSegment GetSegment(float distance)
		{
			int childCount = this._segmentParent.childCount;
			for (int i = 0; i < childCount; i++)
			{
				TrackSegment trackSegment = this._trackSegments[i];
				TrackSegment trackSegment2 = this._trackSegments[(i + 1) % childCount];
				if (distance >= trackSegment.StartDistance && (distance < trackSegment2.StartDistance || i == childCount - 1))
				{
					return trackSegment;
				}
			}
			return null;
		}

		// Token: 0x06000A13 RID: 2579 RVA: 0x0003E06C File Offset: 0x0003C26C
		public void Regenerate()
		{
			this._trackSegments = this._segmentParent.GetComponentsInChildren<TrackSegment>();
			this.TrackLength = 0f;
			int childCount = this._segmentParent.childCount;
			TrackSegment trackSegment = null;
			float scale = 0f;
			for (int i = 0; i < childCount; i++)
			{
				TrackSegment trackSegment2 = this._trackSegments[i];
				trackSegment2.SubDivCount = this._subDivCount;
				scale = trackSegment2.setGridSize(this._gridSize);
				if (trackSegment != null)
				{
					Pose endPose = trackSegment.EndPose;
					trackSegment2.transform.position = endPose.Position;
					trackSegment2.transform.rotation = endPose.Rotation;
					trackSegment2.StartDistance = this.TrackLength;
				}
				if (this._regnerateTrackMeshOnAwake)
				{
					trackSegment2.RegenerateTrackAndMesh();
				}
				this.TrackLength += trackSegment2.SegmentLength;
				trackSegment = trackSegment2;
			}
			this.SetScale(scale);
		}

		// Token: 0x06000A14 RID: 2580 RVA: 0x0003E154 File Offset: 0x0003C354
		private void SetScale(float ratio)
		{
			this._trainParent.localScale = new Vector3(ratio, ratio, ratio);
			TrainCar[] componentsInChildren = this._trainParent.GetComponentsInChildren<TrainCar>();
			this._trainParent.GetComponentInChildren<TrainLocomotive>().Scale = ratio;
			TrainCar[] array = componentsInChildren;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].Scale = ratio;
			}
		}

		// Token: 0x04000BB0 RID: 2992
		[SerializeField]
		private float _gridSize = 0.5f;

		// Token: 0x04000BB1 RID: 2993
		[SerializeField]
		private int _subDivCount = 20;

		// Token: 0x04000BB2 RID: 2994
		[SerializeField]
		private Transform _segmentParent;

		// Token: 0x04000BB3 RID: 2995
		[SerializeField]
		private Transform _trainParent;

		// Token: 0x04000BB4 RID: 2996
		[SerializeField]
		private bool _regnerateTrackMeshOnAwake;

		// Token: 0x04000BB5 RID: 2997
		private float _trainLength = -1f;

		// Token: 0x04000BB6 RID: 2998
		private TrackSegment[] _trackSegments;
	}
}
