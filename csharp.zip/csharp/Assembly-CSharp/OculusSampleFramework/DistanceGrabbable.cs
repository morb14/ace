﻿using System;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x0200014D RID: 333
	public class DistanceGrabbable : OVRGrabbable
	{
		// Token: 0x17000039 RID: 57
		// (get) Token: 0x060008D5 RID: 2261 RVA: 0x000398FF File Offset: 0x00037AFF
		// (set) Token: 0x060008D6 RID: 2262 RVA: 0x00039907 File Offset: 0x00037B07
		public bool InRange
		{
			get
			{
				return this.m_inRange;
			}
			set
			{
				this.m_inRange = value;
				this.RefreshCrosshair();
			}
		}

		// Token: 0x1700003A RID: 58
		// (get) Token: 0x060008D7 RID: 2263 RVA: 0x00039916 File Offset: 0x00037B16
		// (set) Token: 0x060008D8 RID: 2264 RVA: 0x0003991E File Offset: 0x00037B1E
		public bool Targeted
		{
			get
			{
				return this.m_targeted;
			}
			set
			{
				this.m_targeted = value;
				this.RefreshCrosshair();
			}
		}

		// Token: 0x060008D9 RID: 2265 RVA: 0x00039930 File Offset: 0x00037B30
		protected override void Start()
		{
			base.Start();
			this.m_crosshair = base.gameObject.GetComponentInChildren<GrabbableCrosshair>();
			this.m_renderer = base.gameObject.GetComponent<Renderer>();
			this.m_crosshairManager = Object.FindObjectOfType<GrabManager>();
			this.m_mpb = new MaterialPropertyBlock();
			this.RefreshCrosshair();
			this.m_mpb.SetColor(this.m_materialColorField, Color.white);
			this.m_renderer.SetPropertyBlock(this.m_mpb);
		}

		// Token: 0x060008DA RID: 2266 RVA: 0x000399A8 File Offset: 0x00037BA8
		private void RefreshCrosshair()
		{
			if (this.m_crosshair)
			{
				if (base.isGrabbed)
				{
					this.m_crosshair.SetState(GrabbableCrosshair.CrosshairState.Disabled);
				}
				else if (!this.InRange)
				{
					this.m_crosshair.SetState(GrabbableCrosshair.CrosshairState.Disabled);
				}
				else
				{
					this.m_crosshair.SetState(this.Targeted ? GrabbableCrosshair.CrosshairState.Targeted : GrabbableCrosshair.CrosshairState.Enabled);
				}
			}
			if (this.m_materialColorField != null)
			{
				this.m_renderer.GetPropertyBlock(this.m_mpb);
				if (base.isGrabbed || !this.InRange)
				{
					this.m_mpb.SetColor(this.m_materialColorField, Color.white);
				}
				else if (this.Targeted)
				{
					this.m_mpb.SetColor(this.m_materialColorField, this.m_crosshairManager.OutlineColorHighlighted);
				}
				else
				{
					this.m_mpb.SetColor(this.m_materialColorField, this.m_crosshairManager.OutlineColorInRange);
				}
				this.m_renderer.SetPropertyBlock(this.m_mpb);
			}
		}

		// Token: 0x060008DB RID: 2267 RVA: 0x00039A9C File Offset: 0x00037C9C
		public void SetColor(Color focusColor)
		{
			this.m_mpb.SetColor(this.m_materialColorField, focusColor);
			this.m_renderer.SetPropertyBlock(this.m_mpb);
		}

		// Token: 0x060008DC RID: 2268 RVA: 0x00039AC1 File Offset: 0x00037CC1
		public void ClearColor()
		{
			this.m_mpb.SetColor(this.m_materialColorField, Color.white);
			this.m_renderer.SetPropertyBlock(this.m_mpb);
		}

		// Token: 0x04000A9E RID: 2718
		public string m_materialColorField;

		// Token: 0x04000A9F RID: 2719
		private GrabbableCrosshair m_crosshair;

		// Token: 0x04000AA0 RID: 2720
		private GrabManager m_crosshairManager;

		// Token: 0x04000AA1 RID: 2721
		private Renderer m_renderer;

		// Token: 0x04000AA2 RID: 2722
		private MaterialPropertyBlock m_mpb;

		// Token: 0x04000AA3 RID: 2723
		private bool m_inRange;

		// Token: 0x04000AA4 RID: 2724
		private bool m_targeted;
	}
}
