﻿using System;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x02000150 RID: 336
	public class GrabbableCrosshair : MonoBehaviour
	{
		// Token: 0x060008ED RID: 2285 RVA: 0x0003A393 File Offset: 0x00038593
		private void Start()
		{
			this.m_centerEyeAnchor = GameObject.Find("CenterEyeAnchor").transform;
		}

		// Token: 0x060008EE RID: 2286 RVA: 0x0003A3AC File Offset: 0x000385AC
		public void SetState(GrabbableCrosshair.CrosshairState cs)
		{
			this.m_state = cs;
			if (cs == GrabbableCrosshair.CrosshairState.Disabled)
			{
				this.m_targetedCrosshair.SetActive(false);
				this.m_enabledCrosshair.SetActive(false);
				return;
			}
			if (cs == GrabbableCrosshair.CrosshairState.Enabled)
			{
				this.m_targetedCrosshair.SetActive(false);
				this.m_enabledCrosshair.SetActive(true);
				return;
			}
			if (cs == GrabbableCrosshair.CrosshairState.Targeted)
			{
				this.m_targetedCrosshair.SetActive(true);
				this.m_enabledCrosshair.SetActive(false);
			}
		}

		// Token: 0x060008EF RID: 2287 RVA: 0x0003A415 File Offset: 0x00038615
		private void Update()
		{
			if (this.m_state != GrabbableCrosshair.CrosshairState.Disabled)
			{
				base.transform.LookAt(this.m_centerEyeAnchor);
			}
		}

		// Token: 0x04000AB6 RID: 2742
		private GrabbableCrosshair.CrosshairState m_state;

		// Token: 0x04000AB7 RID: 2743
		private Transform m_centerEyeAnchor;

		// Token: 0x04000AB8 RID: 2744
		[SerializeField]
		private GameObject m_targetedCrosshair;

		// Token: 0x04000AB9 RID: 2745
		[SerializeField]
		private GameObject m_enabledCrosshair;

		// Token: 0x0200023B RID: 571
		public enum CrosshairState
		{
			// Token: 0x04000FB6 RID: 4022
			Disabled,
			// Token: 0x04000FB7 RID: 4023
			Enabled,
			// Token: 0x04000FB8 RID: 4024
			Targeted
		}
	}
}
