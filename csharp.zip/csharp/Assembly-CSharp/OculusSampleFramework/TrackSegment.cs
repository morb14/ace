﻿using System;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x0200016F RID: 367
	public class TrackSegment : MonoBehaviour
	{
		// Token: 0x17000075 RID: 117
		// (get) Token: 0x060009CB RID: 2507 RVA: 0x0003CD33 File Offset: 0x0003AF33
		// (set) Token: 0x060009CC RID: 2508 RVA: 0x0003CD3B File Offset: 0x0003AF3B
		public float StartDistance { get; set; }

		// Token: 0x17000076 RID: 118
		// (get) Token: 0x060009CD RID: 2509 RVA: 0x0003CD44 File Offset: 0x0003AF44
		// (set) Token: 0x060009CE RID: 2510 RVA: 0x0003CD4C File Offset: 0x0003AF4C
		public float GridSize
		{
			get
			{
				return this._gridSize;
			}
			private set
			{
				this._gridSize = value;
			}
		}

		// Token: 0x17000077 RID: 119
		// (get) Token: 0x060009CF RID: 2511 RVA: 0x0003CD55 File Offset: 0x0003AF55
		// (set) Token: 0x060009D0 RID: 2512 RVA: 0x0003CD5D File Offset: 0x0003AF5D
		public int SubDivCount
		{
			get
			{
				return this._subDivCount;
			}
			set
			{
				this._subDivCount = value;
			}
		}

		// Token: 0x17000078 RID: 120
		// (get) Token: 0x060009D1 RID: 2513 RVA: 0x0003CD66 File Offset: 0x0003AF66
		public TrackSegment.SegmentType Type
		{
			get
			{
				return this._segmentType;
			}
		}

		// Token: 0x17000079 RID: 121
		// (get) Token: 0x060009D2 RID: 2514 RVA: 0x0003CD6E File Offset: 0x0003AF6E
		public Pose EndPose
		{
			get
			{
				this.UpdatePose(this.SegmentLength, this._endPose);
				return this._endPose;
			}
		}

		// Token: 0x1700007A RID: 122
		// (get) Token: 0x060009D3 RID: 2515 RVA: 0x0003CD88 File Offset: 0x0003AF88
		public float Radius
		{
			get
			{
				return 0.5f * this.GridSize;
			}
		}

		// Token: 0x060009D4 RID: 2516 RVA: 0x0003CD96 File Offset: 0x0003AF96
		public float setGridSize(float size)
		{
			this.GridSize = size;
			return this.GridSize / 0.8f;
		}

		// Token: 0x1700007B RID: 123
		// (get) Token: 0x060009D5 RID: 2517 RVA: 0x0003CDAC File Offset: 0x0003AFAC
		public float SegmentLength
		{
			get
			{
				TrackSegment.SegmentType type = this.Type;
				if (type == TrackSegment.SegmentType.Straight)
				{
					return this.GridSize;
				}
				if (type - TrackSegment.SegmentType.LeftTurn > 1)
				{
					return 1f;
				}
				return 1.5707964f * this.Radius;
			}
		}

		// Token: 0x060009D6 RID: 2518 RVA: 0x00003297 File Offset: 0x00001497
		private void Awake()
		{
		}

		// Token: 0x060009D7 RID: 2519 RVA: 0x0003CDE4 File Offset: 0x0003AFE4
		public void UpdatePose(float distanceIntoSegment, Pose pose)
		{
			if (this.Type == TrackSegment.SegmentType.Straight)
			{
				pose.Position = base.transform.position + distanceIntoSegment * base.transform.forward;
				pose.Rotation = base.transform.rotation;
				return;
			}
			if (this.Type == TrackSegment.SegmentType.LeftTurn)
			{
				float num = distanceIntoSegment / this.SegmentLength;
				float num2 = 1.5707964f * num;
				Vector3 position = new Vector3(this.Radius * Mathf.Cos(num2) - this.Radius, 0f, this.Radius * Mathf.Sin(num2));
				Quaternion rhs = Quaternion.Euler(0f, -num2 * 57.29578f, 0f);
				pose.Position = base.transform.TransformPoint(position);
				pose.Rotation = base.transform.rotation * rhs;
				return;
			}
			if (this.Type == TrackSegment.SegmentType.RightTurn)
			{
				float num3 = 3.1415927f - 1.5707964f * distanceIntoSegment / this.SegmentLength;
				Vector3 position2 = new Vector3(this.Radius * Mathf.Cos(num3) + this.Radius, 0f, this.Radius * Mathf.Sin(num3));
				Quaternion rhs2 = Quaternion.Euler(0f, (3.1415927f - num3) * 57.29578f, 0f);
				pose.Position = base.transform.TransformPoint(position2);
				pose.Rotation = base.transform.rotation * rhs2;
				return;
			}
			pose.Position = Vector3.zero;
			pose.Rotation = Quaternion.identity;
		}

		// Token: 0x060009D8 RID: 2520 RVA: 0x00003297 File Offset: 0x00001497
		private void Update()
		{
		}

		// Token: 0x060009D9 RID: 2521 RVA: 0x0003CF70 File Offset: 0x0003B170
		private void OnDisable()
		{
			Object.Destroy(this._mesh);
		}

		// Token: 0x060009DA RID: 2522 RVA: 0x0003CF80 File Offset: 0x0003B180
		private void DrawDebugLines()
		{
			for (int i = 1; i < this.SubDivCount + 1; i++)
			{
				float num = this.SegmentLength / (float)this.SubDivCount;
				this.UpdatePose((float)(i - 1) * num, this._p1);
				this.UpdatePose((float)i * num, this._p2);
				float d = 0.075f;
				Debug.DrawLine(this._p1.Position + d * (this._p1.Rotation * Vector3.right), this._p2.Position + d * (this._p2.Rotation * Vector3.right));
				Debug.DrawLine(this._p1.Position - d * (this._p1.Rotation * Vector3.right), this._p2.Position - d * (this._p2.Rotation * Vector3.right));
			}
			Debug.DrawLine(base.transform.position - 0.5f * this.GridSize * base.transform.right, base.transform.position + 0.5f * this.GridSize * base.transform.right, Color.yellow);
			Debug.DrawLine(base.transform.position - 0.5f * this.GridSize * base.transform.right, base.transform.position - 0.5f * this.GridSize * base.transform.right + this.GridSize * base.transform.forward, Color.yellow);
			Debug.DrawLine(base.transform.position + 0.5f * this.GridSize * base.transform.right, base.transform.position + 0.5f * this.GridSize * base.transform.right + this.GridSize * base.transform.forward, Color.yellow);
			Debug.DrawLine(base.transform.position - 0.5f * this.GridSize * base.transform.right + this.GridSize * base.transform.forward, base.transform.position + 0.5f * this.GridSize * base.transform.right + this.GridSize * base.transform.forward, Color.yellow);
		}

		// Token: 0x060009DB RID: 2523 RVA: 0x0003D288 File Offset: 0x0003B488
		public void RegenerateTrackAndMesh()
		{
			if (base.transform.childCount > 0 && !this._mesh)
			{
				this._mesh = base.transform.GetChild(0).gameObject;
			}
			if (this._mesh)
			{
				Object.DestroyImmediate(this._mesh);
			}
			if (this._segmentType == TrackSegment.SegmentType.LeftTurn)
			{
				this._mesh = Object.Instantiate<GameObject>(this._leftTurn.gameObject);
			}
			else if (this._segmentType == TrackSegment.SegmentType.RightTurn)
			{
				this._mesh = Object.Instantiate<GameObject>(this._rightTurn.gameObject);
			}
			else
			{
				this._mesh = Object.Instantiate<GameObject>(this._straight.gameObject);
			}
			this._mesh.transform.SetParent(base.transform, false);
			this._mesh.transform.position += this.GridSize / 2f * base.transform.forward;
			this._mesh.transform.localScale = new Vector3(this.GridSize / 0.8f, this.GridSize / 0.8f, this.GridSize / 0.8f);
		}

		// Token: 0x04000B5E RID: 2910
		[SerializeField]
		private TrackSegment.SegmentType _segmentType;

		// Token: 0x04000B5F RID: 2911
		[SerializeField]
		private MeshFilter _straight;

		// Token: 0x04000B60 RID: 2912
		[SerializeField]
		private MeshFilter _leftTurn;

		// Token: 0x04000B61 RID: 2913
		[SerializeField]
		private MeshFilter _rightTurn;

		// Token: 0x04000B62 RID: 2914
		private float _gridSize = 0.8f;

		// Token: 0x04000B63 RID: 2915
		private int _subDivCount = 20;

		// Token: 0x04000B64 RID: 2916
		private const float _originalGridSize = 0.8f;

		// Token: 0x04000B65 RID: 2917
		private const float _trackWidth = 0.15f;

		// Token: 0x04000B66 RID: 2918
		private GameObject _mesh;

		// Token: 0x04000B68 RID: 2920
		private Pose _p1 = new Pose();

		// Token: 0x04000B69 RID: 2921
		private Pose _p2 = new Pose();

		// Token: 0x04000B6A RID: 2922
		private Pose _endPose = new Pose();

		// Token: 0x02000245 RID: 581
		public enum SegmentType
		{
			// Token: 0x04000FDF RID: 4063
			Straight,
			// Token: 0x04000FE0 RID: 4064
			LeftTurn,
			// Token: 0x04000FE1 RID: 4065
			RightTurn,
			// Token: 0x04000FE2 RID: 4066
			Switch
		}
	}
}
