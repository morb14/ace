﻿using System;
using UnityEngine;
using UnityEngine.UI;

namespace OculusSampleFramework
{
	// Token: 0x0200016A RID: 362
	public class DistanceGrabberSample : MonoBehaviour
	{
		// Token: 0x17000072 RID: 114
		// (get) Token: 0x060009A9 RID: 2473 RVA: 0x0003C81F File Offset: 0x0003AA1F
		// (set) Token: 0x060009AA RID: 2474 RVA: 0x0003C828 File Offset: 0x0003AA28
		public bool UseSpherecast
		{
			get
			{
				return this.useSpherecast;
			}
			set
			{
				this.useSpherecast = value;
				for (int i = 0; i < this.m_grabbers.Length; i++)
				{
					this.m_grabbers[i].UseSpherecast = this.useSpherecast;
				}
			}
		}

		// Token: 0x17000073 RID: 115
		// (get) Token: 0x060009AB RID: 2475 RVA: 0x0003C862 File Offset: 0x0003AA62
		// (set) Token: 0x060009AC RID: 2476 RVA: 0x0003C86C File Offset: 0x0003AA6C
		public bool AllowGrabThroughWalls
		{
			get
			{
				return this.allowGrabThroughWalls;
			}
			set
			{
				this.allowGrabThroughWalls = value;
				for (int i = 0; i < this.m_grabbers.Length; i++)
				{
					this.m_grabbers[i].m_preventGrabThroughWalls = !this.allowGrabThroughWalls;
				}
			}
		}

		// Token: 0x060009AD RID: 2477 RVA: 0x0003C8AC File Offset: 0x0003AAAC
		private void Start()
		{
			DebugUIBuilder.instance.AddLabel("Distance Grab Sample", 0);
			DebugUIBuilder.instance.AddToggle("Use Spherecasting", new DebugUIBuilder.OnToggleValueChange(this.ToggleSphereCasting), this.useSpherecast, 0);
			DebugUIBuilder.instance.AddToggle("Grab Through Walls", new DebugUIBuilder.OnToggleValueChange(this.ToggleGrabThroughWalls), this.allowGrabThroughWalls, 0);
			DebugUIBuilder.instance.Show();
		}

		// Token: 0x060009AE RID: 2478 RVA: 0x0003C91A File Offset: 0x0003AB1A
		public void ToggleSphereCasting(Toggle t)
		{
			this.UseSpherecast = !this.UseSpherecast;
		}

		// Token: 0x060009AF RID: 2479 RVA: 0x0003C92B File Offset: 0x0003AB2B
		public void ToggleGrabThroughWalls(Toggle t)
		{
			this.AllowGrabThroughWalls = !this.AllowGrabThroughWalls;
		}

		// Token: 0x04000B47 RID: 2887
		private bool useSpherecast;

		// Token: 0x04000B48 RID: 2888
		private bool allowGrabThroughWalls;

		// Token: 0x04000B49 RID: 2889
		[SerializeField]
		private DistanceGrabber[] m_grabbers;
	}
}
