﻿using System;

namespace OculusSampleFramework
{
	// Token: 0x0200015A RID: 346
	public enum InteractableCollisionDepth
	{
		// Token: 0x04000AED RID: 2797
		None,
		// Token: 0x04000AEE RID: 2798
		Proximity,
		// Token: 0x04000AEF RID: 2799
		Contact,
		// Token: 0x04000AF0 RID: 2800
		Action
	}
}
