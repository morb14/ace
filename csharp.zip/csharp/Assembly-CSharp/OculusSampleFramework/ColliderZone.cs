﻿using System;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x02000155 RID: 341
	public interface ColliderZone
	{
		// Token: 0x17000041 RID: 65
		// (get) Token: 0x0600090D RID: 2317
		Collider Collider { get; }

		// Token: 0x17000042 RID: 66
		// (get) Token: 0x0600090E RID: 2318
		Interactable ParentInteractable { get; }

		// Token: 0x17000043 RID: 67
		// (get) Token: 0x0600090F RID: 2319
		InteractableCollisionDepth CollisionDepth { get; }
	}
}
