﻿using System;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x0200016C RID: 364
	public class CowController : MonoBehaviour
	{
		// Token: 0x060009BB RID: 2491 RVA: 0x00003297 File Offset: 0x00001497
		private void Start()
		{
		}

		// Token: 0x060009BC RID: 2492 RVA: 0x0003C9EB File Offset: 0x0003ABEB
		public void PlayMooSound()
		{
			this._mooCowAudioSource.timeSamples = 0;
			this._mooCowAudioSource.Play();
		}

		// Token: 0x060009BD RID: 2493 RVA: 0x0003CA04 File Offset: 0x0003AC04
		public void GoMooCowGo()
		{
			this._cowAnimation.Rewind();
			this._cowAnimation.Play();
		}

		// Token: 0x04000B4C RID: 2892
		[SerializeField]
		private Animation _cowAnimation;

		// Token: 0x04000B4D RID: 2893
		[SerializeField]
		private AudioSource _mooCowAudioSource;
	}
}
