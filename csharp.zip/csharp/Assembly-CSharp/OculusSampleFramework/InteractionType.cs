﻿using System;

namespace OculusSampleFramework
{
	// Token: 0x02000157 RID: 343
	public enum InteractionType
	{
		// Token: 0x04000AD2 RID: 2770
		Enter,
		// Token: 0x04000AD3 RID: 2771
		Stay,
		// Token: 0x04000AD4 RID: 2772
		Exit
	}
}
