﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x02000152 RID: 338
	public class BoneCapsuleTriggerLogic : MonoBehaviour
	{
		// Token: 0x060008F5 RID: 2293 RVA: 0x0003A46C File Offset: 0x0003866C
		private void OnDisable()
		{
			this.CollidersTouchingUs.Clear();
		}

		// Token: 0x060008F6 RID: 2294 RVA: 0x0003A479 File Offset: 0x00038679
		private void Update()
		{
			this.CleanUpDeadColliders();
		}

		// Token: 0x060008F7 RID: 2295 RVA: 0x0003A484 File Offset: 0x00038684
		private void OnTriggerEnter(Collider other)
		{
			ButtonTriggerZone component = other.GetComponent<ButtonTriggerZone>();
			if (component != null && (component.ParentInteractable.ValidToolTagsMask & (int)this.ToolTags) != 0)
			{
				this.CollidersTouchingUs.Add(component);
			}
		}

		// Token: 0x060008F8 RID: 2296 RVA: 0x0003A4C4 File Offset: 0x000386C4
		private void OnTriggerExit(Collider other)
		{
			ButtonTriggerZone component = other.GetComponent<ButtonTriggerZone>();
			if (component != null && (component.ParentInteractable.ValidToolTagsMask & (int)this.ToolTags) != 0)
			{
				this.CollidersTouchingUs.Remove(component);
			}
		}

		// Token: 0x060008F9 RID: 2297 RVA: 0x0003A504 File Offset: 0x00038704
		private void CleanUpDeadColliders()
		{
			this._elementsToCleanUp.Clear();
			foreach (ColliderZone colliderZone in this.CollidersTouchingUs)
			{
				if (!colliderZone.Collider.gameObject.activeInHierarchy)
				{
					this._elementsToCleanUp.Add(colliderZone);
				}
			}
			foreach (ColliderZone item in this._elementsToCleanUp)
			{
				this.CollidersTouchingUs.Remove(item);
			}
		}

		// Token: 0x04000ABA RID: 2746
		public InteractableToolTags ToolTags;

		// Token: 0x04000ABB RID: 2747
		public HashSet<ColliderZone> CollidersTouchingUs = new HashSet<ColliderZone>();

		// Token: 0x04000ABC RID: 2748
		private List<ColliderZone> _elementsToCleanUp = new List<ColliderZone>();
	}
}
