﻿using System;

namespace OculusSampleFramework
{
	// Token: 0x02000164 RID: 356
	public class InteractableCollisionInfo
	{
		// Token: 0x0600096B RID: 2411 RVA: 0x0003BAA7 File Offset: 0x00039CA7
		public InteractableCollisionInfo(ColliderZone collider, InteractableCollisionDepth collisionDepth, InteractableTool collidingTool)
		{
			this.InteractableCollider = collider;
			this.CollisionDepth = collisionDepth;
			this.CollidingTool = collidingTool;
		}

		// Token: 0x04000B1E RID: 2846
		public ColliderZone InteractableCollider;

		// Token: 0x04000B1F RID: 2847
		public InteractableCollisionDepth CollisionDepth;

		// Token: 0x04000B20 RID: 2848
		public InteractableTool CollidingTool;
	}
}
