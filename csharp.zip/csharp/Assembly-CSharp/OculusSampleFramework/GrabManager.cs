﻿using System;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x0200014F RID: 335
	public class GrabManager : MonoBehaviour
	{
		// Token: 0x060008EA RID: 2282 RVA: 0x0003A34C File Offset: 0x0003854C
		private void OnTriggerEnter(Collider otherCollider)
		{
			DistanceGrabbable componentInChildren = otherCollider.GetComponentInChildren<DistanceGrabbable>();
			if (componentInChildren)
			{
				componentInChildren.InRange = true;
			}
		}

		// Token: 0x060008EB RID: 2283 RVA: 0x0003A370 File Offset: 0x00038570
		private void OnTriggerExit(Collider otherCollider)
		{
			DistanceGrabbable componentInChildren = otherCollider.GetComponentInChildren<DistanceGrabbable>();
			if (componentInChildren)
			{
				componentInChildren.InRange = false;
			}
		}

		// Token: 0x04000AB3 RID: 2739
		private Collider m_grabVolume;

		// Token: 0x04000AB4 RID: 2740
		public Color OutlineColorInRange;

		// Token: 0x04000AB5 RID: 2741
		public Color OutlineColorHighlighted;
	}
}
