﻿using System;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x0200014C RID: 332
	public class ColorGrabbable : OVRGrabbable
	{
		// Token: 0x17000038 RID: 56
		// (get) Token: 0x060008CC RID: 2252 RVA: 0x00039740 File Offset: 0x00037940
		// (set) Token: 0x060008CD RID: 2253 RVA: 0x00039748 File Offset: 0x00037948
		public bool Highlight
		{
			get
			{
				return this.m_highlight;
			}
			set
			{
				this.m_highlight = value;
				this.UpdateColor();
			}
		}

		// Token: 0x060008CE RID: 2254 RVA: 0x00039757 File Offset: 0x00037957
		protected void UpdateColor()
		{
			if (base.isGrabbed)
			{
				this.SetColor(ColorGrabbable.COLOR_GRAB);
				return;
			}
			if (this.Highlight)
			{
				this.SetColor(ColorGrabbable.COLOR_HIGHLIGHT);
				return;
			}
			this.SetColor(this.m_color);
		}

		// Token: 0x060008CF RID: 2255 RVA: 0x0003978D File Offset: 0x0003798D
		public override void GrabBegin(OVRGrabber hand, Collider grabPoint)
		{
			base.GrabBegin(hand, grabPoint);
			this.UpdateColor();
		}

		// Token: 0x060008D0 RID: 2256 RVA: 0x0003979D File Offset: 0x0003799D
		public override void GrabEnd(Vector3 linearVelocity, Vector3 angularVelocity)
		{
			base.GrabEnd(linearVelocity, angularVelocity);
			this.UpdateColor();
		}

		// Token: 0x060008D1 RID: 2257 RVA: 0x000397B0 File Offset: 0x000379B0
		private void Awake()
		{
			if (this.m_grabPoints.Length == 0)
			{
				Collider component = base.GetComponent<Collider>();
				if (component == null)
				{
					throw new ArgumentException("Grabbables cannot have zero grab points and no collider -- please add a grab point or collider.");
				}
				this.m_grabPoints = new Collider[]
				{
					component
				};
				this.m_meshRenderers = new MeshRenderer[1];
				this.m_meshRenderers[0] = base.GetComponent<MeshRenderer>();
			}
			else
			{
				this.m_meshRenderers = base.GetComponentsInChildren<MeshRenderer>();
			}
			this.m_color = new Color(Random.Range(0.1f, 0.95f), Random.Range(0.1f, 0.95f), Random.Range(0.1f, 0.95f), 1f);
			this.SetColor(this.m_color);
		}

		// Token: 0x060008D2 RID: 2258 RVA: 0x00039864 File Offset: 0x00037A64
		private void SetColor(Color color)
		{
			for (int i = 0; i < this.m_meshRenderers.Length; i++)
			{
				MeshRenderer meshRenderer = this.m_meshRenderers[i];
				for (int j = 0; j < meshRenderer.materials.Length; j++)
				{
					meshRenderer.materials[j].color = color;
				}
			}
		}

		// Token: 0x04000A99 RID: 2713
		public static readonly Color COLOR_GRAB = new Color(1f, 0.5f, 0f, 1f);

		// Token: 0x04000A9A RID: 2714
		public static readonly Color COLOR_HIGHLIGHT = new Color(1f, 0f, 1f, 1f);

		// Token: 0x04000A9B RID: 2715
		private Color m_color = Color.black;

		// Token: 0x04000A9C RID: 2716
		private MeshRenderer[] m_meshRenderers;

		// Token: 0x04000A9D RID: 2717
		private bool m_highlight;
	}
}
