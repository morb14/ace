﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x02000165 RID: 357
	public abstract class InteractableTool : MonoBehaviour
	{
		// Token: 0x1700005D RID: 93
		// (get) Token: 0x0600096C RID: 2412 RVA: 0x0003BAC4 File Offset: 0x00039CC4
		public Transform ToolTransform
		{
			get
			{
				return base.transform;
			}
		}

		// Token: 0x1700005E RID: 94
		// (get) Token: 0x0600096D RID: 2413 RVA: 0x0003BACC File Offset: 0x00039CCC
		// (set) Token: 0x0600096E RID: 2414 RVA: 0x0003BAD4 File Offset: 0x00039CD4
		public bool IsRightHandedTool { get; set; }

		// Token: 0x1700005F RID: 95
		// (get) Token: 0x0600096F RID: 2415
		public abstract InteractableToolTags ToolTags { get; }

		// Token: 0x17000060 RID: 96
		// (get) Token: 0x06000970 RID: 2416
		public abstract ToolInputState ToolInputState { get; }

		// Token: 0x17000061 RID: 97
		// (get) Token: 0x06000971 RID: 2417
		public abstract bool IsFarFieldTool { get; }

		// Token: 0x17000062 RID: 98
		// (get) Token: 0x06000972 RID: 2418 RVA: 0x0003BADD File Offset: 0x00039CDD
		// (set) Token: 0x06000973 RID: 2419 RVA: 0x0003BAE5 File Offset: 0x00039CE5
		public Vector3 Velocity { get; protected set; }

		// Token: 0x17000063 RID: 99
		// (get) Token: 0x06000974 RID: 2420 RVA: 0x0003BAEE File Offset: 0x00039CEE
		// (set) Token: 0x06000975 RID: 2421 RVA: 0x0003BAF6 File Offset: 0x00039CF6
		public Vector3 InteractionPosition { get; protected set; }

		// Token: 0x06000976 RID: 2422 RVA: 0x0003BAFF File Offset: 0x00039CFF
		public List<InteractableCollisionInfo> GetCurrentIntersectingObjects()
		{
			return this._currentIntersectingObjects;
		}

		// Token: 0x06000977 RID: 2423
		public abstract List<InteractableCollisionInfo> GetNextIntersectingObjects();

		// Token: 0x06000978 RID: 2424
		public abstract void FocusOnInteractable(Interactable focusedInteractable, ColliderZone colliderZone);

		// Token: 0x06000979 RID: 2425
		public abstract void DeFocus();

		// Token: 0x17000064 RID: 100
		// (get) Token: 0x0600097A RID: 2426
		// (set) Token: 0x0600097B RID: 2427
		public abstract bool EnableState { get; set; }

		// Token: 0x0600097C RID: 2428
		public abstract void Initialize();

		// Token: 0x0600097D RID: 2429 RVA: 0x0003BB07 File Offset: 0x00039D07
		public KeyValuePair<Interactable, InteractableCollisionInfo> GetFirstCurrentCollisionInfo()
		{
			return this._currInteractableToCollisionInfos.First<KeyValuePair<Interactable, InteractableCollisionInfo>>();
		}

		// Token: 0x0600097E RID: 2430 RVA: 0x0003BB14 File Offset: 0x00039D14
		public void ClearAllCurrentCollisionInfos()
		{
			this._currInteractableToCollisionInfos.Clear();
		}

		// Token: 0x0600097F RID: 2431 RVA: 0x0003BB24 File Offset: 0x00039D24
		public virtual void UpdateCurrentCollisionsBasedOnDepth()
		{
			this._currInteractableToCollisionInfos.Clear();
			foreach (InteractableCollisionInfo interactableCollisionInfo in this._currentIntersectingObjects)
			{
				Interactable parentInteractable = interactableCollisionInfo.InteractableCollider.ParentInteractable;
				InteractableCollisionDepth collisionDepth = interactableCollisionInfo.CollisionDepth;
				InteractableCollisionInfo interactableCollisionInfo2 = null;
				if (!this._currInteractableToCollisionInfos.TryGetValue(parentInteractable, out interactableCollisionInfo2))
				{
					this._currInteractableToCollisionInfos[parentInteractable] = interactableCollisionInfo;
				}
				else if (interactableCollisionInfo2.CollisionDepth < collisionDepth)
				{
					interactableCollisionInfo2.InteractableCollider = interactableCollisionInfo.InteractableCollider;
					interactableCollisionInfo2.CollisionDepth = collisionDepth;
				}
			}
		}

		// Token: 0x06000980 RID: 2432 RVA: 0x0003BBD0 File Offset: 0x00039DD0
		public virtual void UpdateLatestCollisionData()
		{
			this._addedInteractables.Clear();
			this._removedInteractables.Clear();
			this._remainingInteractables.Clear();
			foreach (Interactable interactable in this._currInteractableToCollisionInfos.Keys)
			{
				if (!this._prevInteractableToCollisionInfos.ContainsKey(interactable))
				{
					this._addedInteractables.Add(interactable);
				}
				else
				{
					this._remainingInteractables.Add(interactable);
				}
			}
			foreach (Interactable interactable2 in this._prevInteractableToCollisionInfos.Keys)
			{
				if (!this._currInteractableToCollisionInfos.ContainsKey(interactable2))
				{
					this._removedInteractables.Add(interactable2);
				}
			}
			foreach (Interactable interactable3 in this._removedInteractables)
			{
				interactable3.UpdateCollisionDepth(this, this._prevInteractableToCollisionInfos[interactable3].CollisionDepth, InteractableCollisionDepth.None, this._prevInteractableToCollisionInfos[interactable3].CollidingTool);
			}
			foreach (Interactable interactable4 in this._addedInteractables)
			{
				InteractableCollisionDepth collisionDepth = this._currInteractableToCollisionInfos[interactable4].CollisionDepth;
				interactable4.UpdateCollisionDepth(this, InteractableCollisionDepth.None, collisionDepth, this._currInteractableToCollisionInfos[interactable4].CollidingTool);
			}
			foreach (Interactable interactable5 in this._remainingInteractables)
			{
				InteractableCollisionDepth collisionDepth2 = this._currInteractableToCollisionInfos[interactable5].CollisionDepth;
				InteractableCollisionDepth collisionDepth3 = this._prevInteractableToCollisionInfos[interactable5].CollisionDepth;
				interactable5.UpdateCollisionDepth(this, collisionDepth3, collisionDepth2, this._currInteractableToCollisionInfos[interactable5].CollidingTool);
			}
			this._prevInteractableToCollisionInfos = new Dictionary<Interactable, InteractableCollisionInfo>(this._currInteractableToCollisionInfos);
		}

		// Token: 0x04000B24 RID: 2852
		protected List<InteractableCollisionInfo> _currentIntersectingObjects = new List<InteractableCollisionInfo>();

		// Token: 0x04000B25 RID: 2853
		private List<Interactable> _addedInteractables = new List<Interactable>();

		// Token: 0x04000B26 RID: 2854
		private List<Interactable> _removedInteractables = new List<Interactable>();

		// Token: 0x04000B27 RID: 2855
		private List<Interactable> _remainingInteractables = new List<Interactable>();

		// Token: 0x04000B28 RID: 2856
		private Dictionary<Interactable, InteractableCollisionInfo> _currInteractableToCollisionInfos = new Dictionary<Interactable, InteractableCollisionInfo>();

		// Token: 0x04000B29 RID: 2857
		private Dictionary<Interactable, InteractableCollisionInfo> _prevInteractableToCollisionInfos = new Dictionary<Interactable, InteractableCollisionInfo>();
	}
}
