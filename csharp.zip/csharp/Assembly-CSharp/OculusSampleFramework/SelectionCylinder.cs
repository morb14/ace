﻿using System;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x0200016E RID: 366
	public class SelectionCylinder : MonoBehaviour
	{
		// Token: 0x17000074 RID: 116
		// (get) Token: 0x060009C4 RID: 2500 RVA: 0x0003CB99 File Offset: 0x0003AD99
		// (set) Token: 0x060009C5 RID: 2501 RVA: 0x0003CBA4 File Offset: 0x0003ADA4
		public SelectionCylinder.SelectionState CurrSelectionState
		{
			get
			{
				return this._currSelectionState;
			}
			set
			{
				SelectionCylinder.SelectionState currSelectionState = this._currSelectionState;
				this._currSelectionState = value;
				if (currSelectionState != this._currSelectionState)
				{
					if (this._currSelectionState > SelectionCylinder.SelectionState.Off)
					{
						this._selectionMeshRenderer.enabled = true;
						this.AffectSelectionColor((this._currSelectionState == SelectionCylinder.SelectionState.Selected) ? this._defaultSelectionColors : this._highlightColors);
						return;
					}
					this._selectionMeshRenderer.enabled = false;
				}
			}
		}

		// Token: 0x060009C6 RID: 2502 RVA: 0x0003CC08 File Offset: 0x0003AE08
		private void Awake()
		{
			this._selectionMaterials = this._selectionMeshRenderer.materials;
			int num = this._selectionMaterials.Length;
			this._defaultSelectionColors = new Color[num];
			this._highlightColors = new Color[num];
			for (int i = 0; i < num; i++)
			{
				this._defaultSelectionColors[i] = this._selectionMaterials[i].GetColor(SelectionCylinder._colorId);
				this._highlightColors[i] = new Color(1f, 1f, 1f, this._defaultSelectionColors[i].a);
			}
			this.CurrSelectionState = SelectionCylinder.SelectionState.Off;
		}

		// Token: 0x060009C7 RID: 2503 RVA: 0x0003CCAC File Offset: 0x0003AEAC
		private void OnDestroy()
		{
			if (this._selectionMaterials != null)
			{
				foreach (Material material in this._selectionMaterials)
				{
					if (material != null)
					{
						Object.Destroy(material);
					}
				}
			}
		}

		// Token: 0x060009C8 RID: 2504 RVA: 0x0003CCEC File Offset: 0x0003AEEC
		private void AffectSelectionColor(Color[] newColors)
		{
			int num = newColors.Length;
			for (int i = 0; i < num; i++)
			{
				this._selectionMaterials[i].SetColor(SelectionCylinder._colorId, newColors[i]);
			}
		}

		// Token: 0x04000B58 RID: 2904
		[SerializeField]
		private MeshRenderer _selectionMeshRenderer;

		// Token: 0x04000B59 RID: 2905
		private static int _colorId = Shader.PropertyToID("_Color");

		// Token: 0x04000B5A RID: 2906
		private Material[] _selectionMaterials;

		// Token: 0x04000B5B RID: 2907
		private Color[] _defaultSelectionColors;

		// Token: 0x04000B5C RID: 2908
		private Color[] _highlightColors;

		// Token: 0x04000B5D RID: 2909
		private SelectionCylinder.SelectionState _currSelectionState;

		// Token: 0x02000244 RID: 580
		public enum SelectionState
		{
			// Token: 0x04000FDB RID: 4059
			Off,
			// Token: 0x04000FDC RID: 4060
			Selected,
			// Token: 0x04000FDD RID: 4061
			Highlighted
		}
	}
}
