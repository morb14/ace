﻿using System;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x02000172 RID: 370
	public abstract class TrainCarBase : MonoBehaviour
	{
		// Token: 0x1700007D RID: 125
		// (get) Token: 0x060009EC RID: 2540 RVA: 0x0003D808 File Offset: 0x0003BA08
		// (set) Token: 0x060009ED RID: 2541 RVA: 0x0003D810 File Offset: 0x0003BA10
		public float Distance { get; protected set; }

		// Token: 0x1700007E RID: 126
		// (get) Token: 0x060009EE RID: 2542 RVA: 0x0003D819 File Offset: 0x0003BA19
		// (set) Token: 0x060009EF RID: 2543 RVA: 0x0003D821 File Offset: 0x0003BA21
		public float Scale
		{
			get
			{
				return this.scale;
			}
			set
			{
				this.scale = value;
			}
		}

		// Token: 0x060009F0 RID: 2544 RVA: 0x00003297 File Offset: 0x00001497
		protected virtual void Awake()
		{
		}

		// Token: 0x060009F1 RID: 2545 RVA: 0x0003D82C File Offset: 0x0003BA2C
		public void UpdatePose(float distance, TrainCarBase train, Pose pose)
		{
			distance = (train._trainTrack.TrackLength + distance) % train._trainTrack.TrackLength;
			if (distance < 0f)
			{
				distance += train._trainTrack.TrackLength;
			}
			TrackSegment segment = train._trainTrack.GetSegment(distance);
			float distanceIntoSegment = distance - segment.StartDistance;
			segment.UpdatePose(distanceIntoSegment, pose);
		}

		// Token: 0x060009F2 RID: 2546 RVA: 0x0003D88C File Offset: 0x0003BA8C
		protected void UpdateCarPosition()
		{
			this.UpdatePose(this.Distance + this._frontWheels.transform.localPosition.z * this.scale, this, this._frontPose);
			this.UpdatePose(this.Distance + this._rearWheels.transform.localPosition.z * this.scale, this, this._rearPose);
			Vector3 a = 0.5f * (this._frontPose.Position + this._rearPose.Position);
			Vector3 forward = this._frontPose.Position - this._rearPose.Position;
			base.transform.position = a + TrainCarBase.OFFSET;
			base.transform.rotation = Quaternion.LookRotation(forward, base.transform.up);
			this._frontWheels.transform.rotation = this._frontPose.Rotation;
			this._rearWheels.transform.rotation = this._rearPose.Rotation;
		}

		// Token: 0x060009F3 RID: 2547 RVA: 0x0003D9A4 File Offset: 0x0003BBA4
		protected void RotateCarWheels()
		{
			float num = this.Distance / 0.027f % 6.2831855f;
			Transform[] individualWheels = this._individualWheels;
			for (int i = 0; i < individualWheels.Length; i++)
			{
				individualWheels[i].localRotation = Quaternion.AngleAxis(57.29578f * num, Vector3.right);
			}
		}

		// Token: 0x060009F4 RID: 2548
		public abstract void UpdatePosition();

		// Token: 0x04000B7E RID: 2942
		private static Vector3 OFFSET = new Vector3(0f, 0.0195f, 0f);

		// Token: 0x04000B7F RID: 2943
		private const float WHEEL_RADIUS = 0.027f;

		// Token: 0x04000B80 RID: 2944
		private const float TWO_PI = 6.2831855f;

		// Token: 0x04000B81 RID: 2945
		[SerializeField]
		protected Transform _frontWheels;

		// Token: 0x04000B82 RID: 2946
		[SerializeField]
		protected Transform _rearWheels;

		// Token: 0x04000B83 RID: 2947
		[SerializeField]
		protected TrainTrack _trainTrack;

		// Token: 0x04000B84 RID: 2948
		[SerializeField]
		protected Transform[] _individualWheels;

		// Token: 0x04000B86 RID: 2950
		protected float scale = 1f;

		// Token: 0x04000B87 RID: 2951
		private Pose _frontPose = new Pose();

		// Token: 0x04000B88 RID: 2952
		private Pose _rearPose = new Pose();
	}
}
