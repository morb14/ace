﻿using System;
using System.Collections;
using UnityEngine;

namespace OculusSampleFramework
{
	// Token: 0x02000177 RID: 375
	public class WindmillBladesController : MonoBehaviour
	{
		// Token: 0x17000080 RID: 128
		// (get) Token: 0x06000A18 RID: 2584 RVA: 0x0003E202 File Offset: 0x0003C402
		// (set) Token: 0x06000A19 RID: 2585 RVA: 0x0003E20A File Offset: 0x0003C40A
		public bool IsMoving { get; private set; }

		// Token: 0x06000A1A RID: 2586 RVA: 0x0003E213 File Offset: 0x0003C413
		private void Start()
		{
			this._originalRotation = base.transform.localRotation;
		}

		// Token: 0x06000A1B RID: 2587 RVA: 0x0003E228 File Offset: 0x0003C428
		private void Update()
		{
			this._rotAngle += this._currentSpeed * Time.deltaTime;
			if (this._rotAngle > 360f)
			{
				this._rotAngle = 0f;
			}
			base.transform.localRotation = this._originalRotation * Quaternion.AngleAxis(this._rotAngle, Vector3.forward);
		}

		// Token: 0x06000A1C RID: 2588 RVA: 0x0003E28C File Offset: 0x0003C48C
		public void SetMoveState(bool newMoveState, float goalSpeed)
		{
			this.IsMoving = newMoveState;
			if (this._lerpSpeedCoroutine != null)
			{
				base.StopCoroutine(this._lerpSpeedCoroutine);
			}
			this._lerpSpeedCoroutine = base.StartCoroutine(this.LerpToSpeed(goalSpeed));
		}

		// Token: 0x06000A1D RID: 2589 RVA: 0x0003E2BC File Offset: 0x0003C4BC
		private IEnumerator LerpToSpeed(float goalSpeed)
		{
			float totalTime = 0f;
			float startSpeed = this._currentSpeed;
			if (this._audioChangeCr != null)
			{
				base.StopCoroutine(this._audioChangeCr);
			}
			if (this.IsMoving)
			{
				this._audioChangeCr = base.StartCoroutine(this.PlaySoundDelayed(this._windMillStartSound, this._windMillRotationSound, this._windMillStartSound.length * 0.95f));
			}
			else
			{
				this.PlaySound(this._windMillStopSound, false);
			}
			for (float num = Mathf.Abs(this._currentSpeed - goalSpeed); num > Mathf.Epsilon; num = Mathf.Abs(this._currentSpeed - goalSpeed))
			{
				this._currentSpeed = Mathf.Lerp(startSpeed, goalSpeed, totalTime / 1f);
				totalTime += Time.deltaTime;
				yield return null;
			}
			this._lerpSpeedCoroutine = null;
			yield break;
		}

		// Token: 0x06000A1E RID: 2590 RVA: 0x0003E2D2 File Offset: 0x0003C4D2
		private IEnumerator PlaySoundDelayed(AudioClip initial, AudioClip clip, float timeDelayAfterInitial)
		{
			this.PlaySound(initial, false);
			yield return new WaitForSeconds(timeDelayAfterInitial);
			this.PlaySound(clip, true);
			yield break;
		}

		// Token: 0x06000A1F RID: 2591 RVA: 0x0003E2F6 File Offset: 0x0003C4F6
		private void PlaySound(AudioClip clip, bool loop = false)
		{
			this._audioSource.loop = loop;
			this._audioSource.timeSamples = 0;
			this._audioSource.clip = clip;
			this._audioSource.Play();
		}

		// Token: 0x04000BB9 RID: 3001
		private const float MAX_TIME = 1f;

		// Token: 0x04000BBA RID: 3002
		[SerializeField]
		private AudioSource _audioSource;

		// Token: 0x04000BBB RID: 3003
		[SerializeField]
		private AudioClip _windMillRotationSound;

		// Token: 0x04000BBC RID: 3004
		[SerializeField]
		private AudioClip _windMillStartSound;

		// Token: 0x04000BBD RID: 3005
		[SerializeField]
		private AudioClip _windMillStopSound;

		// Token: 0x04000BBF RID: 3007
		private float _currentSpeed;

		// Token: 0x04000BC0 RID: 3008
		private Coroutine _lerpSpeedCoroutine;

		// Token: 0x04000BC1 RID: 3009
		private Coroutine _audioChangeCr;

		// Token: 0x04000BC2 RID: 3010
		private Quaternion _originalRotation;

		// Token: 0x04000BC3 RID: 3011
		private float _rotAngle;
	}
}
