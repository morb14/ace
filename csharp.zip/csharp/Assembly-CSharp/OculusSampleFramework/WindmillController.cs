﻿using System;
using UnityEngine;
using UnityEngine.Events;

namespace OculusSampleFramework
{
	// Token: 0x02000178 RID: 376
	public class WindmillController : MonoBehaviour
	{
		// Token: 0x06000A21 RID: 2593 RVA: 0x0003E327 File Offset: 0x0003C527
		private void Awake()
		{
			this._bladesRotation = base.GetComponentInChildren<WindmillBladesController>();
			this._bladesRotation.SetMoveState(true, this._maxSpeed);
		}

		// Token: 0x06000A22 RID: 2594 RVA: 0x0003E347 File Offset: 0x0003C547
		private void OnEnable()
		{
			this._startStopButton.GetComponent<Interactable>().InteractableStateChanged.AddListener(new UnityAction<InteractableStateArgs>(this.StartStopStateChanged));
		}

		// Token: 0x06000A23 RID: 2595 RVA: 0x0003E36A File Offset: 0x0003C56A
		private void OnDisable()
		{
			if (this._startStopButton != null)
			{
				this._startStopButton.GetComponent<Interactable>().InteractableStateChanged.RemoveListener(new UnityAction<InteractableStateArgs>(this.StartStopStateChanged));
			}
		}

		// Token: 0x06000A24 RID: 2596 RVA: 0x0003E39C File Offset: 0x0003C59C
		private void StartStopStateChanged(InteractableStateArgs obj)
		{
			if (obj.NewInteractableState == InteractableState.ActionState)
			{
				if (this._bladesRotation.IsMoving)
				{
					this._bladesRotation.SetMoveState(false, 0f);
				}
				else
				{
					this._bladesRotation.SetMoveState(true, this._maxSpeed);
				}
			}
			this._toolInteractingWithMe = ((obj.NewInteractableState > InteractableState.Default) ? obj.Tool : null);
		}

		// Token: 0x06000A25 RID: 2597 RVA: 0x0003E400 File Offset: 0x0003C600
		private void Update()
		{
			if (this._toolInteractingWithMe == null)
			{
				this._selectionCylinder.CurrSelectionState = SelectionCylinder.SelectionState.Off;
				return;
			}
			this._selectionCylinder.CurrSelectionState = ((this._toolInteractingWithMe.ToolInputState == ToolInputState.PrimaryInputDown || this._toolInteractingWithMe.ToolInputState == ToolInputState.PrimaryInputDownStay) ? SelectionCylinder.SelectionState.Highlighted : SelectionCylinder.SelectionState.Selected);
		}

		// Token: 0x04000BC4 RID: 3012
		[SerializeField]
		private GameObject _startStopButton;

		// Token: 0x04000BC5 RID: 3013
		[SerializeField]
		private float _maxSpeed = 10f;

		// Token: 0x04000BC6 RID: 3014
		[SerializeField]
		private SelectionCylinder _selectionCylinder;

		// Token: 0x04000BC7 RID: 3015
		private WindmillBladesController _bladesRotation;

		// Token: 0x04000BC8 RID: 3016
		private InteractableTool _toolInteractingWithMe;
	}
}
