﻿using System;

namespace OculusSampleFramework
{
	// Token: 0x02000166 RID: 358
	public interface InteractableToolView
	{
		// Token: 0x17000065 RID: 101
		// (get) Token: 0x06000982 RID: 2434
		InteractableTool InteractableTool { get; }

		// Token: 0x06000983 RID: 2435
		void SetFocusedInteractable(Interactable interactable);

		// Token: 0x17000066 RID: 102
		// (get) Token: 0x06000984 RID: 2436
		// (set) Token: 0x06000985 RID: 2437
		bool EnableState { get; set; }

		// Token: 0x17000067 RID: 103
		// (get) Token: 0x06000986 RID: 2438
		// (set) Token: 0x06000987 RID: 2439
		bool ToolActivateState { get; set; }
	}
}
