﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x0200001C RID: 28
[RequireComponent(typeof(MeshFilter))]
public class WFX_BulletHoleDecal : MonoBehaviour
{
	// Token: 0x06000084 RID: 132 RVA: 0x00004FA8 File Offset: 0x000031A8
	private void Awake()
	{
		this.color = base.GetComponent<Renderer>().material.GetColor("_TintColor");
		this.orgAlpha = this.color.a;
	}

	// Token: 0x06000085 RID: 133 RVA: 0x00004FD8 File Offset: 0x000031D8
	private void OnEnable()
	{
		int num = Random.Range(0, (int)(this.frames.x * this.frames.y));
		int num2 = (int)((float)num % this.frames.x);
		int num3 = (int)((float)num / this.frames.y);
		Vector2[] array = new Vector2[4];
		for (int i = 0; i < 4; i++)
		{
			array[i].x = (WFX_BulletHoleDecal.quadUVs[i].x + (float)num2) * (1f / this.frames.x);
			array[i].y = (WFX_BulletHoleDecal.quadUVs[i].y + (float)num3) * (1f / this.frames.y);
		}
		base.GetComponent<MeshFilter>().mesh.uv = array;
		if (this.randomRotation)
		{
			base.transform.Rotate(0f, 0f, Random.Range(0f, 360f), Space.Self);
		}
		this.life = this.lifetime;
		this.fadeout = this.life * (this.fadeoutpercent / 100f);
		this.color.a = this.orgAlpha;
		base.GetComponent<Renderer>().material.SetColor("_TintColor", this.color);
		base.StopAllCoroutines();
		base.StartCoroutine("holeUpdate");
	}

	// Token: 0x06000086 RID: 134 RVA: 0x00005138 File Offset: 0x00003338
	private IEnumerator holeUpdate()
	{
		while (this.life > 0f)
		{
			this.life -= Time.deltaTime;
			if (this.life <= this.fadeout)
			{
				this.color.a = Mathf.Lerp(0f, this.orgAlpha, this.life / this.fadeout);
				base.GetComponent<Renderer>().material.SetColor("_TintColor", this.color);
			}
			yield return null;
		}
		yield break;
	}

	// Token: 0x0400008D RID: 141
	private static Vector2[] quadUVs = new Vector2[]
	{
		new Vector2(0f, 0f),
		new Vector2(0f, 1f),
		new Vector2(1f, 0f),
		new Vector2(1f, 1f)
	};

	// Token: 0x0400008E RID: 142
	public float lifetime = 10f;

	// Token: 0x0400008F RID: 143
	public float fadeoutpercent = 80f;

	// Token: 0x04000090 RID: 144
	public Vector2 frames;

	// Token: 0x04000091 RID: 145
	public bool randomRotation;

	// Token: 0x04000092 RID: 146
	public bool deactivate;

	// Token: 0x04000093 RID: 147
	private float life;

	// Token: 0x04000094 RID: 148
	private float fadeout;

	// Token: 0x04000095 RID: 149
	private Color color;

	// Token: 0x04000096 RID: 150
	private float orgAlpha;
}
