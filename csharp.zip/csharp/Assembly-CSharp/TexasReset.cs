﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000066 RID: 102
public class TexasReset : MonoBehaviour
{
	// Token: 0x060003C2 RID: 962 RVA: 0x00018F94 File Offset: 0x00017194
	private void Start()
	{
		if (this.steelTarget.autoReset)
		{
			this.mountStartRotation = this.plateMount.transform.rotation;
			foreach (Transform transform in this.plates)
			{
				this.plateStartPos.Add(transform, transform.position);
				this.plateStartRot.Add(transform, transform.rotation);
			}
		}
	}

	// Token: 0x060003C3 RID: 963 RVA: 0x00019004 File Offset: 0x00017204
	private void Update()
	{
		if (this.steelTarget.autoReset)
		{
			bool flag = false;
			if (!this.resetInitiated)
			{
				Transform[] array = this.plates;
				for (int i = 0; i < array.Length; i++)
				{
					if (array[i].parent != null)
					{
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					this.resetInitiated = true;
					base.Invoke("Reset", this.steelTarget.resetTime);
				}
			}
			if (this.resetting)
			{
				this.ResetLerp();
			}
		}
	}

	// Token: 0x060003C4 RID: 964 RVA: 0x00019080 File Offset: 0x00017280
	public void Reset()
	{
		this.resetting = true;
		this.resetBeginTime = Time.time;
		foreach (Transform transform in this.plates)
		{
			this.plateDownPos.Add(transform, transform.position);
			this.plateDownRot.Add(transform, transform.rotation);
		}
		this.mountDownRotation = this.plateMount.rotation;
	}

	// Token: 0x060003C5 RID: 965 RVA: 0x000190F0 File Offset: 0x000172F0
	private void ResetLerp()
	{
		this.plateMount.rotation = Quaternion.RotateTowards(this.mountDownRotation, this.mountStartRotation, (Time.time - this.resetBeginTime) * 200f);
		foreach (Transform transform in this.plates)
		{
			transform.rotation = Quaternion.RotateTowards(this.plateDownRot[transform], this.plateStartRot[transform], (Time.time - this.resetBeginTime) * 200f);
			transform.position = Vector3.Lerp(this.plateDownPos[transform], this.plateStartPos[transform], Time.time - this.resetBeginTime);
			transform.parent = this.plateMount;
		}
		if (Vector3.Distance(this.plates[0].position, this.plateStartPos[this.plates[0]]) < 0.01f && !this.reattaching)
		{
			base.Invoke("Reattach", 2f);
			this.reattaching = true;
		}
	}

	// Token: 0x060003C6 RID: 966 RVA: 0x00019200 File Offset: 0x00017400
	private void Reattach()
	{
		foreach (Transform transform in this.plates)
		{
			FixedJoint fixedJoint = transform.gameObject.AddComponent<FixedJoint>();
			transform.GetComponent<TargetDetach>().fixedJoint = fixedJoint;
			fixedJoint.connectedBody = this.plateMount.GetComponent<Rigidbody>();
		}
		this.plateDownPos.Clear();
		this.plateDownRot.Clear();
		this.reattaching = false;
		this.resetting = false;
		this.resetInitiated = false;
	}

	// Token: 0x040004A2 RID: 1186
	[SerializeField]
	private Transform[] plates;

	// Token: 0x040004A3 RID: 1187
	[SerializeField]
	private Transform plateMount;

	// Token: 0x040004A4 RID: 1188
	[SerializeField]
	private SteelTarget steelTarget;

	// Token: 0x040004A5 RID: 1189
	[SerializeField]
	private GameObject toSpawn;

	// Token: 0x040004A6 RID: 1190
	private Quaternion mountStartRotation;

	// Token: 0x040004A7 RID: 1191
	private Quaternion mountDownRotation;

	// Token: 0x040004A8 RID: 1192
	private Dictionary<Transform, Vector3> plateStartPos = new Dictionary<Transform, Vector3>();

	// Token: 0x040004A9 RID: 1193
	private Dictionary<Transform, Quaternion> plateStartRot = new Dictionary<Transform, Quaternion>();

	// Token: 0x040004AA RID: 1194
	private Dictionary<Transform, Vector3> plateDownPos = new Dictionary<Transform, Vector3>();

	// Token: 0x040004AB RID: 1195
	private Dictionary<Transform, Quaternion> plateDownRot = new Dictionary<Transform, Quaternion>();

	// Token: 0x040004AC RID: 1196
	private bool resetInitiated;

	// Token: 0x040004AD RID: 1197
	private bool resetting;

	// Token: 0x040004AE RID: 1198
	private bool reattaching;

	// Token: 0x040004AF RID: 1199
	private float resetBeginTime;
}
