﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x02000040 RID: 64
public class ObjectManager : MonoBehaviour
{
	// Token: 0x06000218 RID: 536 RVA: 0x0000BC9C File Offset: 0x00009E9C
	private void Start()
	{
		this.savedPoolSize = this.bulletHolePoolSize;
		SceneManager.sceneLoaded += this.ClearQueue;
		SceneManager.sceneLoaded += this.OnSceneLoaded;
	}

	// Token: 0x06000219 RID: 537 RVA: 0x0000BCCC File Offset: 0x00009ECC
	private void ClearQueue(Scene scene, LoadSceneMode mode)
	{
		this.objectQueue = null;
	}

	// Token: 0x0600021A RID: 538 RVA: 0x0000BCD5 File Offset: 0x00009ED5
	private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
	{
		if (Object.FindObjectOfType<SceneSettings>().sceneType == SceneSettings.SceneType.Comp)
		{
			this.bulletHolePoolSize = 1000;
			return;
		}
		this.bulletHolePoolSize = this.savedPoolSize;
	}

	// Token: 0x0600021B RID: 539 RVA: 0x0000BCFC File Offset: 0x00009EFC
	public GameObject PoolObject(GameObject poolObject, ObjectManager.ObjectType type)
	{
		GameObject gameObject = null;
		if (type == ObjectManager.ObjectType.BulletHoles)
		{
			if (this.objectQueue == null)
			{
				this.objectQueue = new Queue<GameObject>();
			}
			if (this.objectQueue.Count < this.bulletHolePoolSize)
			{
				gameObject = Object.Instantiate<GameObject>(poolObject);
				this.objectQueue.Enqueue(gameObject);
			}
			else
			{
				gameObject = this.objectQueue.Peek();
				this.objectQueue.Enqueue(this.objectQueue.Dequeue());
				gameObject.transform.parent = null;
				gameObject.transform.localScale = Vector3.one;
			}
			return gameObject;
		}
		return gameObject;
	}

	// Token: 0x040001E4 RID: 484
	[SerializeField]
	private int bulletHolePoolSize = 50;

	// Token: 0x040001E5 RID: 485
	private int savedPoolSize;

	// Token: 0x040001E6 RID: 486
	private Queue<GameObject> objectQueue;

	// Token: 0x020001B7 RID: 439
	public enum ObjectType
	{
		// Token: 0x04000D42 RID: 3394
		BulletHoles
	}
}
