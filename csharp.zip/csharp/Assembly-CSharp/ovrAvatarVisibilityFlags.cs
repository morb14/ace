﻿using System;

// Token: 0x020000E0 RID: 224
[Flags]
public enum ovrAvatarVisibilityFlags
{
	// Token: 0x04000846 RID: 2118
	FirstPerson = 1,
	// Token: 0x04000847 RID: 2119
	ThirdPerson = 2,
	// Token: 0x04000848 RID: 2120
	SelfOccluding = 4
}
