﻿using System;
using UnityEngine;

// Token: 0x02000035 RID: 53
public class WeaponEquiper : MonoBehaviour
{
	// Token: 0x060001E1 RID: 481 RVA: 0x0000AACF File Offset: 0x00008CCF
	private void Start()
	{
		this.control = Object.FindObjectOfType<ControlManager>();
	}

	// Token: 0x060001E2 RID: 482 RVA: 0x00003297 File Offset: 0x00001497
	private void Update()
	{
	}

	// Token: 0x060001E3 RID: 483 RVA: 0x0000AADC File Offset: 0x00008CDC
	private void LateUpdate()
	{
		this.ResetVolumeCheck();
	}

	// Token: 0x060001E4 RID: 484 RVA: 0x0000AAE4 File Offset: 0x00008CE4
	private void OnTriggerStay(Collider other)
	{
		if (this.control.status == ControlManager.Status.Hand && other.GetComponent<HolsterVolume>())
		{
			this.inHolsterVolume = true;
		}
	}

	// Token: 0x060001E5 RID: 485 RVA: 0x0000AB08 File Offset: 0x00008D08
	private void ResetVolumeCheck()
	{
		this.inHolsterVolume = false;
	}

	// Token: 0x060001E6 RID: 486 RVA: 0x0000AB14 File Offset: 0x00008D14
	public void Draw(GameObject holsterWeapon)
	{
		Transform transform;
		if ((holsterWeapon.GetComponent<WeaponController>().weaponType == WeaponController.WeaponType.ShotgunField || holsterWeapon.GetComponent<WeaponController>().weaponType == WeaponController.WeaponType.RifleField) && this.control.controllerMode != ControlManager.ControllerMode.TwoHand)
		{
			transform = this.straightStockTransform;
		}
		if (this.control.controllerMode == ControlManager.ControllerMode.ControlARPro && holsterWeapon.GetComponent<WeaponController>().weaponType == WeaponController.WeaponType.Rifle)
		{
			transform = this.controlARProTransform;
		}
		else
		{
			transform = this.weaponTransform;
		}
		if (this.rightHand)
		{
			this.control.handedness = ControlManager.Handedness.Right;
			this.control.controller = OVRInput.Controller.RTouch;
		}
		else
		{
			this.control.handedness = ControlManager.Handedness.Left;
			this.control.controller = OVRInput.Controller.LTouch;
		}
		holsterWeapon.transform.parent = transform.transform;
		holsterWeapon.transform.localPosition = Vector3.zero;
		holsterWeapon.transform.localEulerAngles = Vector3.zero;
		holsterWeapon.transform.localScale = Vector3.one;
		this.control.status = ControlManager.Status.Gun;
		holsterWeapon.GetComponent<WeaponController>().Unholster();
		this.weapon = holsterWeapon;
		GameEvents.current.HolsterDraw();
	}

	// Token: 0x060001E7 RID: 487 RVA: 0x0000AC21 File Offset: 0x00008E21
	public GameObject Holster(HolsterControl holster = null)
	{
		this.control.status = ControlManager.Status.Hand;
		this.weapon.GetComponent<WeaponController>().Holster();
		GameEvents.current.Holster();
		return this.weapon;
	}

	// Token: 0x060001E8 RID: 488 RVA: 0x00003297 File Offset: 0x00001497
	private void OnDestroy()
	{
	}

	// Token: 0x0400019B RID: 411
	[SerializeField]
	public Transform weaponTransform;

	// Token: 0x0400019C RID: 412
	[SerializeField]
	public Transform straightStockTransform;

	// Token: 0x0400019D RID: 413
	[SerializeField]
	public Transform controlARProTransform;

	// Token: 0x0400019E RID: 414
	[SerializeField]
	public GameObject OVRLeft;

	// Token: 0x0400019F RID: 415
	[SerializeField]
	public GameObject OVRRight;

	// Token: 0x040001A0 RID: 416
	[SerializeField]
	public bool rightHand;

	// Token: 0x040001A1 RID: 417
	private GameObject weapon;

	// Token: 0x040001A2 RID: 418
	private ControlManager control;

	// Token: 0x040001A3 RID: 419
	private bool inHolsterVolume;
}
