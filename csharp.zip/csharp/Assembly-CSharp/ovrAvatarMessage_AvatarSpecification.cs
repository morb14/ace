﻿using System;

// Token: 0x020000BD RID: 189
public struct ovrAvatarMessage_AvatarSpecification
{
	// Token: 0x04000768 RID: 1896
	public IntPtr avatarSpec;

	// Token: 0x04000769 RID: 1897
	public ulong oculusUserID;
}
