﻿using System;
using System.Diagnostics;
using System.Threading;
using UnityEngine;

// Token: 0x0200010F RID: 271
[RequireComponent(typeof(AudioSource))]
public class OVRLipSyncMicInput : MonoBehaviour
{
	// Token: 0x17000015 RID: 21
	// (get) Token: 0x060006E0 RID: 1760 RVA: 0x0002C176 File Offset: 0x0002A376
	// (set) Token: 0x060006E1 RID: 1761 RVA: 0x0002C17F File Offset: 0x0002A37F
	public float MicFrequency
	{
		get
		{
			return (float)this.micFrequency;
		}
		set
		{
			this.micFrequency = (int)Mathf.Clamp(value, 0f, 96000f);
		}
	}

	// Token: 0x060006E2 RID: 1762 RVA: 0x0002C199 File Offset: 0x0002A399
	private void Awake()
	{
		if (!this.audioSource)
		{
			this.audioSource = base.GetComponent<AudioSource>();
		}
		this.audioSource;
	}

	// Token: 0x060006E3 RID: 1763 RVA: 0x0002C1C0 File Offset: 0x0002A3C0
	private void Start()
	{
		this.audioSource.loop = true;
		this.audioSource.mute = false;
		this.InitializeMicrophone();
	}

	// Token: 0x060006E4 RID: 1764 RVA: 0x0002C1E0 File Offset: 0x0002A3E0
	private void InitializeMicrophone()
	{
		if (this.initialized)
		{
			return;
		}
		if (Microphone.devices.Length == 0)
		{
			return;
		}
		this.selectedDevice = Microphone.devices[0].ToString();
		this.micSelected = true;
		this.GetMicCaps();
		this.initialized = true;
	}

	// Token: 0x060006E5 RID: 1765 RVA: 0x0002C21C File Offset: 0x0002A41C
	private void Update()
	{
		if (!this.focused)
		{
			if (Microphone.IsRecording(this.selectedDevice))
			{
				this.StopMicrophone();
			}
			return;
		}
		if (!Application.isPlaying)
		{
			this.StopMicrophone();
			return;
		}
		if (!this.initialized)
		{
			this.InitializeMicrophone();
		}
		this.audioSource.volume = this.micInputVolume / 100f;
		if (this.micControl == OVRLipSyncMicInput.micActivation.HoldToSpeak)
		{
			if (Input.GetKey(this.micActivationKey))
			{
				if (!Microphone.IsRecording(this.selectedDevice))
				{
					this.StartMicrophone();
				}
			}
			else if (Microphone.IsRecording(this.selectedDevice))
			{
				this.StopMicrophone();
			}
		}
		if (this.micControl == OVRLipSyncMicInput.micActivation.PushToSpeak && Input.GetKeyDown(this.micActivationKey))
		{
			if (Microphone.IsRecording(this.selectedDevice))
			{
				this.StopMicrophone();
			}
			else if (!Microphone.IsRecording(this.selectedDevice))
			{
				this.StartMicrophone();
			}
		}
		if (this.micControl == OVRLipSyncMicInput.micActivation.ConstantSpeak && !Microphone.IsRecording(this.selectedDevice))
		{
			this.StartMicrophone();
		}
		if (this.enableMicSelectionGUI && Input.GetKeyDown(this.micSelectionGUIKey))
		{
			this.micSelected = false;
		}
	}

	// Token: 0x060006E6 RID: 1766 RVA: 0x0002C32B File Offset: 0x0002A52B
	private void OnApplicationFocus(bool focus)
	{
		this.focused = focus;
		if (!this.focused)
		{
			this.StopMicrophone();
		}
	}

	// Token: 0x060006E7 RID: 1767 RVA: 0x0002C342 File Offset: 0x0002A542
	private void OnApplicationPause(bool pauseStatus)
	{
		this.focused = !pauseStatus;
		if (!this.focused)
		{
			this.StopMicrophone();
		}
	}

	// Token: 0x060006E8 RID: 1768 RVA: 0x0002C35C File Offset: 0x0002A55C
	private void OnDisable()
	{
		this.StopMicrophone();
	}

	// Token: 0x060006E9 RID: 1769 RVA: 0x0002C364 File Offset: 0x0002A564
	private void OnGUI()
	{
		this.MicDeviceGUI((float)(Screen.width / 2 - 150), (float)(Screen.height / 2 - 75), 300f, 50f, 10f, -300f);
	}

	// Token: 0x060006EA RID: 1770 RVA: 0x0002C39C File Offset: 0x0002A59C
	public void MicDeviceGUI(float left, float top, float width, float height, float buttonSpaceTop, float buttonSpaceLeft)
	{
		if (Microphone.devices.Length >= 1 && this.enableMicSelectionGUI && !this.micSelected)
		{
			for (int i = 0; i < Microphone.devices.Length; i++)
			{
				if (GUI.Button(new Rect(left + (width + buttonSpaceLeft) * (float)i, top + (height + buttonSpaceTop) * (float)i, width, height), Microphone.devices[i].ToString()))
				{
					this.StopMicrophone();
					this.selectedDevice = Microphone.devices[i].ToString();
					this.micSelected = true;
					this.GetMicCaps();
					this.StartMicrophone();
				}
			}
		}
	}

	// Token: 0x060006EB RID: 1771 RVA: 0x0002C430 File Offset: 0x0002A630
	public void GetMicCaps()
	{
		if (!this.micSelected)
		{
			return;
		}
		Microphone.GetDeviceCaps(this.selectedDevice, out this.minFreq, out this.maxFreq);
		if (this.minFreq == 0 && this.maxFreq == 0)
		{
			Debug.LogWarning("GetMicCaps warning:: min and max frequencies are 0");
			this.minFreq = 44100;
			this.maxFreq = 44100;
		}
		if (this.micFrequency > this.maxFreq)
		{
			this.micFrequency = this.maxFreq;
		}
	}

	// Token: 0x060006EC RID: 1772 RVA: 0x0002C4A8 File Offset: 0x0002A6A8
	public void StartMicrophone()
	{
		if (!this.micSelected)
		{
			return;
		}
		this.audioSource.clip = Microphone.Start(this.selectedDevice, true, 1, this.micFrequency);
		Stopwatch stopwatch = Stopwatch.StartNew();
		while (Microphone.GetPosition(this.selectedDevice) <= 0 && stopwatch.Elapsed.TotalMilliseconds < 1000.0)
		{
			Thread.Sleep(50);
		}
		if (Microphone.GetPosition(this.selectedDevice) <= 0)
		{
			throw new Exception("Timeout initializing microphone " + this.selectedDevice);
		}
		this.audioSource.Play();
	}

	// Token: 0x060006ED RID: 1773 RVA: 0x0002C544 File Offset: 0x0002A744
	public void StopMicrophone()
	{
		if (!this.micSelected)
		{
			return;
		}
		if (this.audioSource != null && this.audioSource.clip != null && this.audioSource.clip.name == "Microphone")
		{
			this.audioSource.Stop();
		}
		base.GetComponent<OVRLipSyncContext>().ResetContext();
		Microphone.End(this.selectedDevice);
	}

	// Token: 0x060006EE RID: 1774 RVA: 0x00016949 File Offset: 0x00014B49
	private float GetAveragedVolume()
	{
		return 0f;
	}

	// Token: 0x04000910 RID: 2320
	[Tooltip("Manual specification of Audio Source - by default will use any attached to the same object.")]
	public AudioSource audioSource;

	// Token: 0x04000911 RID: 2321
	[Tooltip("Enable a keypress to toggle the microphone device selection GUI.")]
	public bool enableMicSelectionGUI;

	// Token: 0x04000912 RID: 2322
	[Tooltip("Key to toggle the microphone selection GUI if enabled.")]
	public KeyCode micSelectionGUIKey = KeyCode.M;

	// Token: 0x04000913 RID: 2323
	[SerializeField]
	[Range(0f, 100f)]
	[Tooltip("Microphone input volume control.")]
	private float micInputVolume = 100f;

	// Token: 0x04000914 RID: 2324
	[SerializeField]
	[Tooltip("Requested microphone input frequency")]
	private int micFrequency = 48000;

	// Token: 0x04000915 RID: 2325
	[Tooltip("Microphone input control method. Hold To Speak and Push To Speak are driven with the Mic Activation Key.")]
	public OVRLipSyncMicInput.micActivation micControl = OVRLipSyncMicInput.micActivation.ConstantSpeak;

	// Token: 0x04000916 RID: 2326
	[Tooltip("Key used to drive Hold To Speak and Push To Speak methods of microphone input control.")]
	public KeyCode micActivationKey = KeyCode.Space;

	// Token: 0x04000917 RID: 2327
	[Tooltip("Will contain the string name of the selected microphone device - read only.")]
	public string selectedDevice;

	// Token: 0x04000918 RID: 2328
	private bool micSelected;

	// Token: 0x04000919 RID: 2329
	private int minFreq;

	// Token: 0x0400091A RID: 2330
	private int maxFreq;

	// Token: 0x0400091B RID: 2331
	private bool focused = true;

	// Token: 0x0400091C RID: 2332
	private bool initialized;

	// Token: 0x02000202 RID: 514
	public enum micActivation
	{
		// Token: 0x04000EC2 RID: 3778
		HoldToSpeak,
		// Token: 0x04000EC3 RID: 3779
		PushToSpeak,
		// Token: 0x04000EC4 RID: 3780
		ConstantSpeak
	}
}
