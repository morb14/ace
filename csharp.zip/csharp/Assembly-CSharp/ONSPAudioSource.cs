﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

// Token: 0x02000140 RID: 320
public class ONSPAudioSource : MonoBehaviour
{
	// Token: 0x0600084C RID: 2124 RVA: 0x00034388 File Offset: 0x00032588
	[RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.BeforeSceneLoad)]
	private static void OnBeforeSceneLoadRuntimeMethod()
	{
		ONSPAudioSource.OSP_SetGlobalVoiceLimit(ONSPSettings.Instance.voiceLimit);
	}

	// Token: 0x0600084D RID: 2125
	[DllImport("AudioPluginOculusSpatializer")]
	private static extern void ONSP_GetGlobalRoomReflectionValues(ref bool reflOn, ref bool reverbOn, ref float width, ref float height, ref float length);

	// Token: 0x1700002B RID: 43
	// (get) Token: 0x0600084E RID: 2126 RVA: 0x0003439A File Offset: 0x0003259A
	// (set) Token: 0x0600084F RID: 2127 RVA: 0x000343A2 File Offset: 0x000325A2
	public bool EnableSpatialization
	{
		get
		{
			return this.enableSpatialization;
		}
		set
		{
			this.enableSpatialization = value;
		}
	}

	// Token: 0x1700002C RID: 44
	// (get) Token: 0x06000850 RID: 2128 RVA: 0x000343AB File Offset: 0x000325AB
	// (set) Token: 0x06000851 RID: 2129 RVA: 0x000343B3 File Offset: 0x000325B3
	public float Gain
	{
		get
		{
			return this.gain;
		}
		set
		{
			this.gain = Mathf.Clamp(value, 0f, 24f);
		}
	}

	// Token: 0x1700002D RID: 45
	// (get) Token: 0x06000852 RID: 2130 RVA: 0x000343CB File Offset: 0x000325CB
	// (set) Token: 0x06000853 RID: 2131 RVA: 0x000343D3 File Offset: 0x000325D3
	public bool UseInvSqr
	{
		get
		{
			return this.useInvSqr;
		}
		set
		{
			this.useInvSqr = value;
		}
	}

	// Token: 0x1700002E RID: 46
	// (get) Token: 0x06000854 RID: 2132 RVA: 0x000343DC File Offset: 0x000325DC
	// (set) Token: 0x06000855 RID: 2133 RVA: 0x000343E4 File Offset: 0x000325E4
	public float Near
	{
		get
		{
			return this.near;
		}
		set
		{
			this.near = Mathf.Clamp(value, 0f, 1000000f);
		}
	}

	// Token: 0x1700002F RID: 47
	// (get) Token: 0x06000856 RID: 2134 RVA: 0x000343FC File Offset: 0x000325FC
	// (set) Token: 0x06000857 RID: 2135 RVA: 0x00034404 File Offset: 0x00032604
	public float Far
	{
		get
		{
			return this.far;
		}
		set
		{
			this.far = Mathf.Clamp(value, 0f, 1000000f);
		}
	}

	// Token: 0x17000030 RID: 48
	// (get) Token: 0x06000858 RID: 2136 RVA: 0x0003441C File Offset: 0x0003261C
	// (set) Token: 0x06000859 RID: 2137 RVA: 0x00034424 File Offset: 0x00032624
	public float VolumetricRadius
	{
		get
		{
			return this.volumetricRadius;
		}
		set
		{
			this.volumetricRadius = Mathf.Clamp(value, 0f, 1000f);
		}
	}

	// Token: 0x17000031 RID: 49
	// (get) Token: 0x0600085A RID: 2138 RVA: 0x0003443C File Offset: 0x0003263C
	// (set) Token: 0x0600085B RID: 2139 RVA: 0x00034444 File Offset: 0x00032644
	public float ReverbSend
	{
		get
		{
			return this.reverbSend;
		}
		set
		{
			this.reverbSend = Mathf.Clamp(value, -60f, 20f);
		}
	}

	// Token: 0x17000032 RID: 50
	// (get) Token: 0x0600085C RID: 2140 RVA: 0x0003445C File Offset: 0x0003265C
	// (set) Token: 0x0600085D RID: 2141 RVA: 0x00034464 File Offset: 0x00032664
	public bool EnableRfl
	{
		get
		{
			return this.enableRfl;
		}
		set
		{
			this.enableRfl = value;
		}
	}

	// Token: 0x0600085E RID: 2142 RVA: 0x00034470 File Offset: 0x00032670
	private void Awake()
	{
		AudioSource component = base.GetComponent<AudioSource>();
		this.SetParameters(ref component);
	}

	// Token: 0x0600085F RID: 2143 RVA: 0x00003297 File Offset: 0x00001497
	private void Start()
	{
	}

	// Token: 0x06000860 RID: 2144 RVA: 0x0003448C File Offset: 0x0003268C
	private void Update()
	{
		AudioSource component = base.GetComponent<AudioSource>();
		if (!Application.isPlaying || AudioListener.pause || !component.isPlaying || !component.isActiveAndEnabled)
		{
			component.spatialize = false;
			return;
		}
		this.SetParameters(ref component);
	}

	// Token: 0x06000861 RID: 2145 RVA: 0x000344D0 File Offset: 0x000326D0
	public void SetParameters(ref AudioSource source)
	{
		source.spatialize = this.enableSpatialization;
		source.SetSpatializerFloat(0, this.gain);
		if (this.useInvSqr)
		{
			source.SetSpatializerFloat(1, 1f);
		}
		else
		{
			source.SetSpatializerFloat(1, 0f);
		}
		source.SetSpatializerFloat(2, this.near);
		source.SetSpatializerFloat(3, this.far);
		source.SetSpatializerFloat(4, this.volumetricRadius);
		if (this.enableRfl)
		{
			source.SetSpatializerFloat(5, 0f);
		}
		else
		{
			source.SetSpatializerFloat(5, 1f);
		}
		source.SetSpatializerFloat(10, this.reverbSend);
	}

	// Token: 0x06000862 RID: 2146 RVA: 0x00034584 File Offset: 0x00032784
	private void OnDrawGizmos()
	{
		if (ONSPAudioSource.RoomReflectionGizmoAS == null)
		{
			ONSPAudioSource.RoomReflectionGizmoAS = this;
		}
		Color color;
		color.r = 1f;
		color.g = 0.5f;
		color.b = 0f;
		color.a = 1f;
		Gizmos.color = color;
		Gizmos.DrawWireSphere(base.transform.position, this.Near);
		color.a = 0.1f;
		Gizmos.color = color;
		Gizmos.DrawSphere(base.transform.position, this.Near);
		color.r = 1f;
		color.g = 0f;
		color.b = 0f;
		color.a = 1f;
		Gizmos.color = Color.red;
		Gizmos.DrawWireSphere(base.transform.position, this.Far);
		color.a = 0.1f;
		Gizmos.color = color;
		Gizmos.DrawSphere(base.transform.position, this.Far);
		color.r = 1f;
		color.g = 0f;
		color.b = 1f;
		color.a = 1f;
		Gizmos.color = color;
		Gizmos.DrawWireSphere(base.transform.position, this.VolumetricRadius);
		color.a = 0.1f;
		Gizmos.color = color;
		Gizmos.DrawSphere(base.transform.position, this.VolumetricRadius);
		if (ONSPAudioSource.RoomReflectionGizmoAS == this)
		{
			bool flag = false;
			bool flag2 = false;
			float x = 1f;
			float y = 1f;
			float z = 1f;
			ONSPAudioSource.ONSP_GetGlobalRoomReflectionValues(ref flag, ref flag2, ref x, ref y, ref z);
			if (Camera.main != null && flag)
			{
				if (flag2)
				{
					color = Color.white;
				}
				else
				{
					color = Color.cyan;
				}
				Gizmos.color = color;
				Gizmos.DrawWireCube(Camera.main.transform.position, new Vector3(x, y, z));
				color.a = 0.1f;
				Gizmos.color = color;
				Gizmos.DrawCube(Camera.main.transform.position, new Vector3(x, y, z));
			}
		}
	}

	// Token: 0x06000863 RID: 2147 RVA: 0x000347B0 File Offset: 0x000329B0
	private void OnDestroy()
	{
		if (ONSPAudioSource.RoomReflectionGizmoAS == this)
		{
			ONSPAudioSource.RoomReflectionGizmoAS = null;
		}
	}

	// Token: 0x06000864 RID: 2148
	[DllImport("AudioPluginOculusSpatializer")]
	private static extern int OSP_SetGlobalVoiceLimit(int VoiceLimit);

	// Token: 0x04000A59 RID: 2649
	public const string strONSPS = "AudioPluginOculusSpatializer";

	// Token: 0x04000A5A RID: 2650
	[SerializeField]
	private bool enableSpatialization = true;

	// Token: 0x04000A5B RID: 2651
	[SerializeField]
	private float gain;

	// Token: 0x04000A5C RID: 2652
	[SerializeField]
	private bool useInvSqr;

	// Token: 0x04000A5D RID: 2653
	[SerializeField]
	private float near = 0.25f;

	// Token: 0x04000A5E RID: 2654
	[SerializeField]
	private float far = 250f;

	// Token: 0x04000A5F RID: 2655
	[SerializeField]
	private float volumetricRadius;

	// Token: 0x04000A60 RID: 2656
	[SerializeField]
	private float reverbSend;

	// Token: 0x04000A61 RID: 2657
	[SerializeField]
	private bool enableRfl;

	// Token: 0x04000A62 RID: 2658
	private static ONSPAudioSource RoomReflectionGizmoAS;

	// Token: 0x0200022D RID: 557
	private enum Parameters
	{
		// Token: 0x04000F5D RID: 3933
		P_GAIN,
		// Token: 0x04000F5E RID: 3934
		P_USEINVSQR,
		// Token: 0x04000F5F RID: 3935
		P_NEAR,
		// Token: 0x04000F60 RID: 3936
		P_FAR,
		// Token: 0x04000F61 RID: 3937
		P_RADIUS,
		// Token: 0x04000F62 RID: 3938
		P_DISABLE_RFL,
		// Token: 0x04000F63 RID: 3939
		P_VSPEAKERMODE,
		// Token: 0x04000F64 RID: 3940
		P_AMBISTAT,
		// Token: 0x04000F65 RID: 3941
		P_READONLY_GLOBAL_RFL_ENABLED,
		// Token: 0x04000F66 RID: 3942
		P_READONLY_NUM_VOICES,
		// Token: 0x04000F67 RID: 3943
		P_SENDLEVEL,
		// Token: 0x04000F68 RID: 3944
		P_NUM
	}
}
