﻿using System;
using Oculus.Avatar;
using UnityEngine;

// Token: 0x020000FD RID: 253
public class OvrAvatarSkinnedMeshRenderComponent : OvrAvatarRenderComponent
{
	// Token: 0x06000661 RID: 1633 RVA: 0x0002990C File Offset: 0x00027B0C
	internal void Initialize(ovrAvatarRenderPart_SkinnedMeshRender skinnedMeshRender, Shader surface, Shader surfaceSelfOccluding, int thirdPersonLayer, int firstPersonLayer)
	{
		this.surfaceSelfOccluding = ((surfaceSelfOccluding != null) ? surfaceSelfOccluding : Shader.Find("OvrAvatar/AvatarSurfaceShaderSelfOccluding"));
		this.surface = ((surface != null) ? surface : Shader.Find("OvrAvatar/AvatarSurfaceShader"));
		this.mesh = base.CreateSkinnedMesh(skinnedMeshRender.meshAssetID, skinnedMeshRender.visibilityMask, thirdPersonLayer, firstPersonLayer);
		this.bones = this.mesh.bones;
		this.UpdateMeshMaterial(skinnedMeshRender.visibilityMask, this.mesh);
	}

	// Token: 0x06000662 RID: 1634 RVA: 0x00029990 File Offset: 0x00027B90
	public void UpdateSkinnedMeshRender(OvrAvatarComponent component, OvrAvatar avatar, IntPtr renderPart)
	{
		ovrAvatarVisibilityFlags visibilityMask = CAPI.ovrAvatarSkinnedMeshRender_GetVisibilityMask(renderPart);
		ovrAvatarTransform localTransform = CAPI.ovrAvatarSkinnedMeshRender_GetTransform(renderPart);
		base.UpdateSkinnedMesh(avatar, this.bones, localTransform, visibilityMask, renderPart);
		this.UpdateMeshMaterial(visibilityMask, this.mesh);
		bool activeSelf = base.gameObject.activeSelf;
		if (this.mesh != null && (CAPI.ovrAvatarSkinnedMeshRender_MaterialStateChanged(renderPart) || (!this.previouslyActive && activeSelf)))
		{
			ovrAvatarMaterialState matState = CAPI.ovrAvatarSkinnedMeshRender_GetMaterialState(renderPart);
			component.UpdateAvatarMaterial(this.mesh.sharedMaterial, matState);
		}
		this.previouslyActive = activeSelf;
	}

	// Token: 0x06000663 RID: 1635 RVA: 0x00029A18 File Offset: 0x00027C18
	private void UpdateMeshMaterial(ovrAvatarVisibilityFlags visibilityMask, SkinnedMeshRenderer rootMesh)
	{
		Shader shader = ((visibilityMask & ovrAvatarVisibilityFlags.SelfOccluding) != (ovrAvatarVisibilityFlags)0) ? this.surfaceSelfOccluding : this.surface;
		if (rootMesh.sharedMaterial == null || rootMesh.sharedMaterial.shader != shader)
		{
			rootMesh.sharedMaterial = base.CreateAvatarMaterial(base.gameObject.name + "_material", shader);
		}
	}

	// Token: 0x040008B6 RID: 2230
	private Shader surface;

	// Token: 0x040008B7 RID: 2231
	private Shader surfaceSelfOccluding;

	// Token: 0x040008B8 RID: 2232
	private bool previouslyActive;
}
