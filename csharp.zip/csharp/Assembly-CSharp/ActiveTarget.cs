﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000081 RID: 129
public class ActiveTarget : MonoBehaviour
{
	// Token: 0x060004A3 RID: 1187 RVA: 0x0001EBB4 File Offset: 0x0001CDB4
	private void Start()
	{
		if (base.GetComponent<Animator>())
		{
			this.animator = base.GetComponent<Animator>();
		}
		if (this.startingTransform != null)
		{
			this.sliderStartingPosition = this.startingTransform.position;
		}
		if (this.targetInfo == null)
		{
			this.targetInfo = base.GetComponentInChildren<TargetInfo>();
		}
		base.Invoke("InitiateLinks", 0.1f);
		GameEvents.current.onStagePlannerCompStart += this.OnStagePlannerCompStart;
	}

	// Token: 0x060004A4 RID: 1188 RVA: 0x0001EC39 File Offset: 0x0001CE39
	private void Update()
	{
		if (this.test)
		{
			this.Activate();
		}
		this.SliderMove();
	}

	// Token: 0x060004A5 RID: 1189 RVA: 0x00003297 File Offset: 0x00001497
	private void InitiateLinks()
	{
	}

	// Token: 0x060004A6 RID: 1190 RVA: 0x0001EC4F File Offset: 0x0001CE4F
	public void Reset()
	{
		this.animator.Play("Reset");
	}

	// Token: 0x060004A7 RID: 1191 RVA: 0x0001EC61 File Offset: 0x0001CE61
	public void ResetFinished()
	{
		this.activated = false;
	}

	// Token: 0x060004A8 RID: 1192 RVA: 0x0001EC6C File Offset: 0x0001CE6C
	public void Activate()
	{
		if (this.delay < 0f)
		{
			this.delay = 0f;
		}
		if (this.animator != null)
		{
			this.animator.Play("Activate");
		}
		if (this.delay > 0f)
		{
			base.Invoke("Activation", this.delay);
			return;
		}
		this.Activation();
	}

	// Token: 0x060004A9 RID: 1193 RVA: 0x0001ECD4 File Offset: 0x0001CED4
	private void OnStagePlannerCompStart()
	{
		if (this.lr != null)
		{
			this.lr.enabled = false;
		}
	}

	// Token: 0x060004AA RID: 1194 RVA: 0x0001ECF0 File Offset: 0x0001CEF0
	public int DetermineInstanceID()
	{
		if (this.targetInfo.instanceID != 0)
		{
			return this.targetInfo.instanceID;
		}
		return base.gameObject.GetInstanceID();
	}

	// Token: 0x060004AB RID: 1195 RVA: 0x0001ED18 File Offset: 0x0001CF18
	public void Link(TargetActivator activator, Material lineMaterial, bool manual = false)
	{
		if (this.targetInfo.instanceID == 0)
		{
			this.targetInfo.instanceID = this.targetInfo.gameObject.GetInstanceID();
		}
		this.targetActivatorList.Add(activator);
		if (this.lr == null)
		{
			this.lr = base.gameObject.AddComponent<LineRenderer>();
			this.lr.startWidth = 0.02f;
			this.lr.endWidth = 0.02f;
			this.lr.material = lineMaterial;
		}
		else
		{
			this.lr.enabled = true;
		}
		this.UpdateLineRenderer();
		if (manual)
		{
			this.UpdateActivatorID();
		}
	}

	// Token: 0x060004AC RID: 1196 RVA: 0x0001EDC1 File Offset: 0x0001CFC1
	public void Unlink(TargetActivator targetActivator = null)
	{
		this.targetActivatorList.Remove(targetActivator);
		this.UpdateActivatorID();
		this.UpdateLineRenderer();
	}

	// Token: 0x060004AD RID: 1197 RVA: 0x0001EDDC File Offset: 0x0001CFDC
	public bool Linked()
	{
		return this.targetActivatorList.Count > 0;
	}

	// Token: 0x060004AE RID: 1198 RVA: 0x0001EDF0 File Offset: 0x0001CFF0
	private void UpdateLineRenderer()
	{
		this.lr.positionCount = this.targetActivatorList.Count * 2 + 1;
		this.lr.SetPosition(0, base.transform.position);
		for (int i = 0; i < this.targetActivatorList.Count; i++)
		{
			MonoBehaviour.print(string.Concat(new object[]
			{
				"List Count ",
				this.targetActivatorList.Count,
				" Loop ",
				i
			}));
			this.lr.SetPosition(i * 2 + 1, this.targetActivatorList[i].transform.position);
			this.lr.SetPosition(i * 2 + 2, base.transform.position);
		}
	}

	// Token: 0x060004AF RID: 1199 RVA: 0x0001EEC8 File Offset: 0x0001D0C8
	private void UpdateActivatorID()
	{
		this.activatorIDs.Clear();
		foreach (TargetActivator targetActivator in this.targetActivatorList)
		{
			this.activatorIDs.Add(targetActivator.DetermineInstanceID());
		}
		this.targetInfo.linkID = this.activatorIDs.ToArray();
	}

	// Token: 0x060004B0 RID: 1200 RVA: 0x0001EF48 File Offset: 0x0001D148
	public void Activation()
	{
		switch (this.type)
		{
		case ActiveTarget.ActiveTargetType.Swinger:
			this.rbToActivate.isKinematic = false;
			return;
		case ActiveTarget.ActiveTargetType.Slider:
			this.activated = true;
			return;
		case ActiveTarget.ActiveTargetType.ClayTrap:
		{
			if (this.activated)
			{
				return;
			}
			Quaternion rotation;
			if (this.targetOrientationInFlight != null)
			{
				rotation = this.targetOrientationInFlight.rotation;
			}
			else
			{
				rotation = this.projectileTransform.rotation;
			}
			GameObject gameObject = Object.Instantiate<GameObject>(this.targetProjectile, this.projectileTransform.position, rotation);
			if (this.hasPenalty)
			{
				gameObject.GetComponent<OtherTarget>().hasPenalty = true;
			}
			Rigidbody rigidbody = gameObject.GetComponent<OtherTarget>().rigidbody;
			if (rigidbody == null)
			{
				rigidbody = gameObject.GetComponentInChildren<Rigidbody>();
			}
			rigidbody.useGravity = true;
			rigidbody.AddForce(this.projectileTransform.forward.normalized * this.multiplier, ForceMode.Impulse);
			this.activated = true;
			return;
		}
		default:
			return;
		}
	}

	// Token: 0x060004B1 RID: 1201 RVA: 0x0001F034 File Offset: 0x0001D234
	private void SliderMove()
	{
		if (this.activated && this.type == ActiveTarget.ActiveTargetType.Slider)
		{
			MonoBehaviour.print("moving");
			this.startingTransform.position = Vector3.MoveTowards(this.startingTransform.position, this.endingTransform.position, this.sliderSpeed / 100f);
		}
	}

	// Token: 0x060004B2 RID: 1202 RVA: 0x0001F090 File Offset: 0x0001D290
	private void OnDestroy()
	{
		TargetActivator[] array = Object.FindObjectsOfType<TargetActivator>();
		for (int i = 0; i < array.Length; i++)
		{
			array[i].Unlink(this);
		}
		GameEvents.current.onStagePlannerCompStart -= this.OnStagePlannerCompStart;
	}

	// Token: 0x040005D4 RID: 1492
	[Header("General")]
	[SerializeField]
	public ActiveTarget.ActiveTargetType type;

	// Token: 0x040005D5 RID: 1493
	[SerializeField]
	private float delay;

	// Token: 0x040005D6 RID: 1494
	[Header("Swinger")]
	[SerializeField]
	private Rigidbody rbToActivate;

	// Token: 0x040005D7 RID: 1495
	[Header("Slider")]
	[SerializeField]
	private Transform startingTransform;

	// Token: 0x040005D8 RID: 1496
	[SerializeField]
	private Transform endingTransform;

	// Token: 0x040005D9 RID: 1497
	[SerializeField]
	private float sliderSpeed;

	// Token: 0x040005DA RID: 1498
	[Header("ClayTrap")]
	[SerializeField]
	private GameObject targetProjectile;

	// Token: 0x040005DB RID: 1499
	[SerializeField]
	private Transform projectileTransform;

	// Token: 0x040005DC RID: 1500
	[SerializeField]
	private Transform targetOrientationInFlight;

	// Token: 0x040005DD RID: 1501
	[SerializeField]
	private float multiplier = 1f;

	// Token: 0x040005DE RID: 1502
	[Header("Comp Clay")]
	[SerializeField]
	private bool hasPenalty;

	// Token: 0x040005DF RID: 1503
	[Header("Misc")]
	private Animator animator;

	// Token: 0x040005E0 RID: 1504
	private Vector3 sliderStartingPosition;

	// Token: 0x040005E1 RID: 1505
	[Header("CustomStage")]
	[SerializeField]
	public TargetInfo targetInfo;

	// Token: 0x040005E2 RID: 1506
	public bool activated;

	// Token: 0x040005E3 RID: 1507
	public bool test;

	// Token: 0x040005E4 RID: 1508
	public bool linked;

	// Token: 0x040005E5 RID: 1509
	private List<int> activatorIDs = new List<int>();

	// Token: 0x040005E6 RID: 1510
	public List<TargetActivator> targetActivatorList = new List<TargetActivator>();

	// Token: 0x040005E7 RID: 1511
	private LineRenderer lr;

	// Token: 0x020001DF RID: 479
	public enum ActiveTargetType
	{
		// Token: 0x04000E11 RID: 3601
		Swinger,
		// Token: 0x04000E12 RID: 3602
		Slider,
		// Token: 0x04000E13 RID: 3603
		ClayTrap
	}
}
