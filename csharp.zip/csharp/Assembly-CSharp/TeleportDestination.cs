﻿using System;
using UnityEngine;

// Token: 0x0200011F RID: 287
public class TeleportDestination : MonoBehaviour
{
	// Token: 0x1700001B RID: 27
	// (get) Token: 0x06000774 RID: 1908 RVA: 0x0002E9DD File Offset: 0x0002CBDD
	// (set) Token: 0x06000775 RID: 1909 RVA: 0x0002E9E5 File Offset: 0x0002CBE5
	public bool IsValidDestination { get; private set; }

	// Token: 0x06000776 RID: 1910 RVA: 0x0002E9EE File Offset: 0x0002CBEE
	private TeleportDestination()
	{
		this._updateTeleportDestinationAction = new Action<bool, Vector3?, Quaternion?, Quaternion?>(this.UpdateTeleportDestination);
	}

	// Token: 0x06000777 RID: 1911 RVA: 0x0002EA0C File Offset: 0x0002CC0C
	public void OnEnable()
	{
		this.PositionIndicator.gameObject.SetActive(false);
		if (this.OrientationIndicator != null)
		{
			this.OrientationIndicator.gameObject.SetActive(false);
		}
		this.LocomotionTeleport.UpdateTeleportDestination += this._updateTeleportDestinationAction;
		this._eventsActive = true;
	}

	// Token: 0x06000778 RID: 1912 RVA: 0x0002EA61 File Offset: 0x0002CC61
	private void TryDisableEventHandlers()
	{
		if (!this._eventsActive)
		{
			return;
		}
		this.LocomotionTeleport.UpdateTeleportDestination -= this._updateTeleportDestinationAction;
		this._eventsActive = false;
	}

	// Token: 0x06000779 RID: 1913 RVA: 0x0002EA84 File Offset: 0x0002CC84
	public void OnDisable()
	{
		this.TryDisableEventHandlers();
	}

	// Token: 0x14000047 RID: 71
	// (add) Token: 0x0600077A RID: 1914 RVA: 0x0002EA8C File Offset: 0x0002CC8C
	// (remove) Token: 0x0600077B RID: 1915 RVA: 0x0002EAC4 File Offset: 0x0002CCC4
	public event Action<TeleportDestination> Deactivated;

	// Token: 0x0600077C RID: 1916 RVA: 0x0002EAF9 File Offset: 0x0002CCF9
	public void OnDeactivated()
	{
		if (this.Deactivated != null)
		{
			this.Deactivated(this);
			return;
		}
		this.Recycle();
	}

	// Token: 0x0600077D RID: 1917 RVA: 0x0002EB16 File Offset: 0x0002CD16
	public void Recycle()
	{
		this.LocomotionTeleport.RecycleTeleportDestination(this);
	}

	// Token: 0x0600077E RID: 1918 RVA: 0x0002EB24 File Offset: 0x0002CD24
	public virtual void UpdateTeleportDestination(bool isValidDestination, Vector3? position, Quaternion? rotation, Quaternion? landingRotation)
	{
		this.IsValidDestination = isValidDestination;
		this.LandingRotation = landingRotation.GetValueOrDefault();
		GameObject gameObject = this.PositionIndicator.gameObject;
		bool activeInHierarchy = gameObject.activeInHierarchy;
		if (position == null)
		{
			if (activeInHierarchy)
			{
				gameObject.SetActive(false);
			}
			return;
		}
		if (!activeInHierarchy)
		{
			gameObject.SetActive(true);
		}
		base.transform.position = position.GetValueOrDefault();
		if (this.OrientationIndicator == null)
		{
			if (rotation != null)
			{
				base.transform.rotation = rotation.GetValueOrDefault();
			}
			return;
		}
		GameObject gameObject2 = this.OrientationIndicator.gameObject;
		bool activeInHierarchy2 = gameObject2.activeInHierarchy;
		if (rotation == null)
		{
			if (activeInHierarchy2)
			{
				gameObject2.SetActive(false);
			}
			return;
		}
		this.OrientationIndicator.rotation = rotation.GetValueOrDefault();
		if (!activeInHierarchy2)
		{
			gameObject2.SetActive(true);
		}
	}

	// Token: 0x0400099A RID: 2458
	[Tooltip("If the target handler provides a target position, this transform will be moved to that position and it's game object enabled. A target position being provided does not mean the position is valid, only that the aim handler found something to test as a destination.")]
	public Transform PositionIndicator;

	// Token: 0x0400099B RID: 2459
	[Tooltip("This transform will be rotated to match the rotation of the aiming target. Simple teleport destinations should assign this to the object containing this component. More complex teleport destinations might assign this to a sub-object that is used to indicate the landing orientation independently from the rest of the destination indicator, such as when world space effects are required. This will typically be a child of the PositionIndicator.")]
	public Transform OrientationIndicator;

	// Token: 0x0400099C RID: 2460
	[Tooltip("After the player teleports, the character controller will have it's rotation set to this value. It is different from the OrientationIndicator transform.rotation in order to support both head-relative and forward-facing teleport modes (See TeleportOrientationHandlerThumbstick.cs).")]
	public Quaternion LandingRotation;

	// Token: 0x0400099D RID: 2461
	[NonSerialized]
	public LocomotionTeleport LocomotionTeleport;

	// Token: 0x0400099E RID: 2462
	[NonSerialized]
	public LocomotionTeleport.States TeleportState;

	// Token: 0x0400099F RID: 2463
	private readonly Action<bool, Vector3?, Quaternion?, Quaternion?> _updateTeleportDestinationAction;

	// Token: 0x040009A0 RID: 2464
	private bool _eventsActive;
}
