﻿using System;

// Token: 0x0200012D RID: 301
public abstract class TeleportTransition : TeleportSupport
{
	// Token: 0x060007C1 RID: 1985 RVA: 0x0002F9B0 File Offset: 0x0002DBB0
	protected override void AddEventHandlers()
	{
		base.LocomotionTeleport.EnterStateTeleporting += this.LocomotionTeleportOnEnterStateTeleporting;
		base.AddEventHandlers();
	}

	// Token: 0x060007C2 RID: 1986 RVA: 0x0002F9D0 File Offset: 0x0002DBD0
	protected override void RemoveEventHandlers()
	{
		base.LocomotionTeleport.EnterStateTeleporting -= this.LocomotionTeleportOnEnterStateTeleporting;
		base.RemoveEventHandlers();
	}

	// Token: 0x060007C3 RID: 1987
	protected abstract void LocomotionTeleportOnEnterStateTeleporting();
}
