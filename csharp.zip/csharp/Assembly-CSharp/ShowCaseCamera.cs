﻿using System;
using UnityEngine;

// Token: 0x02000089 RID: 137
public class ShowCaseCamera : MonoBehaviour
{
	// Token: 0x060004D5 RID: 1237 RVA: 0x000202E4 File Offset: 0x0001E4E4
	private void Start()
	{
		this.moveTo.parent = null;
		if (Object.FindObjectOfType<OVRCameraRig>())
		{
			Object.FindObjectOfType<OVRCameraRig>().gameObject.SetActive(false);
		}
		if (this.moveFrom != null)
		{
			base.transform.position = this.moveFrom.position;
		}
	}

	// Token: 0x060004D6 RID: 1238 RVA: 0x0002033D File Offset: 0x0001E53D
	private void Update()
	{
		this.Movement();
	}

	// Token: 0x060004D7 RID: 1239 RVA: 0x00020348 File Offset: 0x0001E548
	private void Movement()
	{
		if (Vector3.Distance(base.transform.position, this.moveTo.position) < 0.01f)
		{
			return;
		}
		if (this.objectToFocusOn != null)
		{
			base.transform.LookAt(this.objectToFocusOn);
		}
		if (this.moveTo != null)
		{
			base.transform.Translate((this.moveTo.position - base.transform.position).normalized * 0.0005f * this.moveSpeedMultiplier, Space.World);
		}
	}

	// Token: 0x04000628 RID: 1576
	[SerializeField]
	private Transform objectToFocusOn;

	// Token: 0x04000629 RID: 1577
	[SerializeField]
	private Transform moveFrom;

	// Token: 0x0400062A RID: 1578
	[SerializeField]
	private Transform moveTo;

	// Token: 0x0400062B RID: 1579
	[SerializeField]
	private float moveSpeedMultiplier = 1f;
}
