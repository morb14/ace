﻿using System;
using System.Collections.Generic;
using Oculus.Spatializer.Propagation;
using UnityEngine;

// Token: 0x02000142 RID: 322
public class ONSPPropagationGeometry : MonoBehaviour
{
	// Token: 0x17000033 RID: 51
	// (get) Token: 0x0600086C RID: 2156 RVA: 0x00034840 File Offset: 0x00032A40
	public static string GeometryAssetPath
	{
		get
		{
			return Application.streamingAssetsPath + "/" + ONSPPropagationGeometry.GeometryAssetDirectory;
		}
	}

	// Token: 0x17000034 RID: 52
	// (get) Token: 0x0600086D RID: 2157 RVA: 0x00034856 File Offset: 0x00032A56
	public string filePath
	{
		get
		{
			return ONSPPropagationGeometry.GeometryAssetPath + "/" + this.filePathRelative;
		}
	}

	// Token: 0x0600086E RID: 2158 RVA: 0x00034870 File Offset: 0x00032A70
	private static string GetPath(Transform current)
	{
		if (current.parent == null)
		{
			return current.gameObject.scene.name + "/" + current.name;
		}
		return ONSPPropagationGeometry.GetPath(current.parent) + "-" + current.name;
	}

	// Token: 0x0600086F RID: 2159 RVA: 0x000348CA File Offset: 0x00032ACA
	private void Awake()
	{
		this.CreatePropagationGeometry();
	}

	// Token: 0x06000870 RID: 2160 RVA: 0x000348D4 File Offset: 0x00032AD4
	private void CreatePropagationGeometry()
	{
		if (ONSPPropagation.Interface.CreateAudioGeometry(out this.geometryHandle) != ONSPPropagationGeometry.OSPSuccess)
		{
			throw new Exception("Unable to create geometry handle");
		}
		if (this.filePath != null && this.filePath.Length != 0 && this.fileEnabled && Application.isPlaying)
		{
			if (!this.ReadFile())
			{
				Debug.LogError("Failed to read file, attempting to regenerate audio geometry");
				this.UploadGeometry();
				return;
			}
		}
		else
		{
			this.UploadGeometry();
		}
	}

	// Token: 0x06000871 RID: 2161 RVA: 0x00034948 File Offset: 0x00032B48
	private void Update()
	{
		if (this.geometryHandle == IntPtr.Zero)
		{
			return;
		}
		Matrix4x4 localToWorldMatrix = base.transform.localToWorldMatrix;
		float[] matrix4x = new float[]
		{
			localToWorldMatrix[0, 0],
			localToWorldMatrix[1, 0],
			-localToWorldMatrix[2, 0],
			localToWorldMatrix[3, 0],
			localToWorldMatrix[0, 1],
			localToWorldMatrix[1, 1],
			-localToWorldMatrix[2, 1],
			localToWorldMatrix[3, 1],
			localToWorldMatrix[0, 2],
			localToWorldMatrix[1, 2],
			-localToWorldMatrix[2, 2],
			localToWorldMatrix[3, 2],
			localToWorldMatrix[0, 3],
			localToWorldMatrix[1, 3],
			-localToWorldMatrix[2, 3],
			localToWorldMatrix[3, 3]
		};
		ONSPPropagation.Interface.AudioGeometrySetTransform(this.geometryHandle, matrix4x);
	}

	// Token: 0x06000872 RID: 2162 RVA: 0x00034A5C File Offset: 0x00032C5C
	private void OnDestroy()
	{
		if (this.geometryHandle != IntPtr.Zero && ONSPPropagation.Interface.DestroyAudioGeometry(this.geometryHandle) != ONSPPropagationGeometry.OSPSuccess)
		{
			throw new Exception("Unable to destroy geometry");
		}
		this.geometryHandle = IntPtr.Zero;
	}

	// Token: 0x06000873 RID: 2163 RVA: 0x00034AA8 File Offset: 0x00032CA8
	private static void traverseMeshHierarchy(GameObject obj, ONSPPropagationMaterial[] currentMaterials, bool includeChildren, List<ONSPPropagationGeometry.MeshMaterial> meshMaterials, List<ONSPPropagationGeometry.TerrainMaterial> terrainMaterials, bool ignoreStatic, ref int ignoredMeshCount)
	{
		if (!obj.activeInHierarchy)
		{
			return;
		}
		MeshFilter[] components = obj.GetComponents<MeshFilter>();
		Terrain[] components2 = obj.GetComponents<Terrain>();
		ONSPPropagationMaterial[] components3 = obj.GetComponents<ONSPPropagationMaterial>();
		if (components3 != null && components3.Length != 0)
		{
			int num = components3.Length;
			if (currentMaterials != null)
			{
				num = Math.Max(num, currentMaterials.Length);
			}
			ONSPPropagationMaterial[] array = new ONSPPropagationMaterial[num];
			if (currentMaterials != null)
			{
				for (int i = components3.Length; i < num; i++)
				{
					array[i] = currentMaterials[i];
				}
			}
			currentMaterials = array;
			for (int j = 0; j < components3.Length; j++)
			{
				currentMaterials[j] = components3[j];
			}
		}
		foreach (MeshFilter meshFilter in components)
		{
			Mesh sharedMesh = meshFilter.sharedMesh;
			if (!(sharedMesh == null))
			{
				if (ignoreStatic && !sharedMesh.isReadable)
				{
					Debug.LogWarning("Mesh: " + meshFilter.gameObject.name + " not readable, cannot be static.", meshFilter.gameObject);
					ignoredMeshCount++;
				}
				else
				{
					meshMaterials.Add(new ONSPPropagationGeometry.MeshMaterial
					{
						meshFilter = meshFilter,
						materials = currentMaterials
					});
				}
			}
		}
		foreach (Terrain terrain in components2)
		{
			terrainMaterials.Add(new ONSPPropagationGeometry.TerrainMaterial
			{
				terrain = terrain,
				materials = currentMaterials
			});
		}
		if (includeChildren)
		{
			foreach (object obj2 in obj.transform)
			{
				Transform transform = (Transform)obj2;
				if (transform.GetComponent<ONSPPropagationGeometry>() == null)
				{
					ONSPPropagationGeometry.traverseMeshHierarchy(transform.gameObject, currentMaterials, includeChildren, meshMaterials, terrainMaterials, ignoreStatic, ref ignoredMeshCount);
				}
			}
		}
	}

	// Token: 0x06000874 RID: 2164 RVA: 0x00034C74 File Offset: 0x00032E74
	private int uploadMesh(IntPtr geometryHandle, GameObject meshObject, Matrix4x4 worldToLocal)
	{
		int num = 0;
		return this.uploadMesh(geometryHandle, meshObject, worldToLocal, false, ref num);
	}

	// Token: 0x06000875 RID: 2165 RVA: 0x00034C90 File Offset: 0x00032E90
	private int uploadMesh(IntPtr geometryHandle, GameObject meshObject, Matrix4x4 worldToLocal, bool ignoreStatic, ref int ignoredMeshCount)
	{
		List<ONSPPropagationGeometry.MeshMaterial> list = new List<ONSPPropagationGeometry.MeshMaterial>();
		List<ONSPPropagationGeometry.TerrainMaterial> list2 = new List<ONSPPropagationGeometry.TerrainMaterial>();
		ONSPPropagationGeometry.traverseMeshHierarchy(meshObject, null, this.includeChildMeshes, list, list2, ignoreStatic, ref ignoredMeshCount);
		ONSPPropagationMaterial[] array = new ONSPPropagationMaterial[]
		{
			base.gameObject.AddComponent<ONSPPropagationMaterial>()
		};
		array[0].SetPreset(ONSPPropagationMaterial.Preset.Foliage);
		int num = 0;
		uint num2 = 0U;
		int num3 = 0;
		int num4 = 0;
		foreach (ONSPPropagationGeometry.MeshMaterial meshMaterial in list)
		{
			ONSPPropagationGeometry.updateCountsForMesh(ref num, ref num2, ref num3, ref num4, meshMaterial.meshFilter.sharedMesh);
		}
		for (int i = 0; i < list2.Count; i++)
		{
			ONSPPropagationGeometry.TerrainMaterial terrainMaterial = list2[i];
			TerrainData terrainData = terrainMaterial.terrain.terrainData;
			int heightmapResolution = terrainData.heightmapResolution;
			int heightmapResolution2 = terrainData.heightmapResolution;
			int num5 = (heightmapResolution - 1) / ONSPPropagationGeometry.terrainDecimation + 1;
			int num6 = (heightmapResolution2 - 1) / ONSPPropagationGeometry.terrainDecimation + 1;
			int num7 = num5 * num6;
			int num8 = (num5 - 1) * (num6 - 1) * 6;
			num4++;
			num += num7;
			num2 += (uint)num8;
			num3 += num8 / 3;
			TreePrototype[] treePrototypes = terrainData.treePrototypes;
			terrainMaterial.treePrototypeMeshes = new Mesh[treePrototypes.Length];
			for (int j = 0; j < treePrototypes.Length; j++)
			{
				MeshFilter[] componentsInChildren = treePrototypes[j].prefab.GetComponentsInChildren<MeshFilter>();
				int num9 = int.MaxValue;
				int num10 = -1;
				for (int k = 0; k < componentsInChildren.Length; k++)
				{
					int vertexCount = componentsInChildren[k].sharedMesh.vertexCount;
					if (vertexCount < num9)
					{
						num9 = vertexCount;
						num10 = k;
					}
				}
				terrainMaterial.treePrototypeMeshes[j] = componentsInChildren[num10].sharedMesh;
			}
			foreach (TreeInstance treeInstance in terrainData.treeInstances)
			{
				ONSPPropagationGeometry.updateCountsForMesh(ref num, ref num2, ref num3, ref num4, terrainMaterial.treePrototypeMeshes[treeInstance.prototypeIndex]);
			}
			list2[i] = terrainMaterial;
		}
		List<Vector3> tempVertices = new List<Vector3>();
		List<int> tempIndices = new List<int>();
		MeshGroup[] array2 = new MeshGroup[num4];
		float[] array3 = new float[num * 3];
		int[] array4 = new int[num2];
		int num11 = 0;
		int num12 = 0;
		int num13 = 0;
		foreach (ONSPPropagationGeometry.MeshMaterial meshMaterial2 in list)
		{
			MeshFilter meshFilter = meshMaterial2.meshFilter;
			Matrix4x4 matrix = worldToLocal * meshFilter.gameObject.transform.localToWorldMatrix;
			ONSPPropagationGeometry.uploadMeshFilter(tempVertices, tempIndices, array2, array3, array4, ref num11, ref num12, ref num13, meshFilter.sharedMesh, meshMaterial2.materials, matrix);
		}
		foreach (ONSPPropagationGeometry.TerrainMaterial terrainMaterial2 in list2)
		{
			TerrainData terrainData2 = terrainMaterial2.terrain.terrainData;
			Matrix4x4 matrix4x = worldToLocal * terrainMaterial2.terrain.gameObject.transform.localToWorldMatrix;
			int heightmapResolution3 = terrainData2.heightmapResolution;
			int heightmapResolution4 = terrainData2.heightmapResolution;
			float[,] heights = terrainData2.GetHeights(0, 0, heightmapResolution3, heightmapResolution4);
			Vector3 size = terrainData2.size;
			size = new Vector3(size.x / (float)(heightmapResolution3 - 1) * (float)ONSPPropagationGeometry.terrainDecimation, size.y, size.z / (float)(heightmapResolution4 - 1) * (float)ONSPPropagationGeometry.terrainDecimation);
			int num14 = (heightmapResolution3 - 1) / ONSPPropagationGeometry.terrainDecimation + 1;
			int num15 = (heightmapResolution4 - 1) / ONSPPropagationGeometry.terrainDecimation + 1;
			int num16 = num14 * num15;
			int num17 = (num14 - 1) * (num15 - 1) * 2;
			array2[num13].faceType = FaceType.TRIANGLES;
			array2[num13].faceCount = (UIntPtr)((ulong)((long)num17));
			array2[num13].indexOffset = (UIntPtr)((ulong)((long)num12));
			if (terrainMaterial2.materials != null && terrainMaterial2.materials.Length != 0)
			{
				terrainMaterial2.materials[0].StartInternal();
				array2[num13].material = terrainMaterial2.materials[0].materialHandle;
			}
			else
			{
				array2[num13].material = IntPtr.Zero;
			}
			for (int m = 0; m < num15; m++)
			{
				for (int n = 0; n < num14; n++)
				{
					int num18 = (num11 + m * num14 + n) * 3;
					Vector3 vector = matrix4x.MultiplyPoint3x4(Vector3.Scale(size, new Vector3((float)m, heights[n * ONSPPropagationGeometry.terrainDecimation, m * ONSPPropagationGeometry.terrainDecimation], (float)n)));
					array3[num18] = vector.x;
					array3[num18 + 1] = vector.y;
					array3[num18 + 2] = vector.z;
				}
			}
			for (int num19 = 0; num19 < num15 - 1; num19++)
			{
				for (int num20 = 0; num20 < num14 - 1; num20++)
				{
					array4[num12] = num11 + num19 * num14 + num20;
					array4[num12 + 1] = num11 + (num19 + 1) * num14 + num20;
					array4[num12 + 2] = num11 + num19 * num14 + num20 + 1;
					array4[num12 + 3] = num11 + (num19 + 1) * num14 + num20;
					array4[num12 + 4] = num11 + (num19 + 1) * num14 + num20 + 1;
					array4[num12 + 5] = num11 + num19 * num14 + num20 + 1;
					num12 += 6;
				}
			}
			num11 += num16;
			num13++;
			foreach (TreeInstance treeInstance2 in terrainData2.treeInstances)
			{
				Vector3 vector2 = Vector3.Scale(treeInstance2.position, terrainData2.size);
				Matrix4x4 localToWorldMatrix = terrainMaterial2.terrain.gameObject.transform.localToWorldMatrix;
				localToWorldMatrix.SetColumn(3, localToWorldMatrix.GetColumn(3) + new Vector4(vector2.x, vector2.y, vector2.z, 0f));
				Matrix4x4 matrix2 = worldToLocal * localToWorldMatrix;
				ONSPPropagationGeometry.uploadMeshFilter(tempVertices, tempIndices, array2, array3, array4, ref num11, ref num12, ref num13, terrainMaterial2.treePrototypeMeshes[treeInstance2.prototypeIndex], array, matrix2);
			}
		}
		return ONSPPropagation.Interface.AudioGeometryUploadMeshArrays(geometryHandle, array3, num, array4, array4.Length, array2, array2.Length);
	}

	// Token: 0x06000876 RID: 2166 RVA: 0x00035324 File Offset: 0x00033524
	private static void uploadMeshFilter(List<Vector3> tempVertices, List<int> tempIndices, MeshGroup[] groups, float[] vertices, int[] indices, ref int vertexOffset, ref int indexOffset, ref int groupOffset, Mesh mesh, ONSPPropagationMaterial[] materials, Matrix4x4 matrix)
	{
		tempVertices.Clear();
		mesh.GetVertices(tempVertices);
		int count = tempVertices.Count;
		for (int i = 0; i < count; i++)
		{
			Vector3 vector = matrix.MultiplyPoint3x4(tempVertices[i]);
			int num = (vertexOffset + i) * 3;
			vertices[num] = vector.x;
			vertices[num + 1] = vector.y;
			vertices[num + 2] = vector.z;
		}
		for (int j = 0; j < mesh.subMeshCount; j++)
		{
			MeshTopology topology = mesh.GetTopology(j);
			if (topology == MeshTopology.Triangles || topology == MeshTopology.Quads)
			{
				tempIndices.Clear();
				mesh.GetIndices(tempIndices, j);
				int count2 = tempIndices.Count;
				for (int k = 0; k < count2; k++)
				{
					indices[indexOffset + k] = tempIndices[k] + vertexOffset;
				}
				if (topology == MeshTopology.Triangles)
				{
					groups[groupOffset + j].faceType = FaceType.TRIANGLES;
					groups[groupOffset + j].faceCount = (UIntPtr)((ulong)((long)(count2 / 3)));
				}
				else if (topology == MeshTopology.Quads)
				{
					groups[groupOffset + j].faceType = FaceType.QUADS;
					groups[groupOffset + j].faceCount = (UIntPtr)((ulong)((long)(count2 / 4)));
				}
				groups[groupOffset + j].indexOffset = (UIntPtr)((ulong)((long)indexOffset));
				if (materials != null && materials.Length != 0)
				{
					int num2 = j;
					if (num2 >= materials.Length)
					{
						num2 = materials.Length - 1;
					}
					materials[num2].StartInternal();
					groups[groupOffset + j].material = materials[num2].materialHandle;
				}
				else
				{
					groups[groupOffset + j].material = IntPtr.Zero;
				}
				indexOffset += count2;
			}
		}
		vertexOffset += count;
		groupOffset += mesh.subMeshCount;
	}

	// Token: 0x06000877 RID: 2167 RVA: 0x000354F4 File Offset: 0x000336F4
	private static void updateCountsForMesh(ref int totalVertexCount, ref uint totalIndexCount, ref int totalFaceCount, ref int totalMaterialCount, Mesh mesh)
	{
		totalMaterialCount += mesh.subMeshCount;
		totalVertexCount += mesh.vertexCount;
		for (int i = 0; i < mesh.subMeshCount; i++)
		{
			MeshTopology topology = mesh.GetTopology(i);
			if (topology == MeshTopology.Triangles || topology == MeshTopology.Quads)
			{
				uint indexCount = mesh.GetIndexCount(i);
				totalIndexCount += indexCount;
				if (topology == MeshTopology.Triangles)
				{
					totalFaceCount += (int)(indexCount / 3U);
				}
				else if (topology == MeshTopology.Quads)
				{
					totalFaceCount += (int)(indexCount / 4U);
				}
			}
		}
	}

	// Token: 0x06000878 RID: 2168 RVA: 0x00035564 File Offset: 0x00033764
	public void UploadGeometry()
	{
		int num = 0;
		if (this.uploadMesh(this.geometryHandle, base.gameObject, base.gameObject.transform.worldToLocalMatrix, true, ref num) != ONSPPropagationGeometry.OSPSuccess)
		{
			throw new Exception("Unable to upload audio mesh geometry");
		}
		if (num != 0)
		{
			Debug.LogError("Failed to upload meshes, " + num + " static meshes ignored. Turn on \"File Enabled\" to process static meshes offline", base.gameObject);
		}
	}

	// Token: 0x06000879 RID: 2169 RVA: 0x000355D0 File Offset: 0x000337D0
	public bool ReadFile()
	{
		if (this.filePath == null || this.filePath.Length == 0)
		{
			Debug.LogError("Invalid mesh file path");
			return false;
		}
		if (ONSPPropagation.Interface.AudioGeometryReadMeshFile(this.geometryHandle, this.filePath) != ONSPPropagationGeometry.OSPSuccess)
		{
			Debug.LogError("Error reading mesh file " + this.filePath);
			return false;
		}
		return true;
	}

	// Token: 0x0600087A RID: 2170 RVA: 0x00035634 File Offset: 0x00033834
	public bool WriteToObj()
	{
		IntPtr zero = IntPtr.Zero;
		if (ONSPPropagation.Interface.CreateAudioGeometry(out zero) != ONSPPropagationGeometry.OSPSuccess)
		{
			throw new Exception("Failed to create temp geometry handle");
		}
		if (this.uploadMesh(zero, base.gameObject, base.gameObject.transform.worldToLocalMatrix) != ONSPPropagationGeometry.OSPSuccess)
		{
			Debug.LogError("Error uploading mesh " + base.gameObject.name);
			return false;
		}
		if (ONSPPropagation.Interface.AudioGeometryWriteMeshFileObj(zero, this.filePath + ".obj") != ONSPPropagationGeometry.OSPSuccess)
		{
			Debug.LogError("Error writing .obj file " + this.filePath + ".obj");
			return false;
		}
		if (ONSPPropagation.Interface.DestroyAudioGeometry(zero) != ONSPPropagationGeometry.OSPSuccess)
		{
			throw new Exception("Failed to destroy temp geometry handle");
		}
		return true;
	}

	// Token: 0x04000A67 RID: 2663
	public static string GeometryAssetDirectory = "AudioGeometry";

	// Token: 0x04000A68 RID: 2664
	public string filePathRelative = "";

	// Token: 0x04000A69 RID: 2665
	public bool fileEnabled;

	// Token: 0x04000A6A RID: 2666
	public bool includeChildMeshes = true;

	// Token: 0x04000A6B RID: 2667
	private IntPtr geometryHandle = IntPtr.Zero;

	// Token: 0x04000A6C RID: 2668
	public static int OSPSuccess = 0;

	// Token: 0x04000A6D RID: 2669
	public const string GEOMETRY_FILE_EXTENSION = "ovramesh";

	// Token: 0x04000A6E RID: 2670
	private static int terrainDecimation = 4;

	// Token: 0x0200022E RID: 558
	private struct MeshMaterial
	{
		// Token: 0x04000F69 RID: 3945
		public MeshFilter meshFilter;

		// Token: 0x04000F6A RID: 3946
		public ONSPPropagationMaterial[] materials;
	}

	// Token: 0x0200022F RID: 559
	private struct TerrainMaterial
	{
		// Token: 0x04000F6B RID: 3947
		public Terrain terrain;

		// Token: 0x04000F6C RID: 3948
		public ONSPPropagationMaterial[] materials;

		// Token: 0x04000F6D RID: 3949
		public Mesh[] treePrototypeMeshes;
	}
}
