﻿using System;
using UnityEngine;

// Token: 0x0200002F RID: 47
public class HolsterVolume : MonoBehaviour
{
	// Token: 0x060001A7 RID: 423 RVA: 0x0000905C File Offset: 0x0000725C
	private void Start()
	{
		this.gameManager = Object.FindObjectOfType<GameManager>();
		this.controlManager = Object.FindObjectOfType<ControlManager>();
		this.meshCollider = base.GetComponent<MeshCollider>();
		this.HideVolume();
		base.Invoke("UpdateCamHeight", 0.5f);
		GameEvents.current.onHolsterDraw += this.HideVolume;
		GameEvents.current.onHolster += this.ShowVolume;
		GameEvents.current.onEnterVehicle += this.HideVolume;
		GameEvents.current.onExitVehicle += this.ShowVolume;
		GameEvents.current.onGrabStart += this.ShowVolume;
		GameEvents.current.onTeleported += this.OnTeleported;
	}

	// Token: 0x060001A8 RID: 424 RVA: 0x00009125 File Offset: 0x00007325
	public bool GunInVolume()
	{
		return this.gameManager.holsteredWeapon != null;
	}

	// Token: 0x060001A9 RID: 425 RVA: 0x00009140 File Offset: 0x00007340
	private void UpdateCamHeight()
	{
		RaycastHit raycastHit;
		if (Physics.Raycast(Camera.main.transform.position, Vector3.down, out raycastHit, float.PositiveInfinity, this.layerMask))
		{
			this.floorPos = raycastHit.point;
		}
	}

	// Token: 0x060001AA RID: 426 RVA: 0x00009187 File Offset: 0x00007387
	private void Update()
	{
		this.DynamicHeight();
		this.CheckRelease();
	}

	// Token: 0x060001AB RID: 427 RVA: 0x00009195 File Offset: 0x00007395
	private void HideVolume()
	{
		this.volumeRenderer.enabled = false;
	}

	// Token: 0x060001AC RID: 428 RVA: 0x000091A3 File Offset: 0x000073A3
	private void ShowVolume()
	{
		this.volumeRenderer.enabled = true;
	}

	// Token: 0x060001AD RID: 429 RVA: 0x000091B1 File Offset: 0x000073B1
	public bool GunCheck()
	{
		return base.transform.parent.GetComponentInChildren<WeaponController>();
	}

	// Token: 0x060001AE RID: 430 RVA: 0x000091D0 File Offset: 0x000073D0
	private void DynamicHeight()
	{
		this.camHeight = Vector3.Distance(Camera.main.transform.position, this.floorPos);
		base.transform.position = new Vector3(base.transform.position.x, Camera.main.transform.position.y - 0.7f, base.transform.position.z);
	}

	// Token: 0x060001AF RID: 431 RVA: 0x00009248 File Offset: 0x00007448
	private void OnTriggerStay(Collider other)
	{
		if (other.gameObject.GetComponent<OVRGrabbable>() && ((other.gameObject.GetComponentInChildren<WeaponController>() && !this.GunCheck()) || other.gameObject.GetComponentInChildren<ShotTimer>()))
		{
			this.grabbable = other.gameObject.GetComponent<OVRGrabbable>();
			this.ShowVolume();
			if (this.grabbable.isGrabbed)
			{
				if (!this.tempInVolume && other.GetComponentInChildren<HolsterControl>())
				{
					other.GetComponentInChildren<HolsterControl>().InVolume(true);
				}
				this.controller = this.grabbable.grabbedBy.controllerType;
				this.controlManager.controllerObject = this.grabbable.grabbedBy.transform.parent.gameObject;
				this.gunInVolume = true;
				this.tempInVolume = true;
				this.holsterObject = other.gameObject;
				this.holsterPos = this.holsterObject.transform.position;
			}
		}
	}

	// Token: 0x060001B0 RID: 432 RVA: 0x0000934C File Offset: 0x0000754C
	private void OnTriggerExit(Collider other)
	{
		if (other.gameObject.GetComponent<OVRGrabbable>() && other.gameObject.GetComponent<OVRGrabbable>().isGrabbed && this.holsterObject != null)
		{
			this.holsterObject.GetComponent<Rigidbody>().useGravity = true;
			if (this.holsterObject.GetComponentInChildren<HolsterControl>())
			{
				this.holsterObject.GetComponentInChildren<HolsterControl>().Reset();
			}
			if (other.gameObject == this.gameManager.holsteredWeapon)
			{
				this.gameManager.holsteredWeapon = null;
			}
			this.Reset();
		}
	}

	// Token: 0x060001B1 RID: 433 RVA: 0x000093E8 File Offset: 0x000075E8
	private void OnTeleported()
	{
		this.UpdateCamHeight();
	}

	// Token: 0x060001B2 RID: 434 RVA: 0x000093F0 File Offset: 0x000075F0
	private void CheckRelease()
	{
		if (this.tempInVolume && OVRInput.GetUp(OVRInput.Button.PrimaryHandTrigger, this.controller))
		{
			base.Invoke("DelayedChild", Time.deltaTime * 2f);
		}
	}

	// Token: 0x060001B3 RID: 435 RVA: 0x00009424 File Offset: 0x00007624
	private void DelayedChild()
	{
		if (this.gunInVolume)
		{
			this.controlManager.controller = this.controller;
		}
		if (this.holsterObject.GetComponentInChildren<HolsterControl>())
		{
			this.holsterObject.GetComponentInChildren<HolsterControl>().InVolume(false);
		}
		this.gameManager.holsteredWeapon = this.holsterObject;
		this.holsterObject.transform.parent = base.transform;
		this.holsterObject.transform.position = this.holsterPos;
		this.grabbable.enabled = false;
		this.holsterObject.GetComponent<Collider>().isTrigger = true;
		this.holsterObject.GetComponent<Rigidbody>().isKinematic = true;
		this.holsterObject.GetComponent<Rigidbody>().useGravity = false;
		MonoBehaviour.print("button release test success");
		base.Invoke("ReactivateGrabbable", 1f);
		this.Reset();
	}

	// Token: 0x060001B4 RID: 436 RVA: 0x00009509 File Offset: 0x00007709
	private void Reset()
	{
		this.tempInVolume = false;
		this.gunInVolume = false;
		this.controller = OVRInput.Controller.None;
	}

	// Token: 0x060001B5 RID: 437 RVA: 0x00003297 File Offset: 0x00001497
	public void ClearHolster()
	{
	}

	// Token: 0x060001B6 RID: 438 RVA: 0x00009520 File Offset: 0x00007720
	private void ReactivateGrabbable()
	{
		this.grabbable.enabled = true;
	}

	// Token: 0x060001B7 RID: 439 RVA: 0x00009530 File Offset: 0x00007730
	private void OnDestroy()
	{
		GameEvents.current.onHolsterDraw -= this.HideVolume;
		GameEvents.current.onHolster -= this.ShowVolume;
		GameEvents.current.onGrabStart -= this.ShowVolume;
		GameEvents.current.onTeleported -= this.OnTeleported;
	}

	// Token: 0x04000147 RID: 327
	private OVRGrabbable grabbable;

	// Token: 0x04000148 RID: 328
	private OVRInput.Controller controller;

	// Token: 0x04000149 RID: 329
	private GameObject holsterObject;

	// Token: 0x0400014A RID: 330
	private Vector3 holsterPos;

	// Token: 0x0400014B RID: 331
	private bool tempInVolume;

	// Token: 0x0400014C RID: 332
	private bool gunInVolume;

	// Token: 0x0400014D RID: 333
	private bool hasGun;

	// Token: 0x0400014E RID: 334
	private Vector3 floorPos;

	// Token: 0x0400014F RID: 335
	private float camHeight;

	// Token: 0x04000150 RID: 336
	private GameManager gameManager;

	// Token: 0x04000151 RID: 337
	private ControlManager controlManager;

	// Token: 0x04000152 RID: 338
	private WeaponController currentController;

	// Token: 0x04000153 RID: 339
	private MeshCollider meshCollider;

	// Token: 0x04000154 RID: 340
	[SerializeField]
	private MeshRenderer volumeRenderer;

	// Token: 0x04000155 RID: 341
	[SerializeField]
	private LayerMask layerMask;
}
