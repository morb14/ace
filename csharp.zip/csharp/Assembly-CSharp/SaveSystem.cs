﻿using System;
using System.IO;
using UnityEngine;

// Token: 0x0200004F RID: 79
public static class SaveSystem
{
	// Token: 0x0600027F RID: 639 RVA: 0x0000E778 File Offset: 0x0000C978
	public static void Init()
	{
		if (!Directory.Exists(SaveSystem.SAVE_FOLDER))
		{
			Directory.CreateDirectory(SaveSystem.SAVE_FOLDER);
		}
	}

	// Token: 0x06000280 RID: 640 RVA: 0x0000E794 File Offset: 0x0000C994
	public static void Save(string saveString, string filename)
	{
		string str = SaveSystem.DeterminePath(filename);
		if (filename == "")
		{
			File.WriteAllText(Application.persistentDataPath + "/save.vrps", saveString);
			return;
		}
		File.WriteAllText(str + "/" + filename + ".vrps", saveString);
	}

	// Token: 0x06000281 RID: 641 RVA: 0x0000E7E4 File Offset: 0x0000C9E4
	public static void Rename(string fromName, string toName)
	{
		string str = SaveSystem.DeterminePath(fromName);
		string sourceFileName = str + "/" + fromName + ".vrps";
		string destFileName = str + "/" + toName + ".vrps";
		File.Move(sourceFileName, destFileName);
	}

	// Token: 0x06000282 RID: 642 RVA: 0x0000E824 File Offset: 0x0000CA24
	public static string Load(string loadString)
	{
		string str = SaveSystem.DeterminePath(loadString);
		if (loadString == "")
		{
			return File.ReadAllText(Application.persistentDataPath + "/save.vrps");
		}
		if (!File.Exists(str + "/" + loadString + ".vrps"))
		{
			Debug.Log(str + "/" + loadString + ".vrps does not exist");
			return "FileNotFound";
		}
		return File.ReadAllText(str + "/" + loadString + ".vrps");
	}

	// Token: 0x06000283 RID: 643 RVA: 0x0000E8A4 File Offset: 0x0000CAA4
	private static string DeterminePath(string fileName)
	{
		if (fileName.Contains("_Results"))
		{
			return SaveSystem.RESULTS_FOLDER;
		}
		if (fileName.Contains("CustomStage_"))
		{
			return SaveSystem.CUSTOMSTAGES_FOLDER;
		}
		return SaveSystem.APPDATA_PATH;
	}

	// Token: 0x06000284 RID: 644 RVA: 0x0000E8D4 File Offset: 0x0000CAD4
	public static void SortFolders()
	{
		if (!Directory.Exists(SaveSystem.RESULTS_FOLDER))
		{
			Directory.CreateDirectory(SaveSystem.RESULTS_FOLDER);
			foreach (FileInfo fileInfo in new DirectoryInfo(SaveSystem.APPDATA_PATH).GetFiles("*.txt"))
			{
				if (fileInfo.ToString().Contains("_Results"))
				{
					string text = Path.GetFileName(fileInfo.ToString());
					text = Path.Combine(SaveSystem.RESULTS_FOLDER, text);
					File.Move(fileInfo.ToString(), text);
				}
			}
		}
		if (!Directory.Exists(SaveSystem.CUSTOMSTAGES_FOLDER))
		{
			Directory.CreateDirectory(SaveSystem.CUSTOMSTAGES_FOLDER);
			foreach (FileInfo fileInfo2 in new DirectoryInfo(SaveSystem.APPDATA_PATH).GetFiles("*.txt"))
			{
				if (fileInfo2.ToString().Contains("CustomStage_"))
				{
					string text2 = Path.GetFileName(fileInfo2.ToString());
					text2 = Path.Combine(SaveSystem.CUSTOMSTAGES_FOLDER, text2);
					File.Move(fileInfo2.ToString(), text2);
				}
			}
		}
		foreach (FileInfo fileInfo3 in new DirectoryInfo(SaveSystem.APPDATA_PATH).GetFiles("*.txt", SearchOption.AllDirectories))
		{
			File.Move(fileInfo3.ToString(), fileInfo3.ToString().Replace(".txt", ".vrps"));
		}
	}

	// Token: 0x06000285 RID: 645 RVA: 0x0000EA1C File Offset: 0x0000CC1C
	public static void DeleteResults()
	{
		foreach (FileInfo fileInfo in new DirectoryInfo(SaveSystem.RESULTS_FOLDER).GetFiles("*.vrps"))
		{
			if (fileInfo.ToString().Contains("_Results"))
			{
				File.Delete(fileInfo.ToString());
			}
		}
	}

	// Token: 0x06000286 RID: 646 RVA: 0x0000EA70 File Offset: 0x0000CC70
	public static void DeleteFile(string fileName)
	{
		fileName = SaveSystem.DeterminePath(fileName) + "/" + fileName + ".vrps";
		try
		{
			File.Delete(fileName);
		}
		catch
		{
			Debug.Log(fileName + " deletion failed");
		}
	}

	// Token: 0x0400028C RID: 652
	private static readonly string SAVE_FOLDER = Application.persistentDataPath + "/Saves/";

	// Token: 0x0400028D RID: 653
	private static readonly string APPDATA_PATH = Application.persistentDataPath;

	// Token: 0x0400028E RID: 654
	public static readonly string RESULTS_FOLDER = Application.persistentDataPath + "/Results";

	// Token: 0x0400028F RID: 655
	public static readonly string CUSTOMSTAGES_FOLDER = Application.persistentDataPath + "/CustomStages";
}
