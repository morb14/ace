﻿using System;
using UnityEngine;

// Token: 0x02000008 RID: 8
public class DisableMeshRenderer : MonoBehaviour
{
	// Token: 0x0600002F RID: 47 RVA: 0x00003151 File Offset: 0x00001351
	private void Start()
	{
		if (base.GetComponent<Renderer>())
		{
			base.GetComponent<Renderer>().enabled = false;
		}
	}
}
