﻿using System;
using System.Collections.Generic;
using Oculus.Avatar;
using UnityEngine;

// Token: 0x020000B9 RID: 185
public class OvrAvatarRemoteDriver : OvrAvatarDriver
{
	// Token: 0x0600061E RID: 1566 RVA: 0x000282B4 File Offset: 0x000264B4
	public void QueuePacket(int sequence, OvrAvatarPacket packet)
	{
		if (sequence > this.CurrentSequence)
		{
			this.CurrentSequence = sequence;
			this.packetQueue.Enqueue(packet);
		}
	}

	// Token: 0x0600061F RID: 1567 RVA: 0x000282D4 File Offset: 0x000264D4
	public override void UpdateTransforms(IntPtr sdkAvatar)
	{
		OvrAvatarDriver.PacketMode mode = this.Mode;
		if (mode == OvrAvatarDriver.PacketMode.SDK)
		{
			this.UpdateFromSDKPacket(sdkAvatar);
			return;
		}
		if (mode != OvrAvatarDriver.PacketMode.Unity)
		{
			return;
		}
		this.UpdateFromUnityPacket(sdkAvatar);
	}

	// Token: 0x06000620 RID: 1568 RVA: 0x00028300 File Offset: 0x00026500
	private void UpdateFromSDKPacket(IntPtr sdkAvatar)
	{
		if (this.CurrentSDKPacket == IntPtr.Zero && this.packetQueue.Count >= 1)
		{
			this.CurrentSDKPacket = this.packetQueue.Dequeue().ovrNativePacket;
		}
		if (this.CurrentSDKPacket != IntPtr.Zero)
		{
			float num = CAPI.ovrAvatarPacket_GetDurationSeconds(this.CurrentSDKPacket);
			CAPI.ovrAvatar_UpdatePoseFromPacket(sdkAvatar, this.CurrentSDKPacket, Mathf.Min(num, this.CurrentPacketTime));
			this.CurrentPacketTime += Time.deltaTime;
			if (this.CurrentPacketTime > num)
			{
				CAPI.ovrAvatarPacket_Free(this.CurrentSDKPacket);
				this.CurrentSDKPacket = IntPtr.Zero;
				this.CurrentPacketTime -= num;
				while (this.packetQueue.Count > 4)
				{
					this.packetQueue.Dequeue();
				}
			}
		}
	}

	// Token: 0x06000621 RID: 1569 RVA: 0x000283D4 File Offset: 0x000265D4
	private void UpdateFromUnityPacket(IntPtr sdkAvatar)
	{
		if (!this.isStreaming && this.packetQueue.Count > 1)
		{
			this.currentPacket = this.packetQueue.Dequeue();
			this.isStreaming = true;
		}
		if (this.isStreaming)
		{
			this.CurrentPacketTime += Time.deltaTime;
			while (this.CurrentPacketTime > this.currentPacket.Duration)
			{
				if (this.packetQueue.Count == 0)
				{
					this.CurrentPose = this.currentPacket.FinalFrame;
					this.CurrentPacketTime = 0f;
					this.currentPacket = null;
					this.isStreaming = false;
					return;
				}
				while (this.packetQueue.Count > 4)
				{
					this.packetQueue.Dequeue();
				}
				this.CurrentPacketTime -= this.currentPacket.Duration;
				this.currentPacket = this.packetQueue.Dequeue();
			}
			this.CurrentPose = this.currentPacket.GetPoseFrame(this.CurrentPacketTime);
			base.UpdateTransformsFromPose(sdkAvatar);
		}
	}

	// Token: 0x04000751 RID: 1873
	private Queue<OvrAvatarPacket> packetQueue = new Queue<OvrAvatarPacket>();

	// Token: 0x04000752 RID: 1874
	private IntPtr CurrentSDKPacket = IntPtr.Zero;

	// Token: 0x04000753 RID: 1875
	private float CurrentPacketTime;

	// Token: 0x04000754 RID: 1876
	private const int MinPacketQueue = 1;

	// Token: 0x04000755 RID: 1877
	private const int MaxPacketQueue = 4;

	// Token: 0x04000756 RID: 1878
	private int CurrentSequence = -1;

	// Token: 0x04000757 RID: 1879
	private bool isStreaming;

	// Token: 0x04000758 RID: 1880
	private OvrAvatarPacket currentPacket;
}
