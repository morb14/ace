﻿using System;
using UnityEngine;

// Token: 0x0200005F RID: 95
public class TargetSpawner : MonoBehaviour
{
	// Token: 0x0600038E RID: 910 RVA: 0x00003297 File Offset: 0x00001497
	private void Start()
	{
	}

	// Token: 0x0600038F RID: 911 RVA: 0x00003297 File Offset: 0x00001497
	private void Update()
	{
	}
}
