﻿using System;
using Oculus.Avatar;
using UnityEngine;

// Token: 0x020000FF RID: 255
public class OvrAvatarSkinnedMeshPBSV2RenderComponent : OvrAvatarRenderComponent
{
	// Token: 0x06000668 RID: 1640 RVA: 0x00029B68 File Offset: 0x00027D68
	internal void Initialize(IntPtr renderPart, ovrAvatarRenderPart_SkinnedMeshRenderPBS_V2 skinnedMeshRender, OvrAvatarMaterialManager materialManager, int thirdPersonLayer, int firstPersonLayer, bool combinedMesh, ovrAvatarAssetLevelOfDetail lod, bool assignExpressiveParams, OvrAvatar avatar, bool isControllerModel)
	{
		this.avatarMaterialManager = materialManager;
		this.isCombinedMaterial = combinedMesh;
		this.mesh = base.CreateSkinnedMesh(skinnedMeshRender.meshAssetID, skinnedMeshRender.visibilityMask, thirdPersonLayer, firstPersonLayer);
		this.EnableExpressive = assignExpressiveParams;
		Shader shader = this.EnableExpressive ? avatar.Skinshaded_Expressive_VertFrag_SingleComponent : avatar.Skinshaded_VertFrag_SingleComponent;
		Shader shader2 = this.EnableExpressive ? avatar.Skinshaded_Expressive_VertFrag_CombinedMesh : avatar.Skinshaded_VertFrag_CombinedMesh;
		Shader shader3 = this.isCombinedMaterial ? shader2 : shader;
		if (isControllerModel)
		{
			shader3 = avatar.ControllerShader;
		}
		if (this.EnableExpressive)
		{
			this.ExpressiveParameters = CAPI.ovrAvatar_GetExpressiveParameters(avatar.sdkAvatar);
			Shader eyeLens = avatar.EyeLens;
			Material[] array = new Material[]
			{
				base.CreateAvatarMaterial(base.gameObject.name + "main_material", shader3),
				base.CreateAvatarMaterial(base.gameObject.name + "eye_material", eyeLens)
			};
			if (avatar.UseTransparentRenderQueue)
			{
				this.SetMaterialTransparent(array[0]);
			}
			else
			{
				this.SetMaterialOpaque(array[0]);
			}
			array[1].renderQueue = -1;
			this.mesh.materials = array;
		}
		else
		{
			this.mesh.sharedMaterial = base.CreateAvatarMaterial(base.gameObject.name + "_material", shader3);
			if (avatar.UseTransparentRenderQueue && !isControllerModel)
			{
				this.SetMaterialTransparent(this.mesh.sharedMaterial);
			}
			else
			{
				this.SetMaterialOpaque(this.mesh.sharedMaterial);
			}
		}
		this.bones = this.mesh.bones;
		if (this.isCombinedMaterial)
		{
			this.avatarMaterialManager.SetRenderer(this.mesh);
			this.InitializeCombinedMaterial(renderPart, (int)lod);
			this.avatarMaterialManager.OnCombinedMeshReady();
		}
		this.blendShapeParams = default(ovrAvatarBlendShapeParams);
		this.blendShapeParams.blendShapeParamCount = 0U;
		this.blendShapeParams.blendShapeParams = new float[64];
		this.blendShapeCount = this.mesh.sharedMesh.blendShapeCount;
	}

	// Token: 0x06000669 RID: 1641 RVA: 0x00029D70 File Offset: 0x00027F70
	public void UpdateSkinnedMeshRender(OvrAvatarComponent component, OvrAvatar avatar, IntPtr renderPart)
	{
		ovrAvatarVisibilityFlags visibilityMask = CAPI.ovrAvatarSkinnedMeshRenderPBSV2_GetVisibilityMask(renderPart);
		ovrAvatarTransform localTransform = CAPI.ovrAvatarSkinnedMeshRenderPBSV2_GetTransform(renderPart);
		base.UpdateSkinnedMesh(avatar, this.bones, localTransform, visibilityMask, renderPart);
		bool activeSelf = base.gameObject.activeSelf;
		if (this.mesh != null && !this.previouslyActive && activeSelf && !this.isCombinedMaterial)
		{
			this.InitializeSingleComponentMaterial(renderPart, avatar.LevelOfDetail - ovrAvatarAssetLevelOfDetail.Lowest);
		}
		if (this.blendShapeCount > 0)
		{
			CAPI.ovrAvatarSkinnedMeshRender_GetBlendShapeParams(renderPart, ref this.blendShapeParams);
			uint num = 0U;
			while (num < this.blendShapeParams.blendShapeParamCount && (ulong)num < (ulong)((long)this.blendShapeCount))
			{
				float num2 = this.blendShapeParams.blendShapeParams[(int)num];
				this.mesh.SetBlendShapeWeight((int)num, num2 * 100f);
				num += 1U;
			}
		}
		this.previouslyActive = activeSelf;
	}

	// Token: 0x0600066A RID: 1642 RVA: 0x00029E3C File Offset: 0x0002803C
	private void InitializeSingleComponentMaterial(IntPtr renderPart, int lodIndex)
	{
		ovrAvatarPBSMaterialState ovrAvatarPBSMaterialState = CAPI.ovrAvatarSkinnedMeshRenderPBSV2_GetPBSMaterialState(renderPart);
		int componentType = (int)OvrAvatarMaterialManager.GetComponentType(base.gameObject.name);
		Texture2D texture2D = OvrAvatarComponent.GetLoadedTexture(ovrAvatarPBSMaterialState.albedoTextureID);
		Texture2D texture2D2 = OvrAvatarComponent.GetLoadedTexture(ovrAvatarPBSMaterialState.normalTextureID);
		Texture2D texture2D3 = OvrAvatarComponent.GetLoadedTexture(ovrAvatarPBSMaterialState.metallicnessTextureID);
		if (texture2D != null)
		{
			this.avatarMaterialManager.AddTextureIDToTextureManager(ovrAvatarPBSMaterialState.albedoTextureID, true);
		}
		else
		{
			texture2D = OvrAvatarSDKManager.Instance.GetTextureCopyManager().FallbackTextureSets[lodIndex].DiffuseRoughness;
		}
		texture2D.anisoLevel = 4;
		if (texture2D2 != null)
		{
			this.avatarMaterialManager.AddTextureIDToTextureManager(ovrAvatarPBSMaterialState.normalTextureID, true);
		}
		else
		{
			texture2D2 = OvrAvatarSDKManager.Instance.GetTextureCopyManager().FallbackTextureSets[lodIndex].Normal;
		}
		texture2D2.anisoLevel = 4;
		if (texture2D3 != null)
		{
			this.avatarMaterialManager.AddTextureIDToTextureManager(ovrAvatarPBSMaterialState.metallicnessTextureID, true);
		}
		else
		{
			texture2D3 = OvrAvatarSDKManager.Instance.GetTextureCopyManager().FallbackTextureSets[lodIndex].DiffuseRoughness;
		}
		texture2D3.anisoLevel = 16;
		this.mesh.materials[0].SetTexture(OvrAvatarMaterialManager.AVATAR_SHADER_MAINTEX, texture2D);
		this.mesh.materials[0].SetTexture(OvrAvatarMaterialManager.AVATAR_SHADER_NORMALMAP, texture2D2);
		this.mesh.materials[0].SetTexture(OvrAvatarMaterialManager.AVATAR_SHADER_ROUGHNESSMAP, texture2D3);
		this.mesh.materials[0].SetVector(OvrAvatarMaterialManager.AVATAR_SHADER_COLOR, ovrAvatarPBSMaterialState.albedoMultiplier);
		this.mesh.materials[0].SetFloat(OvrAvatarMaterialManager.AVATAR_SHADER_DIFFUSEINTENSITY, OvrAvatarMaterialManager.DiffuseIntensities[componentType]);
		this.mesh.materials[0].SetFloat(OvrAvatarMaterialManager.AVATAR_SHADER_RIMINTENSITY, OvrAvatarMaterialManager.RimIntensities[componentType]);
		this.mesh.materials[0].SetFloat(OvrAvatarMaterialManager.AVATAR_SHADER_REFLECTIONINTENSITY, OvrAvatarMaterialManager.ReflectionIntensities[componentType]);
		this.mesh.GetClosestReflectionProbes(this.avatarMaterialManager.ReflectionProbes);
		if (this.avatarMaterialManager.ReflectionProbes != null && this.avatarMaterialManager.ReflectionProbes.Count > 0)
		{
			this.mesh.materials[0].SetTexture(OvrAvatarMaterialManager.AVATAR_SHADER_CUBEMAP, this.avatarMaterialManager.ReflectionProbes[0].probe.texture);
		}
		if (this.EnableExpressive)
		{
			this.mesh.materials[0].SetVector(OvrAvatarMaterialManager.AVATAR_SHADER_IRIS_COLOR, this.ExpressiveParameters.irisColor);
			this.mesh.materials[0].SetVector(OvrAvatarMaterialManager.AVATAR_SHADER_LIP_COLOR, this.ExpressiveParameters.lipColor);
			this.mesh.materials[0].SetVector(OvrAvatarMaterialManager.AVATAR_SHADER_BROW_COLOR, this.ExpressiveParameters.browColor);
			this.mesh.materials[0].SetVector(OvrAvatarMaterialManager.AVATAR_SHADER_LASH_COLOR, this.ExpressiveParameters.lashColor);
			this.mesh.materials[0].SetVector(OvrAvatarMaterialManager.AVATAR_SHADER_SCLERA_COLOR, this.ExpressiveParameters.scleraColor);
			this.mesh.materials[0].SetVector(OvrAvatarMaterialManager.AVATAR_SHADER_GUM_COLOR, this.ExpressiveParameters.gumColor);
			this.mesh.materials[0].SetVector(OvrAvatarMaterialManager.AVATAR_SHADER_TEETH_COLOR, this.ExpressiveParameters.teethColor);
			this.mesh.materials[0].SetFloat(OvrAvatarMaterialManager.AVATAR_SHADER_LIP_SMOOTHNESS, this.ExpressiveParameters.lipSmoothness);
		}
	}

	// Token: 0x0600066B RID: 1643 RVA: 0x0002A18C File Offset: 0x0002838C
	private void InitializeCombinedMaterial(IntPtr renderPart, int lodIndex)
	{
		ovrAvatarPBSMaterialState[] array = CAPI.ovrAvatar_GetBodyPBSMaterialStates(renderPart);
		if (array.Length == 5)
		{
			this.avatarMaterialManager.CreateTextureArrays();
			OvrAvatarMaterialManager.AvatarComponentMaterialProperties[] componentMaterialProperties = this.avatarMaterialManager.LocalAvatarConfig.ComponentMaterialProperties;
			for (int i = 0; i < array.Length; i++)
			{
				componentMaterialProperties[i].TypeIndex = (ovrAvatarBodyPartType)i;
				componentMaterialProperties[i].Color = array[i].albedoMultiplier;
				componentMaterialProperties[i].DiffuseIntensity = OvrAvatarMaterialManager.DiffuseIntensities[i];
				componentMaterialProperties[i].RimIntensity = OvrAvatarMaterialManager.RimIntensities[i];
				componentMaterialProperties[i].ReflectionIntensity = OvrAvatarMaterialManager.ReflectionIntensities[i];
				Texture2D loadedTexture = OvrAvatarComponent.GetLoadedTexture(array[i].albedoTextureID);
				Texture2D loadedTexture2 = OvrAvatarComponent.GetLoadedTexture(array[i].normalTextureID);
				Texture2D loadedTexture3 = OvrAvatarComponent.GetLoadedTexture(array[i].metallicnessTextureID);
				if (loadedTexture != null)
				{
					componentMaterialProperties[i].Textures[0] = loadedTexture;
					this.avatarMaterialManager.AddTextureIDToTextureManager(array[i].albedoTextureID, false);
				}
				else
				{
					componentMaterialProperties[i].Textures[0] = OvrAvatarSDKManager.Instance.GetTextureCopyManager().FallbackTextureSets[lodIndex].DiffuseRoughness;
				}
				componentMaterialProperties[i].Textures[0].anisoLevel = 4;
				if (loadedTexture2 != null)
				{
					componentMaterialProperties[i].Textures[1] = loadedTexture2;
					this.avatarMaterialManager.AddTextureIDToTextureManager(array[i].normalTextureID, false);
				}
				else
				{
					componentMaterialProperties[i].Textures[1] = OvrAvatarSDKManager.Instance.GetTextureCopyManager().FallbackTextureSets[lodIndex].Normal;
				}
				componentMaterialProperties[i].Textures[1].anisoLevel = 4;
				if (loadedTexture3 != null)
				{
					componentMaterialProperties[i].Textures[2] = loadedTexture3;
					this.avatarMaterialManager.AddTextureIDToTextureManager(array[i].metallicnessTextureID, false);
				}
				else
				{
					componentMaterialProperties[i].Textures[2] = OvrAvatarSDKManager.Instance.GetTextureCopyManager().FallbackTextureSets[lodIndex].DiffuseRoughness;
				}
				componentMaterialProperties[i].Textures[2].anisoLevel = 16;
			}
			if (this.EnableExpressive)
			{
				this.mesh.materials[0].SetVector(OvrAvatarMaterialManager.AVATAR_SHADER_IRIS_COLOR, this.ExpressiveParameters.irisColor);
				this.mesh.materials[0].SetVector(OvrAvatarMaterialManager.AVATAR_SHADER_LIP_COLOR, this.ExpressiveParameters.lipColor);
				this.mesh.materials[0].SetVector(OvrAvatarMaterialManager.AVATAR_SHADER_BROW_COLOR, this.ExpressiveParameters.browColor);
				this.mesh.materials[0].SetVector(OvrAvatarMaterialManager.AVATAR_SHADER_LASH_COLOR, this.ExpressiveParameters.lashColor);
				this.mesh.materials[0].SetVector(OvrAvatarMaterialManager.AVATAR_SHADER_SCLERA_COLOR, this.ExpressiveParameters.scleraColor);
				this.mesh.materials[0].SetVector(OvrAvatarMaterialManager.AVATAR_SHADER_GUM_COLOR, this.ExpressiveParameters.gumColor);
				this.mesh.materials[0].SetVector(OvrAvatarMaterialManager.AVATAR_SHADER_TEETH_COLOR, this.ExpressiveParameters.teethColor);
				this.mesh.materials[0].SetFloat(OvrAvatarMaterialManager.AVATAR_SHADER_LIP_SMOOTHNESS, this.ExpressiveParameters.lipSmoothness);
			}
			this.avatarMaterialManager.ValidateTextures(array);
		}
	}

	// Token: 0x0600066C RID: 1644 RVA: 0x0002A4EC File Offset: 0x000286EC
	private void SetMaterialTransparent(Material mat)
	{
		mat.SetOverrideTag("Queue", "Transparent");
		mat.SetOverrideTag("RenderType", "Transparent");
		mat.SetInt("_SrcBlend", 5);
		mat.SetInt("_DstBlend", 10);
		mat.EnableKeyword("_ALPHATEST_ON");
		mat.EnableKeyword("_ALPHABLEND_ON");
		mat.EnableKeyword("_ALPHAPREMULTIPLY_ON");
		mat.renderQueue = 3000;
	}

	// Token: 0x0600066D RID: 1645 RVA: 0x0002A560 File Offset: 0x00028760
	private void SetMaterialOpaque(Material mat)
	{
		mat.SetOverrideTag("Queue", "Geometry");
		mat.SetOverrideTag("RenderType", "Opaque");
		mat.SetInt("_SrcBlend", 1);
		mat.SetInt("_DstBlend", 0);
		mat.DisableKeyword("_ALPHATEST_ON");
		mat.DisableKeyword("_ALPHABLEND_ON");
		mat.DisableKeyword("_ALPHAPREMULTIPLY_ON");
		mat.renderQueue = 2000;
	}

	// Token: 0x040008BA RID: 2234
	private OvrAvatarMaterialManager avatarMaterialManager;

	// Token: 0x040008BB RID: 2235
	private bool previouslyActive;

	// Token: 0x040008BC RID: 2236
	private bool isCombinedMaterial;

	// Token: 0x040008BD RID: 2237
	private ovrAvatarExpressiveParameters ExpressiveParameters;

	// Token: 0x040008BE RID: 2238
	private bool EnableExpressive;

	// Token: 0x040008BF RID: 2239
	private int blendShapeCount;

	// Token: 0x040008C0 RID: 2240
	private ovrAvatarBlendShapeParams blendShapeParams;

	// Token: 0x040008C1 RID: 2241
	private const string MAIN_MATERIAL_NAME = "main_material";

	// Token: 0x040008C2 RID: 2242
	private const string EYE_MATERIAL_NAME = "eye_material";

	// Token: 0x040008C3 RID: 2243
	private const string DEFAULT_MATERIAL_NAME = "_material";
}
