﻿using System;
using UnityEngine;

// Token: 0x02000103 RID: 259
public class LipSyncDemo_Control : MonoBehaviour
{
	// Token: 0x0600067D RID: 1661 RVA: 0x00003297 File Offset: 0x00001497
	private void Start()
	{
	}

	// Token: 0x0600067E RID: 1662 RVA: 0x0002AA90 File Offset: 0x00028C90
	private void Update()
	{
		if (Input.GetKey(this.rotateLeftKey))
		{
			this.RotateObject(this.rotationAmount, false);
			return;
		}
		if (Input.GetKey(this.rotateRightKey))
		{
			this.RotateObject(-this.rotationAmount, false);
			return;
		}
		if (Input.GetKey(this.resetRotationKey))
		{
			this.RotateObject(this.resetRotation, true);
		}
	}

	// Token: 0x0600067F RID: 1663 RVA: 0x0002AAF0 File Offset: 0x00028CF0
	private void RotateObject(float amountDegrees, bool absolute = false)
	{
		GameObject gameObject = GameObject.Find("LipSyncMorphTarget_Female");
		if (gameObject == null)
		{
			gameObject = GameObject.Find("RobotHead_TextureFlip");
		}
		if (gameObject)
		{
			if (absolute)
			{
				float d = amountDegrees - gameObject.transform.eulerAngles.y;
				gameObject.transform.Rotate(Vector3.up * d);
				return;
			}
			float num = Time.deltaTime * amountDegrees;
			if (num + gameObject.transform.eulerAngles.y >= this.resetRotation - this.rotationMax && num + gameObject.transform.eulerAngles.y <= this.resetRotation + this.rotationMax)
			{
				gameObject.transform.Rotate(Vector3.up * num);
			}
		}
	}

	// Token: 0x040008D5 RID: 2261
	[Tooltip("Key used to rotate the demo object up to 45 degrees to the left.")]
	public KeyCode rotateLeftKey = KeyCode.LeftArrow;

	// Token: 0x040008D6 RID: 2262
	[Tooltip("Key used to rotate the demo object up to 45 degrees to the right.")]
	public KeyCode rotateRightKey = KeyCode.RightArrow;

	// Token: 0x040008D7 RID: 2263
	[Tooltip("Key used to reset demo object rotation.")]
	public KeyCode resetRotationKey = KeyCode.DownArrow;

	// Token: 0x040008D8 RID: 2264
	private float resetRotation = 180f;

	// Token: 0x040008D9 RID: 2265
	private float rotationAmount = 20f;

	// Token: 0x040008DA RID: 2266
	private float rotationMax = 45f;
}
