﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000095 RID: 149
public class TutorialTrainingGun : MonoBehaviour
{
	// Token: 0x06000506 RID: 1286 RVA: 0x00020B9E File Offset: 0x0001ED9E
	private void Start()
	{
		this.text.text = "0";
	}

	// Token: 0x06000507 RID: 1287 RVA: 0x00020BB0 File Offset: 0x0001EDB0
	private void Update()
	{
		this.LaserUpdate();
		this.AngleUpdate();
	}

	// Token: 0x06000508 RID: 1288 RVA: 0x00020BC0 File Offset: 0x0001EDC0
	private void LaserUpdate()
	{
		this.laserTransform.localRotation = Quaternion.identity;
		this.laserRenderer.SetPosition(0, this.laserTransform.position);
		this.laserRenderer.SetPosition(1, this.laserTransform.position + base.transform.forward * 5f);
	}

	// Token: 0x06000509 RID: 1289 RVA: 0x00020C28 File Offset: 0x0001EE28
	private void AngleUpdate()
	{
		MonoBehaviour.print("CHECKING 90");
		this.text.color = Color.white;
		float num = TutorialTrainingGun.WrapAngle(base.transform.eulerAngles.y) - TutorialTrainingGun.WrapAngle(float.Epsilon);
		this.text.text = Mathf.Abs(num).ToString("F1") + "°";
		if (num < -90f || num > 90f)
		{
			MonoBehaviour.print("BROKE 90");
			this.text.color = Color.red;
			this.text.text = "DISQUALIFIED";
			if (Object.FindObjectOfType<StageTutorialManager>())
			{
				Object.FindObjectOfType<StageTutorialManager>().Break90();
			}
		}
	}

	// Token: 0x0600050A RID: 1290 RVA: 0x00011988 File Offset: 0x0000FB88
	private static float WrapAngle(float angle)
	{
		angle %= 360f;
		if (angle > 180f)
		{
			return angle - 360f;
		}
		return angle;
	}

	// Token: 0x04000645 RID: 1605
	[SerializeField]
	private LineRenderer laserRenderer;

	// Token: 0x04000646 RID: 1606
	[SerializeField]
	private Transform laserTransform;

	// Token: 0x04000647 RID: 1607
	[SerializeField]
	private TMP_Text text;
}
