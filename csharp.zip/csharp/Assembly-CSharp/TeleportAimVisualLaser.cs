﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200011E RID: 286
public class TeleportAimVisualLaser : TeleportSupport
{
	// Token: 0x0600076D RID: 1901 RVA: 0x0002E86F File Offset: 0x0002CA6F
	public TeleportAimVisualLaser()
	{
		this._enterAimStateAction = new Action(this.EnterAimState);
		this._exitAimStateAction = new Action(this.ExitAimState);
		this._updateAimDataAction = new Action<LocomotionTeleport.AimData>(this.UpdateAimData);
	}

	// Token: 0x0600076E RID: 1902 RVA: 0x0002E8AD File Offset: 0x0002CAAD
	private void EnterAimState()
	{
		this._lineRenderer.gameObject.SetActive(true);
	}

	// Token: 0x0600076F RID: 1903 RVA: 0x0002E8C0 File Offset: 0x0002CAC0
	private void ExitAimState()
	{
		this._lineRenderer.gameObject.SetActive(false);
	}

	// Token: 0x06000770 RID: 1904 RVA: 0x0002E8D3 File Offset: 0x0002CAD3
	private void Awake()
	{
		this.LaserPrefab.gameObject.SetActive(false);
		this._lineRenderer = Object.Instantiate<LineRenderer>(this.LaserPrefab);
	}

	// Token: 0x06000771 RID: 1905 RVA: 0x0002E8F7 File Offset: 0x0002CAF7
	protected override void AddEventHandlers()
	{
		base.AddEventHandlers();
		base.LocomotionTeleport.EnterStateAim += this._enterAimStateAction;
		base.LocomotionTeleport.ExitStateAim += this._exitAimStateAction;
		base.LocomotionTeleport.UpdateAimData += this._updateAimDataAction;
	}

	// Token: 0x06000772 RID: 1906 RVA: 0x0002E932 File Offset: 0x0002CB32
	protected override void RemoveEventHandlers()
	{
		base.LocomotionTeleport.EnterStateAim -= this._enterAimStateAction;
		base.LocomotionTeleport.ExitStateAim -= this._exitAimStateAction;
		base.LocomotionTeleport.UpdateAimData -= this._updateAimDataAction;
		base.RemoveEventHandlers();
	}

	// Token: 0x06000773 RID: 1907 RVA: 0x0002E970 File Offset: 0x0002CB70
	private void UpdateAimData(LocomotionTeleport.AimData obj)
	{
		this._lineRenderer.sharedMaterial.color = (obj.TargetValid ? Color.green : Color.red);
		List<Vector3> points = obj.Points;
		this._lineRenderer.positionCount = points.Count;
		for (int i = 0; i < points.Count; i++)
		{
			this._lineRenderer.SetPosition(i, points[i]);
		}
	}

	// Token: 0x04000993 RID: 2451
	[Tooltip("This prefab will be instantiated when the aim visual is awakened, and will be set active when the user is aiming, and deactivated when they are done aiming.")]
	public LineRenderer LaserPrefab;

	// Token: 0x04000994 RID: 2452
	private readonly Action _enterAimStateAction;

	// Token: 0x04000995 RID: 2453
	private readonly Action _exitAimStateAction;

	// Token: 0x04000996 RID: 2454
	private readonly Action<LocomotionTeleport.AimData> _updateAimDataAction;

	// Token: 0x04000997 RID: 2455
	private LineRenderer _lineRenderer;

	// Token: 0x04000998 RID: 2456
	private Vector3[] _linePoints;
}
