﻿using System;
using System.Diagnostics;
using UnityEngine;

// Token: 0x02000128 RID: 296
public abstract class TeleportSupport : MonoBehaviour
{
	// Token: 0x1700001D RID: 29
	// (get) Token: 0x060007A8 RID: 1960 RVA: 0x0002F5F2 File Offset: 0x0002D7F2
	// (set) Token: 0x060007A9 RID: 1961 RVA: 0x0002F5FA File Offset: 0x0002D7FA
	private protected LocomotionTeleport LocomotionTeleport { protected get; private set; }

	// Token: 0x060007AA RID: 1962 RVA: 0x0002F603 File Offset: 0x0002D803
	protected virtual void OnEnable()
	{
		this.LocomotionTeleport = base.GetComponent<LocomotionTeleport>();
		this.AddEventHandlers();
	}

	// Token: 0x060007AB RID: 1963 RVA: 0x0002F617 File Offset: 0x0002D817
	protected virtual void OnDisable()
	{
		this.RemoveEventHandlers();
		this.LocomotionTeleport = null;
	}

	// Token: 0x060007AC RID: 1964 RVA: 0x0002F626 File Offset: 0x0002D826
	[Conditional("DEBUG_TELEPORT_EVENT_HANDLERS")]
	private void LogEventHandler(string msg)
	{
		Debug.Log("EventHandler: " + base.GetType().Name + ": " + msg);
	}

	// Token: 0x060007AD RID: 1965 RVA: 0x0002F648 File Offset: 0x0002D848
	protected virtual void AddEventHandlers()
	{
		this._eventsActive = true;
	}

	// Token: 0x060007AE RID: 1966 RVA: 0x0002F651 File Offset: 0x0002D851
	protected virtual void RemoveEventHandlers()
	{
		this._eventsActive = false;
	}

	// Token: 0x040009C5 RID: 2501
	private bool _eventsActive;
}
