﻿using System;
using UnityEngine;

// Token: 0x02000114 RID: 276
public class BoundsLockedObject : MonoBehaviour
{
	// Token: 0x06000711 RID: 1809 RVA: 0x0002D1B8 File Offset: 0x0002B3B8
	private void Start()
	{
		this.m_enforcer.TrackingChanged += this.RefreshDisplay;
		this.m_initialOffset = base.gameObject.transform.position - this.m_playerOrigin.transform.position;
		Renderer component = base.gameObject.GetComponent<Renderer>();
		if (component != null)
		{
			this.m_bounds = new Bounds?(component.bounds);
		}
		this.RefreshDisplay();
	}

	// Token: 0x06000712 RID: 1810 RVA: 0x0002D234 File Offset: 0x0002B434
	private void RefreshDisplay()
	{
		if (OVRManager.boundary.GetConfigured())
		{
			Vector3[] geometry = OVRManager.boundary.GetGeometry(OVRBoundary.BoundaryType.PlayArea);
			float num = 10000f;
			float num2 = 10000f;
			float num3 = -10000f;
			float num4 = -10000f;
			for (int i = 0; i < geometry.Length; i++)
			{
				geometry[i] = this.m_enforcer.OrientToOriginalForward * geometry[i];
				num = Mathf.Min(num, geometry[i].x);
				num2 = Mathf.Min(num2, geometry[i].z);
				num3 = Mathf.Max(num3, geometry[i].x);
				num4 = Mathf.Max(num4, geometry[i].z);
			}
			if (this.m_bounds != null)
			{
				float num5 = this.m_bounds.Value.size.x * 0.5f;
				float num6 = this.m_bounds.Value.size.z * 0.5f;
				num += num5;
				num3 -= num5;
				num2 += num6;
				num4 -= num6;
			}
			Vector3 vector = this.m_initialOffset;
			vector.x = Mathf.Max(Mathf.Min(num3, this.m_initialOffset.x), num);
			vector.z = Mathf.Max(Mathf.Min(num4, this.m_initialOffset.z), num2);
			vector.y = base.gameObject.transform.position.y;
			if (this.m_enforcer.m_AllowRecenter)
			{
				vector = Quaternion.Inverse(this.m_enforcer.OrientToOriginalForward) * vector;
			}
			base.gameObject.transform.position = vector;
		}
	}

	// Token: 0x04000944 RID: 2372
	private Vector3 m_initialOffset;

	// Token: 0x04000945 RID: 2373
	public OVRCameraRig m_playerOrigin;

	// Token: 0x04000946 RID: 2374
	public GuardianBoundaryEnforcer m_enforcer;

	// Token: 0x04000947 RID: 2375
	private Bounds? m_bounds;
}
