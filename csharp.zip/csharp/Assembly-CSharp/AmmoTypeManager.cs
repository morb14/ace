﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000022 RID: 34
public class AmmoTypeManager : MonoBehaviour
{
	// Token: 0x0600009F RID: 159 RVA: 0x0000588C File Offset: 0x00003A8C
	private void Start()
	{
		this.defaultAmmoMaterial = this.defaultAmmo.GetComponent<Projectile>().shellMaterial;
		this.altAmmoMaterial = this.altAmmo.GetComponent<Projectile>().shellMaterial;
		this.weaponController = base.GetComponent<WeaponController>();
		if (this.defaultAmmo == null)
		{
			this.defaultAmmo = this.weaponController.GetProjectile();
			return;
		}
		if (this.defaultAmmo != this.weaponController.GetProjectile())
		{
			MonoBehaviour.print(base.gameObject + " ammo manager default ammo is different from weaponcontroller default ammo, is this on purpose?");
		}
	}

	// Token: 0x060000A0 RID: 160 RVA: 0x00003297 File Offset: 0x00001497
	private void Update()
	{
	}

	// Token: 0x060000A1 RID: 161 RVA: 0x00005920 File Offset: 0x00003B20
	public void InitiateRounds(WeaponController controller)
	{
		this.Clear();
		this.weaponController = controller;
		this.roundInChamber = this.defaultAmmo;
		if (this.weaponController.GetCurrentAmmo() > 0)
		{
			int currentAmmo = this.weaponController.GetCurrentAmmo();
			for (int i = 0; i < currentAmmo; i++)
			{
				this.tubeStack.Push(this.defaultAmmo);
			}
		}
	}

	// Token: 0x060000A2 RID: 162 RVA: 0x00005980 File Offset: 0x00003B80
	public void MagReload(int magCapacity, AmmoTypeManager.AmmoType ammoType)
	{
		this.tubeStack.Clear();
		GameObject item;
		if (ammoType == AmmoTypeManager.AmmoType.Alternative)
		{
			item = this.altAmmo;
		}
		else
		{
			item = this.defaultAmmo;
		}
		this.roundTypeInMag = item;
		for (int i = 0; i < magCapacity; i++)
		{
			this.tubeStack.Push(item);
		}
	}

	// Token: 0x060000A3 RID: 163 RVA: 0x000059CB File Offset: 0x00003BCB
	public void Chamber()
	{
		if (this.roundInChamber == null && this.roundTypeInMag != null)
		{
			this.roundInChamber = this.roundTypeInMag;
		}
	}

	// Token: 0x060000A4 RID: 164 RVA: 0x000059F5 File Offset: 0x00003BF5
	public GameObject PeekChamberRound()
	{
		return this.roundInChamber;
	}

	// Token: 0x060000A5 RID: 165 RVA: 0x000059FD File Offset: 0x00003BFD
	public AmmoTypeManager.AmmoType PeekTubeRoundType()
	{
		if (this.tubeStack.Peek() == this.defaultAmmo)
		{
			return AmmoTypeManager.AmmoType.Default;
		}
		return AmmoTypeManager.AmmoType.Alternative;
	}

	// Token: 0x060000A6 RID: 166 RVA: 0x00005A1A File Offset: 0x00003C1A
	public Material GetChamberRoundMaterial()
	{
		if (this.roundInChamber == this.defaultAmmo)
		{
			return this.defaultAmmoMaterial;
		}
		return this.altAmmoMaterial;
	}

	// Token: 0x060000A7 RID: 167 RVA: 0x00005A3C File Offset: 0x00003C3C
	public GameObject UseRoundInChamber()
	{
		GameObject result = this.roundInChamber;
		if (this.tubeStack.Count > 0)
		{
			this.roundInChamber = this.tubeStack.Pop();
			return result;
		}
		this.roundInChamber = null;
		return result;
	}

	// Token: 0x060000A8 RID: 168 RVA: 0x00005A6C File Offset: 0x00003C6C
	public void AddRound(AmmoTypeManager.AmmoType loadType = AmmoTypeManager.AmmoType.Default, bool toChamber = false, int rounds = 0)
	{
		if (rounds == 0)
		{
			return;
		}
		GameObject item;
		if (loadType == AmmoTypeManager.AmmoType.Default)
		{
			item = this.defaultAmmo;
		}
		else
		{
			item = this.altAmmo;
		}
		if (toChamber)
		{
			this.roundInChamber = item;
			return;
		}
		for (int i = 0; i < rounds; i++)
		{
			this.tubeStack.Push(item);
		}
	}

	// Token: 0x060000A9 RID: 169 RVA: 0x00005AB3 File Offset: 0x00003CB3
	public void Clear()
	{
		this.tubeStack.Clear();
		this.roundInChamber = null;
	}

	// Token: 0x040000AA RID: 170
	[SerializeField]
	public GameObject defaultAmmo;

	// Token: 0x040000AB RID: 171
	[SerializeField]
	public GameObject altAmmo;

	// Token: 0x040000AC RID: 172
	private Stack<GameObject> tubeStack = new Stack<GameObject>();

	// Token: 0x040000AD RID: 173
	private WeaponController weaponController;

	// Token: 0x040000AE RID: 174
	public Material defaultAmmoMaterial;

	// Token: 0x040000AF RID: 175
	public Material altAmmoMaterial;

	// Token: 0x040000B0 RID: 176
	private GameObject roundInChamber;

	// Token: 0x040000B1 RID: 177
	private GameObject roundTypeInMag;

	// Token: 0x020001AE RID: 430
	public enum AmmoType
	{
		// Token: 0x04000D0D RID: 3341
		Default,
		// Token: 0x04000D0E RID: 3342
		Alternative
	}
}
