﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000105 RID: 261
public class OVRLipSyncDebugConsole : MonoBehaviour
{
	// Token: 0x17000011 RID: 17
	// (get) Token: 0x06000686 RID: 1670 RVA: 0x0002AE6C File Offset: 0x0002906C
	public static OVRLipSyncDebugConsole instance
	{
		get
		{
			if (OVRLipSyncDebugConsole.s_Instance == null)
			{
				OVRLipSyncDebugConsole.s_Instance = (Object.FindObjectOfType(typeof(OVRLipSyncDebugConsole)) as OVRLipSyncDebugConsole);
				if (OVRLipSyncDebugConsole.s_Instance == null)
				{
					GameObject gameObject = new GameObject();
					gameObject.AddComponent<OVRLipSyncDebugConsole>();
					gameObject.name = "OVRLipSyncDebugConsole";
					OVRLipSyncDebugConsole.s_Instance = (Object.FindObjectOfType(typeof(OVRLipSyncDebugConsole)) as OVRLipSyncDebugConsole);
				}
			}
			return OVRLipSyncDebugConsole.s_Instance;
		}
	}

	// Token: 0x06000687 RID: 1671 RVA: 0x0002AEE0 File Offset: 0x000290E0
	private void Awake()
	{
		OVRLipSyncDebugConsole.s_Instance = this;
		this.Init();
	}

	// Token: 0x06000688 RID: 1672 RVA: 0x0002AEEE File Offset: 0x000290EE
	private void Update()
	{
		if (this.clearTimeoutOn)
		{
			this.clearTimeout -= Time.deltaTime;
			if (this.clearTimeout < 0f)
			{
				OVRLipSyncDebugConsole.Clear();
				this.clearTimeout = 0f;
				this.clearTimeoutOn = false;
			}
		}
	}

	// Token: 0x06000689 RID: 1673 RVA: 0x0002AF2E File Offset: 0x0002912E
	public void Init()
	{
		if (this.textMsg == null)
		{
			Debug.LogWarning("DebugConsole Init WARNING::UI text not set. Will not be able to display anything.");
		}
		OVRLipSyncDebugConsole.Clear();
	}

	// Token: 0x0600068A RID: 1674 RVA: 0x0002AF4D File Offset: 0x0002914D
	public static void Log(string message)
	{
		OVRLipSyncDebugConsole.instance.AddMessage(message, Color.white);
	}

	// Token: 0x0600068B RID: 1675 RVA: 0x0002AF5F File Offset: 0x0002915F
	public static void Log(string message, Color color)
	{
		OVRLipSyncDebugConsole.instance.AddMessage(message, color);
	}

	// Token: 0x0600068C RID: 1676 RVA: 0x0002AF6D File Offset: 0x0002916D
	public static void Clear()
	{
		OVRLipSyncDebugConsole.instance.ClearMessages();
	}

	// Token: 0x0600068D RID: 1677 RVA: 0x0002AF79 File Offset: 0x00029179
	public static void ClearTimeout(float timeToClear)
	{
		OVRLipSyncDebugConsole.instance.SetClearTimeout(timeToClear);
	}

	// Token: 0x0600068E RID: 1678 RVA: 0x0002AF86 File Offset: 0x00029186
	public void AddMessage(string message, Color color)
	{
		this.messages.Add(message);
		if (this.textMsg != null)
		{
			this.textMsg.color = color;
		}
		this.Display();
	}

	// Token: 0x0600068F RID: 1679 RVA: 0x0002AFB5 File Offset: 0x000291B5
	public void ClearMessages()
	{
		this.messages.Clear();
		this.Display();
	}

	// Token: 0x06000690 RID: 1680 RVA: 0x0002AFC8 File Offset: 0x000291C8
	public void SetClearTimeout(float timeout)
	{
		this.clearTimeout = timeout;
		this.clearTimeoutOn = true;
	}

	// Token: 0x06000691 RID: 1681 RVA: 0x0002AFD8 File Offset: 0x000291D8
	private void Prune()
	{
		if (this.messages.Count > this.maxMessages)
		{
			int count;
			if (this.messages.Count <= 0)
			{
				count = 0;
			}
			else
			{
				count = this.messages.Count - this.maxMessages;
			}
			this.messages.RemoveRange(0, count);
		}
	}

	// Token: 0x06000692 RID: 1682 RVA: 0x0002B02C File Offset: 0x0002922C
	private void Display()
	{
		if (this.messages.Count > this.maxMessages)
		{
			this.Prune();
		}
		if (this.textMsg != null)
		{
			this.textMsg.text = "";
			for (int i = 0; i < this.messages.Count; i++)
			{
				Text text = this.textMsg;
				text.text += (string)this.messages[i];
				Text text2 = this.textMsg;
				text2.text += "\n";
			}
		}
	}

	// Token: 0x040008DE RID: 2270
	public ArrayList messages = new ArrayList();

	// Token: 0x040008DF RID: 2271
	public int maxMessages = 15;

	// Token: 0x040008E0 RID: 2272
	public Text textMsg;

	// Token: 0x040008E1 RID: 2273
	private static OVRLipSyncDebugConsole s_Instance;

	// Token: 0x040008E2 RID: 2274
	private bool clearTimeoutOn;

	// Token: 0x040008E3 RID: 2275
	private float clearTimeout;
}
