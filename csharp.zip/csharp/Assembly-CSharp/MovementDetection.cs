﻿using System;
using UnityEngine;

// Token: 0x0200003F RID: 63
public class MovementDetection : MonoBehaviour
{
	// Token: 0x06000212 RID: 530 RVA: 0x0000B9BD File Offset: 0x00009BBD
	private void Start()
	{
		this.controlManager = Object.FindObjectOfType<ControlManager>();
	}

	// Token: 0x06000213 RID: 531 RVA: 0x0000B9CA File Offset: 0x00009BCA
	public bool CompareHeight(float height)
	{
		return Camera.main.transform.position.y > this.controlManager.controllerObject.transform.position.y + height;
	}

	// Token: 0x06000214 RID: 532 RVA: 0x0000BA01 File Offset: 0x00009C01
	public void DetectMovementReset()
	{
		this.perFrameCheck = false;
	}

	// Token: 0x06000215 RID: 533 RVA: 0x0000BA0A File Offset: 0x00009C0A
	public void DelayDetection()
	{
		this.countDownStartTime = Time.time;
		MonoBehaviour.print("SHOT TIME TIME DELAYED");
	}

	// Token: 0x06000216 RID: 534 RVA: 0x0000BA24 File Offset: 0x00009C24
	public bool DetectMovement(float countDownDuration = 0f, MovementDetection.MovementType type = MovementDetection.MovementType.Head)
	{
		if (type == MovementDetection.MovementType.Hand)
		{
			this.hand = this.controlManager.controllerObject;
		}
		Vector3 position;
		Quaternion rotation;
		float num;
		float num2;
		float num3;
		if (type == MovementDetection.MovementType.Head)
		{
			position = Camera.main.transform.position;
			rotation = Camera.main.transform.rotation;
			num = this.headMovementThreshold;
			num2 = this.headRotationThreshold;
			num3 = this.headMovementTimeInterval;
		}
		else
		{
			position = this.hand.transform.position;
			rotation = this.hand.transform.rotation;
			num = this.handMovementThreshold;
			num2 = this.handRotationThreshold;
			num3 = this.handMovementTimeInterval;
		}
		if (countDownDuration == 0f)
		{
			if (!this.perFrameCheck)
			{
				this.perFrameCheck = true;
				this.pos = position;
				this.rot = rotation;
			}
			this.countDownBegun = true;
			this.countDownStartTime = Time.time;
			if (Time.time > this.timeSinceLastMovement + num3)
			{
				if (Vector3.Distance(position, this.pos) > num * 5f)
				{
					this.timeSinceLastMovement = Time.time;
					this.countDownBegun = false;
					this.countDownStartTime = 0f;
					MonoBehaviour.print(type + " moved, per frame check");
					this.perFrameCheck = false;
					return true;
				}
				MonoBehaviour.print(type + " still, per frame check");
				return false;
			}
		}
		if (countDownDuration != 0f && !this.countDownBegun)
		{
			this.countDownBegun = true;
			this.countDownStartTime = Time.time;
		}
		if (!this.countDownBegun && countDownDuration != 0f)
		{
			return false;
		}
		if (Time.time > this.timeSinceLastMovement + num3)
		{
			this.timeSinceLastMovement = Time.time;
			if (Vector3.Distance(position, this.pos) > num || Quaternion.Angle(rotation, this.rot) > num2)
			{
				MonoBehaviour.print(type + " moved beyond threshold since last interval");
				this.countDownBegun = false;
				this.countDownStartTime = 0f;
			}
			else
			{
				MonoBehaviour.print(type + " still");
				if (Time.time >= this.countDownStartTime + countDownDuration)
				{
					MonoBehaviour.print(string.Concat(new object[]
					{
						type,
						" movement not detected for longer than ",
						countDownDuration,
						" and counting ",
						Time.time - this.countDownStartTime
					}));
					return true;
				}
			}
			this.pos = position;
			this.rot = rotation;
		}
		return false;
	}

	// Token: 0x040001D1 RID: 465
	[SerializeField]
	private float handMovementThreshold;

	// Token: 0x040001D2 RID: 466
	[SerializeField]
	private float handRotationThreshold;

	// Token: 0x040001D3 RID: 467
	[SerializeField]
	private float handMovementTimeInterval;

	// Token: 0x040001D4 RID: 468
	[SerializeField]
	private float handStillTime = 2f;

	// Token: 0x040001D5 RID: 469
	[SerializeField]
	private float headMovementThreshold;

	// Token: 0x040001D6 RID: 470
	[SerializeField]
	private float headRotationThreshold;

	// Token: 0x040001D7 RID: 471
	[SerializeField]
	private float headMovementTimeInterval;

	// Token: 0x040001D8 RID: 472
	[SerializeField]
	private float headStillTime = 2f;

	// Token: 0x040001D9 RID: 473
	[SerializeField]
	private GameObject test;

	// Token: 0x040001DA RID: 474
	private float timeSinceLastMovement;

	// Token: 0x040001DB RID: 475
	private Vector3 pos;

	// Token: 0x040001DC RID: 476
	private Quaternion rot;

	// Token: 0x040001DD RID: 477
	private GameObject hand;

	// Token: 0x040001DE RID: 478
	private bool countDownBegun;

	// Token: 0x040001DF RID: 479
	private bool perFrameCheck;

	// Token: 0x040001E0 RID: 480
	private float countDownDuration;

	// Token: 0x040001E1 RID: 481
	private float countDownStartTime;

	// Token: 0x040001E2 RID: 482
	private GameObject testSphere;

	// Token: 0x040001E3 RID: 483
	private ControlManager controlManager;

	// Token: 0x020001B6 RID: 438
	public enum MovementType
	{
		// Token: 0x04000D3F RID: 3391
		Hand,
		// Token: 0x04000D40 RID: 3392
		Head
	}
}
