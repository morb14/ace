﻿using System;
using UnityEngine;

// Token: 0x020000DC RID: 220
public struct ovrAvatarExpressiveParameters
{
	// Token: 0x06000630 RID: 1584 RVA: 0x000288A5 File Offset: 0x00026AA5
	private static bool VectorEquals(Vector4 a, Vector4 b)
	{
		return a.x == b.x && a.y == b.y && a.z == b.z && a.w == b.w;
	}

	// Token: 0x06000631 RID: 1585 RVA: 0x00028CF0 File Offset: 0x00026EF0
	public override bool Equals(object obj)
	{
		if (!(obj is ovrAvatarExpressiveParameters))
		{
			return false;
		}
		ovrAvatarExpressiveParameters ovrAvatarExpressiveParameters = (ovrAvatarExpressiveParameters)obj;
		return ovrAvatarExpressiveParameters.VectorEquals(this.irisColor, ovrAvatarExpressiveParameters.irisColor) && ovrAvatarExpressiveParameters.VectorEquals(this.scleraColor, ovrAvatarExpressiveParameters.scleraColor) && ovrAvatarExpressiveParameters.VectorEquals(this.lashColor, ovrAvatarExpressiveParameters.lashColor) && ovrAvatarExpressiveParameters.VectorEquals(this.browColor, ovrAvatarExpressiveParameters.browColor) && ovrAvatarExpressiveParameters.VectorEquals(this.lipColor, ovrAvatarExpressiveParameters.lipColor) && ovrAvatarExpressiveParameters.VectorEquals(this.teethColor, ovrAvatarExpressiveParameters.teethColor) && ovrAvatarExpressiveParameters.VectorEquals(this.gumColor, ovrAvatarExpressiveParameters.gumColor) && this.browLashIntensity == ovrAvatarExpressiveParameters.browLashIntensity && this.lipSmoothness == ovrAvatarExpressiveParameters.lipSmoothness;
	}

	// Token: 0x06000632 RID: 1586 RVA: 0x00028DC4 File Offset: 0x00026FC4
	public override int GetHashCode()
	{
		return this.irisColor.GetHashCode() ^ this.scleraColor.GetHashCode() ^ this.lashColor.GetHashCode() ^ this.browColor.GetHashCode() ^ this.lipColor.GetHashCode() ^ this.teethColor.GetHashCode() ^ this.gumColor.GetHashCode() ^ this.browLashIntensity.GetHashCode() ^ this.lipSmoothness.GetHashCode();
	}

	// Token: 0x0400082A RID: 2090
	public Vector4 irisColor;

	// Token: 0x0400082B RID: 2091
	public Vector4 scleraColor;

	// Token: 0x0400082C RID: 2092
	public Vector4 lashColor;

	// Token: 0x0400082D RID: 2093
	public Vector4 browColor;

	// Token: 0x0400082E RID: 2094
	public Vector4 lipColor;

	// Token: 0x0400082F RID: 2095
	public Vector4 teethColor;

	// Token: 0x04000830 RID: 2096
	public Vector4 gumColor;

	// Token: 0x04000831 RID: 2097
	public float browLashIntensity;

	// Token: 0x04000832 RID: 2098
	public float lipSmoothness;
}
