﻿using System;
using UnityEngine;

// Token: 0x02000042 RID: 66
public class OffIfEditor : MonoBehaviour
{
	// Token: 0x06000223 RID: 547 RVA: 0x0000C062 File Offset: 0x0000A262
	private void Start()
	{
		if (Application.platform != RuntimePlatform.Android)
		{
			base.gameObject.SetActive(false);
		}
	}
}
