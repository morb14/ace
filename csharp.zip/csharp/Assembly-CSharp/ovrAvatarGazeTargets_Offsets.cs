﻿using System;
using System.Runtime.InteropServices;

// Token: 0x020000EF RID: 239
internal struct ovrAvatarGazeTargets_Offsets
{
	// Token: 0x0400087F RID: 2175
	public static int targetCount = Marshal.OffsetOf(typeof(ovrAvatarGazeTargets), "targetCount").ToInt32();

	// Token: 0x04000880 RID: 2176
	public static long targets = (long)Marshal.SizeOf(typeof(uint));
}
