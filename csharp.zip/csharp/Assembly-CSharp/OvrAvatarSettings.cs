﻿using System;
using UnityEngine;

// Token: 0x020000FC RID: 252
public sealed class OvrAvatarSettings : ScriptableObject
{
	// Token: 0x1700000E RID: 14
	// (get) Token: 0x0600065A RID: 1626 RVA: 0x00029879 File Offset: 0x00027A79
	// (set) Token: 0x0600065B RID: 1627 RVA: 0x00029885 File Offset: 0x00027A85
	public static string AppID
	{
		get
		{
			return OvrAvatarSettings.Instance.ovrAppID;
		}
		set
		{
			OvrAvatarSettings.Instance.ovrAppID = value;
		}
	}

	// Token: 0x1700000F RID: 15
	// (get) Token: 0x0600065C RID: 1628 RVA: 0x00029892 File Offset: 0x00027A92
	// (set) Token: 0x0600065D RID: 1629 RVA: 0x0002989E File Offset: 0x00027A9E
	public static string MobileAppID
	{
		get
		{
			return OvrAvatarSettings.Instance.ovrGearAppID;
		}
		set
		{
			OvrAvatarSettings.Instance.ovrGearAppID = value;
		}
	}

	// Token: 0x17000010 RID: 16
	// (get) Token: 0x0600065E RID: 1630 RVA: 0x000298AB File Offset: 0x00027AAB
	// (set) Token: 0x0600065F RID: 1631 RVA: 0x000298E5 File Offset: 0x00027AE5
	public static OvrAvatarSettings Instance
	{
		get
		{
			if (OvrAvatarSettings.instance == null)
			{
				OvrAvatarSettings.instance = Resources.Load<OvrAvatarSettings>("OvrAvatarSettings");
				if (OvrAvatarSettings.instance == null)
				{
					OvrAvatarSettings.instance = ScriptableObject.CreateInstance<OvrAvatarSettings>();
				}
			}
			return OvrAvatarSettings.instance;
		}
		set
		{
			OvrAvatarSettings.instance = value;
		}
	}

	// Token: 0x040008B3 RID: 2227
	private static OvrAvatarSettings instance;

	// Token: 0x040008B4 RID: 2228
	[SerializeField]
	private string ovrAppID = "";

	// Token: 0x040008B5 RID: 2229
	[SerializeField]
	private string ovrGearAppID = "";
}
