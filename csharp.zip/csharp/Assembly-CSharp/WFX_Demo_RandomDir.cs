﻿using System;
using UnityEngine;

// Token: 0x02000018 RID: 24
public class WFX_Demo_RandomDir : MonoBehaviour
{
	// Token: 0x06000079 RID: 121 RVA: 0x00004D6C File Offset: 0x00002F6C
	private void Awake()
	{
		base.transform.eulerAngles = new Vector3(Random.Range(this.min.x, this.max.x), Random.Range(this.min.y, this.max.y), Random.Range(this.min.z, this.max.z));
	}

	// Token: 0x04000082 RID: 130
	public Vector3 min = new Vector3(0f, 0f, 0f);

	// Token: 0x04000083 RID: 131
	public Vector3 max = new Vector3(0f, 360f, 0f);
}
