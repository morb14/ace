﻿using System;
using UnityEngine;

// Token: 0x02000091 RID: 145
public class TutorialDestroy : MonoBehaviour
{
	// Token: 0x060004F6 RID: 1270 RVA: 0x000207CD File Offset: 0x0001E9CD
	private void Start()
	{
		GameEvents.current.onDisqualify += this.OnDisqualify;
	}

	// Token: 0x060004F7 RID: 1271 RVA: 0x000207E8 File Offset: 0x0001E9E8
	private void OnDisqualify()
	{
		GameObject[] array = this.saveToDestroy;
		for (int i = 0; i < array.Length; i++)
		{
			Object.Destroy(array[i]);
		}
	}

	// Token: 0x0400063A RID: 1594
	[SerializeField]
	private GameObject[] saveToDestroy;
}
