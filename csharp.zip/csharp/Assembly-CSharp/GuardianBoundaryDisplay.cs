﻿using System;
using UnityEngine;

// Token: 0x02000115 RID: 277
public class GuardianBoundaryDisplay : MonoBehaviour
{
	// Token: 0x06000714 RID: 1812 RVA: 0x0002D3FB File Offset: 0x0002B5FB
	private void Start()
	{
		this.m_enforcer.TrackingChanged += this.RefreshDisplay;
		this.RefreshDisplay();
	}

	// Token: 0x06000715 RID: 1813 RVA: 0x0002D41C File Offset: 0x0002B61C
	private void RefreshDisplay()
	{
		bool configured = OVRManager.boundary.GetConfigured();
		if (configured)
		{
			LineRenderer component = base.GetComponent<LineRenderer>();
			component.positionCount = 0;
			Vector3[] geometry = OVRManager.boundary.GetGeometry(this.m_boundaryType);
			component.positionCount = geometry.Length + 1;
			Vector3 position;
			for (int i = 0; i < geometry.Length; i++)
			{
				position = geometry[i];
				position.y = 0f;
				component.SetPosition(i, position);
			}
			position = geometry[0];
			position.y = 0f;
			component.SetPosition(geometry.Length, position);
		}
		if (this.m_errorDisplay)
		{
			this.m_errorDisplay.SetActive(!configured);
		}
	}

	// Token: 0x04000948 RID: 2376
	public GuardianBoundaryEnforcer m_enforcer;

	// Token: 0x04000949 RID: 2377
	public OVRBoundary.BoundaryType m_boundaryType;

	// Token: 0x0400094A RID: 2378
	public GameObject m_errorDisplay;
}
