﻿using System;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x02000031 RID: 49
public class MenuController : MonoBehaviour
{
	// Token: 0x060001C6 RID: 454 RVA: 0x0000A06C File Offset: 0x0000826C
	private void Start()
	{
		GameEvents.current.onHolsterLock += this.HolsterLockShowMenu;
		GameEvents.current.onHolster += this.ShowMenu;
		GameEvents.current.onHolsterDraw += this.HideMenu;
		this.controlManager = Object.FindObjectOfType<ControlManager>();
		this.holster = Object.FindObjectOfType<HolsterVolume>();
	}

	// Token: 0x060001C7 RID: 455 RVA: 0x0000A0D4 File Offset: 0x000082D4
	private void HolsterLockShowMenu()
	{
		if (SceneManager.GetActiveScene().buildIndex == 0)
		{
			this.ShowMenu();
		}
	}

	// Token: 0x060001C8 RID: 456 RVA: 0x0000A0F8 File Offset: 0x000082F8
	public void ShowMenu()
	{
		if (this.alwaysOn)
		{
			return;
		}
		GameObject[] array = this.menuPanels;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetActive(true);
		}
	}

	// Token: 0x060001C9 RID: 457 RVA: 0x0000A12C File Offset: 0x0000832C
	public void HideMenu()
	{
		if (this.alwaysOn)
		{
			return;
		}
		GameObject[] array = this.menuPanels;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetActive(false);
		}
	}

	// Token: 0x060001CA RID: 458 RVA: 0x0000A160 File Offset: 0x00008360
	private void OnDestroy()
	{
		GameEvents.current.onHolsterLock -= this.HolsterLockShowMenu;
		GameEvents.current.onHolster -= this.ShowMenu;
		GameEvents.current.onHolsterDraw -= this.HideMenu;
	}

	// Token: 0x04000171 RID: 369
	[SerializeField]
	private GameObject[] menuPanels;

	// Token: 0x04000172 RID: 370
	[SerializeField]
	private bool alwaysOn;

	// Token: 0x04000173 RID: 371
	[SerializeField]
	private bool showWhenHolstered;

	// Token: 0x04000174 RID: 372
	[SerializeField]
	private GameObject[] leaveActivatedOnStart;

	// Token: 0x04000175 RID: 373
	private HolsterVolume holster;

	// Token: 0x04000176 RID: 374
	private ControlManager controlManager;
}
