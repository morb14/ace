﻿using System;
using UnityEngine;

// Token: 0x0200004D RID: 77
public class RobotStatusLight : MonoBehaviour
{
	// Token: 0x06000271 RID: 625 RVA: 0x0000E3DC File Offset: 0x0000C5DC
	private void Start()
	{
		this.meshRenderer = base.GetComponent<MeshRenderer>();
	}

	// Token: 0x06000272 RID: 626 RVA: 0x0000E3EC File Offset: 0x0000C5EC
	private void Update()
	{
		if (this.robotController.robotStatus == RobotController.Status.Roam)
		{
			this.meshRenderer.material = this.roam;
			return;
		}
		if (this.robotController.robotStatus == RobotController.Status.Panic)
		{
			this.meshRenderer.material = this.panic;
			return;
		}
		if (this.robotController.robotStatus == RobotController.Status.Charge)
		{
			this.meshRenderer.material = this.charge;
			return;
		}
		if (this.robotController.robotStatus == RobotController.Status.Dead)
		{
			this.meshRenderer.material = this.dead;
		}
	}

	// Token: 0x04000284 RID: 644
	[SerializeField]
	private RobotController robotController;

	// Token: 0x04000285 RID: 645
	[SerializeField]
	private Material roam;

	// Token: 0x04000286 RID: 646
	[SerializeField]
	private Material panic;

	// Token: 0x04000287 RID: 647
	[SerializeField]
	private Material charge;

	// Token: 0x04000288 RID: 648
	[SerializeField]
	private Material dead;

	// Token: 0x04000289 RID: 649
	private MeshRenderer meshRenderer;
}
