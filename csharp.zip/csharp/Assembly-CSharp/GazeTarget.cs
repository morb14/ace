﻿using System;
using Oculus.Avatar;
using UnityEngine;

// Token: 0x020000A8 RID: 168
public class GazeTarget : MonoBehaviour
{
	// Token: 0x0600059E RID: 1438 RVA: 0x00023D9F File Offset: 0x00021F9F
	static GazeTarget()
	{
		GazeTarget.RuntimeTargetList.targets = new ovrAvatarGazeTarget[128];
		GazeTarget.RuntimeTargetList.targetCount = 1U;
	}

	// Token: 0x0600059F RID: 1439 RVA: 0x00023DC0 File Offset: 0x00021FC0
	private void Start()
	{
		this.UpdateGazeTarget();
		base.transform.hasChanged = false;
	}

	// Token: 0x060005A0 RID: 1440 RVA: 0x00023DD4 File Offset: 0x00021FD4
	private void Update()
	{
		if (base.transform.hasChanged)
		{
			base.transform.hasChanged = false;
			this.UpdateGazeTarget();
		}
	}

	// Token: 0x060005A1 RID: 1441 RVA: 0x00023DF8 File Offset: 0x00021FF8
	private void OnDestroy()
	{
		CAPI.ovrAvatar_RemoveGazeTargets(1U, new uint[]
		{
			(uint)base.transform.GetInstanceID()
		});
	}

	// Token: 0x060005A2 RID: 1442 RVA: 0x00023E24 File Offset: 0x00022024
	private void UpdateGazeTarget()
	{
		ovrAvatarGazeTarget ovrAvatarGazeTarget = this.CreateOvrGazeTarget((uint)base.transform.GetInstanceID(), base.transform.position, this.Type);
		GazeTarget.RuntimeTargetList.targets[0] = ovrAvatarGazeTarget;
		CAPI.ovrAvatar_UpdateGazeTargets(GazeTarget.RuntimeTargetList);
	}

	// Token: 0x060005A3 RID: 1443 RVA: 0x00023E70 File Offset: 0x00022070
	private ovrAvatarGazeTarget CreateOvrGazeTarget(uint targetId, Vector3 targetPosition, ovrAvatarGazeTargetType targetType)
	{
		return new ovrAvatarGazeTarget
		{
			id = targetId,
			worldPosition = new Vector3(targetPosition.x, targetPosition.y, -targetPosition.z),
			type = targetType
		};
	}

	// Token: 0x040006B1 RID: 1713
	public ovrAvatarGazeTargetType Type;

	// Token: 0x040006B2 RID: 1714
	private static ovrAvatarGazeTargets RuntimeTargetList;
}
