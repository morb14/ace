﻿using System;
using UnityEngine;

// Token: 0x02000059 RID: 89
public class StagePlannerDisabler : MonoBehaviour
{
	// Token: 0x06000370 RID: 880 RVA: 0x00017068 File Offset: 0x00015268
	private void Update()
	{
		if (OVRInput.Get(OVRInput.Button.One, this.stagePlanner.activeController))
		{
			if (this.pressTime == 1E-45f)
			{
				this.pressTime = Time.time;
			}
			if (Time.time > this.pressTime + this.timeToDisable)
			{
				this.Enable(!this.stagePlanner.enabled);
				return;
			}
		}
		else if (this.pressTime != 1E-45f)
		{
			this.pressTime = float.Epsilon;
		}
	}

	// Token: 0x06000371 RID: 881 RVA: 0x000170E1 File Offset: 0x000152E1
	public void Enable(bool enable)
	{
		if (enable)
		{
			this.stagePlanner.enabled = true;
			return;
		}
		this.stagePlanner.enabled = false;
	}

	// Token: 0x04000437 RID: 1079
	[SerializeField]
	private StagePlanner stagePlanner;

	// Token: 0x04000438 RID: 1080
	[SerializeField]
	private float timeToDisable = 2f;

	// Token: 0x04000439 RID: 1081
	private float pressTime;
}
