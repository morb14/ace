﻿using System;
using UnityEngine;

// Token: 0x02000146 RID: 326
public sealed class ONSPSettings : ScriptableObject
{
	// Token: 0x17000037 RID: 55
	// (get) Token: 0x060008A8 RID: 2216 RVA: 0x00038AAE File Offset: 0x00036CAE
	public static ONSPSettings Instance
	{
		get
		{
			if (ONSPSettings.instance == null)
			{
				ONSPSettings.instance = Resources.Load<ONSPSettings>("ONSPSettings");
				if (ONSPSettings.instance == null)
				{
					ONSPSettings.instance = ScriptableObject.CreateInstance<ONSPSettings>();
				}
			}
			return ONSPSettings.instance;
		}
	}

	// Token: 0x04000A76 RID: 2678
	[SerializeField]
	public int voiceLimit = 64;

	// Token: 0x04000A77 RID: 2679
	private static ONSPSettings instance;
}
