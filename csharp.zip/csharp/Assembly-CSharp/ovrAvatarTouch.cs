﻿using System;

// Token: 0x020000CB RID: 203
[Flags]
public enum ovrAvatarTouch
{
	// Token: 0x040007CE RID: 1998
	One = 1,
	// Token: 0x040007CF RID: 1999
	Two = 2,
	// Token: 0x040007D0 RID: 2000
	Joystick = 4,
	// Token: 0x040007D1 RID: 2001
	ThumbRest = 8,
	// Token: 0x040007D2 RID: 2002
	Index = 16,
	// Token: 0x040007D3 RID: 2003
	Pointing = 64,
	// Token: 0x040007D4 RID: 2004
	ThumbUp = 128
}
