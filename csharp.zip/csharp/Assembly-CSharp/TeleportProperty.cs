﻿using System;
using UnityEngine;

// Token: 0x0200008F RID: 143
public class TeleportProperty : MonoBehaviour
{
	// Token: 0x060004F0 RID: 1264 RVA: 0x000207A8 File Offset: 0x0001E9A8
	public void Enter()
	{
		if (this.movingVehicle != null)
		{
			this.movingVehicle.Pair();
			GameEvents.current.EnterVehicle();
		}
	}

	// Token: 0x060004F1 RID: 1265 RVA: 0x00003297 File Offset: 0x00001497
	private void OnDestroy()
	{
	}

	// Token: 0x04000638 RID: 1592
	public bool dormant;

	// Token: 0x04000639 RID: 1593
	[SerializeField]
	private MovingVehicle movingVehicle;
}
