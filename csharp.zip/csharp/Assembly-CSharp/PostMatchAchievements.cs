﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x0200007C RID: 124
public class PostMatchAchievements : MonoBehaviour
{
	// Token: 0x06000476 RID: 1142 RVA: 0x0001DF20 File Offset: 0x0001C120
	private void Awake()
	{
		this.animator = base.GetComponent<Animator>();
		GameEvents.current.onBreakRecordPlayed += this.EventUpdateShieldPlayed;
		GameEvents.current.onBreakRecordVirginiaCount += this.EventUpdateShieldVirginiaCount;
		GameEvents.current.onBreakRecordBronze += this.EventUpdateShieldBronze;
		GameEvents.current.onBreakRecordSilver += this.EventUpdateShieldSilver;
		GameEvents.current.onBreakRecordGold += this.EventUpdateShieldGold;
	}

	// Token: 0x06000477 RID: 1143 RVA: 0x0001DFA8 File Offset: 0x0001C1A8
	public void InitiateShields(SaveManager.ResultList resultList, float bronzeHF = 0f, float silverHF = 0f, float goldHF = 0f)
	{
		if (resultList == null)
		{
			this.firstShieldAnimated.gameObject.SetActive(false);
			this.secondShieldAnimated.gameObject.SetActive(false);
			this.thirdShieldAnimated.gameObject.SetActive(false);
			return;
		}
		if (resultList.played)
		{
			this.firstShield.material = this.gold;
			this.firstShield.gameObject.SetActive(true);
		}
		if (resultList.virginiaCount)
		{
			this.secondShield.material = this.gold;
			this.secondShield.gameObject.SetActive(true);
		}
		if (resultList.bronzeShield)
		{
			this.thirdShield.material = this.bronze;
			this.thirdShield.gameObject.SetActive(true);
		}
		if (resultList.silverShield)
		{
			this.thirdShield.material = this.silver;
			this.thirdShield.gameObject.SetActive(true);
		}
		if (resultList.goldShield)
		{
			this.thirdShield.material = this.gold;
			this.thirdShield.gameObject.SetActive(true);
		}
		this.bronzeInfoText.text = bronzeHF.ToString();
		this.silverInfoText.text = silverHF.ToString();
		this.goldInfoText.text = goldHF.ToString();
	}

	// Token: 0x06000478 RID: 1144 RVA: 0x0001E0F4 File Offset: 0x0001C2F4
	public void AnimateResults()
	{
		base.Invoke("AnimateAchievements", 0.2f);
	}

	// Token: 0x06000479 RID: 1145 RVA: 0x0001E106 File Offset: 0x0001C306
	private void EventUpdateShieldPlayed()
	{
		MonoBehaviour.print("EVENT PLAYED ONCE");
		this.playedUpdate = true;
	}

	// Token: 0x0600047A RID: 1146 RVA: 0x0001E119 File Offset: 0x0001C319
	private void EventUpdateShieldVirginiaCount()
	{
		MonoBehaviour.print("EVENT VIRGINIA MET");
		this.virginiaCountUpdate = true;
	}

	// Token: 0x0600047B RID: 1147 RVA: 0x0001E12C File Offset: 0x0001C32C
	private void EventUpdateShieldBronze()
	{
		MonoBehaviour.print("EVENT BRONZE MET");
		this.bronzeUpdate = true;
	}

	// Token: 0x0600047C RID: 1148 RVA: 0x0001E13F File Offset: 0x0001C33F
	private void EventUpdateShieldSilver()
	{
		MonoBehaviour.print("EVENT SILVER MET");
		this.silverUpdate = true;
	}

	// Token: 0x0600047D RID: 1149 RVA: 0x0001E152 File Offset: 0x0001C352
	private void EventUpdateShieldGold()
	{
		MonoBehaviour.print("EVENT GOLD MET");
		this.goldUpdate = true;
	}

	// Token: 0x0600047E RID: 1150 RVA: 0x0001E168 File Offset: 0x0001C368
	private void AnimateAchievements()
	{
		if (this.playedUpdate)
		{
			this.firstShieldAnimated.gameObject.SetActive(true);
			this.animator.SetTrigger("ShieldOne");
			MonoBehaviour.print("Animation shield one");
		}
		if (this.virginiaCountUpdate)
		{
			this.secondShieldAnimated.gameObject.SetActive(true);
			this.animator.SetTrigger("ShieldTwo");
			MonoBehaviour.print("Animation shield two");
		}
		if (this.bronzeUpdate || this.silverUpdate || this.goldUpdate)
		{
			this.thirdShieldAnimated.gameObject.SetActive(true);
			if (this.bronzeUpdate && !this.silverUpdate)
			{
				this.thirdShieldAnimated.material = this.bronze;
				MonoBehaviour.print("third shield material changed to bronze");
			}
			if (this.silverUpdate && !this.goldUpdate)
			{
				this.thirdShieldAnimated.material = this.silver;
				MonoBehaviour.print("third shield material changed to silver");
			}
			if (this.goldUpdate)
			{
				this.thirdShieldAnimated.material = this.gold;
				MonoBehaviour.print("third shield material changed to gold");
			}
			this.animator.SetTrigger("ShieldThree");
			MonoBehaviour.print("Animation shield three");
		}
	}

	// Token: 0x0600047F RID: 1151 RVA: 0x0001E29A File Offset: 0x0001C49A
	public void FirstShieldAnimationEnd()
	{
		this.firstShield.gameObject.SetActive(true);
	}

	// Token: 0x06000480 RID: 1152 RVA: 0x0001E2AD File Offset: 0x0001C4AD
	public void SecondShieldTwoAnimationEnd()
	{
		this.secondShield.gameObject.SetActive(true);
	}

	// Token: 0x06000481 RID: 1153 RVA: 0x0001E2C0 File Offset: 0x0001C4C0
	public void ThirdShieldAnimationEnd()
	{
		if (this.bronzeUpdate)
		{
			this.thirdShield.gameObject.SetActive(true);
			this.thirdShield.material = this.bronze;
		}
		if (this.silverUpdate)
		{
			this.thirdShield.gameObject.SetActive(true);
			this.thirdShield.material = this.silver;
		}
		if (this.goldUpdate)
		{
			this.thirdShield.gameObject.SetActive(true);
			this.thirdShield.material = this.gold;
		}
	}

	// Token: 0x06000482 RID: 1154 RVA: 0x0001E34C File Offset: 0x0001C54C
	private void OnDestroy()
	{
		GameEvents.current.onBreakRecordPlayed -= this.EventUpdateShieldPlayed;
		GameEvents.current.onBreakRecordVirginiaCount -= this.EventUpdateShieldVirginiaCount;
		GameEvents.current.onBreakRecordBronze -= this.EventUpdateShieldBronze;
		GameEvents.current.onBreakRecordSilver -= this.EventUpdateShieldSilver;
		GameEvents.current.onBreakRecordGold -= this.EventUpdateShieldGold;
	}

	// Token: 0x040005B5 RID: 1461
	[SerializeField]
	private Material bronze;

	// Token: 0x040005B6 RID: 1462
	[SerializeField]
	private Material silver;

	// Token: 0x040005B7 RID: 1463
	[SerializeField]
	private Material gold;

	// Token: 0x040005B8 RID: 1464
	[SerializeField]
	private MeshRenderer firstShield;

	// Token: 0x040005B9 RID: 1465
	[SerializeField]
	private MeshRenderer secondShield;

	// Token: 0x040005BA RID: 1466
	[SerializeField]
	private MeshRenderer thirdShield;

	// Token: 0x040005BB RID: 1467
	[SerializeField]
	private MeshRenderer firstShieldAnimated;

	// Token: 0x040005BC RID: 1468
	[SerializeField]
	private MeshRenderer secondShieldAnimated;

	// Token: 0x040005BD RID: 1469
	[SerializeField]
	private MeshRenderer thirdShieldAnimated;

	// Token: 0x040005BE RID: 1470
	[SerializeField]
	private TMP_Text bronzeInfoText;

	// Token: 0x040005BF RID: 1471
	[SerializeField]
	private TMP_Text silverInfoText;

	// Token: 0x040005C0 RID: 1472
	[SerializeField]
	private TMP_Text goldInfoText;

	// Token: 0x040005C1 RID: 1473
	private Material originalShieldMaterial;

	// Token: 0x040005C2 RID: 1474
	private Animator animator;

	// Token: 0x040005C3 RID: 1475
	private bool playedUpdate;

	// Token: 0x040005C4 RID: 1476
	private bool virginiaCountUpdate;

	// Token: 0x040005C5 RID: 1477
	private bool bronzeUpdate;

	// Token: 0x040005C6 RID: 1478
	private bool silverUpdate;

	// Token: 0x040005C7 RID: 1479
	private bool goldUpdate;
}
