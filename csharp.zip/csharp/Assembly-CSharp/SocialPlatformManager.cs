﻿using System;
using System.Collections.Generic;
using AOT;
using Oculus.Avatar;
using Oculus.Platform;
using Oculus.Platform.Models;
using UnityEngine;

// Token: 0x020000A6 RID: 166
public class SocialPlatformManager : MonoBehaviour
{
	// Token: 0x0600057B RID: 1403 RVA: 0x00022D4C File Offset: 0x00020F4C
	public virtual void Update()
	{
		this.p2pManager.GetRemotePackets();
		foreach (KeyValuePair<ulong, RemotePlayer> keyValuePair in this.remoteUsers)
		{
			if (keyValuePair.Value.voipSource == null && keyValuePair.Value.RemoteAvatar.MouthAnchor != null)
			{
				keyValuePair.Value.voipSource = keyValuePair.Value.RemoteAvatar.MouthAnchor.AddComponent<VoipAudioSourceHiLevel>();
				keyValuePair.Value.voipSource.senderID = keyValuePair.Value.remoteUserID;
			}
			if (keyValuePair.Value.voipSource != null)
			{
				float voiceAmplitude = Mathf.Clamp(keyValuePair.Value.voipSource.peakAmplitude * SocialPlatformManager.VOIP_SCALE, 0f, 1f);
				keyValuePair.Value.RemoteAvatar.VoiceAmplitude = voiceAmplitude;
			}
		}
		if (this.localAvatar != null)
		{
			this.localAvatar.VoiceAmplitude = Mathf.Clamp(this.voiceCurrent * SocialPlatformManager.VOIP_SCALE, 0f, 1f);
		}
		Request.RunCallbacks(0U);
	}

	// Token: 0x0600057C RID: 1404 RVA: 0x00022E9C File Offset: 0x0002109C
	public virtual void Awake()
	{
		this.LogOutputLine("Start Log.");
		this.helpMesh = this.helpPanel.GetComponent<MeshRenderer>();
		this.sphereMesh = this.roomSphere.GetComponent<MeshRenderer>();
		this.floorMesh = this.roomFloor.GetComponent<MeshRenderer>();
		this.localTrackingSpace = base.transform.Find("OVRCameraRig/TrackingSpace").gameObject;
		this.localPlayerHead = base.transform.Find("OVRCameraRig/TrackingSpace/CenterEyeAnchor").gameObject;
		if (SocialPlatformManager.s_instance != null)
		{
			Object.Destroy(base.gameObject);
			return;
		}
		SocialPlatformManager.s_instance = this;
		Object.DontDestroyOnLoad(base.gameObject);
		SocialPlatformManager.TransitionToState(SocialPlatformManager.State.INITIALIZING);
		Core.AsyncInitialize(null).OnComplete(new Message<PlatformInitialize>.Callback(this.InitCallback));
		this.roomManager = new RoomManager();
		this.p2pManager = new P2PManager();
		this.voipManager = new VoipManager();
	}

	// Token: 0x0600057D RID: 1405 RVA: 0x00022F88 File Offset: 0x00021188
	private void InitCallback(Message<PlatformInitialize> msg)
	{
		if (msg.IsError)
		{
			SocialPlatformManager.TerminateWithError(msg);
			return;
		}
		LaunchDetails launchDetails = ApplicationLifecycle.GetLaunchDetails();
		SocialPlatformManager.LogOutput("App launched with LaunchType " + launchDetails.LaunchType);
		Entitlements.IsUserEntitledToApplication().OnComplete(new Message.Callback(this.IsEntitledCallback));
	}

	// Token: 0x0600057E RID: 1406 RVA: 0x00003297 File Offset: 0x00001497
	public virtual void Start()
	{
	}

	// Token: 0x0600057F RID: 1407 RVA: 0x00022FDB File Offset: 0x000211DB
	private void IsEntitledCallback(Message msg)
	{
		if (msg.IsError)
		{
			SocialPlatformManager.TerminateWithError(msg);
			return;
		}
		Users.GetLoggedInUser().OnComplete(new Message<User>.Callback(this.GetLoggedInUserCallback));
	}

	// Token: 0x06000580 RID: 1408 RVA: 0x00023004 File Offset: 0x00021204
	private void GetLoggedInUserCallback(Message<User> msg)
	{
		if (msg.IsError)
		{
			SocialPlatformManager.TerminateWithError(msg);
			return;
		}
		this.myID = msg.Data.ID;
		this.myOculusID = msg.Data.OculusID;
		this.localAvatar = Object.Instantiate<OvrAvatar>(this.localAvatarPrefab);
		this.localAvatar.CanOwnMicrophone = false;
		this.localTrackingSpace = base.transform.Find("OVRCameraRig/TrackingSpace").gameObject;
		this.localAvatar.transform.SetParent(this.localTrackingSpace.transform, false);
		this.localAvatar.transform.localPosition = new Vector3(0f, 0f, 0f);
		this.localAvatar.transform.localRotation = Quaternion.identity;
		if (UnityEngine.Application.platform == RuntimePlatform.Android)
		{
			this.helpPanel.transform.SetParent(this.localAvatar.transform.Find("body"), false);
			this.helpPanel.transform.localPosition = new Vector3(0f, 1f, 1f);
			this.helpMesh.material = this.gearMaterial;
		}
		else
		{
			this.helpPanel.transform.SetParent(this.localAvatar.transform.Find("hand_left"), false);
			this.helpPanel.transform.localPosition = new Vector3(0f, 0.2f, 0.2f);
			this.helpMesh.material = this.riftMaterial;
		}
		this.localAvatar.oculusUserID = this.myID.ToString();
		this.localAvatar.RecordPackets = true;
		OvrAvatar ovrAvatar = this.localAvatar;
		ovrAvatar.PacketRecorded = (EventHandler<OvrAvatar.PacketEventArgs>)Delegate.Combine(ovrAvatar.PacketRecorded, new EventHandler<OvrAvatar.PacketEventArgs>(this.OnLocalAvatarPacketRecorded));
		this.localAvatar.EnableMouthVertexAnimation = true;
		Quaternion identity = Quaternion.identity;
		switch (Random.Range(0, 4))
		{
		case 0:
			identity.eulerAngles = SocialPlatformManager.START_ROTATION_ONE;
			base.transform.localPosition = SocialPlatformManager.START_POSITION_ONE;
			base.transform.localRotation = identity;
			goto IL_2A0;
		case 1:
			identity.eulerAngles = SocialPlatformManager.START_ROTATION_TWO;
			base.transform.localPosition = SocialPlatformManager.START_POSITION_TWO;
			base.transform.localRotation = identity;
			goto IL_2A0;
		case 2:
			identity.eulerAngles = SocialPlatformManager.START_ROTATION_THREE;
			base.transform.localPosition = SocialPlatformManager.START_POSITION_THREE;
			base.transform.localRotation = identity;
			goto IL_2A0;
		}
		identity.eulerAngles = SocialPlatformManager.START_ROTATION_FOUR;
		base.transform.localPosition = SocialPlatformManager.START_POSITION_FOUR;
		base.transform.localRotation = identity;
		IL_2A0:
		SocialPlatformManager.TransitionToState(SocialPlatformManager.State.CHECKING_LAUNCH_STATE);
		if (!this.roomManager.CheckForInvite())
		{
			SocialPlatformManager.LogOutput("No invite on launch, looking for a friend to join.");
			Users.GetLoggedInUserFriendsAndRooms().OnComplete(new Message<UserAndRoomList>.Callback(this.GetLoggedInUserFriendsAndRoomsCallback));
		}
		Voip.SetMicrophoneFilterCallback(new Oculus.Platform.CAPI.FilterCallback(SocialPlatformManager.MicFilter));
	}

	// Token: 0x06000581 RID: 1409 RVA: 0x000232F8 File Offset: 0x000214F8
	private void GetLoggedInUserFriendsAndRoomsCallback(Message<UserAndRoomList> msg)
	{
		if (msg.IsError)
		{
			return;
		}
		foreach (UserAndRoom userAndRoom in msg.Data)
		{
			if (userAndRoom.User != null && userAndRoom.RoomOptional != null && !userAndRoom.RoomOptional.IsMembershipLocked && userAndRoom.RoomOptional.Joinability == RoomJoinability.CanJoin && userAndRoom.RoomOptional.JoinPolicy != RoomJoinPolicy.None)
			{
				SocialPlatformManager.LogOutput(string.Concat(new object[]
				{
					"Trying to join room ",
					userAndRoom.RoomOptional.ID,
					", friend ",
					userAndRoom.User.OculusID
				}));
				this.roomManager.JoinExistingRoom(userAndRoom.RoomOptional.ID);
				return;
			}
		}
		SocialPlatformManager.LogOutput("No friend to join. Creating my own room.");
		this.roomManager.CreateRoom();
		SocialPlatformManager.TransitionToState(SocialPlatformManager.State.CREATING_A_ROOM);
	}

	// Token: 0x06000582 RID: 1410 RVA: 0x00023400 File Offset: 0x00021600
	public void OnLocalAvatarPacketRecorded(object sender, OvrAvatar.PacketEventArgs args)
	{
		uint num = Oculus.Avatar.CAPI.ovrAvatarPacket_GetSize(args.Packet.ovrNativePacket);
		byte[] array = new byte[num];
		Oculus.Avatar.CAPI.ovrAvatarPacket_Write(args.Packet.ovrNativePacket, num, array);
		foreach (KeyValuePair<ulong, RemotePlayer> keyValuePair in this.remoteUsers)
		{
			this.p2pManager.SendAvatarUpdate(keyValuePair.Key, this.localTrackingSpace.transform, this.packetSequence, array);
		}
		this.packetSequence += 1U;
	}

	// Token: 0x06000583 RID: 1411 RVA: 0x000234AC File Offset: 0x000216AC
	public void OnApplicationQuit()
	{
		this.roomManager.LeaveCurrentRoom();
		foreach (KeyValuePair<ulong, RemotePlayer> keyValuePair in this.remoteUsers)
		{
			this.p2pManager.Disconnect(keyValuePair.Key);
			this.voipManager.Disconnect(keyValuePair.Key);
		}
		this.LogOutputLine("End Log.");
	}

	// Token: 0x06000584 RID: 1412 RVA: 0x00023534 File Offset: 0x00021734
	public void AddUser(ulong userID, ref RemotePlayer remoteUser)
	{
		this.remoteUsers.Add(userID, remoteUser);
	}

	// Token: 0x06000585 RID: 1413 RVA: 0x00023544 File Offset: 0x00021744
	public void LogOutputLine(string line)
	{
		Debug.Log(Time.time + ": " + line);
	}

	// Token: 0x06000586 RID: 1414 RVA: 0x00023560 File Offset: 0x00021760
	public static void TerminateWithError(Message msg)
	{
		SocialPlatformManager.s_instance.LogOutputLine("Error: " + msg.GetError().Message);
		UnityEngine.Application.Quit();
	}

	// Token: 0x17000008 RID: 8
	// (get) Token: 0x06000587 RID: 1415 RVA: 0x00023586 File Offset: 0x00021786
	public static SocialPlatformManager.State CurrentState
	{
		get
		{
			return SocialPlatformManager.s_instance.currentState;
		}
	}

	// Token: 0x17000009 RID: 9
	// (get) Token: 0x06000588 RID: 1416 RVA: 0x00023592 File Offset: 0x00021792
	public static ulong MyID
	{
		get
		{
			if (SocialPlatformManager.s_instance != null)
			{
				return SocialPlatformManager.s_instance.myID;
			}
			return 0UL;
		}
	}

	// Token: 0x1700000A RID: 10
	// (get) Token: 0x06000589 RID: 1417 RVA: 0x000235AE File Offset: 0x000217AE
	public static string MyOculusID
	{
		get
		{
			if (SocialPlatformManager.s_instance != null && SocialPlatformManager.s_instance.myOculusID != null)
			{
				return SocialPlatformManager.s_instance.myOculusID;
			}
			return string.Empty;
		}
	}

	// Token: 0x0600058A RID: 1418 RVA: 0x000235DC File Offset: 0x000217DC
	public static void TransitionToState(SocialPlatformManager.State newState)
	{
		if (SocialPlatformManager.s_instance)
		{
			SocialPlatformManager.s_instance.LogOutputLine(string.Concat(new object[]
			{
				"State ",
				SocialPlatformManager.s_instance.currentState,
				" -> ",
				newState
			}));
		}
		if (SocialPlatformManager.s_instance && SocialPlatformManager.s_instance.currentState != newState)
		{
			SocialPlatformManager.s_instance.currentState = newState;
			if (newState == SocialPlatformManager.State.SHUTDOWN)
			{
				SocialPlatformManager.s_instance.OnApplicationQuit();
			}
		}
		SocialPlatformManager.SetSphereColorForState();
	}

	// Token: 0x0600058B RID: 1419 RVA: 0x0002366C File Offset: 0x0002186C
	private static void SetSphereColorForState()
	{
		SocialPlatformManager.State state = SocialPlatformManager.s_instance.currentState;
		if (state != SocialPlatformManager.State.INITIALIZING)
		{
			switch (state)
			{
			case SocialPlatformManager.State.WAITING_IN_A_ROOM:
				SocialPlatformManager.s_instance.sphereMesh.material.color = SocialPlatformManager.WHITE;
				return;
			case SocialPlatformManager.State.JOINING_A_ROOM:
			case SocialPlatformManager.State.LEAVING_A_ROOM:
				break;
			case SocialPlatformManager.State.CONNECTED_IN_A_ROOM:
				SocialPlatformManager.s_instance.sphereMesh.material.color = SocialPlatformManager.CYAN;
				break;
			case SocialPlatformManager.State.SHUTDOWN:
				goto IL_2B;
			default:
				return;
			}
			return;
		}
		IL_2B:
		SocialPlatformManager.s_instance.sphereMesh.material.color = SocialPlatformManager.BLACK;
	}

	// Token: 0x0600058C RID: 1420 RVA: 0x000236F1 File Offset: 0x000218F1
	public static void SetFloorColorForState(bool host)
	{
		if (host)
		{
			SocialPlatformManager.s_instance.floorMesh.material.color = SocialPlatformManager.BLUE;
			return;
		}
		SocialPlatformManager.s_instance.floorMesh.material.color = SocialPlatformManager.GREEN;
	}

	// Token: 0x0600058D RID: 1421 RVA: 0x0002372C File Offset: 0x0002192C
	public static void MarkAllRemoteUsersAsNotInRoom()
	{
		foreach (KeyValuePair<ulong, RemotePlayer> keyValuePair in SocialPlatformManager.s_instance.remoteUsers)
		{
			keyValuePair.Value.stillInRoom = false;
		}
	}

	// Token: 0x0600058E RID: 1422 RVA: 0x0002378C File Offset: 0x0002198C
	public static void MarkRemoteUserInRoom(ulong userID)
	{
		RemotePlayer remotePlayer = new RemotePlayer();
		if (SocialPlatformManager.s_instance.remoteUsers.TryGetValue(userID, out remotePlayer))
		{
			remotePlayer.stillInRoom = true;
		}
	}

	// Token: 0x0600058F RID: 1423 RVA: 0x000237BC File Offset: 0x000219BC
	public static void ForgetRemoteUsersNotInRoom()
	{
		List<ulong> list = new List<ulong>();
		foreach (KeyValuePair<ulong, RemotePlayer> keyValuePair in SocialPlatformManager.s_instance.remoteUsers)
		{
			if (!keyValuePair.Value.stillInRoom)
			{
				list.Add(keyValuePair.Key);
			}
		}
		foreach (ulong userID in list)
		{
			SocialPlatformManager.RemoveRemoteUser(userID);
		}
	}

	// Token: 0x06000590 RID: 1424 RVA: 0x00023868 File Offset: 0x00021A68
	public static void LogOutput(string line)
	{
		SocialPlatformManager.s_instance.LogOutputLine(Time.time + ": " + line);
	}

	// Token: 0x06000591 RID: 1425 RVA: 0x00023889 File Offset: 0x00021A89
	public static bool IsUserInRoom(ulong userID)
	{
		return SocialPlatformManager.s_instance.remoteUsers.ContainsKey(userID);
	}

	// Token: 0x06000592 RID: 1426 RVA: 0x0002389C File Offset: 0x00021A9C
	public static void AddRemoteUser(ulong userID)
	{
		RemotePlayer remotePlayer = new RemotePlayer();
		remotePlayer.RemoteAvatar = Object.Instantiate<OvrAvatar>(SocialPlatformManager.s_instance.remoteAvatarPrefab);
		remotePlayer.RemoteAvatar.oculusUserID = userID.ToString();
		remotePlayer.RemoteAvatar.ShowThirdPerson = true;
		remotePlayer.RemoteAvatar.EnableMouthVertexAnimation = true;
		remotePlayer.p2pConnectionState = PeerConnectionState.Unknown;
		remotePlayer.voipConnectionState = PeerConnectionState.Unknown;
		remotePlayer.stillInRoom = true;
		remotePlayer.remoteUserID = userID;
		SocialPlatformManager.s_instance.AddUser(userID, ref remotePlayer);
		SocialPlatformManager.s_instance.p2pManager.ConnectTo(userID);
		SocialPlatformManager.s_instance.voipManager.ConnectTo(userID);
		SocialPlatformManager.s_instance.LogOutputLine("Adding User " + userID);
	}

	// Token: 0x06000593 RID: 1427 RVA: 0x00023954 File Offset: 0x00021B54
	public static void RemoveRemoteUser(ulong userID)
	{
		RemotePlayer remotePlayer = new RemotePlayer();
		if (SocialPlatformManager.s_instance.remoteUsers.TryGetValue(userID, out remotePlayer))
		{
			Object.Destroy(remotePlayer.RemoteAvatar.MouthAnchor.GetComponent<VoipAudioSourceHiLevel>(), 0f);
			Object.Destroy(remotePlayer.RemoteAvatar.gameObject, 0f);
			SocialPlatformManager.s_instance.remoteUsers.Remove(userID);
			SocialPlatformManager.s_instance.LogOutputLine("Removing User " + userID);
		}
	}

	// Token: 0x06000594 RID: 1428 RVA: 0x000239D8 File Offset: 0x00021BD8
	public void UpdateVoiceData(short[] pcmData, int numChannels)
	{
		if (this.localAvatar != null)
		{
			this.localAvatar.UpdateVoiceData(pcmData, numChannels);
		}
		float num = 0f;
		float[] array = new float[pcmData.Length];
		for (int i = 0; i < pcmData.Length; i++)
		{
			float num2 = array[i] = (float)pcmData[i] / 32767f;
			if (num2 > num)
			{
				num = num2;
			}
		}
		this.voiceCurrent = num;
	}

	// Token: 0x06000595 RID: 1429 RVA: 0x00023A3D File Offset: 0x00021C3D
	[MonoPInvokeCallback(typeof(Oculus.Platform.CAPI.FilterCallback))]
	public static void MicFilter(short[] pcmData, UIntPtr pcmDataLength, int frequency, int numChannels)
	{
		SocialPlatformManager.s_instance.UpdateVoiceData(pcmData, numChannels);
	}

	// Token: 0x06000596 RID: 1430 RVA: 0x00023A4C File Offset: 0x00021C4C
	public static RemotePlayer GetRemoteUser(ulong userID)
	{
		RemotePlayer result = new RemotePlayer();
		if (SocialPlatformManager.s_instance.remoteUsers.TryGetValue(userID, out result))
		{
			return result;
		}
		return null;
	}

	// Token: 0x0400068C RID: 1676
	private static readonly Vector3 START_ROTATION_ONE = new Vector3(0f, 180f, 0f);

	// Token: 0x0400068D RID: 1677
	private static readonly Vector3 START_POSITION_ONE = new Vector3(0f, 4f, 5f);

	// Token: 0x0400068E RID: 1678
	private static readonly Vector3 START_ROTATION_TWO = new Vector3(0f, 0f, 0f);

	// Token: 0x0400068F RID: 1679
	private static readonly Vector3 START_POSITION_TWO = new Vector3(0f, 4f, -5f);

	// Token: 0x04000690 RID: 1680
	private static readonly Vector3 START_ROTATION_THREE = new Vector3(0f, 270f, 0f);

	// Token: 0x04000691 RID: 1681
	private static readonly Vector3 START_POSITION_THREE = new Vector3(5f, 4f, 0f);

	// Token: 0x04000692 RID: 1682
	private static readonly Vector3 START_ROTATION_FOUR = new Vector3(0f, 90f, 0f);

	// Token: 0x04000693 RID: 1683
	private static readonly Vector3 START_POSITION_FOUR = new Vector3(-5f, 4f, 0f);

	// Token: 0x04000694 RID: 1684
	private static readonly Color BLACK = new Color(0f, 0f, 0f);

	// Token: 0x04000695 RID: 1685
	private static readonly Color WHITE = new Color(1f, 1f, 1f);

	// Token: 0x04000696 RID: 1686
	private static readonly Color CYAN = new Color(0f, 1f, 1f);

	// Token: 0x04000697 RID: 1687
	private static readonly Color BLUE = new Color(0f, 0f, 1f);

	// Token: 0x04000698 RID: 1688
	private static readonly Color GREEN = new Color(0f, 1f, 0f);

	// Token: 0x04000699 RID: 1689
	private float voiceCurrent;

	// Token: 0x0400069A RID: 1690
	private uint packetSequence;

	// Token: 0x0400069B RID: 1691
	public OvrAvatar localAvatarPrefab;

	// Token: 0x0400069C RID: 1692
	public OvrAvatar remoteAvatarPrefab;

	// Token: 0x0400069D RID: 1693
	public GameObject helpPanel;

	// Token: 0x0400069E RID: 1694
	protected MeshRenderer helpMesh;

	// Token: 0x0400069F RID: 1695
	public Material riftMaterial;

	// Token: 0x040006A0 RID: 1696
	public Material gearMaterial;

	// Token: 0x040006A1 RID: 1697
	protected OvrAvatar localAvatar;

	// Token: 0x040006A2 RID: 1698
	protected GameObject localTrackingSpace;

	// Token: 0x040006A3 RID: 1699
	protected GameObject localPlayerHead;

	// Token: 0x040006A4 RID: 1700
	protected Dictionary<ulong, RemotePlayer> remoteUsers = new Dictionary<ulong, RemotePlayer>();

	// Token: 0x040006A5 RID: 1701
	public GameObject roomSphere;

	// Token: 0x040006A6 RID: 1702
	protected MeshRenderer sphereMesh;

	// Token: 0x040006A7 RID: 1703
	public GameObject roomFloor;

	// Token: 0x040006A8 RID: 1704
	protected MeshRenderer floorMesh;

	// Token: 0x040006A9 RID: 1705
	protected SocialPlatformManager.State currentState;

	// Token: 0x040006AA RID: 1706
	protected static SocialPlatformManager s_instance = null;

	// Token: 0x040006AB RID: 1707
	protected RoomManager roomManager;

	// Token: 0x040006AC RID: 1708
	protected P2PManager p2pManager;

	// Token: 0x040006AD RID: 1709
	protected VoipManager voipManager;

	// Token: 0x040006AE RID: 1710
	protected ulong myID;

	// Token: 0x040006AF RID: 1711
	protected string myOculusID;

	// Token: 0x040006B0 RID: 1712
	public static readonly float VOIP_SCALE = 2f;

	// Token: 0x020001E7 RID: 487
	public enum State
	{
		// Token: 0x04000E2F RID: 3631
		INITIALIZING,
		// Token: 0x04000E30 RID: 3632
		CHECKING_LAUNCH_STATE,
		// Token: 0x04000E31 RID: 3633
		CREATING_A_ROOM,
		// Token: 0x04000E32 RID: 3634
		WAITING_IN_A_ROOM,
		// Token: 0x04000E33 RID: 3635
		JOINING_A_ROOM,
		// Token: 0x04000E34 RID: 3636
		CONNECTED_IN_A_ROOM,
		// Token: 0x04000E35 RID: 3637
		LEAVING_A_ROOM,
		// Token: 0x04000E36 RID: 3638
		SHUTDOWN
	}
}
