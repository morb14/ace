﻿using System;
using System.Collections;
using TMPro;
using UnityEngine;

// Token: 0x0200008E RID: 142
public class SystemMessage : MonoBehaviour
{
	// Token: 0x060004EB RID: 1259 RVA: 0x000206BC File Offset: 0x0001E8BC
	private void Start()
	{
		this.originalColor = this.systemText.faceColor;
		this.systemText.enabled = false;
		this.gameManager = Object.FindObjectOfType<GameManager>();
		GameEvents.current.onMessageBroadcast += this.OnMessageBroadcast;
	}

	// Token: 0x060004EC RID: 1260 RVA: 0x0002070C File Offset: 0x0001E90C
	private void OnMessageBroadcast()
	{
		base.StopCoroutine("FadeTo");
		this.systemText.faceColor = this.originalColor;
		this.systemText.enabled = true;
		this.systemText.text = this.gameManager.broadcastMessage;
		base.StartCoroutine(this.FadeTo(0f, 3f));
	}

	// Token: 0x060004ED RID: 1261 RVA: 0x00020773 File Offset: 0x0001E973
	private IEnumerator FadeTo(float aValue, float aTime)
	{
		Color tempColor = this.systemText.faceColor;
		float tempAlpha = tempColor.a;
		for (float t = 0f; t < 1f; t += Time.deltaTime / aTime)
		{
			tempColor.a = Mathf.Lerp(tempAlpha, aValue, t);
			this.systemText.faceColor = tempColor;
			yield return null;
		}
		this.systemText.enabled = false;
		yield break;
	}

	// Token: 0x060004EE RID: 1262 RVA: 0x00020790 File Offset: 0x0001E990
	private void OnDestroy()
	{
		GameEvents.current.onMessageBroadcast -= this.OnMessageBroadcast;
	}

	// Token: 0x04000635 RID: 1589
	[SerializeField]
	private TMP_Text systemText;

	// Token: 0x04000636 RID: 1590
	private Color originalColor;

	// Token: 0x04000637 RID: 1591
	private GameManager gameManager;
}
