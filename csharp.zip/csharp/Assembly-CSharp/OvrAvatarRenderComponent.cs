﻿using System;
using Oculus.Avatar;
using UnityEngine;
using UnityEngine.Rendering;

// Token: 0x020000BA RID: 186
public class OvrAvatarRenderComponent : MonoBehaviour
{
	// Token: 0x06000623 RID: 1571 RVA: 0x00028504 File Offset: 0x00026704
	protected void UpdateActive(OvrAvatar avatar, ovrAvatarVisibilityFlags mask)
	{
		if (this.isBodyComponent && avatar.EnableExpressive && avatar.ShowFirstPerson && !avatar.ShowThirdPerson)
		{
			bool flag = (mask & ovrAvatarVisibilityFlags.FirstPerson) > (ovrAvatarVisibilityFlags)0;
			bool flag2 = (mask & ovrAvatarVisibilityFlags.ThirdPerson) > (ovrAvatarVisibilityFlags)0;
			base.gameObject.SetActive(flag2 || flag2);
			if (!flag)
			{
				this.mesh.enabled = false;
				return;
			}
		}
		else
		{
			bool flag3 = avatar.ShowFirstPerson && (mask & ovrAvatarVisibilityFlags.FirstPerson) > (ovrAvatarVisibilityFlags)0;
			flag3 |= (avatar.ShowThirdPerson && (mask & ovrAvatarVisibilityFlags.ThirdPerson) > (ovrAvatarVisibilityFlags)0);
			base.gameObject.SetActive(flag3);
			this.mesh.enabled = flag3;
		}
	}

	// Token: 0x06000624 RID: 1572 RVA: 0x000285A0 File Offset: 0x000267A0
	protected SkinnedMeshRenderer CreateSkinnedMesh(ulong assetID, ovrAvatarVisibilityFlags visibilityMask, int thirdPersonLayer, int firstPersonLayer)
	{
		this.isBodyComponent = base.name.Contains("body");
		OvrAvatarAssetMesh ovrAvatarAssetMesh = (OvrAvatarAssetMesh)OvrAvatarSDKManager.Instance.GetAsset(assetID);
		if (ovrAvatarAssetMesh == null)
		{
			throw new Exception("Couldn't find mesh for asset " + assetID);
		}
		if ((visibilityMask & ovrAvatarVisibilityFlags.ThirdPerson) != (ovrAvatarVisibilityFlags)0)
		{
			base.gameObject.layer = thirdPersonLayer;
		}
		else
		{
			base.gameObject.layer = firstPersonLayer;
		}
		SkinnedMeshRenderer skinnedMeshRenderer = ovrAvatarAssetMesh.CreateSkinnedMeshRendererOnObject(base.gameObject);
		skinnedMeshRenderer.quality = SkinQuality.Bone2;
		skinnedMeshRenderer.updateWhenOffscreen = true;
		if ((visibilityMask & ovrAvatarVisibilityFlags.SelfOccluding) == (ovrAvatarVisibilityFlags)0)
		{
			skinnedMeshRenderer.shadowCastingMode = ShadowCastingMode.Off;
		}
		base.gameObject.SetActive(false);
		return skinnedMeshRenderer;
	}

	// Token: 0x06000625 RID: 1573 RVA: 0x00028640 File Offset: 0x00026840
	protected void UpdateSkinnedMesh(OvrAvatar avatar, Transform[] bones, ovrAvatarTransform localTransform, ovrAvatarVisibilityFlags visibilityMask, IntPtr renderPart)
	{
		this.UpdateActive(avatar, visibilityMask);
		OvrAvatar.ConvertTransform(localTransform, base.transform);
		ovrAvatarRenderPartType ovrAvatarRenderPartType = CAPI.ovrAvatarRenderPart_GetType(renderPart);
		switch (ovrAvatarRenderPartType)
		{
		case ovrAvatarRenderPartType.SkinnedMeshRender:
		{
			ulong num = CAPI.ovrAvatarSkinnedMeshRender_GetDirtyJoints(renderPart);
			goto IL_69;
		}
		case ovrAvatarRenderPartType.SkinnedMeshRenderPBS:
		{
			ulong num = CAPI.ovrAvatarSkinnedMeshRenderPBS_GetDirtyJoints(renderPart);
			goto IL_69;
		}
		case ovrAvatarRenderPartType.SkinnedMeshRenderPBS_V2:
		{
			ulong num = CAPI.ovrAvatarSkinnedMeshRenderPBSV2_GetDirtyJoints(renderPart);
			goto IL_69;
		}
		}
		throw new Exception("Unhandled render part type: " + ovrAvatarRenderPartType);
		IL_69:
		for (uint num2 = 0U; num2 < 64U; num2 += 1U)
		{
			ulong num3 = 1UL << (int)num2;
			ulong num;
			if ((this.firstSkinnedUpdate && (ulong)num2 < (ulong)((long)bones.Length)) || (num3 & num) != 0UL)
			{
				Transform target = bones[(int)num2];
				ovrAvatarTransform transform;
				switch (ovrAvatarRenderPartType)
				{
				case ovrAvatarRenderPartType.SkinnedMeshRender:
					transform = CAPI.ovrAvatarSkinnedMeshRender_GetJointTransform(renderPart, num2);
					break;
				case ovrAvatarRenderPartType.SkinnedMeshRenderPBS:
					transform = CAPI.ovrAvatarSkinnedMeshRenderPBS_GetJointTransform(renderPart, num2);
					break;
				case ovrAvatarRenderPartType.ProjectorRender:
					goto IL_CE;
				case ovrAvatarRenderPartType.SkinnedMeshRenderPBS_V2:
					transform = CAPI.ovrAvatarSkinnedMeshRenderPBSV2_GetJointTransform(renderPart, num2);
					break;
				default:
					goto IL_CE;
				}
				OvrAvatar.ConvertTransform(transform, target);
				goto IL_ED;
				IL_CE:
				throw new Exception("Unhandled render part type: " + ovrAvatarRenderPartType);
			}
			IL_ED:;
		}
		this.firstSkinnedUpdate = false;
	}

	// Token: 0x06000626 RID: 1574 RVA: 0x0002874D File Offset: 0x0002694D
	protected Material CreateAvatarMaterial(string name, Shader shader)
	{
		if (shader == null)
		{
			throw new Exception("No shader provided for avatar material.");
		}
		return new Material(shader)
		{
			name = name
		};
	}

	// Token: 0x04000759 RID: 1881
	private bool firstSkinnedUpdate = true;

	// Token: 0x0400075A RID: 1882
	public SkinnedMeshRenderer mesh;

	// Token: 0x0400075B RID: 1883
	public Transform[] bones;

	// Token: 0x0400075C RID: 1884
	private bool isBodyComponent;
}
