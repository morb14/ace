﻿using System;
using UnityEngine;

// Token: 0x02000063 RID: 99
public class SteelTarget : MonoBehaviour
{
	// Token: 0x060003AB RID: 939 RVA: 0x000185F4 File Offset: 0x000167F4
	private void Start()
	{
		if (this.scoreConditionTransform != null)
		{
			this.scoreStartPosition = this.scoreConditionTransform.position;
			this.scoreStartRotation = this.scoreConditionTransform.rotation;
			this.originalParent = base.gameObject.transform.parent;
		}
	}

	// Token: 0x060003AC RID: 940 RVA: 0x00018647 File Offset: 0x00016847
	public int GetScore(bool IsNoShoot = false)
	{
		if (IsNoShoot && this.scoreConditionMet)
		{
			return 1;
		}
		if (this.scoreConditionMet)
		{
			return this.score;
		}
		return 0;
	}

	// Token: 0x060003AD RID: 941 RVA: 0x00018666 File Offset: 0x00016866
	public int RoundCount()
	{
		return 1;
	}

	// Token: 0x060003AE RID: 942 RVA: 0x00018669 File Offset: 0x00016869
	private void Update()
	{
		if (this.hasBeenHit)
		{
			this.CheckScoringCondition();
		}
		if (this.test)
		{
			this.Hit(new Vector3?(Vector3.forward));
			this.test = false;
		}
	}

	// Token: 0x060003AF RID: 943 RVA: 0x00018698 File Offset: 0x00016898
	private void LateUpdate()
	{
		if (this.resetting)
		{
			this.ResetLerp();
		}
	}

	// Token: 0x060003B0 RID: 944 RVA: 0x000186A8 File Offset: 0x000168A8
	private void CheckScoringCondition()
	{
		if (this.scoreCondition == SteelTarget.ScoreConditionType.Rotation)
		{
			if (this.rotationAxis == SteelTarget.ScoreRotationAxis.x && this.scoreConditionTransform.transform.localEulerAngles.x > this.scoreConditionRotation)
			{
				this.ScoreConditionMet();
			}
			if (this.rotationAxis == SteelTarget.ScoreRotationAxis.y && this.scoreConditionTransform.transform.localEulerAngles.y > this.scoreConditionRotation)
			{
				this.ScoreConditionMet();
			}
			if (this.rotationAxis == SteelTarget.ScoreRotationAxis.z && this.scoreConditionTransform.transform.localEulerAngles.z > this.scoreConditionRotation)
			{
				this.ScoreConditionMet();
			}
		}
		if (this.scoreCondition == SteelTarget.ScoreConditionType.Parent && base.transform.parent == null)
		{
			this.ScoreConditionMet();
		}
		if (this.anyHitCounts && this.hasBeenHit)
		{
			this.ScoreConditionMet();
		}
	}

	// Token: 0x060003B1 RID: 945 RVA: 0x0001877C File Offset: 0x0001697C
	private void ScoreConditionMet()
	{
		this.scoreConditionMet = true;
		this.hasBeenHit = false;
		if (this.targetActivator != null && this.targetActivator.activeTargets.Length != 0)
		{
			this.targetActivator.Activate();
		}
		if (this.autoReset && !this.resetInitiated)
		{
			base.Invoke("Reset", this.resetTime);
			this.resetInitiated = true;
		}
	}

	// Token: 0x060003B2 RID: 946 RVA: 0x000187E8 File Offset: 0x000169E8
	public void Reset()
	{
		if (this.targetActivator != null)
		{
			foreach (ActiveTarget activeTarget in this.targetActivator.activeTargets)
			{
				if (activeTarget != null)
				{
					activeTarget.Reset();
				}
			}
		}
		this.resetting = true;
		this.resetBeginTime = Time.time;
		this.scoreDownPosition = this.scoreConditionTransform.position;
		this.scoreDownRotation = this.scoreConditionTransform.rotation;
		if (this.scoreConditionTransform.GetComponent<Rigidbody>() != null)
		{
			this.scoreConditionTransform.GetComponent<Rigidbody>().useGravity = false;
		}
	}

	// Token: 0x060003B3 RID: 947 RVA: 0x00018888 File Offset: 0x00016A88
	private void ResetLerp()
	{
		if (this.hitToRB)
		{
			this.scoreConditionTransform.rotation = Quaternion.RotateTowards(this.scoreDownRotation, this.scoreStartRotation, (Time.time - this.resetBeginTime) * 100f);
			this.scoreConditionTransform.position = Vector3.Lerp(base.transform.position, this.scoreStartPosition, (Time.time - this.resetBeginTime) / 20f);
			if ((double)Vector3.Distance(base.transform.position, this.scoreStartPosition) < 0.01 && Quaternion.Dot(this.scoreConditionTransform.rotation, this.scoreStartRotation) > 0.999f)
			{
				base.transform.position = this.scoreStartPosition;
				base.transform.rotation = this.scoreStartRotation;
				base.GetComponent<Rigidbody>().useGravity = true;
				base.GetComponent<Rigidbody>().isKinematic = true;
				this.scoreConditionMet = false;
				this.resetting = false;
				this.resetInitiated = false;
				return;
			}
		}
		else
		{
			MonoBehaviour.print("RESETTUBG");
			this.scoreConditionTransform.rotation = Quaternion.RotateTowards(this.scoreDownRotation, this.scoreStartRotation, (Time.time - this.resetBeginTime) * 100f);
			if (Quaternion.Dot(this.scoreConditionTransform.rotation, this.scoreStartRotation) > 0.9999f)
			{
				this.scoreConditionTransform.rotation = this.scoreStartRotation;
				this.scoreConditionMet = false;
				this.resetting = false;
				this.resetInitiated = false;
				if (this.scoreConditionTransform.GetComponent<Rigidbody>() != null)
				{
					this.scoreConditionTransform.GetComponent<Rigidbody>().useGravity = true;
				}
			}
		}
	}

	// Token: 0x060003B4 RID: 948 RVA: 0x00018A38 File Offset: 0x00016C38
	public void Hit(Vector3? impact = null)
	{
		this.hasBeenHit = true;
		this.Splash(impact);
		if (this.isStopPlate)
		{
			GameEvents.current.StopPlateHit();
		}
		if (this.anyHitCounts)
		{
			GameEvents.current.SteelHit();
		}
		if (this.hitToRB)
		{
			base.GetComponent<Rigidbody>().isKinematic = false;
			if (this.ignoreHitToRB.Length != 0)
			{
				GameObject[] array = this.ignoreHitToRB;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].transform.parent = null;
				}
			}
		}
		if (this.zeroingTarget)
		{
			GameObject gameObject = new GameObject();
			gameObject.transform.position = impact.Value;
			gameObject.transform.parent = base.transform;
			this.zeroingDisplay.UpdateShotPosition(gameObject.transform.localPosition, this.zeroingTargetButton);
			Object.Destroy(gameObject);
		}
	}

	// Token: 0x060003B5 RID: 949 RVA: 0x00018B0C File Offset: 0x00016D0C
	private void Splash(Vector3? impact = null)
	{
		float y = 0f;
		if (this.splash != null)
		{
			if (impact != null)
			{
				Vector3 value = impact.Value;
				foreach (RaycastHit raycastHit in Physics.RaycastAll(value, Vector3.down, 5f))
				{
					if (raycastHit.transform.tag == "Ground")
					{
						y = raycastHit.point.y;
					}
				}
				this.splash.transform.position = new Vector3(value.x, y, value.z);
			}
			this.splash.main.playOnAwake = true;
			this.splash.gameObject.SetActive(false);
			this.splash.gameObject.SetActive(true);
		}
	}

	// Token: 0x04000473 RID: 1139
	[SerializeField]
	public ParticleSystem splash;

	// Token: 0x04000474 RID: 1140
	[SerializeField]
	public AudioClip bespokeHitAudio;

	// Token: 0x04000475 RID: 1141
	[SerializeField]
	public int score;

	// Token: 0x04000476 RID: 1142
	[SerializeField]
	private Transform scoreConditionTransform;

	// Token: 0x04000477 RID: 1143
	[SerializeField]
	private float scoreConditionRotation;

	// Token: 0x04000478 RID: 1144
	[SerializeField]
	private SteelTarget.ScoreRotationAxis rotationAxis;

	// Token: 0x04000479 RID: 1145
	[SerializeField]
	private SteelTarget.ScoreConditionType scoreCondition;

	// Token: 0x0400047A RID: 1146
	[SerializeField]
	private bool hitToRB;

	// Token: 0x0400047B RID: 1147
	[SerializeField]
	public bool noShoot;

	// Token: 0x0400047C RID: 1148
	[SerializeField]
	private GameObject[] ignoreHitToRB;

	// Token: 0x0400047D RID: 1149
	[SerializeField]
	public bool autoReset;

	// Token: 0x0400047E RID: 1150
	[SerializeField]
	public float resetTime = 5f;

	// Token: 0x0400047F RID: 1151
	[Header("Zeroing Target")]
	[SerializeField]
	public bool zeroingTarget;

	// Token: 0x04000480 RID: 1152
	[SerializeField]
	private ZeroingDisplay zeroingDisplay;

	// Token: 0x04000481 RID: 1153
	[SerializeField]
	private ZeroingTargetButton zeroingTargetButton;

	// Token: 0x04000482 RID: 1154
	[Header("Speed Steel")]
	[SerializeField]
	private bool anyHitCounts;

	// Token: 0x04000483 RID: 1155
	[SerializeField]
	private bool isStopPlate;

	// Token: 0x04000484 RID: 1156
	[Header("Misc")]
	[SerializeField]
	private TargetActivator targetActivator;

	// Token: 0x04000485 RID: 1157
	[SerializeField]
	public bool dormant;

	// Token: 0x04000486 RID: 1158
	[SerializeField]
	private bool test;

	// Token: 0x04000487 RID: 1159
	private bool scoreConditionMet;

	// Token: 0x04000488 RID: 1160
	private bool hasBeenHit;

	// Token: 0x04000489 RID: 1161
	private bool resetInitiated;

	// Token: 0x0400048A RID: 1162
	private bool resetting;

	// Token: 0x0400048B RID: 1163
	private Transform originalParent;

	// Token: 0x0400048C RID: 1164
	private float resetBeginTime;

	// Token: 0x0400048D RID: 1165
	private Vector3 scoreStartPosition;

	// Token: 0x0400048E RID: 1166
	private Vector3 scoreDownPosition;

	// Token: 0x0400048F RID: 1167
	private Quaternion scoreStartRotation;

	// Token: 0x04000490 RID: 1168
	private Quaternion scoreDownRotation;

	// Token: 0x020001D6 RID: 470
	public enum ScoreConditionType
	{
		// Token: 0x04000DDB RID: 3547
		None,
		// Token: 0x04000DDC RID: 3548
		Rotation,
		// Token: 0x04000DDD RID: 3549
		Parent
	}

	// Token: 0x020001D7 RID: 471
	public enum ScoreRotationAxis
	{
		// Token: 0x04000DDF RID: 3551
		x,
		// Token: 0x04000DE0 RID: 3552
		y,
		// Token: 0x04000DE1 RID: 3553
		z
	}
}
