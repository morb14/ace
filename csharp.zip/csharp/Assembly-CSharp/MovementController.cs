﻿using System;
using UnityEngine;

// Token: 0x0200003E RID: 62
public class MovementController : MonoBehaviour
{
	// Token: 0x06000209 RID: 521 RVA: 0x0000B5FD File Offset: 0x000097FD
	private void Start()
	{
		this.controlManager = Object.FindObjectOfType<ControlManager>();
		this.characterController = base.GetComponent<CharacterController>();
		this.cameraRig = Object.FindObjectOfType<OVRCameraRig>();
		GameEvents.current.onTeleported += this.OnTeleported;
	}

	// Token: 0x0600020A RID: 522 RVA: 0x0000B637 File Offset: 0x00009837
	private void Update()
	{
		this.HolsterVolumeRotation();
		this.Input();
	}

	// Token: 0x0600020B RID: 523 RVA: 0x0000B648 File Offset: 0x00009848
	private void RayCheck()
	{
		RaycastHit raycastHit;
		if (Physics.Raycast(Camera.main.transform.position, Camera.main.transform.forward, out raycastHit, float.PositiveInfinity, this.layerMask) && raycastHit.transform.gameObject.layer == 10)
		{
			if (raycastHit.transform.GetComponent<RendererEnabler>())
			{
				raycastHit.transform.GetComponent<RendererEnabler>().Highlighted();
			}
			this.targetObject = raycastHit.transform.gameObject;
			this.movementPositionAcquired = true;
			this.targetPosition = raycastHit.transform.position;
			this.targetRotation = raycastHit.transform.rotation;
		}
	}

	// Token: 0x0600020C RID: 524 RVA: 0x0000B704 File Offset: 0x00009904
	private void OnTeleported()
	{
		float num = Object.FindObjectOfType<PlayerData>().cameraRigLocalY;
		if (num == 1E-45f)
		{
			num = -0.83f;
		}
		this.cameraRig.transform.localPosition = new Vector3(this.cameraRig.transform.localPosition.x, num, this.cameraRig.transform.localPosition.z);
	}

	// Token: 0x0600020D RID: 525 RVA: 0x0000B770 File Offset: 0x00009970
	private void HolsterVolumeRotation()
	{
		if (this.headset.eulerAngles.x > 40f && this.headset.eulerAngles.x < 70f)
		{
			if (this.holsterVolumeLastRot == Vector3.zero)
			{
				this.holsterVolumeLastRot = base.transform.eulerAngles;
			}
			MonoBehaviour.print("HOLSTER FIXED");
			Vector3 eulerAngles = new Vector3(base.transform.rotation.x, -base.transform.rotation.y + this.holsterVolumeLastRot.y, base.transform.rotation.z);
			this.holsterVolume.transform.eulerAngles = eulerAngles;
			this.holsterVolumeAdjusted = true;
			return;
		}
		if (this.holsterVolumeAdjusted)
		{
			MonoBehaviour.print("HOLSTER unFIXED");
			this.holsterVolume.transform.localEulerAngles = Vector3.zero;
			this.holsterVolumeAdjusted = false;
			this.holsterVolumeLastRot = Vector3.zero;
		}
	}

	// Token: 0x0600020E RID: 526 RVA: 0x00003297 File Offset: 0x00001497
	private void OnDrawGizmos()
	{
	}

	// Token: 0x0600020F RID: 527 RVA: 0x0000B874 File Offset: 0x00009A74
	private void Input()
	{
		Vector2 vector = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, this.controlManager.controller);
		if (vector.y >= 0.5f)
		{
			GameEvents.current.StickForward();
			MonoBehaviour.print("OVR stick forward");
			if (!this.forwardHeld && this.movementPositionAcquired)
			{
				this.forwardHeld = true;
			}
			this.RayCheck();
		}
		if (vector.y < 0.5f && this.forwardHeld)
		{
			GameEvents.current.StickRelease();
			if (this.movementPositionAcquired)
			{
				Vector3 vector2 = new Vector3(this.targetPosition.x, this.targetPosition.y, this.targetPosition.z);
				this.characterController.enabled = false;
				this.characterController.transform.position = vector2;
				Object.FindObjectOfType<OVRPlayerController>().Teleported = true;
				this.characterController.enabled = true;
				this.CheckProperty();
				GameEvents.current.Teleported();
				MonoBehaviour.print(vector2);
				this.forwardHeld = false;
			}
			this.movementPositionAcquired = false;
		}
	}

	// Token: 0x06000210 RID: 528 RVA: 0x0000B984 File Offset: 0x00009B84
	private void CheckProperty()
	{
		if (this.targetObject.GetComponent<TeleportProperty>())
		{
			TeleportProperty component = this.targetObject.GetComponent<TeleportProperty>();
			if (!component.dormant)
			{
				component.Enter();
			}
		}
	}

	// Token: 0x040001C4 RID: 452
	private ControlManager controlManager;

	// Token: 0x040001C5 RID: 453
	private CharacterController characterController;

	// Token: 0x040001C6 RID: 454
	[SerializeField]
	private LayerMask layerMask;

	// Token: 0x040001C7 RID: 455
	[SerializeField]
	private Transform holsterVolume;

	// Token: 0x040001C8 RID: 456
	[SerializeField]
	private Transform headset;

	// Token: 0x040001C9 RID: 457
	private bool movementPositionAcquired;

	// Token: 0x040001CA RID: 458
	private bool forwardHeld;

	// Token: 0x040001CB RID: 459
	private Vector3 targetPosition;

	// Token: 0x040001CC RID: 460
	private Quaternion targetRotation;

	// Token: 0x040001CD RID: 461
	private bool holsterVolumeAdjusted;

	// Token: 0x040001CE RID: 462
	private Vector3 holsterVolumeLastRot;

	// Token: 0x040001CF RID: 463
	private OVRCameraRig cameraRig;

	// Token: 0x040001D0 RID: 464
	private GameObject targetObject;
}
