﻿using System;
using UnityEngine;

// Token: 0x0200006D RID: 109
public class WeaponTransformAdjustment : MonoBehaviour
{
	// Token: 0x060003FD RID: 1021 RVA: 0x0001AC00 File Offset: 0x00018E00
	private void Start()
	{
		this.InitializeArrows();
		this.playerData = Object.FindObjectOfType<PlayerData>();
		this.controlManager = Object.FindObjectOfType<ControlManager>();
		GameEvents.current.onHolsterDraw += this.OnHolsterDraw;
		GameEvents.current.onHolster += this.OnHolster;
	}

	// Token: 0x060003FE RID: 1022 RVA: 0x0001AC55 File Offset: 0x00018E55
	private void Update()
	{
		this.Activate();
		if (this.weaponTransform != null && this.mode != 0)
		{
			this.Adjustment();
		}
	}

	// Token: 0x060003FF RID: 1023 RVA: 0x0001AC79 File Offset: 0x00018E79
	public void InitializeArrows()
	{
		this.arrowObject = Object.Instantiate<GameObject>(this.adjustmentArrows);
		this.weaponAdjustmentArrows = this.arrowObject.GetComponent<WeaponAdjustmentArrows>();
	}

	// Token: 0x06000400 RID: 1024 RVA: 0x0001ACA0 File Offset: 0x00018EA0
	private void OnHolsterDraw()
	{
		if (this.weaponController != null)
		{
			this.weaponController.DisableControls(false);
		}
		this.weaponController = this.controlManager.currentWeapon;
		this.weaponTransform = this.weaponController.transform;
		if (this.playerData != null)
		{
			Vector3 weaponPosition = this.playerData.GetWeaponPosition(this.weaponController.WeaponID());
			Quaternion weaponRotation = this.playerData.GetWeaponRotation(this.weaponController.WeaponID());
			if (weaponPosition != Vector3.zero)
			{
				this.weaponTransform.transform.localPosition = weaponPosition;
			}
			if (weaponRotation != Quaternion.identity)
			{
				this.weaponTransform.transform.localRotation = weaponRotation;
			}
		}
		if (this.weaponController.adjustmentArrowsTransform != null && this.arrowObject != null)
		{
			this.UpdateArrowPosition();
		}
		if (this.arrowObject != null)
		{
			this.arrowObject.transform.parent = this.weaponTransform.transform;
		}
	}

	// Token: 0x06000401 RID: 1025 RVA: 0x0001ADB4 File Offset: 0x00018FB4
	private void OnHolster()
	{
		if (this.mode != 0)
		{
			this.playerData.SaveWeaponTransform(this.weaponController.WeaponID(), this.weaponTransform.transform.localPosition, this.weaponTransform.localRotation);
			this.weaponTransform.localPosition = Vector3.zero;
			this.weaponTransform.localRotation = Quaternion.identity;
		}
		if (this.arrowObject != null)
		{
			this.arrowObject.transform.parent = base.transform;
		}
		this.mode = 0;
		this.weaponAdjustmentArrows.Reset();
	}

	// Token: 0x06000402 RID: 1026 RVA: 0x0001AE50 File Offset: 0x00019050
	private void Activate()
	{
		if (OVRInput.GetDown(OVRInput.Button.PrimaryThumbstick, this.controlManager.controller))
		{
			if (!base.GetComponentInChildren<WeaponController>())
			{
				return;
			}
			if (Object.FindObjectOfType<SceneSettings>() && Object.FindObjectOfType<SceneSettings>().sceneType == SceneSettings.SceneType.Comp)
			{
				return;
			}
			if (this.weaponController != base.GetComponentInChildren<WeaponController>())
			{
				this.weaponController = base.GetComponentInChildren<WeaponController>();
				this.weaponTransform = base.GetComponentInChildren<WeaponController>().transform;
			}
			if (this.weaponAdjustmentArrows == null)
			{
				this.weaponAdjustmentArrows = this.arrowObject.GetComponent<WeaponAdjustmentArrows>();
			}
			this.weaponAdjustmentArrows.toggleProgressOuter.SetActive(true);
			if (!this.weaponController.isEquipped)
			{
				return;
			}
			if (!this.firstClicked)
			{
				this.firstClicked = true;
				if (this.clickTime == 0f)
				{
					this.clickTime = Time.time;
				}
			}
		}
		if (this.firstClicked && OVRInput.Get(OVRInput.Button.PrimaryThumbstick, this.controlManager.controller))
		{
			float num = (Time.time - this.clickTime) / this.timeToActivate;
			if (num > 1f)
			{
				num = 1f;
			}
			this.weaponAdjustmentArrows.toggleProgressInner.transform.localScale = new Vector3(num, num, num);
			if (Time.time > this.clickTime + this.timeToActivate)
			{
				this.Toggle();
				this.clickTime = 0f;
				this.firstClicked = false;
				this.weaponAdjustmentArrows.toggleProgressInner.transform.localScale = Vector3.zero;
				this.weaponAdjustmentArrows.toggleProgressOuter.SetActive(false);
			}
		}
		if (OVRInput.GetUp(OVRInput.Button.PrimaryThumbstick, this.controlManager.controller))
		{
			this.clickTime = 0f;
			this.weaponAdjustmentArrows.toggleProgressOuter.SetActive(false);
			this.firstClicked = false;
		}
	}

	// Token: 0x06000403 RID: 1027 RVA: 0x0001B02C File Offset: 0x0001922C
	private void Toggle()
	{
		if (this.mode < 3)
		{
			this.mode++;
			this.weaponController.DisableControls(true);
			return;
		}
		this.mode = 0;
		this.weaponAdjustmentArrows.Reset();
		this.weaponController.DisableControls(false);
		this.playerData.SaveWeaponTransform(this.weaponController.WeaponID(), this.weaponTransform.transform.localPosition, this.weaponTransform.localRotation);
	}

	// Token: 0x06000404 RID: 1028 RVA: 0x0001B0AC File Offset: 0x000192AC
	private void UpdateArrowPosition()
	{
		this.arrowObject.transform.parent = this.weaponController.transform;
		this.arrowObject.transform.position = this.weaponController.adjustmentArrowsTransform.position;
		this.arrowObject.transform.localScale = this.weaponController.adjustmentArrowsTransform.localScale;
		this.arrowObject.transform.rotation = this.weaponController.adjustmentArrowsTransform.rotation;
	}

	// Token: 0x06000405 RID: 1029 RVA: 0x0001B134 File Offset: 0x00019334
	private void Adjustment()
	{
		float num = 0.2f;
		float num2 = 0.001f;
		Vector2 vector = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, this.controlManager.controller);
		this.weaponAdjustmentArrows.Adjust(this.mode, vector.x, vector.y);
		if (this.mode == 1)
		{
			if (Mathf.Abs(vector.x) > num || Mathf.Abs(vector.y) > num)
			{
				this.weaponTransform.transform.localPosition = new Vector3(this.weaponTransform.transform.localPosition.x + vector.x * num2, this.weaponTransform.transform.localPosition.y, this.weaponTransform.transform.localPosition.z + vector.y * num2);
				return;
			}
		}
		else if (this.mode == 2)
		{
			if (Mathf.Abs(vector.x) > num || Mathf.Abs(vector.y) > num)
			{
				this.weaponTransform.transform.Rotate(vector.y * 0.2f, vector.x * 0.2f, 0f);
				return;
			}
		}
		else if (this.mode == 3 && (Mathf.Abs(vector.x) > num || Mathf.Abs(vector.y) > num))
		{
			this.weaponTransform.transform.position = new Vector3(this.weaponTransform.transform.position.x, this.weaponTransform.transform.position.y + vector.y * num2, this.weaponTransform.transform.position.z);
			this.weaponTransform.transform.Rotate(0f, 0f, -vector.x * 0.2f);
		}
	}

	// Token: 0x06000406 RID: 1030 RVA: 0x0001B313 File Offset: 0x00019513
	private void DoubleClickTimeOut()
	{
		this.firstClicked = false;
	}

	// Token: 0x06000407 RID: 1031 RVA: 0x0001B31C File Offset: 0x0001951C
	private void OnDestroy()
	{
		GameEvents.current.onHolsterDraw -= this.OnHolsterDraw;
		GameEvents.current.onHolster -= this.OnHolster;
	}

	// Token: 0x04000507 RID: 1287
	[SerializeField]
	private Transform weaponTransform;

	// Token: 0x04000508 RID: 1288
	[SerializeField]
	private float doubleClickTime = 0.5f;

	// Token: 0x04000509 RID: 1289
	[SerializeField]
	private GameObject adjustmentArrows;

	// Token: 0x0400050A RID: 1290
	[SerializeField]
	private float timeToActivate = 1f;

	// Token: 0x0400050B RID: 1291
	private bool firstClicked;

	// Token: 0x0400050C RID: 1292
	private bool active;

	// Token: 0x0400050D RID: 1293
	private ControlManager controlManager;

	// Token: 0x0400050E RID: 1294
	private PlayerData playerData;

	// Token: 0x0400050F RID: 1295
	private WeaponController weaponController;

	// Token: 0x04000510 RID: 1296
	private GameObject arrowObject;

	// Token: 0x04000511 RID: 1297
	private WeaponAdjustmentArrows weaponAdjustmentArrows;

	// Token: 0x04000512 RID: 1298
	private int mode;

	// Token: 0x04000513 RID: 1299
	private float startTime;

	// Token: 0x04000514 RID: 1300
	private float clickTime;
}
