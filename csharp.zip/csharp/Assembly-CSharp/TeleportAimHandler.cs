﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200011B RID: 283
public abstract class TeleportAimHandler : TeleportSupport
{
	// Token: 0x06000765 RID: 1893 RVA: 0x0002E6D5 File Offset: 0x0002C8D5
	protected override void OnEnable()
	{
		base.OnEnable();
		base.LocomotionTeleport.AimHandler = this;
	}

	// Token: 0x06000766 RID: 1894 RVA: 0x0002E6E9 File Offset: 0x0002C8E9
	protected override void OnDisable()
	{
		if (base.LocomotionTeleport.AimHandler == this)
		{
			base.LocomotionTeleport.AimHandler = null;
		}
		base.OnDisable();
	}

	// Token: 0x06000767 RID: 1895
	public abstract void GetPoints(List<Vector3> points);
}
