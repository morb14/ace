﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x0200006B RID: 107
public class WeaponModification : MonoBehaviour
{
	// Token: 0x060003E5 RID: 997 RVA: 0x0001A030 File Offset: 0x00018230
	private void Awake()
	{
		this.controlManager = Object.FindObjectOfType<ControlManager>();
		SceneManager.sceneLoaded += this.OnSceneLoaded;
	}

	// Token: 0x060003E6 RID: 998 RVA: 0x0001A050 File Offset: 0x00018250
	private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
	{
		if (scene.buildIndex != 0)
		{
			this.weapon = Object.FindObjectOfType<WeaponController>();
			this.holsterVolume = Object.FindObjectOfType<HolsterVolume>();
			this.ActivateButtons(true, true);
			this.TransformToVice();
			this.ActivateHolster(false);
			if (this.weapon.chokes.Length != 0)
			{
				this.ActivateChokeCone(true);
			}
		}
	}

	// Token: 0x060003E7 RID: 999 RVA: 0x0001A0A6 File Offset: 0x000182A6
	private void Update()
	{
		this.ToggleButtons();
	}

	// Token: 0x060003E8 RID: 1000 RVA: 0x0001A0B0 File Offset: 0x000182B0
	private void ToggleButtons()
	{
		if (OVRInput.Get(OVRInput.Touch.PrimaryIndexTrigger, this.controlManager.controller) && this.toToggle.Count > 0)
		{
			if (!this.buttonsEnabled)
			{
				foreach (GameObject gameObject in this.toToggle)
				{
					if (gameObject == null)
					{
						this.toToggle.Remove(gameObject);
					}
					else
					{
						gameObject.SetActive(true);
					}
				}
				this.buttonsEnabled = true;
				return;
			}
		}
		else if (this.buttonsEnabled)
		{
			foreach (GameObject gameObject2 in this.toToggle)
			{
				if (gameObject2 == null)
				{
					this.toToggle.Remove(gameObject2);
				}
				else
				{
					gameObject2.SetActive(false);
				}
			}
			this.buttonsEnabled = false;
		}
	}

	// Token: 0x060003E9 RID: 1001 RVA: 0x0001A1BC File Offset: 0x000183BC
	private void ActivateChokeCone(bool state)
	{
		foreach (GameObject gameObject in this.weapon.chokes)
		{
			if (gameObject.activeSelf)
			{
				gameObject.GetComponent<MeshRenderer>().enabled = state;
			}
		}
	}

	// Token: 0x060003EA RID: 1002 RVA: 0x0001A1FB File Offset: 0x000183FB
	private void ActivateHolster(bool state)
	{
		this.holsterVolume.gameObject.SetActive(state);
	}

	// Token: 0x060003EB RID: 1003 RVA: 0x0001A210 File Offset: 0x00018410
	private void ActivateButtons(bool state, bool skip = false)
	{
		this.modButtons = this.weapon.GetComponentsInChildren<WeaponModificationButton>(true);
		foreach (WeaponModificationButton weaponModificationButton in this.modButtons)
		{
			if (!skip)
			{
				weaponModificationButton.gameObject.SetActive(state);
			}
			this.toToggle.Add(weaponModificationButton.gameObject);
		}
	}

	// Token: 0x060003EC RID: 1004 RVA: 0x0001A268 File Offset: 0x00018468
	public void TransformToVice()
	{
		this.weapon = Object.FindObjectOfType<WeaponController>();
		this.originalRotation = this.weapon.gameObject.transform.localRotation;
		this.originalPosition = this.weapon.gameObject.transform.localPosition;
		this.originalTransform = this.weapon.gameObject.transform.parent.transform;
		MonoBehaviour.print("transfer to vice from " + this.originalTransform.name);
		this.weapon.gameObject.transform.parent = null;
		this.weapon.gameObject.transform.position = base.transform.position;
		this.weapon.gameObject.transform.rotation = base.transform.rotation;
		if (!this.weapon.magazineToBeDisabled.activeSelf)
		{
			this.weapon.magazineToBeDisabled.SetActive(true);
		}
	}

	// Token: 0x060003ED RID: 1005 RVA: 0x0001A36C File Offset: 0x0001856C
	private void ReturnWeaponToHolster()
	{
		this.weapon.gameObject.transform.parent = this.originalTransform;
		this.weapon.gameObject.transform.localPosition = this.originalPosition;
		this.weapon.gameObject.transform.localRotation = this.originalRotation;
	}

	// Token: 0x060003EE RID: 1006 RVA: 0x0001A3CA File Offset: 0x000185CA
	private void OnDestroy()
	{
		this.ReturnWeaponToHolster();
		this.ActivateButtons(false, false);
		this.ActivateChokeCone(false);
		this.ActivateHolster(true);
		this.toToggle.Clear();
		SceneManager.sceneLoaded -= this.OnSceneLoaded;
	}

	// Token: 0x040004E2 RID: 1250
	private Vector3 originalPosition;

	// Token: 0x040004E3 RID: 1251
	private Quaternion originalRotation;

	// Token: 0x040004E4 RID: 1252
	private WeaponController weapon;

	// Token: 0x040004E5 RID: 1253
	private HolsterVolume holsterVolume;

	// Token: 0x040004E6 RID: 1254
	private List<GameObject> toToggle = new List<GameObject>();

	// Token: 0x040004E7 RID: 1255
	private Transform originalTransform;

	// Token: 0x040004E8 RID: 1256
	private ControlManager controlManager;

	// Token: 0x040004E9 RID: 1257
	private bool buttonsEnabled;

	// Token: 0x040004EA RID: 1258
	private WeaponModificationButton[] modButtons;
}
