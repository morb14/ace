﻿using System;
using UnityEngine;

// Token: 0x02000074 RID: 116
public class LightCookie : MonoBehaviour
{
	// Token: 0x06000452 RID: 1106 RVA: 0x0001D54B File Offset: 0x0001B74B
	private void Start()
	{
		this.light.cookie = this.cookieTexture;
	}

	// Token: 0x04000586 RID: 1414
	public Texture cookieTexture;

	// Token: 0x04000587 RID: 1415
	[SerializeField]
	private Light light;
}
