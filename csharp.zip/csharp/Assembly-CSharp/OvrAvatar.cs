﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using Oculus.Avatar;
using UnityEngine;

// Token: 0x020000AB RID: 171
public class OvrAvatar : MonoBehaviour
{
	// Token: 0x060005A7 RID: 1447 RVA: 0x00023EC8 File Offset: 0x000220C8
	static OvrAvatar()
	{
		string[,] array = new string[2, 5];
		array[0, 0] = "hands:r_hand_world";
		array[0, 1] = "hands:r_hand_world/hands:b_r_hand/hands:b_r_index1";
		array[0, 2] = "hands:r_hand_world/hands:b_r_hand/hands:b_r_index1/hands:b_r_index2/hands:b_r_index3/hands:b_r_index_ignore";
		array[0, 3] = "hands:r_hand_world/hands:b_r_hand/hands:b_r_thumb1/hands:b_r_thumb2";
		array[0, 4] = "hands:r_hand_world/hands:b_r_hand/hands:b_r_thumb1/hands:b_r_thumb2/hands:b_r_thumb3/hands:b_r_thumb_ignore";
		array[1, 0] = "hands:l_hand_world";
		array[1, 1] = "hands:l_hand_world/hands:b_l_hand/hands:b_l_index1";
		array[1, 2] = "hands:l_hand_world/hands:b_l_hand/hands:b_l_index1/hands:b_l_index2/hands:b_l_index3/hands:b_l_index_ignore";
		array[1, 3] = "hands:l_hand_world/hands:b_l_hand/hands:b_l_thumb1/hands:b_l_thumb2";
		array[1, 4] = "hands:l_hand_world/hands:b_l_hand/hands:b_l_thumb1/hands:b_l_thumb2/hands:b_l_thumb3/hands:b_l_thumb_ignore";
		OvrAvatar.HandJoints = array;
		OvrAvatar.MOUTH_POSITION_OFFSET = new Vector3(0f, -0.018f, 0.1051f);
		OvrAvatar.VOICE_PROPERTY = "_Voice";
		OvrAvatar.MOUTH_POSITION_PROPERTY = "_MouthPosition";
		OvrAvatar.MOUTH_DIRECTION_PROPERTY = "_MouthDirection";
		OvrAvatar.MOUTH_SCALE_PROPERTY = "_MouthEffectScale";
		OvrAvatar.MOUTH_SCALE_GLOBAL = 0.007f;
		OvrAvatar.MOUTH_MAX_GLOBAL = 0.007f;
		OvrAvatar.NECK_JONT = "root_JNT/body_JNT/chest_JNT/neckBase_JNT/neck_JNT";
		OvrAvatar.ovrLights = default(ovrAvatarLights);
		OvrAvatar.RuntimeVisemes.visemeParams = new float[32];
		OvrAvatar.RuntimeVisemes.visemeParamCount = 16U;
	}

	// Token: 0x060005A8 RID: 1448 RVA: 0x00024009 File Offset: 0x00022209
	private void OnDestroy()
	{
		if (this.sdkAvatar != IntPtr.Zero)
		{
			CAPI.ovrAvatar_Destroy(this.sdkAvatar);
		}
	}

	// Token: 0x060005A9 RID: 1449 RVA: 0x00024028 File Offset: 0x00022228
	public void AssetLoadedCallback(OvrAvatarAsset asset)
	{
		this.assetLoadingIds.Remove(asset.assetID);
	}

	// Token: 0x060005AA RID: 1450 RVA: 0x0002403C File Offset: 0x0002223C
	public void CombinedMeshLoadedCallback(IntPtr assetPtr)
	{
		if (!this.waitingForCombinedMesh)
		{
			return;
		}
		foreach (ulong item in CAPI.ovrAvatarAsset_GetCombinedMeshIDs(assetPtr))
		{
			this.assetLoadingIds.Remove(item);
		}
		CAPI.ovrAvatar_GetCombinedMeshAlphaData(this.sdkAvatar, ref this.clothingAlphaTexture, ref this.clothingAlphaOffset);
		this.waitingForCombinedMesh = false;
	}

	// Token: 0x060005AB RID: 1451 RVA: 0x00024096 File Offset: 0x00022296
	private OvrAvatarSkinnedMeshRenderComponent AddSkinnedMeshRenderComponent(GameObject gameObject, ovrAvatarRenderPart_SkinnedMeshRender skinnedMeshRender)
	{
		OvrAvatarSkinnedMeshRenderComponent ovrAvatarSkinnedMeshRenderComponent = gameObject.AddComponent<OvrAvatarSkinnedMeshRenderComponent>();
		ovrAvatarSkinnedMeshRenderComponent.Initialize(skinnedMeshRender, this.Monochrome_SurfaceShader, this.Monochrome_SurfaceShader_SelfOccluding, this.ThirdPersonLayer.layerIndex, this.FirstPersonLayer.layerIndex);
		return ovrAvatarSkinnedMeshRenderComponent;
	}

	// Token: 0x060005AC RID: 1452 RVA: 0x000240C7 File Offset: 0x000222C7
	private OvrAvatarSkinnedMeshRenderPBSComponent AddSkinnedMeshRenderPBSComponent(GameObject gameObject, ovrAvatarRenderPart_SkinnedMeshRenderPBS skinnedMeshRenderPBS)
	{
		OvrAvatarSkinnedMeshRenderPBSComponent ovrAvatarSkinnedMeshRenderPBSComponent = gameObject.AddComponent<OvrAvatarSkinnedMeshRenderPBSComponent>();
		ovrAvatarSkinnedMeshRenderPBSComponent.Initialize(skinnedMeshRenderPBS, this.Monochrome_SurfaceShader_PBS, this.ThirdPersonLayer.layerIndex, this.FirstPersonLayer.layerIndex);
		return ovrAvatarSkinnedMeshRenderPBSComponent;
	}

	// Token: 0x060005AD RID: 1453 RVA: 0x000240F4 File Offset: 0x000222F4
	private OvrAvatarSkinnedMeshPBSV2RenderComponent AddSkinnedMeshRenderPBSV2Component(IntPtr renderPart, GameObject go, ovrAvatarRenderPart_SkinnedMeshRenderPBS_V2 skinnedMeshRenderPBSV2, bool isBodyPartZero, bool isControllerModel)
	{
		OvrAvatarSkinnedMeshPBSV2RenderComponent ovrAvatarSkinnedMeshPBSV2RenderComponent = go.AddComponent<OvrAvatarSkinnedMeshPBSV2RenderComponent>();
		ovrAvatarSkinnedMeshPBSV2RenderComponent.Initialize(renderPart, skinnedMeshRenderPBSV2, this.materialManager, this.ThirdPersonLayer.layerIndex, this.FirstPersonLayer.layerIndex, isBodyPartZero && this.CombineMeshes, this.LevelOfDetail, isBodyPartZero && this.EnableExpressive, this, isControllerModel);
		return ovrAvatarSkinnedMeshPBSV2RenderComponent;
	}

	// Token: 0x060005AE RID: 1454 RVA: 0x0002414E File Offset: 0x0002234E
	public static IntPtr GetRenderPart(ovrAvatarComponent component, uint renderPartIndex)
	{
		return Marshal.ReadIntPtr(component.renderParts, Marshal.SizeOf(typeof(IntPtr)) * (int)renderPartIndex);
	}

	// Token: 0x060005AF RID: 1455 RVA: 0x0002416C File Offset: 0x0002236C
	private static string GetRenderPartName(ovrAvatarComponent component, uint renderPartIndex)
	{
		return component.name + "_renderPart_" + (int)renderPartIndex;
	}

	// Token: 0x060005B0 RID: 1456 RVA: 0x00024184 File Offset: 0x00022384
	internal static void ConvertTransform(float[] transform, ref ovrAvatarTransform target)
	{
		target.position.x = transform[0];
		target.position.y = transform[1];
		target.position.z = transform[2];
		target.orientation.x = transform[3];
		target.orientation.y = transform[4];
		target.orientation.z = transform[5];
		target.orientation.w = transform[6];
		target.scale.x = transform[7];
		target.scale.y = transform[8];
		target.scale.z = transform[9];
	}

	// Token: 0x060005B1 RID: 1457 RVA: 0x00024220 File Offset: 0x00022420
	internal static void ConvertTransform(ovrAvatarTransform transform, Transform target)
	{
		Vector3 position = transform.position;
		position.z = -position.z;
		Quaternion orientation = transform.orientation;
		orientation.x = -orientation.x;
		orientation.y = -orientation.y;
		target.localPosition = position;
		target.localRotation = orientation;
		target.localScale = transform.scale;
	}

	// Token: 0x060005B2 RID: 1458 RVA: 0x00024280 File Offset: 0x00022480
	public static ovrAvatarTransform CreateOvrAvatarTransform(Vector3 position, Quaternion orientation)
	{
		return new ovrAvatarTransform
		{
			position = new Vector3(position.x, position.y, -position.z),
			orientation = new Quaternion(-orientation.x, -orientation.y, orientation.z, orientation.w),
			scale = Vector3.one
		};
	}

	// Token: 0x060005B3 RID: 1459 RVA: 0x000242E8 File Offset: 0x000224E8
	private static ovrAvatarGazeTarget CreateOvrGazeTarget(uint targetId, Vector3 targetPosition, ovrAvatarGazeTargetType targetType)
	{
		return new ovrAvatarGazeTarget
		{
			id = targetId,
			worldPosition = new Vector3(targetPosition.x, targetPosition.y, -targetPosition.z),
			type = targetType
		};
	}

	// Token: 0x060005B4 RID: 1460 RVA: 0x00024330 File Offset: 0x00022530
	private void BuildRenderComponents()
	{
		ovrAvatarBaseComponent ovrAvatarBaseComponent = default(ovrAvatarBaseComponent);
		ovrAvatarHandComponent ovrAvatarHandComponent = default(ovrAvatarHandComponent);
		ovrAvatarHandComponent ovrAvatarHandComponent2 = default(ovrAvatarHandComponent);
		ovrAvatarControllerComponent ovrAvatarControllerComponent = default(ovrAvatarControllerComponent);
		ovrAvatarControllerComponent ovrAvatarControllerComponent2 = default(ovrAvatarControllerComponent);
		ovrAvatarBodyComponent ovrAvatarBodyComponent = default(ovrAvatarBodyComponent);
		ovrAvatarComponent nativeComponent = default(ovrAvatarComponent);
		if (CAPI.ovrAvatarPose_GetLeftHandComponent(this.sdkAvatar, ref ovrAvatarHandComponent))
		{
			CAPI.ovrAvatarComponent_Get(ovrAvatarHandComponent.renderComponent, true, ref nativeComponent);
			this.AddAvatarComponent<OvrAvatarHand>(ref this.HandLeft, nativeComponent);
			this.HandLeft.isLeftHand = true;
		}
		if (CAPI.ovrAvatarPose_GetRightHandComponent(this.sdkAvatar, ref ovrAvatarHandComponent2))
		{
			CAPI.ovrAvatarComponent_Get(ovrAvatarHandComponent2.renderComponent, true, ref nativeComponent);
			this.AddAvatarComponent<OvrAvatarHand>(ref this.HandRight, nativeComponent);
			this.HandRight.isLeftHand = false;
		}
		if (CAPI.ovrAvatarPose_GetBodyComponent(this.sdkAvatar, ref ovrAvatarBodyComponent))
		{
			CAPI.ovrAvatarComponent_Get(ovrAvatarBodyComponent.renderComponent, true, ref nativeComponent);
			this.AddAvatarComponent<OvrAvatarBody>(ref this.Body, nativeComponent);
		}
		if (CAPI.ovrAvatarPose_GetLeftControllerComponent(this.sdkAvatar, ref ovrAvatarControllerComponent))
		{
			CAPI.ovrAvatarComponent_Get(ovrAvatarControllerComponent.renderComponent, true, ref nativeComponent);
			this.AddAvatarComponent<OvrAvatarTouchController>(ref this.ControllerLeft, nativeComponent);
			this.ControllerLeft.isLeftHand = true;
		}
		if (CAPI.ovrAvatarPose_GetRightControllerComponent(this.sdkAvatar, ref ovrAvatarControllerComponent2))
		{
			CAPI.ovrAvatarComponent_Get(ovrAvatarControllerComponent2.renderComponent, true, ref nativeComponent);
			this.AddAvatarComponent<OvrAvatarTouchController>(ref this.ControllerRight, nativeComponent);
			this.ControllerRight.isLeftHand = false;
		}
		if (CAPI.ovrAvatarPose_GetBaseComponent(this.sdkAvatar, ref ovrAvatarBaseComponent))
		{
			CAPI.ovrAvatarComponent_Get(ovrAvatarBaseComponent.renderComponent, true, ref nativeComponent);
			this.AddAvatarComponent<OvrAvatarBase>(ref this.Base, nativeComponent);
		}
	}

	// Token: 0x060005B5 RID: 1461 RVA: 0x000244AC File Offset: 0x000226AC
	private void AddAvatarComponent<T>(ref T root, ovrAvatarComponent nativeComponent) where T : OvrAvatarComponent
	{
		GameObject gameObject = new GameObject();
		gameObject.name = nativeComponent.name;
		gameObject.transform.SetParent(base.transform);
		root = gameObject.AddComponent<T>();
		root.SetOvrAvatarOwner(this);
		this.AddRenderParts(root, nativeComponent, gameObject.transform);
	}

	// Token: 0x060005B6 RID: 1462 RVA: 0x00024510 File Offset: 0x00022710
	private void UpdateCustomPoses()
	{
		if (OvrAvatar.UpdatePoseRoot(this.LeftHandCustomPose, ref this.cachedLeftHandCustomPose, ref this.cachedCustomLeftHandJoints, ref this.cachedLeftHandTransforms) && this.cachedLeftHandCustomPose == null && this.sdkAvatar != IntPtr.Zero)
		{
			CAPI.ovrAvatar_SetLeftHandGesture(this.sdkAvatar, ovrAvatarHandGesture.Default);
		}
		if (OvrAvatar.UpdatePoseRoot(this.RightHandCustomPose, ref this.cachedRightHandCustomPose, ref this.cachedCustomRightHandJoints, ref this.cachedRightHandTransforms) && this.cachedRightHandCustomPose == null && this.sdkAvatar != IntPtr.Zero)
		{
			CAPI.ovrAvatar_SetRightHandGesture(this.sdkAvatar, ovrAvatarHandGesture.Default);
		}
		if (this.sdkAvatar != IntPtr.Zero)
		{
			if (this.cachedLeftHandCustomPose != null && OvrAvatar.UpdateTransforms(this.cachedCustomLeftHandJoints, this.cachedLeftHandTransforms))
			{
				CAPI.ovrAvatar_SetLeftHandCustomGesture(this.sdkAvatar, (uint)this.cachedLeftHandTransforms.Length, this.cachedLeftHandTransforms);
			}
			if (this.cachedRightHandCustomPose != null && OvrAvatar.UpdateTransforms(this.cachedCustomRightHandJoints, this.cachedRightHandTransforms))
			{
				CAPI.ovrAvatar_SetRightHandCustomGesture(this.sdkAvatar, (uint)this.cachedRightHandTransforms.Length, this.cachedRightHandTransforms);
			}
		}
	}

	// Token: 0x060005B7 RID: 1463 RVA: 0x0002463C File Offset: 0x0002283C
	private static bool UpdatePoseRoot(Transform poseRoot, ref Transform cachedPoseRoot, ref Transform[] cachedPoseJoints, ref ovrAvatarTransform[] transforms)
	{
		if (poseRoot == cachedPoseRoot)
		{
			return false;
		}
		if (!poseRoot)
		{
			cachedPoseRoot = null;
			cachedPoseJoints = null;
			transforms = null;
		}
		else
		{
			List<Transform> list = new List<Transform>();
			OvrAvatar.OrderJoints(poseRoot, list);
			cachedPoseRoot = poseRoot;
			cachedPoseJoints = list.ToArray();
			transforms = new ovrAvatarTransform[list.Count];
		}
		return true;
	}

	// Token: 0x060005B8 RID: 1464 RVA: 0x00024690 File Offset: 0x00022890
	private static bool UpdateTransforms(Transform[] joints, ovrAvatarTransform[] transforms)
	{
		bool result = false;
		for (int i = 0; i < joints.Length; i++)
		{
			Transform transform = joints[i];
			ovrAvatarTransform ovrAvatarTransform = OvrAvatar.CreateOvrAvatarTransform(transform.localPosition, transform.localRotation);
			if (ovrAvatarTransform.position != transforms[i].position || ovrAvatarTransform.orientation != transforms[i].orientation)
			{
				transforms[i] = ovrAvatarTransform;
				result = true;
			}
		}
		return result;
	}

	// Token: 0x060005B9 RID: 1465 RVA: 0x00024700 File Offset: 0x00022900
	private static void OrderJoints(Transform transform, List<Transform> joints)
	{
		joints.Add(transform);
		for (int i = 0; i < transform.childCount; i++)
		{
			OvrAvatar.OrderJoints(transform.GetChild(i), joints);
		}
	}

	// Token: 0x060005BA RID: 1466 RVA: 0x00024734 File Offset: 0x00022934
	private void AvatarSpecificationCallback(IntPtr avatarSpecification)
	{
		this.sdkAvatar = CAPI.ovrAvatar_Create(avatarSpecification, this.Capabilities);
		this.ShowLeftController(this.showLeftController);
		this.ShowRightController(this.showRightController);
		if (this.Driver != null)
		{
			this.Driver.UpdateTransformsFromPose(this.sdkAvatar);
		}
		uint num = CAPI.ovrAvatar_GetReferencedAssetCount(this.sdkAvatar);
		for (uint num2 = 0U; num2 < num; num2 += 1U)
		{
			ulong num3 = CAPI.ovrAvatar_GetReferencedAsset(this.sdkAvatar, num2);
			if (OvrAvatarSDKManager.Instance.GetAsset(num3) == null)
			{
				OvrAvatarSDKManager.Instance.BeginLoadingAsset(num3, this.LevelOfDetail, new assetLoadedCallback(this.AssetLoadedCallback));
				this.assetLoadingIds.Add(num3);
			}
		}
		if (this.CombineMeshes)
		{
			OvrAvatarSDKManager.Instance.RegisterCombinedMeshCallback(this.sdkAvatar, new combinedMeshLoadedCallback(this.CombinedMeshLoadedCallback));
		}
	}

	// Token: 0x060005BB RID: 1467 RVA: 0x0002480C File Offset: 0x00022A0C
	private void Start()
	{
		if (OvrAvatarSDKManager.Instance == null)
		{
			return;
		}
		this.materialManager = base.gameObject.AddComponent<OvrAvatarMaterialManager>();
		try
		{
			this.oculusUserIDInternal = ulong.Parse(this.oculusUserID);
		}
		catch (Exception)
		{
			this.oculusUserIDInternal = 0UL;
		}
		if (this.oculusUserIDInternal == 0UL)
		{
			this.CombineMeshes = false;
		}
		this.Capabilities = (ovrAvatarCapabilities)0;
		bool flag = false;
		OVRPlugin.SystemHeadset systemHeadsetType = OVRPlugin.GetSystemHeadsetType();
		if (systemHeadsetType <= OVRPlugin.SystemHeadset.Oculus_Quest)
		{
			if (systemHeadsetType - OVRPlugin.SystemHeadset.GearVR_R320 > 6)
			{
				if (systemHeadsetType != OVRPlugin.SystemHeadset.Oculus_Quest)
				{
				}
			}
			else
			{
				flag = true;
			}
		}
		else if (systemHeadsetType - OVRPlugin.SystemHeadset.Rift_DK1 > 2 && systemHeadsetType != OVRPlugin.SystemHeadset.Rift_S)
		{
		}
		if (flag && !this.EnableBody)
		{
			this.EnableBody = true;
			this.ShowFirstPerson = true;
			this.ShowThirdPerson = false;
		}
		if (this.EnableBody)
		{
			this.Capabilities |= ovrAvatarCapabilities.Body;
		}
		if (this.EnableHands)
		{
			this.Capabilities |= ovrAvatarCapabilities.Hands;
		}
		if (this.EnableBase && this.EnableBody)
		{
			this.Capabilities |= ovrAvatarCapabilities.Base;
		}
		if (this.EnableExpressive)
		{
			this.Capabilities |= ovrAvatarCapabilities.Expressive;
		}
		if (OVRPlugin.positionSupported)
		{
			this.Capabilities |= ovrAvatarCapabilities.BodyTilt;
		}
		this.ShowLeftController(this.StartWithControllers);
		this.ShowRightController(this.StartWithControllers);
		OvrAvatarSDKManager.AvatarSpecRequestParams avatarSpecRequest = new OvrAvatarSDKManager.AvatarSpecRequestParams(this.oculusUserIDInternal, new specificationCallback(this.AvatarSpecificationCallback), this.CombineMeshes, this.LevelOfDetail, true, this.LookAndFeelVersion, this.FallbackLookAndFeelVersion, this.EnableExpressive);
		OvrAvatarSDKManager.Instance.RequestAvatarSpecification(avatarSpecRequest);
		OvrAvatarSDKManager.Instance.AddLoadingAvatar(base.GetInstanceID());
		this.waitingForCombinedMesh = this.CombineMeshes;
		if (this.Driver != null)
		{
			this.Driver.Mode = (this.UseSDKPackets ? OvrAvatarDriver.PacketMode.SDK : OvrAvatarDriver.PacketMode.Unity);
		}
	}

	// Token: 0x060005BC RID: 1468 RVA: 0x000249E0 File Offset: 0x00022BE0
	private void Update()
	{
		if (!OvrAvatarSDKManager.Instance || this.sdkAvatar == IntPtr.Zero || this.materialManager == null)
		{
			return;
		}
		if (this.Driver != null)
		{
			this.Driver.UpdateTransforms(this.sdkAvatar);
			foreach (float[] pcmData in this.voiceUpdates)
			{
				CAPI.ovrAvatarPose_UpdateVoiceVisualization(this.sdkAvatar, pcmData);
			}
			this.voiceUpdates.Clear();
			CAPI.ovrAvatarPose_Finalize(this.sdkAvatar, Time.deltaTime);
		}
		if (this.RecordPackets)
		{
			this.RecordFrame();
		}
		if (this.assetLoadingIds.Count == 0)
		{
			if (!this.assetsFinishedLoading)
			{
				try
				{
					this.BuildRenderComponents();
				}
				catch (Exception ex)
				{
					this.assetsFinishedLoading = true;
					throw ex;
				}
				this.InitPostLoad();
				this.assetsFinishedLoading = true;
				OvrAvatarSDKManager.Instance.RemoveLoadingAvatar(base.GetInstanceID());
			}
			this.UpdateVoiceBehavior();
			this.UpdateCustomPoses();
			if (this.EnableExpressive)
			{
				this.UpdateExpressive();
			}
		}
	}

	// Token: 0x060005BD RID: 1469 RVA: 0x00024B18 File Offset: 0x00022D18
	public static ovrAvatarHandInputState CreateInputState(ovrAvatarTransform transform, OvrAvatarDriver.ControllerPose pose)
	{
		return new ovrAvatarHandInputState
		{
			transform = transform,
			buttonMask = pose.buttons,
			touchMask = pose.touches,
			joystickX = pose.joystickPosition.x,
			joystickY = pose.joystickPosition.y,
			indexTrigger = pose.indexTrigger,
			handTrigger = pose.handTrigger,
			isActive = pose.isActive
		};
	}

	// Token: 0x060005BE RID: 1470 RVA: 0x00024B9B File Offset: 0x00022D9B
	public void ShowControllers(bool show)
	{
		this.ShowLeftController(show);
		this.ShowRightController(show);
	}

	// Token: 0x060005BF RID: 1471 RVA: 0x00024BAB File Offset: 0x00022DAB
	public void ShowLeftController(bool show)
	{
		if (this.sdkAvatar != IntPtr.Zero)
		{
			CAPI.ovrAvatar_SetLeftControllerVisibility(this.sdkAvatar, show);
		}
		this.showLeftController = show;
	}

	// Token: 0x060005C0 RID: 1472 RVA: 0x00024BD2 File Offset: 0x00022DD2
	public void ShowRightController(bool show)
	{
		if (this.sdkAvatar != IntPtr.Zero)
		{
			CAPI.ovrAvatar_SetRightControllerVisibility(this.sdkAvatar, show);
		}
		this.showRightController = show;
	}

	// Token: 0x060005C1 RID: 1473 RVA: 0x00024BF9 File Offset: 0x00022DF9
	public void UpdateVoiceVisualization(float[] voiceSamples)
	{
		this.voiceUpdates.Add(voiceSamples);
	}

	// Token: 0x060005C2 RID: 1474 RVA: 0x00024C07 File Offset: 0x00022E07
	private void RecordFrame()
	{
		if (this.UseSDKPackets)
		{
			this.RecordSDKFrame();
			return;
		}
		this.RecordUnityFrame();
	}

	// Token: 0x060005C3 RID: 1475 RVA: 0x00024C20 File Offset: 0x00022E20
	private void RecordUnityFrame()
	{
		float num = Time.deltaTime;
		OvrAvatarDriver.PoseFrame currentPose = this.Driver.GetCurrentPose();
		if (this.CurrentUnityPacket == null)
		{
			this.CurrentUnityPacket = new OvrAvatarPacket(currentPose);
			num = 0f;
		}
		float num2 = 0f;
		while (num2 < num)
		{
			float num3 = num - num2;
			float num4 = this.PacketSettings.UpdateRate - this.CurrentUnityPacket.Duration;
			if (num3 < num4)
			{
				this.CurrentUnityPacket.AddFrame(currentPose, num3);
				num2 += num3;
			}
			else
			{
				OvrAvatarDriver.PoseFrame finalFrame = this.CurrentUnityPacket.FinalFrame;
				OvrAvatarDriver.PoseFrame b = currentPose;
				float t = num4 / num3;
				OvrAvatarDriver.PoseFrame poseFrame = OvrAvatarDriver.PoseFrame.Interpolate(finalFrame, b, t);
				this.CurrentUnityPacket.AddFrame(poseFrame, num4);
				num2 += num4;
				if (this.PacketRecorded != null)
				{
					this.PacketRecorded(this, new OvrAvatar.PacketEventArgs(this.CurrentUnityPacket));
				}
				this.CurrentUnityPacket = new OvrAvatarPacket(poseFrame);
			}
		}
	}

	// Token: 0x060005C4 RID: 1476 RVA: 0x00024D00 File Offset: 0x00022F00
	private void RecordSDKFrame()
	{
		if (this.sdkAvatar == IntPtr.Zero)
		{
			return;
		}
		if (!this.PacketSettings.RecordingFrames)
		{
			CAPI.ovrAvatarPacket_BeginRecording(this.sdkAvatar);
			this.PacketSettings.AccumulatedTime = 0f;
			this.PacketSettings.RecordingFrames = true;
		}
		this.PacketSettings.AccumulatedTime += Time.deltaTime;
		if (this.PacketSettings.AccumulatedTime >= this.PacketSettings.UpdateRate)
		{
			this.PacketSettings.AccumulatedTime = 0f;
			IntPtr intPtr = CAPI.ovrAvatarPacket_EndRecording(this.sdkAvatar);
			CAPI.ovrAvatarPacket_BeginRecording(this.sdkAvatar);
			if (this.PacketRecorded != null)
			{
				this.PacketRecorded(this, new OvrAvatar.PacketEventArgs(new OvrAvatarPacket
				{
					ovrNativePacket = intPtr
				}));
			}
			CAPI.ovrAvatarPacket_Free(intPtr);
		}
	}

	// Token: 0x060005C5 RID: 1477 RVA: 0x00024DD8 File Offset: 0x00022FD8
	private void AddRenderParts(OvrAvatarComponent ovrComponent, ovrAvatarComponent component, Transform parent)
	{
		bool flag = ovrComponent.name == "body";
		bool flag2 = ovrComponent.name == "controller_left";
		bool flag3 = ovrComponent.name == "controller_right";
		for (uint num = 0U; num < component.renderPartCount; num += 1U)
		{
			GameObject gameObject = new GameObject();
			gameObject.name = OvrAvatar.GetRenderPartName(component, num);
			gameObject.transform.SetParent(parent);
			IntPtr renderPart = OvrAvatar.GetRenderPart(component, num);
			ovrAvatarRenderPartType ovrAvatarRenderPartType = CAPI.ovrAvatarRenderPart_GetType(renderPart);
			OvrAvatarRenderComponent ovrAvatarRenderComponent = null;
			switch (ovrAvatarRenderPartType)
			{
			case ovrAvatarRenderPartType.SkinnedMeshRender:
				ovrAvatarRenderComponent = this.AddSkinnedMeshRenderComponent(gameObject, CAPI.ovrAvatarRenderPart_GetSkinnedMeshRender(renderPart));
				break;
			case ovrAvatarRenderPartType.SkinnedMeshRenderPBS:
				ovrAvatarRenderComponent = this.AddSkinnedMeshRenderPBSComponent(gameObject, CAPI.ovrAvatarRenderPart_GetSkinnedMeshRenderPBS(renderPart));
				break;
			case ovrAvatarRenderPartType.SkinnedMeshRenderPBS_V2:
				ovrAvatarRenderComponent = this.AddSkinnedMeshRenderPBSV2Component(renderPart, gameObject, CAPI.ovrAvatarRenderPart_GetSkinnedMeshRenderPBSV2(renderPart), flag && num == 0U, flag2 || flag3);
				break;
			}
			if (ovrAvatarRenderComponent != null)
			{
				ovrComponent.RenderParts.Add(ovrAvatarRenderComponent);
			}
		}
	}

	// Token: 0x060005C6 RID: 1478 RVA: 0x00024EDC File Offset: 0x000230DC
	public void RefreshBodyParts()
	{
		if (this.Body != null)
		{
			foreach (OvrAvatarRenderComponent ovrAvatarRenderComponent in this.Body.RenderParts)
			{
				Object.Destroy(ovrAvatarRenderComponent.gameObject);
			}
			this.Body.RenderParts.Clear();
			ovrAvatarComponent? nativeAvatarComponent = this.Body.GetNativeAvatarComponent();
			if (nativeAvatarComponent != null)
			{
				this.AddRenderParts(this.Body, nativeAvatarComponent.Value, this.Body.gameObject.transform);
			}
		}
	}

	// Token: 0x060005C7 RID: 1479 RVA: 0x00024F90 File Offset: 0x00023190
	public ovrAvatarBodyComponent? GetBodyComponent()
	{
		if (this.Body != null)
		{
			CAPI.ovrAvatarPose_GetBodyComponent(this.sdkAvatar, ref this.Body.component);
			return new ovrAvatarBodyComponent?(this.Body.component);
		}
		return null;
	}

	// Token: 0x060005C8 RID: 1480 RVA: 0x00024FDC File Offset: 0x000231DC
	public Transform GetHandTransform(OvrAvatar.HandType hand, OvrAvatar.HandJoint joint)
	{
		if (hand >= OvrAvatar.HandType.Max || joint >= OvrAvatar.HandJoint.Max)
		{
			return null;
		}
		OvrAvatarHand ovrAvatarHand = (hand == OvrAvatar.HandType.Left) ? this.HandLeft : this.HandRight;
		if (ovrAvatarHand != null)
		{
			OvrAvatarComponent component = ovrAvatarHand.GetComponent<OvrAvatarComponent>();
			if (component != null && component.RenderParts.Count > 0)
			{
				return component.RenderParts[0].transform.Find(OvrAvatar.HandJoints[(int)hand, (int)joint]);
			}
		}
		return null;
	}

	// Token: 0x060005C9 RID: 1481 RVA: 0x00025054 File Offset: 0x00023254
	public void GetPointingDirection(OvrAvatar.HandType hand, ref Vector3 forward, ref Vector3 up)
	{
		Transform handTransform = this.GetHandTransform(hand, OvrAvatar.HandJoint.HandBase);
		if (handTransform != null)
		{
			forward = handTransform.forward;
			up = handTransform.up;
		}
	}

	// Token: 0x060005CA RID: 1482 RVA: 0x0002508C File Offset: 0x0002328C
	private void UpdateVoiceBehavior()
	{
		if (!this.EnableMouthVertexAnimation)
		{
			return;
		}
		if (this.Body != null)
		{
			OvrAvatarComponent component = this.Body.GetComponent<OvrAvatarComponent>();
			this.VoiceAmplitude = Mathf.Clamp(this.VoiceAmplitude, 0f, 1f);
			if (component.RenderParts.Count > 0)
			{
				Material sharedMaterial = component.RenderParts[0].mesh.sharedMaterial;
				Transform transform = component.RenderParts[0].mesh.transform.Find(OvrAvatar.NECK_JONT);
				Vector3 vector = transform.TransformPoint(Vector3.up) - transform.position;
				sharedMaterial.SetFloat(OvrAvatar.MOUTH_SCALE_PROPERTY, vector.magnitude);
				sharedMaterial.SetFloat(OvrAvatar.VOICE_PROPERTY, Mathf.Min(vector.magnitude * OvrAvatar.MOUTH_MAX_GLOBAL, vector.magnitude * this.VoiceAmplitude * OvrAvatar.MOUTH_SCALE_GLOBAL));
				sharedMaterial.SetVector(OvrAvatar.MOUTH_POSITION_PROPERTY, transform.TransformPoint(OvrAvatar.MOUTH_POSITION_OFFSET));
				sharedMaterial.SetVector(OvrAvatar.MOUTH_DIRECTION_PROPERTY, transform.up);
			}
		}
	}

	// Token: 0x060005CB RID: 1483 RVA: 0x000251AC File Offset: 0x000233AC
	private bool IsValidMic()
	{
		string[] devices = Microphone.devices;
		if (devices.Length < 1)
		{
			return false;
		}
		int num = 0;
		string deviceName = devices[num];
		int num2;
		int num3;
		Microphone.GetDeviceCaps(deviceName, out num2, out num3);
		if (num3 == 0)
		{
			num3 = 44100;
		}
		if (Microphone.Start(deviceName, true, 1, num3) == null)
		{
			return false;
		}
		Microphone.End(deviceName);
		return true;
	}

	// Token: 0x060005CC RID: 1484 RVA: 0x00025200 File Offset: 0x00023400
	private void InitPostLoad()
	{
		OvrAvatar.ExpressiveGlobalInit();
		this.ConfigureHelpers();
		if (base.GetComponent<OvrAvatarLocalDriver>() != null)
		{
			this.lipsyncContext.audioLoopback = false;
			if (this.CanOwnMicrophone && this.IsValidMic())
			{
				this.micInput = this.MouthAnchor.gameObject.AddComponent<OVRLipSyncMicInput>();
				this.micInput.enableMicSelectionGUI = false;
				this.micInput.MicFrequency = 44100f;
				this.micInput.micControl = OVRLipSyncMicInput.micActivation.ConstantSpeak;
			}
			CAPI.ovrAvatar_SetActionUnitOnsetSpeed(this.sdkAvatar, 30f);
			CAPI.ovrAvatar_SetActionUnitFalloffSpeed(this.sdkAvatar, 20f);
			CAPI.ovrAvatar_SetVisemeMultiplier(this.sdkAvatar, 1.5f);
		}
	}

	// Token: 0x060005CD RID: 1485 RVA: 0x000252B3 File Offset: 0x000234B3
	private static void ExpressiveGlobalInit()
	{
		if (OvrAvatar.doneExpressiveGlobalInit)
		{
			return;
		}
		OvrAvatar.doneExpressiveGlobalInit = true;
		OvrAvatar.ovrLights.lights = new ovrAvatarLight[16];
		OvrAvatar.InitializeLights();
	}

	// Token: 0x060005CE RID: 1486 RVA: 0x000252DC File Offset: 0x000234DC
	private static void InitializeLights()
	{
		OvrAvatar.ovrLights.ambientIntensity = RenderSettings.ambientLight.grayscale * 0.5f;
		Light[] array = Object.FindObjectsOfType(typeof(Light)) as Light[];
		int num = 0;
		while (num < array.Length && num < OvrAvatar.ovrLights.lights.Length)
		{
			Light light = array[num];
			if (light && light.enabled)
			{
				uint instanceID = (uint)light.transform.GetInstanceID();
				switch (light.type)
				{
				case LightType.Spot:
					OvrAvatar.CreateLightSpot(instanceID, light.transform.position, light.transform.forward, light.spotAngle, light.range, light.intensity, ref OvrAvatar.ovrLights.lights[num]);
					break;
				case LightType.Directional:
					OvrAvatar.CreateLightDirectional(instanceID, light.transform.forward, light.intensity, ref OvrAvatar.ovrLights.lights[num]);
					break;
				case LightType.Point:
					OvrAvatar.CreateLightPoint(instanceID, light.transform.position, light.range, light.intensity, ref OvrAvatar.ovrLights.lights[num]);
					break;
				}
			}
			num++;
		}
		OvrAvatar.ovrLights.lightCount = (uint)num;
		CAPI.ovrAvatar_UpdateLights(OvrAvatar.ovrLights);
	}

	// Token: 0x060005CF RID: 1487 RVA: 0x00025438 File Offset: 0x00023638
	private static ovrAvatarLight CreateLightDirectional(uint id, Vector3 direction, float intensity, ref ovrAvatarLight light)
	{
		light.id = id;
		light.type = ovrAvatarLightType.Direction;
		light.worldDirection = new Vector3(direction.x, direction.y, -direction.z);
		light.intensity = intensity;
		return light;
	}

	// Token: 0x060005D0 RID: 1488 RVA: 0x00025474 File Offset: 0x00023674
	private static ovrAvatarLight CreateLightPoint(uint id, Vector3 position, float range, float intensity, ref ovrAvatarLight light)
	{
		light.id = id;
		light.type = ovrAvatarLightType.Point;
		light.worldPosition = new Vector3(position.x, position.y, -position.z);
		light.range = range;
		light.intensity = intensity;
		return light;
	}

	// Token: 0x060005D1 RID: 1489 RVA: 0x000254C8 File Offset: 0x000236C8
	private static ovrAvatarLight CreateLightSpot(uint id, Vector3 position, Vector3 direction, float spotAngleDeg, float range, float intensity, ref ovrAvatarLight light)
	{
		light.id = id;
		light.type = ovrAvatarLightType.Spot;
		light.worldPosition = new Vector3(position.x, position.y, -position.z);
		light.worldDirection = new Vector3(direction.x, direction.y, -direction.z);
		light.spotAngleDeg = spotAngleDeg;
		light.range = range;
		light.intensity = intensity;
		return light;
	}

	// Token: 0x060005D2 RID: 1490 RVA: 0x00025544 File Offset: 0x00023744
	private void UpdateExpressive()
	{
		ovrAvatarTransform transform = OvrAvatar.CreateOvrAvatarTransform(base.transform.position, base.transform.rotation);
		CAPI.ovrAvatar_UpdateWorldTransform(this.sdkAvatar, transform);
		this.UpdateFacewave();
	}

	// Token: 0x060005D3 RID: 1491 RVA: 0x00025580 File Offset: 0x00023780
	private void ConfigureHelpers()
	{
		Transform transform = base.transform.Find("body/body_renderPart_0/root_JNT/body_JNT/chest_JNT/neckBase_JNT/neck_JNT/head_JNT");
		if (transform == null)
		{
			transform = base.transform;
		}
		if (this.MouthAnchor == null)
		{
			this.MouthAnchor = this.CreateHelperObject(transform, OvrAvatar.MOUTH_HEAD_OFFSET, "MouthAnchor", "");
		}
		if (base.GetComponent<OvrAvatarLocalDriver>() != null)
		{
			if (this.audioSource == null)
			{
				this.audioSource = this.MouthAnchor.gameObject.AddComponent<AudioSource>();
			}
			this.spatializedSource = this.MouthAnchor.GetComponent<ONSPAudioSource>();
			if (this.spatializedSource == null)
			{
				this.spatializedSource = this.MouthAnchor.gameObject.AddComponent<ONSPAudioSource>();
			}
			this.spatializedSource.UseInvSqr = true;
			this.spatializedSource.EnableRfl = false;
			this.spatializedSource.EnableSpatialization = true;
			this.spatializedSource.Far = 100f;
			this.spatializedSource.Near = 0.1f;
			this.lipsyncContext = this.MouthAnchor.GetComponent<OVRLipSyncContext>();
			if (this.lipsyncContext == null)
			{
				this.lipsyncContext = this.MouthAnchor.gameObject.AddComponent<OVRLipSyncContext>();
			}
			this.lipsyncContext.provider = (this.EnableLaughter ? OVRLipSync.ContextProviders.Enhanced_with_Laughter : OVRLipSync.ContextProviders.Enhanced);
			this.lipsyncContext.skipAudioSource = !this.CanOwnMicrophone;
			base.StartCoroutine(this.WaitForMouthAudioSource());
		}
		if (base.GetComponent<OvrAvatarRemoteDriver>() != null)
		{
			transform.gameObject.AddComponent<GazeTarget>().Type = ovrAvatarGazeTargetType.AvatarHead;
			Transform transform2 = base.transform.Find("hand_left");
			if (!(transform2 == null))
			{
				transform2.gameObject.AddComponent<GazeTarget>().Type = ovrAvatarGazeTargetType.AvatarHand;
			}
			transform2 = base.transform.Find("hand_right");
			if (!(transform2 == null))
			{
				transform2.gameObject.AddComponent<GazeTarget>().Type = ovrAvatarGazeTargetType.AvatarHand;
			}
		}
	}

	// Token: 0x060005D4 RID: 1492 RVA: 0x00025768 File Offset: 0x00023968
	private IEnumerator WaitForMouthAudioSource()
	{
		while (this.MouthAnchor.GetComponent<AudioSource>() == null)
		{
			yield return new WaitForSeconds(0.1f);
		}
		AudioSource component = this.MouthAnchor.GetComponent<AudioSource>();
		component.minDistance = 0.3f;
		component.maxDistance = 4f;
		component.rolloffMode = AudioRolloffMode.Logarithmic;
		component.loop = true;
		component.playOnAwake = true;
		component.spatialBlend = 1f;
		component.spatialize = true;
		component.spatializePostEffects = true;
		yield break;
	}

	// Token: 0x060005D5 RID: 1493 RVA: 0x00025777 File Offset: 0x00023977
	public void DestroyHelperObjects()
	{
		if (this.MouthAnchor)
		{
			Object.DestroyImmediate(this.MouthAnchor.gameObject);
		}
	}

	// Token: 0x060005D6 RID: 1494 RVA: 0x00025798 File Offset: 0x00023998
	public GameObject CreateHelperObject(Transform parent, Vector3 localPositionOffset, string helperName, string helperTag = "")
	{
		GameObject gameObject = new GameObject();
		gameObject.name = helperName;
		if (helperTag != "")
		{
			gameObject.tag = helperTag;
		}
		gameObject.transform.SetParent(parent);
		gameObject.transform.localRotation = Quaternion.identity;
		gameObject.transform.localPosition = localPositionOffset;
		return gameObject;
	}

	// Token: 0x060005D7 RID: 1495 RVA: 0x000257F1 File Offset: 0x000239F1
	public void UpdateVoiceData(short[] pcmData, int numChannels)
	{
		if (this.lipsyncContext != null && this.micInput == null)
		{
			this.lipsyncContext.ProcessAudioSamplesRaw(pcmData, numChannels);
		}
	}

	// Token: 0x060005D8 RID: 1496 RVA: 0x0002581C File Offset: 0x00023A1C
	public void UpdateVoiceData(float[] pcmData, int numChannels)
	{
		if (this.lipsyncContext != null && this.micInput == null)
		{
			this.lipsyncContext.ProcessAudioSamplesRaw(pcmData, numChannels);
		}
	}

	// Token: 0x060005D9 RID: 1497 RVA: 0x00025848 File Offset: 0x00023A48
	private void UpdateFacewave()
	{
		if (this.lipsyncContext != null && (this.micInput != null || !this.CanOwnMicrophone))
		{
			this.currentFrame = this.lipsyncContext.GetCurrentPhonemeFrame();
			if (this.currentFrame.Visemes.Length != 15)
			{
				Debug.LogError("Unexpected number of visemes " + this.currentFrame.Visemes);
				return;
			}
			this.currentFrame.Visemes.CopyTo(this.visemes, 0);
			this.visemes[15] = (this.EnableLaughter ? this.currentFrame.laughterScore : 0f);
			for (int i = 0; i < 16; i++)
			{
				OvrAvatar.RuntimeVisemes.visemeParams[i] = this.visemes[i];
			}
			CAPI.ovrAvatar_SetVisemes(this.sdkAvatar, OvrAvatar.RuntimeVisemes);
		}
	}

	// Token: 0x040006B7 RID: 1719
	[Header("Avatar")]
	public IntPtr sdkAvatar = IntPtr.Zero;

	// Token: 0x040006B8 RID: 1720
	public string oculusUserID;

	// Token: 0x040006B9 RID: 1721
	public OvrAvatarDriver Driver;

	// Token: 0x040006BA RID: 1722
	[Header("Capabilities")]
	public bool EnableBody = true;

	// Token: 0x040006BB RID: 1723
	public bool EnableHands = true;

	// Token: 0x040006BC RID: 1724
	public bool EnableBase = true;

	// Token: 0x040006BD RID: 1725
	public bool EnableExpressive;

	// Token: 0x040006BE RID: 1726
	[Header("Network")]
	public bool RecordPackets;

	// Token: 0x040006BF RID: 1727
	public bool UseSDKPackets = true;

	// Token: 0x040006C0 RID: 1728
	public PacketRecordSettings PacketSettings = new PacketRecordSettings();

	// Token: 0x040006C1 RID: 1729
	[Header("Visibility")]
	public bool StartWithControllers;

	// Token: 0x040006C2 RID: 1730
	public AvatarLayer FirstPersonLayer;

	// Token: 0x040006C3 RID: 1731
	public AvatarLayer ThirdPersonLayer;

	// Token: 0x040006C4 RID: 1732
	public bool ShowFirstPerson = true;

	// Token: 0x040006C5 RID: 1733
	public bool ShowThirdPerson;

	// Token: 0x040006C6 RID: 1734
	internal ovrAvatarCapabilities Capabilities = ovrAvatarCapabilities.Body;

	// Token: 0x040006C7 RID: 1735
	[Header("Performance")]
	[Tooltip("LOD mesh complexity and texture resolution. Highest LOD recommended on PC and simple mobile apps. Medium LOD recommended on mobile devices or for background characters on PC. Lowest LOD recommended for background characters on mobile.")]
	[SerializeField]
	internal ovrAvatarAssetLevelOfDetail LevelOfDetail = ovrAvatarAssetLevelOfDetail.Medium;

	// Token: 0x040006C8 RID: 1736
	[Tooltip("Enable to use combined meshes to reduce draw calls. Currently only available on mobile devices. Will be forced to false on PC.")]
	private bool CombineMeshes = true;

	// Token: 0x040006C9 RID: 1737
	[Tooltip("Enable to use transparent queue, disable to use geometry queue. Requires restart to take effect.")]
	public bool UseTransparentRenderQueue = true;

	// Token: 0x040006CA RID: 1738
	[Header("Shaders")]
	public Shader Monochrome_SurfaceShader;

	// Token: 0x040006CB RID: 1739
	public Shader Monochrome_SurfaceShader_SelfOccluding;

	// Token: 0x040006CC RID: 1740
	public Shader Monochrome_SurfaceShader_PBS;

	// Token: 0x040006CD RID: 1741
	public Shader Skinshaded_SurfaceShader_SingleComponent;

	// Token: 0x040006CE RID: 1742
	public Shader Skinshaded_VertFrag_SingleComponent;

	// Token: 0x040006CF RID: 1743
	public Shader Skinshaded_VertFrag_CombinedMesh;

	// Token: 0x040006D0 RID: 1744
	public Shader Skinshaded_Expressive_SurfaceShader_SingleComponent;

	// Token: 0x040006D1 RID: 1745
	public Shader Skinshaded_Expressive_VertFrag_SingleComponent;

	// Token: 0x040006D2 RID: 1746
	public Shader Skinshaded_Expressive_VertFrag_CombinedMesh;

	// Token: 0x040006D3 RID: 1747
	public Shader Loader_VertFrag_CombinedMesh;

	// Token: 0x040006D4 RID: 1748
	public Shader EyeLens;

	// Token: 0x040006D5 RID: 1749
	public Shader ControllerShader;

	// Token: 0x040006D6 RID: 1750
	[Header("Other")]
	public bool CanOwnMicrophone = true;

	// Token: 0x040006D7 RID: 1751
	[Tooltip("Enable laughter detection and animation as part of OVRLipSync.")]
	public bool EnableLaughter = true;

	// Token: 0x040006D8 RID: 1752
	public GameObject MouthAnchor;

	// Token: 0x040006D9 RID: 1753
	public Transform LeftHandCustomPose;

	// Token: 0x040006DA RID: 1754
	public Transform RightHandCustomPose;

	// Token: 0x040006DB RID: 1755
	private HashSet<ulong> assetLoadingIds = new HashSet<ulong>();

	// Token: 0x040006DC RID: 1756
	private bool assetsFinishedLoading;

	// Token: 0x040006DD RID: 1757
	private OvrAvatarMaterialManager materialManager;

	// Token: 0x040006DE RID: 1758
	private bool waitingForCombinedMesh;

	// Token: 0x040006DF RID: 1759
	private static bool doneExpressiveGlobalInit = false;

	// Token: 0x040006E0 RID: 1760
	private Vector4 clothingAlphaOffset = new Vector4(0f, 0f, 0f, 1f);

	// Token: 0x040006E1 RID: 1761
	private ulong clothingAlphaTexture;

	// Token: 0x040006E2 RID: 1762
	private OVRLipSyncMicInput micInput;

	// Token: 0x040006E3 RID: 1763
	private OVRLipSyncContext lipsyncContext;

	// Token: 0x040006E4 RID: 1764
	private OVRLipSync.Frame currentFrame = new OVRLipSync.Frame();

	// Token: 0x040006E5 RID: 1765
	private float[] visemes = new float[16];

	// Token: 0x040006E6 RID: 1766
	private AudioSource audioSource;

	// Token: 0x040006E7 RID: 1767
	private ONSPAudioSource spatializedSource;

	// Token: 0x040006E8 RID: 1768
	private List<float[]> voiceUpdates = new List<float[]>();

	// Token: 0x040006E9 RID: 1769
	private static ovrAvatarVisemes RuntimeVisemes;

	// Token: 0x040006EA RID: 1770
	private Transform cachedLeftHandCustomPose;

	// Token: 0x040006EB RID: 1771
	private Transform[] cachedCustomLeftHandJoints;

	// Token: 0x040006EC RID: 1772
	private ovrAvatarTransform[] cachedLeftHandTransforms;

	// Token: 0x040006ED RID: 1773
	private Transform cachedRightHandCustomPose;

	// Token: 0x040006EE RID: 1774
	private Transform[] cachedCustomRightHandJoints;

	// Token: 0x040006EF RID: 1775
	private ovrAvatarTransform[] cachedRightHandTransforms;

	// Token: 0x040006F0 RID: 1776
	private bool showLeftController;

	// Token: 0x040006F1 RID: 1777
	private bool showRightController;

	// Token: 0x040006F2 RID: 1778
	private const bool USE_MOBILE_TEXTURE_FORMAT = true;

	// Token: 0x040006F3 RID: 1779
	private static readonly Vector3 MOUTH_HEAD_OFFSET = new Vector3(0f, -0.085f, 0.09f);

	// Token: 0x040006F4 RID: 1780
	private const string MOUTH_HELPER_NAME = "MouthAnchor";

	// Token: 0x040006F5 RID: 1781
	private const int VISEME_COUNT = 16;

	// Token: 0x040006F6 RID: 1782
	private const float ACTION_UNIT_ONSET_SPEED = 30f;

	// Token: 0x040006F7 RID: 1783
	private const float ACTION_UNIT_FALLOFF_SPEED = 20f;

	// Token: 0x040006F8 RID: 1784
	private const float VISEME_LEVEL_MULTIPLIER = 1.5f;

	// Token: 0x040006F9 RID: 1785
	internal ulong oculusUserIDInternal;

	// Token: 0x040006FA RID: 1786
	internal OvrAvatarBase Base;

	// Token: 0x040006FB RID: 1787
	internal OvrAvatarTouchController ControllerLeft;

	// Token: 0x040006FC RID: 1788
	internal OvrAvatarTouchController ControllerRight;

	// Token: 0x040006FD RID: 1789
	internal OvrAvatarBody Body;

	// Token: 0x040006FE RID: 1790
	internal OvrAvatarHand HandLeft;

	// Token: 0x040006FF RID: 1791
	internal OvrAvatarHand HandRight;

	// Token: 0x04000700 RID: 1792
	internal ovrAvatarLookAndFeelVersion LookAndFeelVersion = ovrAvatarLookAndFeelVersion.Two;

	// Token: 0x04000701 RID: 1793
	internal ovrAvatarLookAndFeelVersion FallbackLookAndFeelVersion = ovrAvatarLookAndFeelVersion.Two;

	// Token: 0x04000702 RID: 1794
	private OvrAvatarPacket CurrentUnityPacket;

	// Token: 0x04000703 RID: 1795
	public EventHandler<OvrAvatar.PacketEventArgs> PacketRecorded;

	// Token: 0x04000704 RID: 1796
	private static string[,] HandJoints;

	// Token: 0x04000705 RID: 1797
	private static Vector3 MOUTH_POSITION_OFFSET;

	// Token: 0x04000706 RID: 1798
	private static string VOICE_PROPERTY;

	// Token: 0x04000707 RID: 1799
	private static string MOUTH_POSITION_PROPERTY;

	// Token: 0x04000708 RID: 1800
	private static string MOUTH_DIRECTION_PROPERTY;

	// Token: 0x04000709 RID: 1801
	private static string MOUTH_SCALE_PROPERTY;

	// Token: 0x0400070A RID: 1802
	private static float MOUTH_SCALE_GLOBAL;

	// Token: 0x0400070B RID: 1803
	private static float MOUTH_MAX_GLOBAL;

	// Token: 0x0400070C RID: 1804
	private static string NECK_JONT;

	// Token: 0x0400070D RID: 1805
	public float VoiceAmplitude;

	// Token: 0x0400070E RID: 1806
	public bool EnableMouthVertexAnimation;

	// Token: 0x0400070F RID: 1807
	private static ovrAvatarLights ovrLights;

	// Token: 0x020001E8 RID: 488
	public class PacketEventArgs : EventArgs
	{
		// Token: 0x06000C32 RID: 3122 RVA: 0x0004406B File Offset: 0x0004226B
		public PacketEventArgs(OvrAvatarPacket packet)
		{
			this.Packet = packet;
		}

		// Token: 0x04000E37 RID: 3639
		public readonly OvrAvatarPacket Packet;
	}

	// Token: 0x020001E9 RID: 489
	public enum HandType
	{
		// Token: 0x04000E39 RID: 3641
		Right,
		// Token: 0x04000E3A RID: 3642
		Left,
		// Token: 0x04000E3B RID: 3643
		Max
	}

	// Token: 0x020001EA RID: 490
	public enum HandJoint
	{
		// Token: 0x04000E3D RID: 3645
		HandBase,
		// Token: 0x04000E3E RID: 3646
		IndexBase,
		// Token: 0x04000E3F RID: 3647
		IndexTip,
		// Token: 0x04000E40 RID: 3648
		ThumbBase,
		// Token: 0x04000E41 RID: 3649
		ThumbTip,
		// Token: 0x04000E42 RID: 3650
		Max
	}
}
