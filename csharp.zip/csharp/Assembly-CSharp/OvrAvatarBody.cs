﻿using System;
using Oculus.Avatar;
using UnityEngine;

// Token: 0x020000B0 RID: 176
public class OvrAvatarBody : OvrAvatarComponent
{
	// Token: 0x060005E5 RID: 1509 RVA: 0x00026504 File Offset: 0x00024704
	public ovrAvatarComponent? GetNativeAvatarComponent()
	{
		if (this.owner == null)
		{
			return null;
		}
		if (CAPI.ovrAvatarPose_GetBodyComponent(this.owner.sdkAvatar, ref this.component))
		{
			CAPI.ovrAvatarComponent_Get(this.component.renderComponent, true, ref this.nativeAvatarComponent);
			return new ovrAvatarComponent?(this.nativeAvatarComponent);
		}
		return null;
	}

	// Token: 0x060005E6 RID: 1510 RVA: 0x00026570 File Offset: 0x00024770
	private void Update()
	{
		if (this.owner == null)
		{
			return;
		}
		if (CAPI.ovrAvatarPose_GetBodyComponent(this.owner.sdkAvatar, ref this.component))
		{
			base.UpdateAvatar(this.component.renderComponent);
			return;
		}
		this.owner.Body = null;
		Object.Destroy(this);
	}

	// Token: 0x04000717 RID: 1815
	public ovrAvatarBodyComponent component;
}
