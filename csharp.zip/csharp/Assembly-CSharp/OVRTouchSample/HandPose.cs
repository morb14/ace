﻿using System;
using UnityEngine;

namespace OVRTouchSample
{
	// Token: 0x0200017D RID: 381
	public class HandPose : MonoBehaviour
	{
		// Token: 0x17000081 RID: 129
		// (get) Token: 0x06000A43 RID: 2627 RVA: 0x0003F063 File Offset: 0x0003D263
		public bool AllowPointing
		{
			get
			{
				return this.m_allowPointing;
			}
		}

		// Token: 0x17000082 RID: 130
		// (get) Token: 0x06000A44 RID: 2628 RVA: 0x0003F06B File Offset: 0x0003D26B
		public bool AllowThumbsUp
		{
			get
			{
				return this.m_allowThumbsUp;
			}
		}

		// Token: 0x17000083 RID: 131
		// (get) Token: 0x06000A45 RID: 2629 RVA: 0x0003F073 File Offset: 0x0003D273
		public HandPoseId PoseId
		{
			get
			{
				return this.m_poseId;
			}
		}

		// Token: 0x04000C07 RID: 3079
		[SerializeField]
		private bool m_allowPointing;

		// Token: 0x04000C08 RID: 3080
		[SerializeField]
		private bool m_allowThumbsUp;

		// Token: 0x04000C09 RID: 3081
		[SerializeField]
		private HandPoseId m_poseId;
	}
}
