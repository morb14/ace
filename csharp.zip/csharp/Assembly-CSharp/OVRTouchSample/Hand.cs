﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace OVRTouchSample
{
	// Token: 0x0200017B RID: 379
	[RequireComponent(typeof(OVRGrabber))]
	public class Hand : MonoBehaviour
	{
		// Token: 0x06000A37 RID: 2615 RVA: 0x0003EB54 File Offset: 0x0003CD54
		private void Awake()
		{
			this.m_grabber = base.GetComponent<OVRGrabber>();
		}

		// Token: 0x06000A38 RID: 2616 RVA: 0x0003EB64 File Offset: 0x0003CD64
		private void Start()
		{
			this.m_showAfterInputFocusAcquired = new List<Renderer>();
			this.m_colliders = (from childCollider in base.GetComponentsInChildren<Collider>()
			where !childCollider.isTrigger
			select childCollider).ToArray<Collider>();
			this.CollisionEnable(false);
			this.m_animLayerIndexPoint = this.m_animator.GetLayerIndex("Point Layer");
			this.m_animLayerIndexThumb = this.m_animator.GetLayerIndex("Thumb Layer");
			this.m_animParamIndexFlex = Animator.StringToHash("Flex");
			this.m_animParamIndexPose = Animator.StringToHash("Pose");
			OVRManager.InputFocusAcquired += this.OnInputFocusAcquired;
			OVRManager.InputFocusLost += this.OnInputFocusLost;
		}

		// Token: 0x06000A39 RID: 2617 RVA: 0x0003EC26 File Offset: 0x0003CE26
		private void OnDestroy()
		{
			OVRManager.InputFocusAcquired -= this.OnInputFocusAcquired;
			OVRManager.InputFocusLost -= this.OnInputFocusLost;
		}

		// Token: 0x06000A3A RID: 2618 RVA: 0x0003EC4C File Offset: 0x0003CE4C
		private void Update()
		{
			this.UpdateCapTouchStates();
			this.m_pointBlend = this.InputValueRateChange(this.m_isPointing, this.m_pointBlend);
			this.m_thumbsUpBlend = this.InputValueRateChange(this.m_isGivingThumbsUp, this.m_thumbsUpBlend);
			float num = OVRInput.Get(OVRInput.Axis1D.PrimaryHandTrigger, this.m_controller);
			bool enabled = this.m_grabber.grabbedObject == null && num >= 0.9f;
			this.CollisionEnable(enabled);
			this.UpdateAnimStates();
		}

		// Token: 0x06000A3B RID: 2619 RVA: 0x0003ECCB File Offset: 0x0003CECB
		private void UpdateCapTouchStates()
		{
			this.m_isPointing = !OVRInput.Get(OVRInput.NearTouch.PrimaryIndexTrigger, this.m_controller);
			this.m_isGivingThumbsUp = !OVRInput.Get(OVRInput.NearTouch.PrimaryThumbButtons, this.m_controller);
		}

		// Token: 0x06000A3C RID: 2620 RVA: 0x0003ECF8 File Offset: 0x0003CEF8
		private void LateUpdate()
		{
			if (this.m_collisionEnabled && this.m_collisionScaleCurrent + Mathf.Epsilon < 1f)
			{
				this.m_collisionScaleCurrent = Mathf.Min(1f, this.m_collisionScaleCurrent + Time.deltaTime * 1f);
				for (int i = 0; i < this.m_colliders.Length; i++)
				{
					this.m_colliders[i].transform.localScale = new Vector3(this.m_collisionScaleCurrent, this.m_collisionScaleCurrent, this.m_collisionScaleCurrent);
				}
			}
		}

		// Token: 0x06000A3D RID: 2621 RVA: 0x0003ED80 File Offset: 0x0003CF80
		private void OnInputFocusLost()
		{
			if (base.gameObject.activeInHierarchy)
			{
				this.m_showAfterInputFocusAcquired.Clear();
				Renderer[] componentsInChildren = base.GetComponentsInChildren<Renderer>();
				for (int i = 0; i < componentsInChildren.Length; i++)
				{
					if (componentsInChildren[i].enabled)
					{
						componentsInChildren[i].enabled = false;
						this.m_showAfterInputFocusAcquired.Add(componentsInChildren[i]);
					}
				}
				this.CollisionEnable(false);
				this.m_restoreOnInputAcquired = true;
			}
		}

		// Token: 0x06000A3E RID: 2622 RVA: 0x0003EDEC File Offset: 0x0003CFEC
		private void OnInputFocusAcquired()
		{
			if (this.m_restoreOnInputAcquired)
			{
				for (int i = 0; i < this.m_showAfterInputFocusAcquired.Count; i++)
				{
					if (this.m_showAfterInputFocusAcquired[i])
					{
						this.m_showAfterInputFocusAcquired[i].enabled = true;
					}
				}
				this.m_showAfterInputFocusAcquired.Clear();
				this.m_restoreOnInputAcquired = false;
			}
		}

		// Token: 0x06000A3F RID: 2623 RVA: 0x0003EE50 File Offset: 0x0003D050
		private float InputValueRateChange(bool isDown, float value)
		{
			float num = Time.deltaTime * 20f;
			float num2 = isDown ? 1f : -1f;
			return Mathf.Clamp01(value + num * num2);
		}

		// Token: 0x06000A40 RID: 2624 RVA: 0x0003EE84 File Offset: 0x0003D084
		private void UpdateAnimStates()
		{
			bool flag = this.m_grabber.grabbedObject != null;
			HandPose handPose = this.m_defaultGrabPose;
			if (flag)
			{
				HandPose component = this.m_grabber.grabbedObject.GetComponent<HandPose>();
				if (component != null)
				{
					handPose = component;
				}
			}
			HandPoseId poseId = handPose.PoseId;
			this.m_animator.SetInteger(this.m_animParamIndexPose, (int)poseId);
			float value = OVRInput.Get(OVRInput.Axis1D.PrimaryHandTrigger, this.m_controller);
			this.m_animator.SetFloat(this.m_animParamIndexFlex, value);
			float weight = (!flag || handPose.AllowPointing) ? this.m_pointBlend : 0f;
			this.m_animator.SetLayerWeight(this.m_animLayerIndexPoint, weight);
			float weight2 = (!flag || handPose.AllowThumbsUp) ? this.m_thumbsUpBlend : 0f;
			this.m_animator.SetLayerWeight(this.m_animLayerIndexThumb, weight2);
			float value2 = OVRInput.Get(OVRInput.Axis1D.PrimaryIndexTrigger, this.m_controller);
			this.m_animator.SetFloat("Pinch", value2);
		}

		// Token: 0x06000A41 RID: 2625 RVA: 0x0003EF80 File Offset: 0x0003D180
		private void CollisionEnable(bool enabled)
		{
			if (this.m_collisionEnabled == enabled)
			{
				return;
			}
			this.m_collisionEnabled = enabled;
			if (enabled)
			{
				this.m_collisionScaleCurrent = 0.01f;
				for (int i = 0; i < this.m_colliders.Length; i++)
				{
					Collider collider = this.m_colliders[i];
					collider.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
					collider.enabled = true;
				}
				return;
			}
			this.m_collisionScaleCurrent = 1f;
			for (int j = 0; j < this.m_colliders.Length; j++)
			{
				Collider collider2 = this.m_colliders[j];
				collider2.enabled = false;
				collider2.transform.localScale = new Vector3(0.01f, 0.01f, 0.01f);
			}
		}

		// Token: 0x04000BE6 RID: 3046
		public const string ANIM_LAYER_NAME_POINT = "Point Layer";

		// Token: 0x04000BE7 RID: 3047
		public const string ANIM_LAYER_NAME_THUMB = "Thumb Layer";

		// Token: 0x04000BE8 RID: 3048
		public const string ANIM_PARAM_NAME_FLEX = "Flex";

		// Token: 0x04000BE9 RID: 3049
		public const string ANIM_PARAM_NAME_POSE = "Pose";

		// Token: 0x04000BEA RID: 3050
		public const float THRESH_COLLISION_FLEX = 0.9f;

		// Token: 0x04000BEB RID: 3051
		public const float INPUT_RATE_CHANGE = 20f;

		// Token: 0x04000BEC RID: 3052
		public const float COLLIDER_SCALE_MIN = 0.01f;

		// Token: 0x04000BED RID: 3053
		public const float COLLIDER_SCALE_MAX = 1f;

		// Token: 0x04000BEE RID: 3054
		public const float COLLIDER_SCALE_PER_SECOND = 1f;

		// Token: 0x04000BEF RID: 3055
		public const float TRIGGER_DEBOUNCE_TIME = 0.05f;

		// Token: 0x04000BF0 RID: 3056
		public const float THUMB_DEBOUNCE_TIME = 0.15f;

		// Token: 0x04000BF1 RID: 3057
		[SerializeField]
		private OVRInput.Controller m_controller;

		// Token: 0x04000BF2 RID: 3058
		[SerializeField]
		private Animator m_animator;

		// Token: 0x04000BF3 RID: 3059
		[SerializeField]
		private HandPose m_defaultGrabPose;

		// Token: 0x04000BF4 RID: 3060
		private Collider[] m_colliders;

		// Token: 0x04000BF5 RID: 3061
		private bool m_collisionEnabled = true;

		// Token: 0x04000BF6 RID: 3062
		private OVRGrabber m_grabber;

		// Token: 0x04000BF7 RID: 3063
		private List<Renderer> m_showAfterInputFocusAcquired;

		// Token: 0x04000BF8 RID: 3064
		private int m_animLayerIndexThumb = -1;

		// Token: 0x04000BF9 RID: 3065
		private int m_animLayerIndexPoint = -1;

		// Token: 0x04000BFA RID: 3066
		private int m_animParamIndexFlex = -1;

		// Token: 0x04000BFB RID: 3067
		private int m_animParamIndexPose = -1;

		// Token: 0x04000BFC RID: 3068
		private bool m_isPointing;

		// Token: 0x04000BFD RID: 3069
		private bool m_isGivingThumbsUp;

		// Token: 0x04000BFE RID: 3070
		private float m_pointBlend;

		// Token: 0x04000BFF RID: 3071
		private float m_thumbsUpBlend;

		// Token: 0x04000C00 RID: 3072
		private bool m_restoreOnInputAcquired;

		// Token: 0x04000C01 RID: 3073
		private float m_collisionScaleCurrent;
	}
}
