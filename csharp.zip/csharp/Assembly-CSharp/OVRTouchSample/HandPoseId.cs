﻿using System;

namespace OVRTouchSample
{
	// Token: 0x0200017C RID: 380
	public enum HandPoseId
	{
		// Token: 0x04000C03 RID: 3075
		Default,
		// Token: 0x04000C04 RID: 3076
		Generic,
		// Token: 0x04000C05 RID: 3077
		PingPongBall,
		// Token: 0x04000C06 RID: 3078
		Controller
	}
}
