﻿using System;
using UnityEngine;

namespace OVRTouchSample
{
	// Token: 0x0200017E RID: 382
	public class TouchController : MonoBehaviour
	{
		// Token: 0x06000A47 RID: 2631 RVA: 0x0003F07C File Offset: 0x0003D27C
		private void Update()
		{
			this.m_animator.SetFloat("Button 1", OVRInput.Get(OVRInput.Button.One, this.m_controller) ? 1f : 0f);
			this.m_animator.SetFloat("Button 2", OVRInput.Get(OVRInput.Button.Two, this.m_controller) ? 1f : 0f);
			this.m_animator.SetFloat("Joy X", OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, this.m_controller).x);
			this.m_animator.SetFloat("Joy Y", OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, this.m_controller).y);
			this.m_animator.SetFloat("Grip", OVRInput.Get(OVRInput.Axis1D.PrimaryHandTrigger, this.m_controller));
			this.m_animator.SetFloat("Trigger", OVRInput.Get(OVRInput.Axis1D.PrimaryIndexTrigger, this.m_controller));
			OVRManager.InputFocusAcquired += this.OnInputFocusAcquired;
			OVRManager.InputFocusLost += this.OnInputFocusLost;
		}

		// Token: 0x06000A48 RID: 2632 RVA: 0x0003F179 File Offset: 0x0003D379
		private void OnInputFocusLost()
		{
			if (base.gameObject.activeInHierarchy)
			{
				base.gameObject.SetActive(false);
				this.m_restoreOnInputAcquired = true;
			}
		}

		// Token: 0x06000A49 RID: 2633 RVA: 0x0003F19B File Offset: 0x0003D39B
		private void OnInputFocusAcquired()
		{
			if (this.m_restoreOnInputAcquired)
			{
				base.gameObject.SetActive(true);
				this.m_restoreOnInputAcquired = false;
			}
		}

		// Token: 0x04000C0A RID: 3082
		[SerializeField]
		private OVRInput.Controller m_controller;

		// Token: 0x04000C0B RID: 3083
		[SerializeField]
		private Animator m_animator;

		// Token: 0x04000C0C RID: 3084
		private bool m_restoreOnInputAcquired;
	}
}
