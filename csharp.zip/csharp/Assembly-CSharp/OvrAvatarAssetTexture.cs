﻿using System;
using Oculus.Avatar;
using UnityEngine;

// Token: 0x020000AE RID: 174
public class OvrAvatarAssetTexture : OvrAvatarAsset
{
	// Token: 0x060005E2 RID: 1506 RVA: 0x000263A8 File Offset: 0x000245A8
	public OvrAvatarAssetTexture(ulong _assetId, IntPtr asset)
	{
		this.assetID = _assetId;
		ovrAvatarTextureAssetData ovrAvatarTextureAssetData = CAPI.ovrAvatarAsset_GetTextureData(asset);
		IntPtr textureData = ovrAvatarTextureAssetData.textureData;
		int num = (int)ovrAvatarTextureAssetData.textureDataSize;
		TextureFormat textureFormat;
		switch (ovrAvatarTextureAssetData.format)
		{
		case ovrAvatarTextureFormat.RGB24:
			textureFormat = TextureFormat.RGB24;
			break;
		case ovrAvatarTextureFormat.DXT1:
			textureFormat = TextureFormat.DXT1;
			break;
		case ovrAvatarTextureFormat.DXT5:
			textureFormat = TextureFormat.DXT5;
			break;
		case ovrAvatarTextureFormat.ASTC_RGB_6x6:
			textureFormat = TextureFormat.ASTC_6x6;
			textureData = new IntPtr(textureData.ToInt64() + 16L);
			num -= 16;
			break;
		case ovrAvatarTextureFormat.ASTC_RGB_6x6_MIPMAPS:
			textureFormat = TextureFormat.ASTC_6x6;
			break;
		default:
			throw new NotImplementedException(string.Format("Unsupported texture format {0}", ovrAvatarTextureAssetData.format.ToString()));
		}
		this.texture = new Texture2D((int)ovrAvatarTextureAssetData.sizeX, (int)ovrAvatarTextureAssetData.sizeY, textureFormat, ovrAvatarTextureAssetData.mipCount > 1U, QualitySettings.activeColorSpace != ColorSpace.Gamma)
		{
			filterMode = FilterMode.Trilinear,
			anisoLevel = 4
		};
		this.texture.LoadRawTextureData(textureData, num);
		this.texture.Apply(true, false);
	}

	// Token: 0x04000714 RID: 1812
	public Texture2D texture;

	// Token: 0x04000715 RID: 1813
	private const int ASTCHeaderSize = 16;
}
