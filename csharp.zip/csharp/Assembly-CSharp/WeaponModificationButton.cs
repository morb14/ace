﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x0200006C RID: 108
public class WeaponModificationButton : MonoBehaviour
{
	// Token: 0x060003F0 RID: 1008 RVA: 0x0001A418 File Offset: 0x00018618
	private void Start()
	{
		this.soundManager = Object.FindObjectOfType<SoundManager>();
		if (this.icon != null)
		{
			this.originalRotation = this.icon.transform.localRotation;
		}
		if (this.type == AccessoryManager.AccessoryType.Zero)
		{
			this.InitiateZero();
		}
		if (!Object.FindObjectOfType<WeaponModification>())
		{
			base.gameObject.SetActive(false);
		}
		if (this.icon != null && this.icon.transform.localScale != Vector3.one)
		{
			this.originalScale = this.icon.transform.localScale;
		}
		if (this.isEasterEgg)
		{
			this.InitiateEasterEgg();
		}
	}

	// Token: 0x060003F1 RID: 1009 RVA: 0x0001A4C9 File Offset: 0x000186C9
	public AccessoryManager.AccessoryType ButtonType()
	{
		return this.type;
	}

	// Token: 0x060003F2 RID: 1010 RVA: 0x0001A4D1 File Offset: 0x000186D1
	private void InitiateZero()
	{
		if (this.zeroes.Length == 0)
		{
			Object.Destroy(base.gameObject);
			return;
		}
		this.ChangeZero(this.currentZero);
	}

	// Token: 0x060003F3 RID: 1011 RVA: 0x0001A4F4 File Offset: 0x000186F4
	private void Update()
	{
		if (this.icon != null && (double)(Time.time - this.timeSelected) > 0.1)
		{
			this.icon.transform.localRotation = Quaternion.Lerp(this.icon.transform.localRotation, this.originalRotation, 0.2f);
		}
	}

	// Token: 0x060003F4 RID: 1012 RVA: 0x0001A557 File Offset: 0x00018757
	public void Highlight()
	{
		this.Spin();
	}

	// Token: 0x060003F5 RID: 1013 RVA: 0x0001A55F File Offset: 0x0001875F
	private void Spin()
	{
		if (this.icon != null)
		{
			this.icon.transform.Rotate(0f, this.rotateSpeed, 0f);
			this.timeSelected = Time.time;
		}
	}

	// Token: 0x060003F6 RID: 1014 RVA: 0x0001A59A File Offset: 0x0001879A
	private bool AllAccessoriesHaveIcons()
	{
		return this.backupOptics.Length == this.accessoryIcons.Length;
	}

	// Token: 0x060003F7 RID: 1015 RVA: 0x0001A5B4 File Offset: 0x000187B4
	public void Select()
	{
		if (this.weaponController == null)
		{
			this.weaponController = Object.FindObjectOfType<WeaponController>();
		}
		if (this.type == AccessoryManager.AccessoryType.BackupOptic && this.backupOptics.Length != 0)
		{
			for (int i = 0; i < this.backupOptics.Length; i++)
			{
				if (this.backupOpticDisabled)
				{
					this.backupOptics[0].SetActive(true);
					if (this.AllAccessoriesHaveIcons())
					{
						this.accessoryIcons[0].SetActive(true);
					}
					GameObject gameObject = this.backupOptics[0];
					this.backupOpticDisabled = false;
				}
				else if (this.backupOptics[i].activeSelf)
				{
					this.backupOptics[i].SetActive(false);
					if (this.AllAccessoriesHaveIcons())
					{
						this.accessoryIcons[i].SetActive(false);
					}
					if (i + 1 >= this.backupOptics.Length && !this.backupOpticDisabled && !this.neverEmpty)
					{
						this.backupOpticDisabled = true;
						break;
					}
					if (i + 1 >= this.backupOptics.Length && this.neverEmpty)
					{
						this.backupOptics[0].SetActive(true);
						if (this.AllAccessoriesHaveIcons())
						{
							this.accessoryIcons[0].SetActive(true);
						}
						GameObject gameObject2 = this.backupOptics[0];
						break;
					}
					this.backupOptics[i + 1].SetActive(true);
					if (this.AllAccessoriesHaveIcons())
					{
						this.accessoryIcons[i + 1].SetActive(true);
					}
					GameObject gameObject3 = this.backupOptics[i + 1];
					break;
				}
			}
		}
		else if (this.weaponController != null)
		{
			this.weaponController.CycleAttachments(this.type);
		}
		if (this.type == AccessoryManager.AccessoryType.MaterialColour && this.weaponController.holsterMaterialAssigner != null)
		{
			this.weaponController.holsterMaterialAssigner.SwitchSpecificMaterials();
		}
		if (this.type == AccessoryManager.AccessoryType.Zero && this.zeroes.Length > 1)
		{
			if (this.currentZero < this.zeroes.Length - 1)
			{
				this.currentZero++;
			}
			else
			{
				this.currentZero = 0;
			}
			this.ChangeZero(this.currentZero);
		}
		if (this.type == AccessoryManager.AccessoryType.Preset)
		{
			if (this.weaponController.presets.Length <= 1)
			{
				return;
			}
			if (this.specificPresetToggle != "")
			{
				if (this.weaponController.currentPreset == this.weaponController.GetPreset(this.specificPresetToggle))
				{
					this.weaponController.ChoosePreset(this.weaponController.previousPreset);
				}
				else
				{
					if (this.isEasterEgg)
					{
						this.soundManager.Play(this.soundManager.secretUnlocked);
					}
					this.weaponController.ChoosePreset(this.weaponController.GetPreset(this.specificPresetToggle));
				}
			}
			else
			{
				this.weaponController.CyclePreset(false);
			}
		}
		if (this.type == AccessoryManager.AccessoryType.MagazineAdjustment)
		{
			if (this.increaseMagAmmo)
			{
				if (this.weaponController.currentMagazineMax <= this.weaponController.GetCurrentCapacity())
				{
					this.buttonPressed++;
					this.soundManager.Play(this.soundManager.UIerror);
					GameEvents.current.BroadcastMessage("The magazine is full", false);
					base.Invoke("ButtonPressedReset", 1f);
					if (this.buttonPressed >= 5)
					{
						this.weaponController.magazineCapacity = 9999;
						this.weaponController.currentAmmo = this.weaponController.magazineCapacity;
						this.soundManager.Play(this.soundManager.secretUnlocked);
					}
				}
				else
				{
					this.weaponController.magazineCapacity++;
				}
			}
			else
			{
				if (this.weaponController.currentMagazineMax <= 1 || this.weaponController.magazineCapacity == 9999)
				{
					this.soundManager.Play(this.soundManager.UIerror);
				}
				else
				{
					this.weaponController.magazineCapacity--;
				}
				this.weaponController.currentAmmo = this.weaponController.magazineCapacity + 1;
			}
			GameEvents.current.WeaponModified();
		}
		if (this.icon != null)
		{
			this.icon.transform.localScale = new Vector3(this.icon.transform.localScale.x * this.iconScale, this.icon.transform.localScale.y * this.iconScale, this.icon.transform.localScale.z * this.iconScale);
		}
		base.Invoke("Rescale", 0.1f);
		this.soundManager.Play(this.soundManager.UIclick);
	}

	// Token: 0x060003F8 RID: 1016 RVA: 0x0001AA46 File Offset: 0x00018C46
	private void ButtonPressedReset()
	{
		this.buttonPressed = 0;
	}

	// Token: 0x060003F9 RID: 1017 RVA: 0x0001AA50 File Offset: 0x00018C50
	private void ChangeZero(int currentZero)
	{
		this.zeroText.text = this.zeroes[currentZero].ToString() + "yard";
		if (this.isReflex)
		{
			this.zeroObject.transform.localPosition = new Vector3(this.zeroObject.transform.localPosition.x, this.adjustmentValues[currentZero], this.zeroObject.transform.localPosition.z);
			return;
		}
		this.zeroObject.transform.localEulerAngles = new Vector3(this.adjustmentValues[currentZero], this.zeroObject.transform.localEulerAngles.y, this.zeroObject.transform.localEulerAngles.z);
	}

	// Token: 0x060003FA RID: 1018 RVA: 0x0001AB1C File Offset: 0x00018D1C
	private void InitiateEasterEgg()
	{
		if (this.hideUnlessPresent && this.weaponController.weaponID != this.easterEggForWeaponID)
		{
			base.gameObject.SetActive(false);
		}
		if (!this.hideUnlessPresent && this.weaponController.weaponID != this.easterEggForWeaponID)
		{
			base.GetComponent<Collider>().enabled = false;
			base.enabled = false;
		}
	}

	// Token: 0x060003FB RID: 1019 RVA: 0x0001AB88 File Offset: 0x00018D88
	private void Rescale()
	{
		if (this.icon != null)
		{
			if (this.originalScale != Vector3.zero)
			{
				this.icon.transform.localScale = this.originalScale;
				return;
			}
			this.icon.transform.localScale = Vector3.one;
		}
	}

	// Token: 0x040004EB RID: 1259
	[Header("General")]
	public WeaponController weaponController;

	// Token: 0x040004EC RID: 1260
	[SerializeField]
	private AccessoryManager.AccessoryType type;

	// Token: 0x040004ED RID: 1261
	[SerializeField]
	private Transform icon;

	// Token: 0x040004EE RID: 1262
	[SerializeField]
	private float rotateSpeed = 0.2f;

	// Token: 0x040004EF RID: 1263
	[SerializeField]
	private float iconScale = 1.1f;

	// Token: 0x040004F0 RID: 1264
	[SerializeField]
	private GameObject[] backupOptics;

	// Token: 0x040004F1 RID: 1265
	[SerializeField]
	private GameObject[] accessoryIcons;

	// Token: 0x040004F2 RID: 1266
	[SerializeField]
	private bool neverEmpty;

	// Token: 0x040004F3 RID: 1267
	public bool backupOpticDisabled;

	// Token: 0x040004F4 RID: 1268
	[Header("Zeroing")]
	[SerializeField]
	private GameObject zeroObject;

	// Token: 0x040004F5 RID: 1269
	[SerializeField]
	private bool isReflex;

	// Token: 0x040004F6 RID: 1270
	[SerializeField]
	private int currentZero;

	// Token: 0x040004F7 RID: 1271
	[SerializeField]
	private int[] zeroes;

	// Token: 0x040004F8 RID: 1272
	[SerializeField]
	private float[] adjustmentValues;

	// Token: 0x040004F9 RID: 1273
	[SerializeField]
	private TMP_Text zeroText;

	// Token: 0x040004FA RID: 1274
	[Header("Magazine Adjustment")]
	[SerializeField]
	private WeaponModificationAmmoCount ammoCountManager;

	// Token: 0x040004FB RID: 1275
	[SerializeField]
	private bool increaseMagAmmo;

	// Token: 0x040004FC RID: 1276
	[Header("Preset Toggle")]
	[SerializeField]
	private string specificPresetToggle;

	// Token: 0x040004FD RID: 1277
	[Header("EasterEgg Preset")]
	[SerializeField]
	private bool isEasterEgg;

	// Token: 0x040004FE RID: 1278
	[SerializeField]
	private bool hideUnlessPresent;

	// Token: 0x040004FF RID: 1279
	[SerializeField]
	private string easterEggForWeaponID;

	// Token: 0x04000500 RID: 1280
	private WeaponController.Preset previousPreset;

	// Token: 0x04000501 RID: 1281
	private Vector3 originalScale;

	// Token: 0x04000502 RID: 1282
	private float timeSelected;

	// Token: 0x04000503 RID: 1283
	private Quaternion originalRotation;

	// Token: 0x04000504 RID: 1284
	private SoundManager soundManager;

	// Token: 0x04000505 RID: 1285
	private int buttonPressed;

	// Token: 0x04000506 RID: 1286
	private bool selected;
}
