﻿using System;
using UnityEngine;

// Token: 0x02000025 RID: 37
public class BonusTarget : MonoBehaviour
{
	// Token: 0x060000B2 RID: 178 RVA: 0x00003297 File Offset: 0x00001497
	private void Start()
	{
	}

	// Token: 0x060000B3 RID: 179 RVA: 0x00005AF4 File Offset: 0x00003CF4
	public void BonusTargetHit(bool isHit)
	{
		this.hit = isHit;
	}

	// Token: 0x060000B4 RID: 180 RVA: 0x00005AFD File Offset: 0x00003CFD
	public bool GetHit()
	{
		return this.hit;
	}

	// Token: 0x040000B3 RID: 179
	public bool hit;

	// Token: 0x040000B4 RID: 180
	public bool hasPenalty;
}
