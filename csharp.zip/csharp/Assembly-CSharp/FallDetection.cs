﻿using System;
using UnityEngine;

// Token: 0x0200003A RID: 58
public class FallDetection : MonoBehaviour
{
	// Token: 0x060001F7 RID: 503 RVA: 0x0000AE84 File Offset: 0x00009084
	private void OnTriggerEnter(Collider other)
	{
		if (other.GetComponent<CharacterController>())
		{
			MonoBehaviour.print("PLAYER FELL, REPOSITIONED");
			other.GetComponent<CharacterController>().enabled = false;
			other.transform.position = this.spawnPoint.transform.position;
			other.GetComponent<CharacterController>().enabled = true;
		}
	}

	// Token: 0x040001AD RID: 429
	[SerializeField]
	private Transform spawnPoint;
}
