﻿using System;
using UnityEngine;

// Token: 0x020000EC RID: 236
public struct ovrAvatarGazeTarget
{
	// Token: 0x04000877 RID: 2167
	public uint id;

	// Token: 0x04000878 RID: 2168
	public Vector3 worldPosition;

	// Token: 0x04000879 RID: 2169
	public ovrAvatarGazeTargetType type;
}
