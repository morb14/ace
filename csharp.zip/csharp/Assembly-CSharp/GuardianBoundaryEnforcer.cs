﻿using System;
using UnityEngine;

// Token: 0x02000116 RID: 278
public class GuardianBoundaryEnforcer : MonoBehaviour
{
	// Token: 0x14000039 RID: 57
	// (add) Token: 0x06000717 RID: 1815 RVA: 0x0002D4CC File Offset: 0x0002B6CC
	// (remove) Token: 0x06000718 RID: 1816 RVA: 0x0002D504 File Offset: 0x0002B704
	public event Action TrackingChanged;

	// Token: 0x17000017 RID: 23
	// (get) Token: 0x06000719 RID: 1817 RVA: 0x0002D539 File Offset: 0x0002B739
	public Quaternion OrientToOriginalForward
	{
		get
		{
			return this.m_orientToOriginalForward;
		}
	}

	// Token: 0x0600071A RID: 1818 RVA: 0x0002D541 File Offset: 0x0002B741
	private void Start()
	{
		OVRManager.display.RecenteredPose += this.Recentered;
		this.m_originalTrackerOrientation = OVRPlugin.GetNodePose(OVRPlugin.Node.TrackerZero, OVRPlugin.Step.Render).ToOVRPose().orientation;
	}

	// Token: 0x0600071B RID: 1819 RVA: 0x0002D570 File Offset: 0x0002B770
	private void Update()
	{
		if (this.m_framecount >= 0)
		{
			this.m_framecount++;
			if (this.m_framecount > 2)
			{
				Quaternion orientation = OVRPlugin.GetNodePose(OVRPlugin.Node.TrackerZero, OVRPlugin.Step.Render).ToOVRPose().orientation;
				float num = orientation.eulerAngles.y - this.m_originalTrackerOrientation.eulerAngles.y;
				this.m_orientToOriginalForward = Quaternion.Euler(0f, -num, 0f);
				if (!this.m_AllowRecenter)
				{
					this.m_mainCamera.trackingSpace.transform.rotation = this.m_orientToOriginalForward;
				}
				this.m_framecount = -1;
				if (this.TrackingChanged != null)
				{
					this.TrackingChanged();
				}
			}
		}
	}

	// Token: 0x0600071C RID: 1820 RVA: 0x0002D627 File Offset: 0x0002B827
	private void Recentered()
	{
		this.m_framecount = 0;
	}

	// Token: 0x0400094C RID: 2380
	public bool m_AllowRecenter = true;

	// Token: 0x0400094D RID: 2381
	public OVRCameraRig m_mainCamera;

	// Token: 0x0400094E RID: 2382
	private Quaternion m_originalTrackerOrientation;

	// Token: 0x0400094F RID: 2383
	private int m_framecount;

	// Token: 0x04000950 RID: 2384
	private Quaternion m_orientToOriginalForward;
}
