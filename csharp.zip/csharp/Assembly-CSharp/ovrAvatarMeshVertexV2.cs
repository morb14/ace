﻿using System;
using System.Runtime.InteropServices;

// Token: 0x020000C1 RID: 193
public struct ovrAvatarMeshVertexV2
{
	// Token: 0x04000783 RID: 1923
	public float x;

	// Token: 0x04000784 RID: 1924
	public float y;

	// Token: 0x04000785 RID: 1925
	public float z;

	// Token: 0x04000786 RID: 1926
	public float nx;

	// Token: 0x04000787 RID: 1927
	public float ny;

	// Token: 0x04000788 RID: 1928
	public float nz;

	// Token: 0x04000789 RID: 1929
	public float tx;

	// Token: 0x0400078A RID: 1930
	public float ty;

	// Token: 0x0400078B RID: 1931
	public float tz;

	// Token: 0x0400078C RID: 1932
	public float tw;

	// Token: 0x0400078D RID: 1933
	public float u;

	// Token: 0x0400078E RID: 1934
	public float v;

	// Token: 0x0400078F RID: 1935
	public float r;

	// Token: 0x04000790 RID: 1936
	public float g;

	// Token: 0x04000791 RID: 1937
	public float b;

	// Token: 0x04000792 RID: 1938
	public float a;

	// Token: 0x04000793 RID: 1939
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
	public byte[] blendIndices;

	// Token: 0x04000794 RID: 1940
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
	public float[] blendWeights;
}
