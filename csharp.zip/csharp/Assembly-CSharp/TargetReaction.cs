﻿using System;
using UnityEngine;

// Token: 0x02000065 RID: 101
public class TargetReaction : MonoBehaviour
{
	// Token: 0x060003BA RID: 954 RVA: 0x00018C74 File Offset: 0x00016E74
	public void ImpactInfo(TargetReaction.TargetType type, int projectileSpeed, AudioClip clip = null, string zone = "")
	{
		this.impactHitZone = zone;
		if (zone != "")
		{
			if (zone == "Alpha")
			{
				this.paperHitIndicator.GetComponent<Outline>().OutlineColor = Color.green;
			}
			else if (zone == "Charlie")
			{
				this.paperHitIndicator.GetComponent<Outline>().OutlineColor = Color.yellow;
			}
			else if (zone == "Delta")
			{
				this.paperHitIndicator.GetComponent<Outline>().OutlineColor = new Color(1f, 0.64f, 0f);
			}
			else if (zone == "Missed")
			{
				this.paperHitIndicator.GetComponent<Outline>().OutlineColor = Color.red;
			}
		}
		this.impactType = type;
		this.speed = (float)projectileSpeed;
		if (clip != null)
		{
			this.originalSteelAudio = this.impactAudioSteel;
			this.impactAudioSteel = clip;
		}
		else if (this.originalSteelAudio != null)
		{
			this.impactAudioSteel = this.originalSteelAudio;
		}
		this.ResetAll();
		switch (type)
		{
		case TargetReaction.TargetType.Steel:
			this.generic.SetActive(false);
			this.steel.SetActive(true);
			return;
		case TargetReaction.TargetType.Paper:
			this.generic.SetActive(false);
			this.paper.SetActive(true);
			return;
		case TargetReaction.TargetType.Default:
			this.generic.SetActive(true);
			this.generic.transform.parent = null;
			base.Invoke("Reparent", 1f);
			return;
		default:
			return;
		}
	}

	// Token: 0x060003BB RID: 955 RVA: 0x00018DFA File Offset: 0x00016FFA
	public void ToggleHitIndicator(bool on)
	{
		if (on)
		{
			this.paperHitIndicator.SetActive(true);
			this.outline.enabled = true;
			return;
		}
		this.paperHitIndicator.SetActive(false);
		this.outline.enabled = false;
	}

	// Token: 0x060003BC RID: 956 RVA: 0x00018E30 File Offset: 0x00017030
	private void ResetAll()
	{
		this.generic.SetActive(false);
		this.steel.SetActive(false);
		this.paper.SetActive(false);
		this.dirt.SetActive(false);
	}

	// Token: 0x060003BD RID: 957 RVA: 0x00018E64 File Offset: 0x00017064
	private void OnEnable()
	{
		this.distance = Vector3.Distance(Camera.main.transform.position, base.transform.position);
		float time = this.distance / this.speed;
		this.impactEffect.gameObject.SetActive(true);
		if (this.impactType == TargetReaction.TargetType.Steel)
		{
			base.Invoke("DelayedAudio", time);
		}
	}

	// Token: 0x060003BE RID: 958 RVA: 0x00018ECC File Offset: 0x000170CC
	private void DelayedAudio()
	{
		if (this.audioSource == null)
		{
			this.audioSource = base.gameObject.AddComponent<AudioSource>();
		}
		this.audioSource.spatialBlend = 0f;
		if (this.distance < 150f)
		{
			this.audioSource.volume = Mathf.Abs(1f - this.distance / 150f);
		}
		else
		{
			this.audioSource.volume = 0.002f;
		}
		this.audioSource.PlayOneShot(this.impactAudioSteel);
		base.Invoke("Disable", this.impactAudioSteel.length);
	}

	// Token: 0x060003BF RID: 959 RVA: 0x00018F70 File Offset: 0x00017170
	private void Reparent()
	{
		this.generic.transform.parent = base.transform;
	}

	// Token: 0x060003C0 RID: 960 RVA: 0x00018F88 File Offset: 0x00017188
	private void Disable()
	{
		base.enabled = false;
	}

	// Token: 0x04000493 RID: 1171
	[SerializeField]
	private ParticleSystem impactEffect;

	// Token: 0x04000494 RID: 1172
	[SerializeField]
	private AudioClip impactAudioSteel;

	// Token: 0x04000495 RID: 1173
	[SerializeField]
	private GameObject generic;

	// Token: 0x04000496 RID: 1174
	[SerializeField]
	private GameObject paper;

	// Token: 0x04000497 RID: 1175
	[SerializeField]
	private GameObject steel;

	// Token: 0x04000498 RID: 1176
	[SerializeField]
	private GameObject dirt;

	// Token: 0x04000499 RID: 1177
	[SerializeField]
	private bool hitToRB;

	// Token: 0x0400049A RID: 1178
	[Header("Paper Hit Indicators")]
	public string impactHitZone;

	// Token: 0x0400049B RID: 1179
	[SerializeField]
	private GameObject paperHitIndicator;

	// Token: 0x0400049C RID: 1180
	[SerializeField]
	private Outline outline;

	// Token: 0x0400049D RID: 1181
	private TargetReaction.TargetType impactType;

	// Token: 0x0400049E RID: 1182
	private AudioSource audioSource;

	// Token: 0x0400049F RID: 1183
	private AudioClip originalSteelAudio;

	// Token: 0x040004A0 RID: 1184
	private float distance;

	// Token: 0x040004A1 RID: 1185
	private float speed;

	// Token: 0x020001D8 RID: 472
	public enum TargetType
	{
		// Token: 0x04000DE3 RID: 3555
		Steel,
		// Token: 0x04000DE4 RID: 3556
		Paper,
		// Token: 0x04000DE5 RID: 3557
		Default,
		// Token: 0x04000DE6 RID: 3558
		Other
	}
}
