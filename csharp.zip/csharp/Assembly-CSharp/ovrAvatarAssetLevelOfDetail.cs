﻿using System;

// Token: 0x020000D8 RID: 216
public enum ovrAvatarAssetLevelOfDetail
{
	// Token: 0x0400080B RID: 2059
	Lowest = 1,
	// Token: 0x0400080C RID: 2060
	Medium = 3,
	// Token: 0x0400080D RID: 2061
	Highest = 5
}
