﻿using System;

// Token: 0x020000D7 RID: 215
public enum ovrAvatarControllerType
{
	// Token: 0x04000805 RID: 2053
	Touch,
	// Token: 0x04000806 RID: 2054
	Malibu,
	// Token: 0x04000807 RID: 2055
	Go,
	// Token: 0x04000808 RID: 2056
	Quest,
	// Token: 0x04000809 RID: 2057
	Count
}
