﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x02000119 RID: 281
public class LocomotionTeleport : MonoBehaviour
{
	// Token: 0x06000726 RID: 1830 RVA: 0x0002D9EF File Offset: 0x0002BBEF
	public void EnableMovement(bool ready, bool aim, bool pre, bool post)
	{
		this.EnableMovementDuringReady = ready;
		this.EnableMovementDuringAim = aim;
		this.EnableMovementDuringPreTeleport = pre;
		this.EnableMovementDuringPostTeleport = post;
	}

	// Token: 0x06000727 RID: 1831 RVA: 0x0002DA0E File Offset: 0x0002BC0E
	public void EnableRotation(bool ready, bool aim, bool pre, bool post)
	{
		this.EnableRotationDuringReady = ready;
		this.EnableRotationDuringAim = aim;
		this.EnableRotationDuringPreTeleport = pre;
		this.EnableRotationDuringPostTeleport = post;
	}

	// Token: 0x17000018 RID: 24
	// (get) Token: 0x06000728 RID: 1832 RVA: 0x0002DA2D File Offset: 0x0002BC2D
	// (set) Token: 0x06000729 RID: 1833 RVA: 0x0002DA35 File Offset: 0x0002BC35
	public LocomotionTeleport.States CurrentState { get; private set; }

	// Token: 0x1400003A RID: 58
	// (add) Token: 0x0600072A RID: 1834 RVA: 0x0002DA40 File Offset: 0x0002BC40
	// (remove) Token: 0x0600072B RID: 1835 RVA: 0x0002DA78 File Offset: 0x0002BC78
	public event Action<bool, Vector3?, Quaternion?, Quaternion?> UpdateTeleportDestination;

	// Token: 0x0600072C RID: 1836 RVA: 0x0002DAAD File Offset: 0x0002BCAD
	public void OnUpdateTeleportDestination(bool isValidDestination, Vector3? position, Quaternion? rotation, Quaternion? landingRotation)
	{
		if (this.UpdateTeleportDestination != null)
		{
			this.UpdateTeleportDestination(isValidDestination, position, rotation, landingRotation);
		}
	}

	// Token: 0x17000019 RID: 25
	// (get) Token: 0x0600072D RID: 1837 RVA: 0x0002DAC7 File Offset: 0x0002BCC7
	public Quaternion DestinationRotation
	{
		get
		{
			return this._teleportDestination.OrientationIndicator.rotation;
		}
	}

	// Token: 0x1700001A RID: 26
	// (get) Token: 0x0600072E RID: 1838 RVA: 0x0002DAD9 File Offset: 0x0002BCD9
	// (set) Token: 0x0600072F RID: 1839 RVA: 0x0002DAE1 File Offset: 0x0002BCE1
	public LocomotionController LocomotionController { get; private set; }

	// Token: 0x06000730 RID: 1840 RVA: 0x0002DAEC File Offset: 0x0002BCEC
	public bool AimCollisionTest(Vector3 start, Vector3 end, LayerMask aimCollisionLayerMask, out RaycastHit hitInfo)
	{
		Vector3 a = end - start;
		float magnitude = a.magnitude;
		Vector3 direction = a / magnitude;
		switch (this.AimCollisionType)
		{
		case LocomotionTeleport.AimCollisionTypes.Point:
			return Physics.Raycast(start, direction, out hitInfo, magnitude, aimCollisionLayerMask, QueryTriggerInteraction.Ignore);
		case LocomotionTeleport.AimCollisionTypes.Sphere:
		{
			float radius;
			if (this.UseCharacterCollisionData)
			{
				radius = this.LocomotionController.CharacterController.radius;
			}
			else
			{
				radius = this.AimCollisionRadius;
			}
			return Physics.SphereCast(start, radius, direction, out hitInfo, magnitude, aimCollisionLayerMask, QueryTriggerInteraction.Ignore);
		}
		case LocomotionTeleport.AimCollisionTypes.Capsule:
		{
			float num;
			float num2;
			if (this.UseCharacterCollisionData)
			{
				CapsuleCollider characterController = this.LocomotionController.CharacterController;
				num = characterController.height;
				num2 = characterController.radius;
			}
			else
			{
				num = this.AimCollisionHeight;
				num2 = this.AimCollisionRadius;
			}
			return Physics.CapsuleCast(start + new Vector3(0f, num2, 0f), start + new Vector3(0f, num + num2, 0f), num2, direction, out hitInfo, magnitude, aimCollisionLayerMask, QueryTriggerInteraction.Ignore);
		}
		default:
			throw new Exception();
		}
	}

	// Token: 0x06000731 RID: 1841 RVA: 0x0002DBF6 File Offset: 0x0002BDF6
	[Conditional("DEBUG_TELEPORT_STATES")]
	protected void LogState(string msg)
	{
		Debug.Log(Time.frameCount + ": " + msg);
	}

	// Token: 0x06000732 RID: 1842 RVA: 0x0002DC14 File Offset: 0x0002BE14
	protected void CreateNewTeleportDestination()
	{
		this.TeleportDestinationPrefab.gameObject.SetActive(false);
		TeleportDestination teleportDestination = Object.Instantiate<TeleportDestination>(this.TeleportDestinationPrefab);
		teleportDestination.LocomotionTeleport = this;
		teleportDestination.gameObject.layer = this.TeleportDestinationLayer;
		this._teleportDestination = teleportDestination;
		this._teleportDestination.LocomotionTeleport = this;
	}

	// Token: 0x06000733 RID: 1843 RVA: 0x0002DC69 File Offset: 0x0002BE69
	private void DeactivateDestination()
	{
		this._teleportDestination.OnDeactivated();
	}

	// Token: 0x06000734 RID: 1844 RVA: 0x0002DC76 File Offset: 0x0002BE76
	public void RecycleTeleportDestination(TeleportDestination oldDestination)
	{
		if (oldDestination == this._teleportDestination)
		{
			this.CreateNewTeleportDestination();
		}
		Object.Destroy(oldDestination.gameObject);
	}

	// Token: 0x06000735 RID: 1845 RVA: 0x0002DC97 File Offset: 0x0002BE97
	private void EnableMotion(bool enableLinear, bool enableRotation)
	{
		this.LocomotionController.PlayerController.EnableLinearMovement = enableLinear;
		this.LocomotionController.PlayerController.EnableRotation = enableRotation;
	}

	// Token: 0x06000736 RID: 1846 RVA: 0x0002DCBB File Offset: 0x0002BEBB
	private void Awake()
	{
		this.LocomotionController = base.GetComponent<LocomotionController>();
		this.CreateNewTeleportDestination();
	}

	// Token: 0x06000737 RID: 1847 RVA: 0x0002DCCF File Offset: 0x0002BECF
	public virtual void OnEnable()
	{
		this.CurrentState = LocomotionTeleport.States.Ready;
		base.StartCoroutine(this.ReadyStateCoroutine());
	}

	// Token: 0x06000738 RID: 1848 RVA: 0x0002DCE5 File Offset: 0x0002BEE5
	public virtual void OnDisable()
	{
		base.StopAllCoroutines();
	}

	// Token: 0x1400003B RID: 59
	// (add) Token: 0x06000739 RID: 1849 RVA: 0x0002DCF0 File Offset: 0x0002BEF0
	// (remove) Token: 0x0600073A RID: 1850 RVA: 0x0002DD28 File Offset: 0x0002BF28
	public event Action EnterStateReady;

	// Token: 0x0600073B RID: 1851 RVA: 0x0002DD5D File Offset: 0x0002BF5D
	protected IEnumerator ReadyStateCoroutine()
	{
		yield return null;
		this.CurrentState = LocomotionTeleport.States.Ready;
		this.EnableMotion(this.EnableMovementDuringReady, this.EnableRotationDuringReady);
		if (this.EnterStateReady != null)
		{
			this.EnterStateReady();
		}
		while (this.CurrentIntention != LocomotionTeleport.TeleportIntentions.Aim)
		{
			yield return null;
		}
		yield return null;
		base.StartCoroutine(this.AimStateCoroutine());
		yield break;
	}

	// Token: 0x1400003C RID: 60
	// (add) Token: 0x0600073C RID: 1852 RVA: 0x0002DD6C File Offset: 0x0002BF6C
	// (remove) Token: 0x0600073D RID: 1853 RVA: 0x0002DDA4 File Offset: 0x0002BFA4
	public event Action EnterStateAim;

	// Token: 0x1400003D RID: 61
	// (add) Token: 0x0600073E RID: 1854 RVA: 0x0002DDDC File Offset: 0x0002BFDC
	// (remove) Token: 0x0600073F RID: 1855 RVA: 0x0002DE14 File Offset: 0x0002C014
	public event Action<LocomotionTeleport.AimData> UpdateAimData;

	// Token: 0x06000740 RID: 1856 RVA: 0x0002DE49 File Offset: 0x0002C049
	public void OnUpdateAimData(LocomotionTeleport.AimData aimData)
	{
		if (this.UpdateAimData != null)
		{
			this.UpdateAimData(aimData);
		}
	}

	// Token: 0x1400003E RID: 62
	// (add) Token: 0x06000741 RID: 1857 RVA: 0x0002DE60 File Offset: 0x0002C060
	// (remove) Token: 0x06000742 RID: 1858 RVA: 0x0002DE98 File Offset: 0x0002C098
	public event Action ExitStateAim;

	// Token: 0x06000743 RID: 1859 RVA: 0x0002DECD File Offset: 0x0002C0CD
	protected IEnumerator AimStateCoroutine()
	{
		this.CurrentState = LocomotionTeleport.States.Aim;
		this.EnableMotion(this.EnableMovementDuringAim, this.EnableRotationDuringAim);
		if (this.EnterStateAim != null)
		{
			this.EnterStateAim();
		}
		this._teleportDestination.gameObject.SetActive(true);
		while (this.CurrentIntention == LocomotionTeleport.TeleportIntentions.Aim)
		{
			yield return null;
		}
		if (this.ExitStateAim != null)
		{
			this.ExitStateAim();
		}
		yield return null;
		if ((this.CurrentIntention == LocomotionTeleport.TeleportIntentions.PreTeleport || this.CurrentIntention == LocomotionTeleport.TeleportIntentions.Teleport) && this._teleportDestination.IsValidDestination)
		{
			base.StartCoroutine(this.PreTeleportStateCoroutine());
		}
		else
		{
			base.StartCoroutine(this.CancelAimStateCoroutine());
		}
		yield break;
	}

	// Token: 0x1400003F RID: 63
	// (add) Token: 0x06000744 RID: 1860 RVA: 0x0002DEDC File Offset: 0x0002C0DC
	// (remove) Token: 0x06000745 RID: 1861 RVA: 0x0002DF14 File Offset: 0x0002C114
	public event Action EnterStateCancelAim;

	// Token: 0x06000746 RID: 1862 RVA: 0x0002DF49 File Offset: 0x0002C149
	protected IEnumerator CancelAimStateCoroutine()
	{
		this.CurrentState = LocomotionTeleport.States.CancelAim;
		if (this.EnterStateCancelAim != null)
		{
			this.EnterStateCancelAim();
		}
		this.DeactivateDestination();
		yield return null;
		base.StartCoroutine(this.ReadyStateCoroutine());
		yield break;
	}

	// Token: 0x14000040 RID: 64
	// (add) Token: 0x06000747 RID: 1863 RVA: 0x0002DF58 File Offset: 0x0002C158
	// (remove) Token: 0x06000748 RID: 1864 RVA: 0x0002DF90 File Offset: 0x0002C190
	public event Action EnterStatePreTeleport;

	// Token: 0x06000749 RID: 1865 RVA: 0x0002DFC5 File Offset: 0x0002C1C5
	protected IEnumerator PreTeleportStateCoroutine()
	{
		this.CurrentState = LocomotionTeleport.States.PreTeleport;
		this.EnableMotion(this.EnableMovementDuringPreTeleport, this.EnableRotationDuringPreTeleport);
		if (this.EnterStatePreTeleport != null)
		{
			this.EnterStatePreTeleport();
		}
		while (this.CurrentIntention == LocomotionTeleport.TeleportIntentions.PreTeleport || this.IsPreTeleportRequested)
		{
			yield return null;
		}
		if (this._teleportDestination.IsValidDestination)
		{
			base.StartCoroutine(this.TeleportingStateCoroutine());
		}
		else
		{
			base.StartCoroutine(this.CancelTeleportStateCoroutine());
		}
		yield break;
	}

	// Token: 0x14000041 RID: 65
	// (add) Token: 0x0600074A RID: 1866 RVA: 0x0002DFD4 File Offset: 0x0002C1D4
	// (remove) Token: 0x0600074B RID: 1867 RVA: 0x0002E00C File Offset: 0x0002C20C
	public event Action EnterStateCancelTeleport;

	// Token: 0x0600074C RID: 1868 RVA: 0x0002E041 File Offset: 0x0002C241
	protected IEnumerator CancelTeleportStateCoroutine()
	{
		this.CurrentState = LocomotionTeleport.States.CancelTeleport;
		if (this.EnterStateCancelTeleport != null)
		{
			this.EnterStateCancelTeleport();
		}
		this.DeactivateDestination();
		yield return null;
		base.StartCoroutine(this.ReadyStateCoroutine());
		yield break;
	}

	// Token: 0x14000042 RID: 66
	// (add) Token: 0x0600074D RID: 1869 RVA: 0x0002E050 File Offset: 0x0002C250
	// (remove) Token: 0x0600074E RID: 1870 RVA: 0x0002E088 File Offset: 0x0002C288
	public event Action EnterStateTeleporting;

	// Token: 0x0600074F RID: 1871 RVA: 0x0002E0BD File Offset: 0x0002C2BD
	protected IEnumerator TeleportingStateCoroutine()
	{
		this.CurrentState = LocomotionTeleport.States.Teleporting;
		this.EnableMotion(false, false);
		if (this.EnterStateTeleporting != null)
		{
			this.EnterStateTeleporting();
		}
		while (this.IsTransitioning)
		{
			yield return null;
		}
		yield return null;
		base.StartCoroutine(this.PostTeleportStateCoroutine());
		yield break;
	}

	// Token: 0x14000043 RID: 67
	// (add) Token: 0x06000750 RID: 1872 RVA: 0x0002E0CC File Offset: 0x0002C2CC
	// (remove) Token: 0x06000751 RID: 1873 RVA: 0x0002E104 File Offset: 0x0002C304
	public event Action EnterStatePostTeleport;

	// Token: 0x06000752 RID: 1874 RVA: 0x0002E139 File Offset: 0x0002C339
	protected IEnumerator PostTeleportStateCoroutine()
	{
		this.CurrentState = LocomotionTeleport.States.PostTeleport;
		this.EnableMotion(this.EnableMovementDuringPostTeleport, this.EnableRotationDuringPostTeleport);
		if (this.EnterStatePostTeleport != null)
		{
			this.EnterStatePostTeleport();
		}
		while (this.IsPostTeleportRequested)
		{
			yield return null;
		}
		this.DeactivateDestination();
		yield return null;
		base.StartCoroutine(this.ReadyStateCoroutine());
		yield break;
	}

	// Token: 0x14000044 RID: 68
	// (add) Token: 0x06000753 RID: 1875 RVA: 0x0002E148 File Offset: 0x0002C348
	// (remove) Token: 0x06000754 RID: 1876 RVA: 0x0002E180 File Offset: 0x0002C380
	public event Action<Transform, Vector3, Quaternion> Teleported;

	// Token: 0x06000755 RID: 1877 RVA: 0x0002E1B8 File Offset: 0x0002C3B8
	public void DoTeleport()
	{
		CapsuleCollider characterController = this.LocomotionController.CharacterController;
		Transform transform = characterController.transform;
		Vector3 position = this._teleportDestination.OrientationIndicator.position;
		position.y += characterController.height * 0.5f;
		Quaternion landingRotation = this._teleportDestination.LandingRotation;
		if (this.Teleported != null)
		{
			this.Teleported(transform, position, landingRotation);
		}
		transform.position = position;
		transform.rotation = landingRotation;
	}

	// Token: 0x06000756 RID: 1878 RVA: 0x0002E230 File Offset: 0x0002C430
	public Vector3 GetCharacterPosition()
	{
		return this.LocomotionController.CharacterController.transform.position;
	}

	// Token: 0x06000757 RID: 1879 RVA: 0x0002E248 File Offset: 0x0002C448
	public Quaternion GetHeadRotationY()
	{
		Quaternion result = Quaternion.identity;
		InputDevice deviceAtXRNode = InputDevices.GetDeviceAtXRNode(XRNode.Head);
		if (deviceAtXRNode.isValid)
		{
			deviceAtXRNode.TryGetFeatureValue(CommonUsages.deviceRotation, out result);
		}
		Vector3 eulerAngles = result.eulerAngles;
		eulerAngles.x = 0f;
		eulerAngles.z = 0f;
		result = Quaternion.Euler(eulerAngles);
		return result;
	}

	// Token: 0x06000758 RID: 1880 RVA: 0x0002E2A4 File Offset: 0x0002C4A4
	public void DoWarp(Vector3 startPos, float positionPercent)
	{
		Vector3 position = this._teleportDestination.OrientationIndicator.position;
		position.y += this.LocomotionController.CharacterController.height / 2f;
		Transform transform = this.LocomotionController.CharacterController.transform;
		Vector3 position2 = Vector3.Lerp(startPos, position, positionPercent);
		transform.position = position2;
	}

	// Token: 0x04000960 RID: 2400
	[Tooltip("Allow linear movement prior to the teleport system being activated.")]
	public bool EnableMovementDuringReady = true;

	// Token: 0x04000961 RID: 2401
	[Tooltip("Allow linear movement while the teleport system is in the process of aiming for a teleport target.")]
	public bool EnableMovementDuringAim = true;

	// Token: 0x04000962 RID: 2402
	[Tooltip("Allow linear movement while the teleport system is in the process of configuring the landing orientation.")]
	public bool EnableMovementDuringPreTeleport = true;

	// Token: 0x04000963 RID: 2403
	[Tooltip("Allow linear movement after the teleport has occurred but before the system has returned to the ready state.")]
	public bool EnableMovementDuringPostTeleport = true;

	// Token: 0x04000964 RID: 2404
	[Tooltip("Allow rotation prior to the teleport system being activated.")]
	public bool EnableRotationDuringReady = true;

	// Token: 0x04000965 RID: 2405
	[Tooltip("Allow rotation while the teleport system is in the process of aiming for a teleport target.")]
	public bool EnableRotationDuringAim = true;

	// Token: 0x04000966 RID: 2406
	[Tooltip("Allow rotation while the teleport system is in the process of configuring the landing orientation.")]
	public bool EnableRotationDuringPreTeleport = true;

	// Token: 0x04000967 RID: 2407
	[Tooltip("Allow rotation after the teleport has occurred but before the system has returned to the ready state.")]
	public bool EnableRotationDuringPostTeleport = true;

	// Token: 0x04000969 RID: 2409
	[NonSerialized]
	public TeleportAimHandler AimHandler;

	// Token: 0x0400096A RID: 2410
	[Tooltip("This prefab will be instantiated as needed and updated to match the current aim target.")]
	public TeleportDestination TeleportDestinationPrefab;

	// Token: 0x0400096B RID: 2411
	[Tooltip("TeleportDestinationPrefab will be instantiated into this layer.")]
	public int TeleportDestinationLayer;

	// Token: 0x0400096D RID: 2413
	[NonSerialized]
	public TeleportInputHandler InputHandler;

	// Token: 0x0400096E RID: 2414
	[NonSerialized]
	public LocomotionTeleport.TeleportIntentions CurrentIntention;

	// Token: 0x0400096F RID: 2415
	[NonSerialized]
	public bool IsPreTeleportRequested;

	// Token: 0x04000970 RID: 2416
	[NonSerialized]
	public bool IsTransitioning;

	// Token: 0x04000971 RID: 2417
	[NonSerialized]
	public bool IsPostTeleportRequested;

	// Token: 0x04000972 RID: 2418
	private TeleportDestination _teleportDestination;

	// Token: 0x04000974 RID: 2420
	[Tooltip("When aiming at possible destinations, the aim collision type determines which shape to use for collision tests.")]
	public LocomotionTeleport.AimCollisionTypes AimCollisionType;

	// Token: 0x04000975 RID: 2421
	[Tooltip("Use the character collision radius/height/skinwidth for sphere/capsule collision tests.")]
	public bool UseCharacterCollisionData;

	// Token: 0x04000976 RID: 2422
	[Tooltip("Radius of the sphere or capsule used for collision testing when aiming to possible teleport destinations. Ignored if UseCharacterCollisionData is true.")]
	public float AimCollisionRadius;

	// Token: 0x04000977 RID: 2423
	[Tooltip("Height of the capsule used for collision testing when aiming to possible teleport destinations. Ignored if UseCharacterCollisionData is true.")]
	public float AimCollisionHeight;

	// Token: 0x0200020D RID: 525
	public enum States
	{
		// Token: 0x04000ED2 RID: 3794
		Ready,
		// Token: 0x04000ED3 RID: 3795
		Aim,
		// Token: 0x04000ED4 RID: 3796
		CancelAim,
		// Token: 0x04000ED5 RID: 3797
		PreTeleport,
		// Token: 0x04000ED6 RID: 3798
		CancelTeleport,
		// Token: 0x04000ED7 RID: 3799
		Teleporting,
		// Token: 0x04000ED8 RID: 3800
		PostTeleport
	}

	// Token: 0x0200020E RID: 526
	public enum TeleportIntentions
	{
		// Token: 0x04000EDA RID: 3802
		None,
		// Token: 0x04000EDB RID: 3803
		Aim,
		// Token: 0x04000EDC RID: 3804
		PreTeleport,
		// Token: 0x04000EDD RID: 3805
		Teleport
	}

	// Token: 0x0200020F RID: 527
	public enum AimCollisionTypes
	{
		// Token: 0x04000EDF RID: 3807
		Point,
		// Token: 0x04000EE0 RID: 3808
		Sphere,
		// Token: 0x04000EE1 RID: 3809
		Capsule
	}

	// Token: 0x02000210 RID: 528
	public class AimData
	{
		// Token: 0x06000C6C RID: 3180 RVA: 0x000449C4 File Offset: 0x00042BC4
		public AimData()
		{
			this.Points = new List<Vector3>();
		}

		// Token: 0x170000CB RID: 203
		// (get) Token: 0x06000C6D RID: 3181 RVA: 0x000449D7 File Offset: 0x00042BD7
		// (set) Token: 0x06000C6E RID: 3182 RVA: 0x000449DF File Offset: 0x00042BDF
		public List<Vector3> Points { get; private set; }

		// Token: 0x06000C6F RID: 3183 RVA: 0x000449E8 File Offset: 0x00042BE8
		public void Reset()
		{
			this.Points.Clear();
			this.TargetValid = false;
			this.Destination = null;
		}

		// Token: 0x04000EE2 RID: 3810
		public RaycastHit TargetHitInfo;

		// Token: 0x04000EE3 RID: 3811
		public bool TargetValid;

		// Token: 0x04000EE4 RID: 3812
		public Vector3? Destination;

		// Token: 0x04000EE5 RID: 3813
		public float Radius;
	}
}
