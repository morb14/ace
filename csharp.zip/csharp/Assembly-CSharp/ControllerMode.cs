﻿using System;

// Token: 0x02000084 RID: 132
public enum ControllerMode
{
	// Token: 0x040005EE RID: 1518
	Hands,
	// Token: 0x040005EF RID: 1519
	Controllers
}
