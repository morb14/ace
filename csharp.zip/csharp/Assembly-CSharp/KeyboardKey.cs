﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000072 RID: 114
public class KeyboardKey : MonoBehaviour
{
	// Token: 0x06000443 RID: 1091 RVA: 0x0001D0AB File Offset: 0x0001B2AB
	private void Start()
	{
		this.originalScale = base.transform.localScale;
		GameEvents.current.onKeyboardCaseToggle += this.ToggleCase;
	}

	// Token: 0x06000444 RID: 1092 RVA: 0x0001D0D4 File Offset: 0x0001B2D4
	public void Highlight()
	{
		if (this.highlight != null)
		{
			GameEvents.current.KeyboardHighlighted();
			if (!this.highlight.activeSelf)
			{
				this.highlight.SetActive(true);
				this.highlighted = true;
				this.highlight.transform.position = base.transform.position;
			}
		}
	}

	// Token: 0x06000445 RID: 1093 RVA: 0x0001D134 File Offset: 0x0001B334
	private void FixedUpdate()
	{
		if (this.highlighted)
		{
			this.highlight.SetActive(false);
		}
	}

	// Token: 0x06000446 RID: 1094 RVA: 0x0001D14C File Offset: 0x0001B34C
	public void Select()
	{
		string a = this.key;
		if (!(a == "Shift"))
		{
			if (!(a == "Spacebar"))
			{
				if (!(a == "Delete"))
				{
					if (!(a == "Return"))
					{
						if (!this.isSpecial && this.keyboardManager.clipBoardText.Length < this.keyboardManager.maxSize)
						{
							KeyboardManager keyboardManager = this.keyboardManager;
							keyboardManager.clipBoardText += this.key;
						}
					}
					else
					{
						GameEvents.current.KeyboardReturnPressed();
						this.keyboardManager.ActivateKeyboard(false, null);
					}
				}
				else
				{
					if (this.keyboardManager.clipBoardText.Length > 0)
					{
						this.keyboardManager.clipBoardText = this.keyboardManager.clipBoardText.Substring(0, this.keyboardManager.clipBoardText.Length - 1);
					}
					if (this.keyboardManager.clipBoardText.Length <= 1)
					{
						this.keyboardManager.clipBoardText = "";
					}
				}
			}
			else
			{
				KeyboardManager keyboardManager2 = this.keyboardManager;
				keyboardManager2.clipBoardText += "_";
			}
		}
		else
		{
			this.keyboardManager.lowerCase = !this.keyboardManager.lowerCase;
			GameEvents.current.KeyboardCaseToggle();
		}
		if (this.key != "Return")
		{
			GameEvents.current.KeyboardKeyPressed();
		}
	}

	// Token: 0x06000447 RID: 1095 RVA: 0x0001D2C0 File Offset: 0x0001B4C0
	private void ToggleCase()
	{
		if (!this.isSpecial && !this.isNumber)
		{
			if (this.keyboardManager.lowerCase)
			{
				this.key = this.key.ToLower();
				this.tileText.text = this.key;
				return;
			}
			this.key = this.key.ToUpper();
			this.tileText.text = this.key;
		}
	}

	// Token: 0x06000448 RID: 1096 RVA: 0x00003297 File Offset: 0x00001497
	private void ResizeKey()
	{
	}

	// Token: 0x06000449 RID: 1097 RVA: 0x0001D32F File Offset: 0x0001B52F
	private void OnDestroy()
	{
		GameEvents.current.onKeyboardCaseToggle -= this.ToggleCase;
	}

	// Token: 0x04000575 RID: 1397
	[SerializeField]
	private string key;

	// Token: 0x04000576 RID: 1398
	[SerializeField]
	private GameObject highlight;

	// Token: 0x04000577 RID: 1399
	[SerializeField]
	private TMP_Text tileText;

	// Token: 0x04000578 RID: 1400
	[SerializeField]
	private bool isNumber;

	// Token: 0x04000579 RID: 1401
	[SerializeField]
	private bool isSpecial;

	// Token: 0x0400057A RID: 1402
	private bool highlighted;

	// Token: 0x0400057B RID: 1403
	public KeyboardManager keyboardManager;

	// Token: 0x0400057C RID: 1404
	private Vector3 originalScale;
}
