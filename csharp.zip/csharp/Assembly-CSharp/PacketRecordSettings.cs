﻿using System;

// Token: 0x020000AA RID: 170
[Serializable]
public class PacketRecordSettings
{
	// Token: 0x040006B4 RID: 1716
	internal bool RecordingFrames;

	// Token: 0x040006B5 RID: 1717
	public float UpdateRate = 0.033333335f;

	// Token: 0x040006B6 RID: 1718
	internal float AccumulatedTime;
}
