﻿using System;
using UnityEngine;

// Token: 0x020000DD RID: 221
public struct ovrAvatarPBSMaterialState
{
	// Token: 0x06000633 RID: 1587 RVA: 0x000288A5 File Offset: 0x00026AA5
	private static bool VectorEquals(Vector4 a, Vector4 b)
	{
		return a.x == b.x && a.y == b.y && a.z == b.z && a.w == b.w;
	}

	// Token: 0x06000634 RID: 1588 RVA: 0x00028E68 File Offset: 0x00027068
	public override bool Equals(object obj)
	{
		if (!(obj is ovrAvatarPBSMaterialState))
		{
			return false;
		}
		ovrAvatarPBSMaterialState ovrAvatarPBSMaterialState = (ovrAvatarPBSMaterialState)obj;
		return ovrAvatarPBSMaterialState.VectorEquals(this.baseColor, ovrAvatarPBSMaterialState.baseColor) && this.albedoTextureID == ovrAvatarPBSMaterialState.albedoTextureID && ovrAvatarPBSMaterialState.VectorEquals(this.albedoMultiplier, ovrAvatarPBSMaterialState.albedoMultiplier) && this.metallicnessTextureID == ovrAvatarPBSMaterialState.metallicnessTextureID && this.glossinessScale == ovrAvatarPBSMaterialState.glossinessScale && this.normalTextureID == ovrAvatarPBSMaterialState.normalTextureID && this.heightTextureID == ovrAvatarPBSMaterialState.heightTextureID && this.occlusionTextureID == ovrAvatarPBSMaterialState.occlusionTextureID && this.emissionTextureID == ovrAvatarPBSMaterialState.emissionTextureID && ovrAvatarPBSMaterialState.VectorEquals(this.emissionMultiplier, ovrAvatarPBSMaterialState.emissionMultiplier) && this.detailMaskTextureID == ovrAvatarPBSMaterialState.detailMaskTextureID && this.detailAlbedoTextureID == ovrAvatarPBSMaterialState.detailAlbedoTextureID && this.detailNormalTextureID == ovrAvatarPBSMaterialState.detailNormalTextureID;
	}

	// Token: 0x06000635 RID: 1589 RVA: 0x00028F68 File Offset: 0x00027168
	public override int GetHashCode()
	{
		return this.baseColor.GetHashCode() ^ this.albedoTextureID.GetHashCode() ^ this.albedoMultiplier.GetHashCode() ^ this.metallicnessTextureID.GetHashCode() ^ this.glossinessScale.GetHashCode() ^ this.normalTextureID.GetHashCode() ^ this.heightTextureID.GetHashCode() ^ this.occlusionTextureID.GetHashCode() ^ this.emissionTextureID.GetHashCode() ^ this.emissionMultiplier.GetHashCode() ^ this.detailMaskTextureID.GetHashCode() ^ this.detailAlbedoTextureID.GetHashCode() ^ this.detailNormalTextureID.GetHashCode();
	}

	// Token: 0x04000833 RID: 2099
	public Vector4 baseColor;

	// Token: 0x04000834 RID: 2100
	public ulong albedoTextureID;

	// Token: 0x04000835 RID: 2101
	public Vector4 albedoMultiplier;

	// Token: 0x04000836 RID: 2102
	public ulong metallicnessTextureID;

	// Token: 0x04000837 RID: 2103
	public float glossinessScale;

	// Token: 0x04000838 RID: 2104
	public ulong normalTextureID;

	// Token: 0x04000839 RID: 2105
	public ulong heightTextureID;

	// Token: 0x0400083A RID: 2106
	public ulong occlusionTextureID;

	// Token: 0x0400083B RID: 2107
	public ulong emissionTextureID;

	// Token: 0x0400083C RID: 2108
	public Vector4 emissionMultiplier;

	// Token: 0x0400083D RID: 2109
	public ulong detailMaskTextureID;

	// Token: 0x0400083E RID: 2110
	public ulong detailAlbedoTextureID;

	// Token: 0x0400083F RID: 2111
	public ulong detailNormalTextureID;
}
