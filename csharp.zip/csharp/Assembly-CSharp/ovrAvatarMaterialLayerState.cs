﻿using System;
using UnityEngine;

// Token: 0x020000DA RID: 218
public struct ovrAvatarMaterialLayerState
{
	// Token: 0x0600062A RID: 1578 RVA: 0x000288A5 File Offset: 0x00026AA5
	private static bool VectorEquals(Vector4 a, Vector4 b)
	{
		return a.x == b.x && a.y == b.y && a.z == b.z && a.w == b.w;
	}

	// Token: 0x0600062B RID: 1579 RVA: 0x000288E4 File Offset: 0x00026AE4
	public override bool Equals(object obj)
	{
		if (!(obj is ovrAvatarMaterialLayerState))
		{
			return false;
		}
		ovrAvatarMaterialLayerState ovrAvatarMaterialLayerState = (ovrAvatarMaterialLayerState)obj;
		return this.blendMode == ovrAvatarMaterialLayerState.blendMode && this.sampleMode == ovrAvatarMaterialLayerState.sampleMode && this.maskType == ovrAvatarMaterialLayerState.maskType && ovrAvatarMaterialLayerState.VectorEquals(this.layerColor, ovrAvatarMaterialLayerState.layerColor) && ovrAvatarMaterialLayerState.VectorEquals(this.sampleParameters, ovrAvatarMaterialLayerState.sampleParameters) && this.sampleTexture == ovrAvatarMaterialLayerState.sampleTexture && ovrAvatarMaterialLayerState.VectorEquals(this.sampleScaleOffset, ovrAvatarMaterialLayerState.sampleScaleOffset) && ovrAvatarMaterialLayerState.VectorEquals(this.maskParameters, ovrAvatarMaterialLayerState.maskParameters) && ovrAvatarMaterialLayerState.VectorEquals(this.maskAxis, ovrAvatarMaterialLayerState.maskAxis);
	}

	// Token: 0x0600062C RID: 1580 RVA: 0x000289AC File Offset: 0x00026BAC
	public override int GetHashCode()
	{
		return this.blendMode.GetHashCode() ^ this.sampleMode.GetHashCode() ^ this.maskType.GetHashCode() ^ this.layerColor.GetHashCode() ^ this.sampleParameters.GetHashCode() ^ this.sampleTexture.GetHashCode() ^ this.sampleScaleOffset.GetHashCode() ^ this.maskParameters.GetHashCode() ^ this.maskAxis.GetHashCode();
	}

	// Token: 0x04000812 RID: 2066
	public ovrAvatarMaterialLayerBlendMode blendMode;

	// Token: 0x04000813 RID: 2067
	public ovrAvatarMaterialLayerSampleMode sampleMode;

	// Token: 0x04000814 RID: 2068
	public ovrAvatarMaterialMaskType maskType;

	// Token: 0x04000815 RID: 2069
	public Vector4 layerColor;

	// Token: 0x04000816 RID: 2070
	public Vector4 sampleParameters;

	// Token: 0x04000817 RID: 2071
	public ulong sampleTexture;

	// Token: 0x04000818 RID: 2072
	public Vector4 sampleScaleOffset;

	// Token: 0x04000819 RID: 2073
	public Vector4 maskParameters;

	// Token: 0x0400081A RID: 2074
	public Vector4 maskAxis;
}
