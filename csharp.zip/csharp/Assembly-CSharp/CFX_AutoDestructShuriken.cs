﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x0200001A RID: 26
[RequireComponent(typeof(ParticleSystem))]
public class CFX_AutoDestructShuriken : MonoBehaviour
{
	// Token: 0x0600007D RID: 125 RVA: 0x00004E88 File Offset: 0x00003088
	private void OnEnable()
	{
		base.StartCoroutine("CheckIfAlive");
	}

	// Token: 0x0600007E RID: 126 RVA: 0x00004E96 File Offset: 0x00003096
	private IEnumerator CheckIfAlive()
	{
		do
		{
			yield return new WaitForSeconds(0.5f);
		}
		while (base.GetComponent<ParticleSystem>().IsAlive(true));
		if (this.OnlyDeactivate)
		{
			base.gameObject.SetActive(false);
		}
		else
		{
			Object.Destroy(base.gameObject);
		}
		yield break;
	}

	// Token: 0x04000085 RID: 133
	public bool OnlyDeactivate;
}
