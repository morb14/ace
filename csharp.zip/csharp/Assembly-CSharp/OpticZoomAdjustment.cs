﻿using System;
using UnityEngine;

// Token: 0x02000044 RID: 68
public class OpticZoomAdjustment : MonoBehaviour
{
	// Token: 0x0600022C RID: 556 RVA: 0x0000C4C8 File Offset: 0x0000A6C8
	private void Start()
	{
		this.controlManager = Object.FindObjectOfType<ControlManager>();
		this.maxZoom = this.scopeCam.fieldOfView;
		if (base.GetComponent<Animator>())
		{
			this.animator = base.GetComponent<Animator>();
		}
	}

	// Token: 0x0600022D RID: 557 RVA: 0x0000C4FF File Offset: 0x0000A6FF
	private void Update()
	{
		if (this.opticType == OpticZoomAdjustment.OpticType.Dial)
		{
			this.Lerp();
		}
	}

	// Token: 0x0600022E RID: 558 RVA: 0x0000C510 File Offset: 0x0000A710
	public void Adjustment()
	{
		if (this.adjusting)
		{
			return;
		}
		if (this.opticType == OpticZoomAdjustment.OpticType.Dial)
		{
			if (this.scopeCam.fieldOfView == this.maxZoom)
			{
				this.zoomOut = true;
			}
			else
			{
				this.zoomOut = false;
			}
			this.adjusting = true;
			base.Invoke("ResetAdjust", this.adjustmentTime + Time.deltaTime);
			return;
		}
		if (this.opticType == OpticZoomAdjustment.OpticType.Flip)
		{
			if (!this.zoomOut)
			{
				this.animator.SetTrigger("Flip");
				return;
			}
			this.animator.SetTrigger("Flip");
		}
	}

	// Token: 0x0600022F RID: 559 RVA: 0x0000C5A4 File Offset: 0x0000A7A4
	private void Lerp()
	{
		if (this.adjusting)
		{
			float a;
			float b;
			if (this.zoomOut)
			{
				a = this.maxZoom;
				b = this.minZoom;
			}
			else
			{
				a = this.minZoom;
				b = this.maxZoom;
			}
			if (this.timeElapsed < this.adjustmentTime)
			{
				this.valueToLerp = Mathf.Lerp(a, b, this.timeElapsed / this.adjustmentTime);
				this.timeElapsed += Time.deltaTime;
			}
			else
			{
				this.valueToLerp = b;
			}
			this.scopeCam.fieldOfView = this.valueToLerp;
		}
	}

	// Token: 0x06000230 RID: 560 RVA: 0x0000C633 File Offset: 0x0000A833
	private void ResetAdjust()
	{
		this.adjusting = false;
		this.timeElapsed = 0f;
	}

	// Token: 0x0400020A RID: 522
	[SerializeField]
	private OpticZoomAdjustment.OpticType opticType;

	// Token: 0x0400020B RID: 523
	[SerializeField]
	private Camera scopeCam;

	// Token: 0x0400020C RID: 524
	[SerializeField]
	public float maxZoom;

	// Token: 0x0400020D RID: 525
	[SerializeField]
	public float minZoom = 14f;

	// Token: 0x0400020E RID: 526
	[SerializeField]
	private float adjustmentTime = 0.5f;

	// Token: 0x0400020F RID: 527
	private bool adjusting;

	// Token: 0x04000210 RID: 528
	private bool zoomOut;

	// Token: 0x04000211 RID: 529
	private Animator animator;

	// Token: 0x04000212 RID: 530
	private float valueToLerp;

	// Token: 0x04000213 RID: 531
	private float timeElapsed;

	// Token: 0x04000214 RID: 532
	private ControlManager controlManager;

	// Token: 0x020001B8 RID: 440
	public enum OpticType
	{
		// Token: 0x04000D44 RID: 3396
		Dial,
		// Token: 0x04000D45 RID: 3397
		Flip
	}
}
