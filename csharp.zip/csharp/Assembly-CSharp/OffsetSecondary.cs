﻿using System;
using UnityEngine;

// Token: 0x0200007A RID: 122
public class OffsetSecondary : MonoBehaviour
{
	// Token: 0x040005AF RID: 1455
	public bool isOffSetOptic;
}
