﻿using System;
using UnityEngine;

// Token: 0x0200008A RID: 138
public class SpawnOneOnly : MonoBehaviour
{
	// Token: 0x060004D9 RID: 1241 RVA: 0x000203FC File Offset: 0x0001E5FC
	private void Start()
	{
		if (this.targetInfo == null)
		{
			this.targetInfo = base.GetComponent<TargetInfo>();
		}
		if (this.targetInfo == null)
		{
			return;
		}
		GameEvents.current.onStagePlannerCompStart += this.OnStagePlannerCompStart;
		GameEvents.current.onStagePlannerCompEnd += this.OnStagePlannerCompEnd;
		this.DeleteOthers();
		base.Invoke("UpdateSceneSettings", 0.1f);
	}

	// Token: 0x060004DA RID: 1242 RVA: 0x00020474 File Offset: 0x0001E674
	private void DeleteOthers()
	{
		foreach (SpawnOneOnly spawnOneOnly in Object.FindObjectsOfType<SpawnOneOnly>())
		{
			if (spawnOneOnly.targetInfo.targetID == this.targetInfo.targetID && spawnOneOnly != this)
			{
				Object.Destroy(spawnOneOnly.gameObject);
			}
		}
	}

	// Token: 0x060004DB RID: 1243 RVA: 0x000204CC File Offset: 0x0001E6CC
	private void UpdateSceneSettings()
	{
		if (this.uniqueType != SpawnOneOnly.UniqueType.InfoPanel)
		{
			return;
		}
		if (this.targetInfo.targetID.Contains("StageInfo"))
		{
			Object.FindObjectOfType<SceneSettings>().introPanelPosition = base.transform;
		}
		if (this.targetInfo.targetID.Contains("StageResults"))
		{
			Object.FindObjectOfType<SceneSettings>().resultsPanelPosition = base.transform;
		}
	}

	// Token: 0x060004DC RID: 1244 RVA: 0x00020530 File Offset: 0x0001E730
	private void OnStagePlannerCompStart()
	{
		this.objectToDisable.SetActive(false);
		if (base.GetComponent<Collider>())
		{
			base.GetComponent<Collider>().enabled = false;
		}
	}

	// Token: 0x060004DD RID: 1245 RVA: 0x00020557 File Offset: 0x0001E757
	private void OnStagePlannerCompEnd()
	{
		this.objectToDisable.SetActive(true);
		if (base.GetComponent<Collider>())
		{
			base.GetComponent<Collider>().enabled = true;
		}
	}

	// Token: 0x060004DE RID: 1246 RVA: 0x0002057E File Offset: 0x0001E77E
	private void OnDestroy()
	{
		GameEvents.current.onStagePlannerCompStart -= this.OnStagePlannerCompStart;
		GameEvents.current.onStagePlannerCompEnd -= this.OnStagePlannerCompEnd;
	}

	// Token: 0x0400062C RID: 1580
	[SerializeField]
	private SpawnOneOnly.UniqueType uniqueType;

	// Token: 0x0400062D RID: 1581
	[SerializeField]
	public TargetInfo targetInfo;

	// Token: 0x0400062E RID: 1582
	[SerializeField]
	private GameObject objectToDisable;

	// Token: 0x020001E0 RID: 480
	private enum UniqueType
	{
		// Token: 0x04000E15 RID: 3605
		InfoPanel,
		// Token: 0x04000E16 RID: 3606
		Others
	}
}
