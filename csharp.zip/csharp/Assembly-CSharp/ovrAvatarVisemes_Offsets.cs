﻿using System;
using System.Runtime.InteropServices;

// Token: 0x020000EA RID: 234
internal struct ovrAvatarVisemes_Offsets
{
	// Token: 0x0400086F RID: 2159
	public static int visemeParamCount = Marshal.OffsetOf(typeof(ovrAvatarVisemes), "visemeParamCount").ToInt32();

	// Token: 0x04000870 RID: 2160
	public static long visemeParams = (long)Marshal.SizeOf(typeof(uint));
}
