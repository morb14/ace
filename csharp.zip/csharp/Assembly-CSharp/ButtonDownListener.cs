﻿using System;
using UnityEngine;
using UnityEngine.EventSystems;

// Token: 0x02000132 RID: 306
public class ButtonDownListener : MonoBehaviour, IPointerDownHandler, IEventSystemHandler
{
	// Token: 0x14000048 RID: 72
	// (add) Token: 0x060007DC RID: 2012 RVA: 0x00030060 File Offset: 0x0002E260
	// (remove) Token: 0x060007DD RID: 2013 RVA: 0x00030098 File Offset: 0x0002E298
	public event Action onButtonDown;

	// Token: 0x060007DE RID: 2014 RVA: 0x000300CD File Offset: 0x0002E2CD
	public void OnPointerDown(PointerEventData eventData)
	{
		if (this.onButtonDown != null)
		{
			this.onButtonDown();
		}
	}
}
