﻿using System;
using UnityEngine;

// Token: 0x02000011 RID: 17
[RequireComponent(typeof(ParticleSystem))]
public class CFX_AutoStopLoopedEffect : MonoBehaviour
{
	// Token: 0x0600004D RID: 77 RVA: 0x00003510 File Offset: 0x00001710
	private void OnEnable()
	{
		this.d = this.effectDuration;
	}

	// Token: 0x0600004E RID: 78 RVA: 0x00003520 File Offset: 0x00001720
	private void Update()
	{
		if (this.d > 0f)
		{
			this.d -= Time.deltaTime;
			if (this.d <= 0f)
			{
				base.GetComponent<ParticleSystem>().Stop(true);
				CFX_Demo_Translate component = base.gameObject.GetComponent<CFX_Demo_Translate>();
				if (component != null)
				{
					component.enabled = false;
				}
			}
		}
	}

	// Token: 0x0400003B RID: 59
	public float effectDuration = 2.5f;

	// Token: 0x0400003C RID: 60
	private float d;
}
