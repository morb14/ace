﻿using System;
using UnityEngine;

// Token: 0x0200009A RID: 154
public class ZeroingTargetButton : MonoBehaviour
{
	// Token: 0x06000523 RID: 1315 RVA: 0x0002127F File Offset: 0x0001F47F
	private void Start()
	{
		this.soundManager = Object.FindObjectOfType<SoundManager>();
		this.UpdateMaterial();
	}

	// Token: 0x06000524 RID: 1316 RVA: 0x00021292 File Offset: 0x0001F492
	public void UpdateMaterial()
	{
		if (!this.linkedObject.activeSelf)
		{
			this.meshMaterial.material = this.offMaterial;
			return;
		}
		this.meshMaterial.material = this.onMaterial;
	}

	// Token: 0x06000525 RID: 1317 RVA: 0x000212C4 File Offset: 0x0001F4C4
	public void Highlight()
	{
		if (this.highLightObject == null)
		{
			return;
		}
		this.highLightObject.SetActive(true);
	}

	// Token: 0x06000526 RID: 1318 RVA: 0x000212E4 File Offset: 0x0001F4E4
	public void Select()
	{
		if (this.linkedObject.GetComponent<SteelTarget>())
		{
			this.linkedObject.GetComponent<SteelTarget>().splash.gameObject.SetActive(false);
		}
		MonoBehaviour.print(this.linkedObject.GetComponentInChildren<ParticleSystem>(true).gameObject);
		this.linkedObject.SetActive(!this.linkedObject.activeSelf);
		this.soundManager.Play(this.soundManager.UIclick);
		this.UpdateMaterial();
	}

	// Token: 0x06000527 RID: 1319 RVA: 0x00021369 File Offset: 0x0001F569
	public void Hit()
	{
		this.meshMaterial.material = this.hitMaterial;
	}

	// Token: 0x04000662 RID: 1634
	[SerializeField]
	private GameObject highLightObject;

	// Token: 0x04000663 RID: 1635
	[SerializeField]
	private GameObject linkedObject;

	// Token: 0x04000664 RID: 1636
	[SerializeField]
	private MeshRenderer meshMaterial;

	// Token: 0x04000665 RID: 1637
	[SerializeField]
	private Material onMaterial;

	// Token: 0x04000666 RID: 1638
	[SerializeField]
	private Material offMaterial;

	// Token: 0x04000667 RID: 1639
	[SerializeField]
	private Material hitMaterial;

	// Token: 0x04000668 RID: 1640
	private SoundManager soundManager;
}
