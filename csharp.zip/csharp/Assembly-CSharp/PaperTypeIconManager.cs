﻿using System;
using UnityEngine;

// Token: 0x0200007B RID: 123
public class PaperTypeIconManager : MonoBehaviour
{
	// Token: 0x06000471 RID: 1137 RVA: 0x0001DE46 File Offset: 0x0001C046
	private void Start()
	{
		this.settingsManager = Object.FindObjectOfType<SettingsManager>();
		GameEvents.current.onTargetTypeChange += this.OnTargetTypeChange;
	}

	// Token: 0x06000472 RID: 1138 RVA: 0x0001DE6C File Offset: 0x0001C06C
	private void OnTargetTypeChange()
	{
		if (this.settingsManager == null)
		{
			this.settingsManager = Object.FindObjectOfType<SettingsManager>();
		}
		if (this.settingsManager.paperType == SettingsManager.PaperType.IPSC)
		{
			this.noShootIPSC.SetActive(true);
			this.scoringIPSC.SetActive(true);
			this.noShootUSPSA.SetActive(false);
			this.scoringUSPSA.SetActive(false);
			return;
		}
		this.noShootIPSC.SetActive(false);
		this.scoringIPSC.SetActive(false);
		this.noShootUSPSA.SetActive(true);
		this.scoringUSPSA.SetActive(true);
	}

	// Token: 0x06000473 RID: 1139 RVA: 0x0001DF00 File Offset: 0x0001C100
	private void OnEnable()
	{
		this.OnTargetTypeChange();
	}

	// Token: 0x06000474 RID: 1140 RVA: 0x0001DF08 File Offset: 0x0001C108
	private void OnDestroy()
	{
		GameEvents.current.onTargetTypeChange -= this.OnTargetTypeChange;
	}

	// Token: 0x040005B0 RID: 1456
	[SerializeField]
	private GameObject scoringUSPSA;

	// Token: 0x040005B1 RID: 1457
	[SerializeField]
	private GameObject noShootUSPSA;

	// Token: 0x040005B2 RID: 1458
	[SerializeField]
	private GameObject scoringIPSC;

	// Token: 0x040005B3 RID: 1459
	[SerializeField]
	private GameObject noShootIPSC;

	// Token: 0x040005B4 RID: 1460
	private SettingsManager settingsManager;
}
