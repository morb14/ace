﻿using System;
using UnityEngine;

// Token: 0x02000102 RID: 258
public class EnableSwitch : MonoBehaviour
{
	// Token: 0x0600067B RID: 1659 RVA: 0x0002A9E4 File Offset: 0x00028BE4
	public bool SetActive<T>(int target) where T : MonoBehaviour
	{
		if (target < 0 || target >= this.SwitchTargets.Length)
		{
			return false;
		}
		for (int i = 0; i < this.SwitchTargets.Length; i++)
		{
			this.SwitchTargets[i].SetActive(false);
			OVRLipSyncContextMorphTarget component = this.SwitchTargets[i].GetComponent<OVRLipSyncContextMorphTarget>();
			if (component)
			{
				component.enabled = false;
			}
			OVRLipSyncContextTextureFlip component2 = this.SwitchTargets[i].GetComponent<OVRLipSyncContextTextureFlip>();
			if (component2)
			{
				component2.enabled = false;
			}
		}
		this.SwitchTargets[target].SetActive(true);
		MonoBehaviour monoBehaviour = this.SwitchTargets[target].GetComponent<T>();
		if (monoBehaviour != null)
		{
			monoBehaviour.enabled = true;
		}
		return true;
	}

	// Token: 0x040008D4 RID: 2260
	public GameObject[] SwitchTargets;
}
