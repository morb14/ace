﻿using System;
using System.Runtime.InteropServices;

// Token: 0x020000CE RID: 206
internal struct ovrAvatarComponent_Offsets
{
	// Token: 0x040007E1 RID: 2017
	public static long transform = Marshal.OffsetOf(typeof(ovrAvatarComponent), "transform").ToInt64();

	// Token: 0x040007E2 RID: 2018
	public static int renderPartCount = Marshal.OffsetOf(typeof(ovrAvatarComponent), "renderPartCount").ToInt32();

	// Token: 0x040007E3 RID: 2019
	public static int renderParts = Marshal.OffsetOf(typeof(ovrAvatarComponent), "renderParts").ToInt32();

	// Token: 0x040007E4 RID: 2020
	public static int name = Marshal.OffsetOf(typeof(ovrAvatarComponent), "name").ToInt32();
}
