﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x0200004B RID: 75
public class Results : MonoBehaviour
{
	// Token: 0x06000258 RID: 600 RVA: 0x0000D15C File Offset: 0x0000B35C
	private void Start()
	{
		this.paperTargets = Object.FindObjectsOfType<PaperTarget>();
		this.steelTargets = Object.FindObjectsOfType<SteelTarget>();
		this.sceneSettings = Object.FindObjectOfType<SceneSettings>();
		this.saveManager = Object.FindObjectOfType<SaveManager>();
		this.scored = false;
		GameEvents.current.onHolster += this.ShowResults;
		GameEvents.current.onHolsterDraw += this.HideResults;
		GameEvents.current.onStagePlannerCompStart += this.OnStagePlannerCompStart;
		GameEvents.current.onStagePlannerCompEnd += this.OnStagePlannerEnd;
		GameEvents.current.onStagePlannerCompStart += this.GatherTargets;
		GameEvents.current.onShotThroughProcedural += this.OnShotThroughProcedural;
		this.defaultTextColor = this.display_time.color;
		this.controlManager = Object.FindObjectOfType<ControlManager>();
		this.holster = Object.FindObjectOfType<HolsterVolume>();
		if (this.holster != null)
		{
			this.resultPanel.SetActive(false);
		}
		this.AnimateStageCam();
		this.LoadResults();
	}

	// Token: 0x06000259 RID: 601 RVA: 0x0000D26D File Offset: 0x0000B46D
	public bool IsScored()
	{
		return this.scored;
	}

	// Token: 0x0600025A RID: 602 RVA: 0x0000D275 File Offset: 0x0000B475
	private void OnShotThroughProcedural()
	{
		this.procedurals++;
	}

	// Token: 0x0600025B RID: 603 RVA: 0x0000D285 File Offset: 0x0000B485
	private void OnStagePlannerEnd()
	{
		this.resultPanel.SetActive(false);
	}

	// Token: 0x0600025C RID: 604 RVA: 0x0000D293 File Offset: 0x0000B493
	private void AnimateStageCam()
	{
		if (this.animation == null)
		{
			return;
		}
		if (this.animation.clip != null)
		{
			this.animation.Play();
		}
	}

	// Token: 0x0600025D RID: 605 RVA: 0x0000D2C4 File Offset: 0x0000B4C4
	public void ForceReset()
	{
		this.savedBestTime = 0f;
		this.savedHitFactor = 0f;
		this.scored = false;
		this.firstTime = true;
		this.resultList = null;
		this.postMatchAchievements.InitiateShields(null, 0f, 0f, 0f);
		this.LoadResults();
	}

	// Token: 0x0600025E RID: 606 RVA: 0x0000D320 File Offset: 0x0000B520
	private string ResultFileName()
	{
		if (SceneManager.GetActiveScene().name.Contains("SD_") && Object.FindObjectOfType<StagePlanner>())
		{
			string str = "";
			if (Object.FindObjectOfType<CustomStageMenu>())
			{
				str = Object.FindObjectOfType<CustomStageMenu>().CurrentOpenedFile();
			}
			return SceneManager.GetActiveScene().name + "_" + str;
		}
		return SceneManager.GetActiveScene().name;
	}

	// Token: 0x0600025F RID: 607 RVA: 0x0000D398 File Offset: 0x0000B598
	public void LoadResults()
	{
		if (this.saveManager.LoadResults(this.ResultFileName()) != null)
		{
			this.resultList = this.saveManager.LoadResults(this.ResultFileName());
			using (List<SaveManager.ResultObject>.Enumerator enumerator = this.resultList.resultObjectList.GetEnumerator())
			{
				while (enumerator.MoveNext())
				{
					SaveManager.ResultObject resultObject = enumerator.Current;
					if (resultObject.weaponID == this.controlManager.currentWeapon.WeaponID())
					{
						this.savedBestTime = resultObject.time;
						this.savedHitFactor = resultObject.hitFactor;
					}
				}
				goto IL_9D;
			}
		}
		this.firstTime = true;
		IL_9D:
		this.postMatchAchievements.InitiateShields(this.resultList, this.sceneSettings.bronzeHitFactor, this.sceneSettings.silverHitFactor, this.sceneSettings.goldHitFactor);
		this.introPanel.InitiateResults(this.resultList);
	}

	// Token: 0x06000260 RID: 608 RVA: 0x0000D498 File Offset: 0x0000B698
	public void GatherTargets()
	{
		this.paperTargets = Object.FindObjectsOfType<PaperTarget>();
		this.steelTargets = Object.FindObjectsOfType<SteelTarget>();
		this.sceneSettings = Object.FindObjectOfType<SceneSettings>();
	}

	// Token: 0x06000261 RID: 609 RVA: 0x0000D4BC File Offset: 0x0000B6BC
	public void ShowResults()
	{
		this.sceneSettings = Object.FindObjectOfType<SceneSettings>();
		if (this.resultPanel.activeSelf)
		{
			return;
		}
		if (this.sceneSettings.sceneType == SceneSettings.SceneType.Comp && this.sceneSettings.status == SceneSettings.CompStatus.Cold)
		{
			MonoBehaviour.print("Showing results B");
			this.resultPanel.SetActive(true);
			this.GatherResults();
			Object.FindObjectOfType<SoundManager>().PlaySingle(Object.FindObjectOfType<SoundManager>().signalRangeIsClear);
		}
	}

	// Token: 0x06000262 RID: 610 RVA: 0x0000D530 File Offset: 0x0000B730
	private void GatherResults()
	{
		if (!this.scored)
		{
			foreach (PaperTarget paperTarget in this.paperTargets)
			{
				if (!paperTarget.noShoot)
				{
					this.paperAlpha += paperTarget.GetCountedHits(PaperTarget.TargetScore.Alpha, true);
					this.paperCharlie += paperTarget.GetCountedHits(PaperTarget.TargetScore.Charlie, true);
					this.paperDelta += paperTarget.GetCountedHits(PaperTarget.TargetScore.Delta, true);
					this.paperAlphaExtras += paperTarget.GetCountedHits(PaperTarget.TargetScore.Alpha, false);
					this.paperCharlieExtras += paperTarget.GetCountedHits(PaperTarget.TargetScore.Charlie, false);
					this.paperDeltaExtras += paperTarget.GetCountedHits(PaperTarget.TargetScore.Delta, false);
				}
				this.misses += paperTarget.GetMisses();
				this.noShoot += paperTarget.GetScore(PaperTarget.TargetScore.NoShoot);
				this.totalScore += (float)paperTarget.GetScore(PaperTarget.TargetScore.None);
			}
			foreach (SteelTarget steelTarget in this.steelTargets)
			{
				if (!steelTarget.dormant)
				{
					if (!steelTarget.noShoot)
					{
						if (steelTarget.GetScore(false) > 0)
						{
							this.steelHit++;
						}
						else
						{
							this.misses++;
						}
						this.totalScore += (float)steelTarget.GetScore(false);
					}
					else
					{
						this.noShoot += steelTarget.GetScore(true);
					}
				}
			}
			BonusTarget[] array3 = Object.FindObjectsOfType<BonusTarget>();
			if (array3.Length != 0)
			{
				foreach (BonusTarget bonusTarget in array3)
				{
					if (bonusTarget.GetHit())
					{
						this.bonusHit++;
					}
					if (bonusTarget.hasPenalty && !bonusTarget.GetHit())
					{
						this.misses++;
					}
				}
			}
			this.procedurals += this.sceneSettings.TotalProcedurals();
			if (this.sceneSettings.isSteelChallenge)
			{
				this.penalties += this.procedurals * 3;
				this.penalties += this.misses * 3;
				this.penalties += this.noShoot * 3;
			}
			else
			{
				this.penalties += this.procedurals * 10;
				this.penalties += this.misses * 10;
				this.penalties += this.noShoot * 10;
				this.totalScore -= (float)this.penalties;
				this.totalScore += (float)(this.bonusHit * 10);
				if (this.totalScore <= 0f)
				{
					this.totalScore = 0f;
				}
			}
		}
		float num;
		if (this.sceneSettings.isSteelChallenge)
		{
			num = this.totalScore / (this.sceneSettings.StageTime() + (float)this.penalties);
		}
		else if (this.sceneSettings.isFixedTimed)
		{
			num = this.totalScore;
		}
		else
		{
			num = this.totalScore / this.sceneSettings.StageTime();
		}
		num = Mathf.Round(num * 100f) / 100f;
		this.display_weapon.text = this.controlManager.currentWeapon.WeaponID();
		this.display_time.text = this.sceneSettings.StageTime().ToString("F2");
		this.display_hitFactor.text = num.ToString("F2");
		this.display_alpha.text = this.paperAlpha.ToString();
		this.display_alphaExtras.text = this.paperAlphaExtras.ToString();
		this.display_charlie.text = this.paperCharlie.ToString();
		this.display_charlieExtras.text = this.paperCharlieExtras.ToString();
		this.display_delta.text = this.paperDelta.ToString();
		this.display_deltaExtras.text = this.paperDeltaExtras.ToString();
		this.display_steel.text = this.steelHit.ToString();
		this.display_bonus.text = this.bonusHit.ToString();
		this.display_recordTime.text = this.savedBestTime.ToString();
		this.display_recordHitFactor.text = this.savedHitFactor.ToString();
		this.display_misses.text = this.misses.ToString();
		this.display_procedurals.text = this.procedurals.ToString();
		this.display_noShoots.text = this.noShoot.ToString();
		this.display_totalScore.text = this.totalScore.ToString();
		this.display_newRecord.enabled = false;
		if (this.sceneSettings.maxHitFactor == 0f)
		{
			this.display_maxHF.gameObject.SetActive(false);
		}
		else
		{
			this.display_maxHF.text = (num / this.sceneSettings.maxHitFactor * 100f).ToString("F0") + "%";
		}
		if (this.savedBestTime > this.sceneSettings.StageTime() || this.savedBestTime == 0f)
		{
			this.display_time.color = Color.green;
		}
		else
		{
			this.display_time.color = Color.red;
		}
		if (this.savedHitFactor > num)
		{
			this.display_hitFactor.color = Color.red;
		}
		else
		{
			this.display_hitFactor.color = Color.green;
		}
		if (this.sceneSettings.isSteelChallenge)
		{
			this.display_hitFactor.color = this.defaultTextColor;
			this.totalScore = this.sceneSettings.StageTime() + (float)this.penalties;
			this.display_hitFactor.text = "-";
			this.display_recordHitFactor.text = "-";
			this.display_totalScore.text = this.totalScore.ToString();
		}
		if (this.sceneSettings.isFixedTimed)
		{
			this.display_time.text = "-";
			this.display_time.color = this.defaultTextColor;
		}
		bool virginiaCount = false;
		bool bronze = false;
		bool silver = false;
		bool gold = false;
		float num2;
		float num3;
		float num4;
		if (this.sceneSettings.isSteelChallenge)
		{
			num2 = 25f / this.sceneSettings.bronzeHitFactor;
			num3 = 25f / this.sceneSettings.silverHitFactor;
			num4 = 25f / this.sceneSettings.goldHitFactor;
		}
		else
		{
			num2 = this.sceneSettings.bronzeHitFactor;
			num3 = this.sceneSettings.silverHitFactor;
			num4 = this.sceneSettings.goldHitFactor;
		}
		if (this.sceneSettings.GetShotFired() == this.sceneSettings.GetStageShotCount())
		{
			virginiaCount = true;
		}
		if (num > num2)
		{
			bronze = true;
		}
		if (num > num3)
		{
			silver = true;
		}
		if (num > num4)
		{
			gold = true;
		}
		this.UpdateResults(num, virginiaCount, bronze, silver, gold);
		this.scored = true;
	}

	// Token: 0x06000263 RID: 611 RVA: 0x0000DC34 File Offset: 0x0000BE34
	private void UpdateResults(float newHitFactor, bool virginiaCount = false, bool bronze = false, bool silver = false, bool gold = false)
	{
		bool flag = false;
		float num = this.sceneSettings.StageTime();
		if (this.sceneSettings.isSteelChallenge)
		{
			num += (float)this.penalties;
		}
		if (this.firstTime)
		{
			this.resultList = new SaveManager.ResultList();
			SaveManager.ResultObject resultObject = new SaveManager.ResultObject();
			resultObject.weaponID = this.controlManager.currentWeapon.WeaponID();
			resultObject.hitFactor = newHitFactor;
			resultObject.time = num;
			this.resultList.topWeapon = resultObject.weaponID;
			this.resultList.topHitFactor = newHitFactor;
			this.resultList.topTime = num;
			this.resultList.resultObjectList.Add(resultObject);
			this.display_newRecord.enabled = true;
			this.resultList.played = true;
			GameEvents.current.RecordBreak(0);
			MonoBehaviour.print("RECORD BREAK PLAYED");
		}
		else
		{
			foreach (SaveManager.ResultObject resultObject2 in this.resultList.resultObjectList)
			{
				if (this.controlManager.currentWeapon.WeaponID() == resultObject2.weaponID && !flag)
				{
					if (newHitFactor > resultObject2.hitFactor)
					{
						resultObject2.hitFactor = newHitFactor;
						resultObject2.time = num;
						this.display_newRecord.enabled = true;
					}
					if (this.resultList.topHitFactor < newHitFactor)
					{
						this.resultList.topWeapon = resultObject2.weaponID;
						this.resultList.topHitFactor = newHitFactor;
						this.resultList.topTime = num;
					}
					flag = true;
				}
			}
			if (!flag)
			{
				SaveManager.ResultObject resultObject3 = new SaveManager.ResultObject();
				resultObject3.weaponID = this.controlManager.currentWeapon.WeaponID();
				resultObject3.hitFactor = newHitFactor;
				resultObject3.time = num;
				this.display_newRecord.enabled = true;
				if (this.resultList.topHitFactor < newHitFactor)
				{
					this.resultList.topWeapon = this.controlManager.currentWeapon.WeaponID();
					this.resultList.topHitFactor = newHitFactor;
					this.resultList.topTime = num;
				}
				this.resultList.resultObjectList.Add(resultObject3);
			}
		}
		if (!this.resultList.virginiaCount)
		{
			this.resultList.virginiaCount = virginiaCount;
			if (virginiaCount)
			{
				GameEvents.current.RecordBreak(1);
				MonoBehaviour.print("RECORD BREAK V COUNT");
			}
		}
		if (!this.resultList.bronzeShield && !this.resultList.silverShield && !this.resultList.goldShield)
		{
			this.resultList.bronzeShield = bronze;
			if (bronze)
			{
				GameEvents.current.RecordBreak(2);
				MonoBehaviour.print("RECORD BREAK BRONZE");
			}
		}
		if (!this.resultList.silverShield && !this.resultList.goldShield)
		{
			this.resultList.silverShield = silver;
			if (silver)
			{
				GameEvents.current.RecordBreak(3);
				MonoBehaviour.print("RECORD BREAK SILVER");
			}
		}
		if (!this.resultList.goldShield)
		{
			this.resultList.goldShield = gold;
			if (gold)
			{
				GameEvents.current.RecordBreak(4);
				MonoBehaviour.print("RECORD BREAK GOLD");
			}
		}
		if (Object.FindObjectOfType<StagePlanner>())
		{
			this.postMatchAchievements.gameObject.SetActive(false);
		}
		this.postMatchAchievements.AnimateResults();
		this.saveManager.UpdateResults(this.ResultFileName(), this.resultList);
	}

	// Token: 0x06000264 RID: 612 RVA: 0x0000DFA0 File Offset: 0x0000C1A0
	private void OnStagePlannerCompStart()
	{
		this.sceneSettings = Object.FindObjectOfType<SceneSettings>();
		Vector3 position;
		Quaternion rotation;
		if (this.sceneSettings.resultsPanelPosition == null)
		{
			position = this.sceneSettings.defaultPanelPosition.position;
			rotation = this.sceneSettings.defaultPanelPosition.rotation;
			MonoBehaviour.print("RESULT PANEL MOVED TO DEFAULT");
		}
		else
		{
			position = this.sceneSettings.resultsPanelPosition.position;
			rotation = this.sceneSettings.resultsPanelPosition.rotation;
			MonoBehaviour.print("RESULT PANEL MOVED TO NEW POSITION");
		}
		this.objectToReposition.transform.position = position;
		this.objectToReposition.transform.rotation = rotation;
		this.LoadResults();
	}

	// Token: 0x06000265 RID: 613 RVA: 0x0000D285 File Offset: 0x0000B485
	public void HideResults()
	{
		this.resultPanel.SetActive(false);
	}

	// Token: 0x06000266 RID: 614 RVA: 0x0000E050 File Offset: 0x0000C250
	private void OnDestroy()
	{
		GameEvents.current.onHolster -= this.ShowResults;
		GameEvents.current.onHolsterDraw -= this.HideResults;
		GameEvents.current.onStagePlannerCompStart -= this.OnStagePlannerCompStart;
		GameEvents.current.onStagePlannerCompEnd -= this.OnStagePlannerEnd;
		GameEvents.current.onStagePlannerCompStart -= this.GatherTargets;
	}

	// Token: 0x04000237 RID: 567
	[SerializeField]
	private GameObject resultPanel;

	// Token: 0x04000238 RID: 568
	[SerializeField]
	private TMP_Text resultText;

	// Token: 0x04000239 RID: 569
	private Color defaultTextColor;

	// Token: 0x0400023A RID: 570
	public bool scored;

	// Token: 0x0400023B RID: 571
	public bool firstTime;

	// Token: 0x0400023C RID: 572
	private HolsterVolume holster;

	// Token: 0x0400023D RID: 573
	private ControlManager controlManager;

	// Token: 0x0400023E RID: 574
	private PaperTarget[] paperTargets;

	// Token: 0x0400023F RID: 575
	private SteelTarget[] steelTargets;

	// Token: 0x04000240 RID: 576
	private float totalScore;

	// Token: 0x04000241 RID: 577
	private int paperAlpha;

	// Token: 0x04000242 RID: 578
	private int paperCharlie;

	// Token: 0x04000243 RID: 579
	private int paperDelta;

	// Token: 0x04000244 RID: 580
	private int steelHit;

	// Token: 0x04000245 RID: 581
	private int bonusHit;

	// Token: 0x04000246 RID: 582
	private int misses;

	// Token: 0x04000247 RID: 583
	private int procedurals;

	// Token: 0x04000248 RID: 584
	private int noShoot;

	// Token: 0x04000249 RID: 585
	private int penalties;

	// Token: 0x0400024A RID: 586
	private int paperAlphaExtras;

	// Token: 0x0400024B RID: 587
	private int paperCharlieExtras;

	// Token: 0x0400024C RID: 588
	private int paperDeltaExtras;

	// Token: 0x0400024D RID: 589
	[SerializeField]
	private PostMatchAchievements postMatchAchievements;

	// Token: 0x0400024E RID: 590
	[SerializeField]
	private IntroPanel introPanel;

	// Token: 0x0400024F RID: 591
	[SerializeField]
	private Animation animation;

	// Token: 0x04000250 RID: 592
	[Header("Result Texts")]
	[SerializeField]
	private TMP_Text display_weapon;

	// Token: 0x04000251 RID: 593
	[SerializeField]
	private TMP_Text display_time;

	// Token: 0x04000252 RID: 594
	[SerializeField]
	private TMP_Text display_hitFactor;

	// Token: 0x04000253 RID: 595
	[SerializeField]
	private TMP_Text display_alpha;

	// Token: 0x04000254 RID: 596
	[SerializeField]
	private TMP_Text display_alphaExtras;

	// Token: 0x04000255 RID: 597
	[SerializeField]
	private TMP_Text display_charlie;

	// Token: 0x04000256 RID: 598
	[SerializeField]
	private TMP_Text display_charlieExtras;

	// Token: 0x04000257 RID: 599
	[SerializeField]
	private TMP_Text display_delta;

	// Token: 0x04000258 RID: 600
	[SerializeField]
	private TMP_Text display_deltaExtras;

	// Token: 0x04000259 RID: 601
	[SerializeField]
	private TMP_Text display_steel;

	// Token: 0x0400025A RID: 602
	[SerializeField]
	private TMP_Text display_bonus;

	// Token: 0x0400025B RID: 603
	[SerializeField]
	private TMP_Text display_recordTime;

	// Token: 0x0400025C RID: 604
	[SerializeField]
	private TMP_Text display_recordHitFactor;

	// Token: 0x0400025D RID: 605
	[SerializeField]
	private TMP_Text display_misses;

	// Token: 0x0400025E RID: 606
	[SerializeField]
	private TMP_Text display_procedurals;

	// Token: 0x0400025F RID: 607
	[SerializeField]
	private TMP_Text display_noShoots;

	// Token: 0x04000260 RID: 608
	[SerializeField]
	private TMP_Text display_totalScore;

	// Token: 0x04000261 RID: 609
	[SerializeField]
	private TMP_Text display_newRecord;

	// Token: 0x04000262 RID: 610
	[Header("Classifier")]
	[SerializeField]
	private TMP_Text display_maxHF;

	// Token: 0x04000263 RID: 611
	[Header("Steel Challenge")]
	[SerializeField]
	private TMP_Text display_stringOne;

	// Token: 0x04000264 RID: 612
	[SerializeField]
	private TMP_Text display_stringTwo;

	// Token: 0x04000265 RID: 613
	[SerializeField]
	private TMP_Text display_stringThree;

	// Token: 0x04000266 RID: 614
	[SerializeField]
	private TMP_Text display_stringFour;

	// Token: 0x04000267 RID: 615
	[SerializeField]
	private TMP_Text display_stringFive;

	// Token: 0x04000268 RID: 616
	[SerializeField]
	private TMP_Text display_averageOfStrings;

	// Token: 0x04000269 RID: 617
	[SerializeField]
	private TMP_Text display_totalTime;

	// Token: 0x0400026A RID: 618
	[SerializeField]
	private TMP_Text display_recordTotalTime;

	// Token: 0x0400026B RID: 619
	[SerializeField]
	private TMP_Text display_recordBestStringTime;

	// Token: 0x0400026C RID: 620
	[Header("StagePlanner")]
	[SerializeField]
	private GameObject objectToReposition;

	// Token: 0x0400026D RID: 621
	private SceneSettings sceneSettings;

	// Token: 0x0400026E RID: 622
	private float savedBestTime;

	// Token: 0x0400026F RID: 623
	private float savedHitFactor;

	// Token: 0x04000270 RID: 624
	private SaveManager saveManager;

	// Token: 0x04000271 RID: 625
	private SaveManager.ResultList resultList;
}
