﻿using System;
using UnityEngine.Audio;

// Token: 0x02000149 RID: 329
public struct ReflectionSnapshot
{
	// Token: 0x04000A8F RID: 2703
	public AudioMixerSnapshot mixerSnapshot;

	// Token: 0x04000A90 RID: 2704
	public float fadeTime;
}
