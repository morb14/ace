﻿using System;
using UnityEngine;

// Token: 0x02000106 RID: 262
public class OVRNamedArrayAttribute : PropertyAttribute
{
	// Token: 0x06000695 RID: 1685 RVA: 0x0002B0E3 File Offset: 0x000292E3
	public OVRNamedArrayAttribute(string[] names)
	{
		this.names = names;
	}

	// Token: 0x040008E4 RID: 2276
	public readonly string[] names;
}
