﻿using System;
using UnityEngine;

// Token: 0x0200002A RID: 42
public class ControlManager : MonoBehaviour
{
	// Token: 0x060000D1 RID: 209 RVA: 0x00006425 File Offset: 0x00004625
	public void Start()
	{
		OVRManager.instance.useRecommendedMSAALevel = false;
		this.status = ControlManager.Status.Hand;
		this.menuController = Object.FindObjectOfType<MenuController>();
		this.gameManager = Object.FindObjectOfType<GameManager>();
	}

	// Token: 0x060000D2 RID: 210 RVA: 0x0000644F File Offset: 0x0000464F
	public void ChangeStatus(ControlManager.Status controllerState)
	{
		this.status = controllerState;
		if (controllerState != ControlManager.Status.Hand)
		{
		}
	}

	// Token: 0x060000D3 RID: 211 RVA: 0x00006460 File Offset: 0x00004660
	private void Update()
	{
		if (this.controllerMode == ControlManager.ControllerMode.OneHand && this.status == ControlManager.Status.Hand)
		{
			if (OVRInput.GetDown(OVRInput.Button.PrimaryIndexTrigger, OVRInput.Controller.RTouch))
			{
				this.ShowController(OVRInput.Controller.RTouch);
				this.handedness = ControlManager.Handedness.Right;
				return;
			}
			if (OVRInput.GetDown(OVRInput.Button.PrimaryIndexTrigger, OVRInput.Controller.LTouch))
			{
				this.ShowController(OVRInput.Controller.LTouch);
				this.handedness = ControlManager.Handedness.Left;
			}
		}
	}

	// Token: 0x060000D4 RID: 212 RVA: 0x000064B8 File Offset: 0x000046B8
	public void ShowController(OVRInput.Controller controller)
	{
		if (controller == OVRInput.Controller.LTouch)
		{
			this.gameManager.handObjectLeft.SetActive(true);
			this.gameManager.handObjectRight.SetActive(false);
		}
		if (controller == OVRInput.Controller.RTouch)
		{
			this.gameManager.handObjectLeft.SetActive(false);
			this.gameManager.handObjectRight.SetActive(true);
		}
		if (controller == OVRInput.Controller.All)
		{
			this.gameManager.handObjectRight.SetActive(true);
			this.gameManager.handObjectLeft.SetActive(true);
		}
		if (controller == OVRInput.Controller.None)
		{
			this.gameManager.handObjectRight.SetActive(false);
			this.gameManager.handObjectLeft.SetActive(false);
		}
	}

	// Token: 0x060000D5 RID: 213 RVA: 0x0000655C File Offset: 0x0000475C
	public void ChangeControllerMode(ControlManager.ControllerMode mode)
	{
		this.controllerMode = mode;
		GameEvents.current.ChangeControllerMode();
	}

	// Token: 0x060000D6 RID: 214 RVA: 0x0000656F File Offset: 0x0000476F
	public Collider EngagedByCollider()
	{
		if (this.engagedBy != null)
		{
			return this.engagedBy;
		}
		return null;
	}

	// Token: 0x060000D7 RID: 215 RVA: 0x00006587 File Offset: 0x00004787
	public void Engage(bool toggle, Collider collider)
	{
		if (toggle)
		{
			this.engagedBy = collider;
			MonoBehaviour.print("control manager activated by " + collider.gameObject);
			return;
		}
		if (collider == this.engagedBy)
		{
			this.engagedBy = null;
		}
	}

	// Token: 0x060000D8 RID: 216 RVA: 0x000065BE File Offset: 0x000047BE
	public WeaponController GetWeapon()
	{
		return this.currentWeapon;
	}

	// Token: 0x060000D9 RID: 217 RVA: 0x000065C6 File Offset: 0x000047C6
	public OVRInput.Controller Controller()
	{
		return this.controller;
	}

	// Token: 0x040000DB RID: 219
	public ControlManager.ControllerMode controllerMode;

	// Token: 0x040000DC RID: 220
	public OVRInput.Controller controller;

	// Token: 0x040000DD RID: 221
	public ControlManager.Handedness handedness;

	// Token: 0x040000DE RID: 222
	public GameObject controllerObject;

	// Token: 0x040000DF RID: 223
	public WeaponController currentWeapon;

	// Token: 0x040000E0 RID: 224
	public ControlManager.Status status;

	// Token: 0x040000E1 RID: 225
	private MenuController menuController;

	// Token: 0x040000E2 RID: 226
	private GameManager gameManager;

	// Token: 0x040000E3 RID: 227
	private Collider engagedBy;

	// Token: 0x040000E4 RID: 228
	public bool weaponEquipped;

	// Token: 0x020001B0 RID: 432
	public enum ControllerMode
	{
		// Token: 0x04000D13 RID: 3347
		OneHand,
		// Token: 0x04000D14 RID: 3348
		TwoHand,
		// Token: 0x04000D15 RID: 3349
		ControlAR,
		// Token: 0x04000D16 RID: 3350
		ControlARPro,
		// Token: 0x04000D17 RID: 3351
		ControlAR2
	}

	// Token: 0x020001B1 RID: 433
	public enum Status
	{
		// Token: 0x04000D19 RID: 3353
		Empty,
		// Token: 0x04000D1A RID: 3354
		Hand,
		// Token: 0x04000D1B RID: 3355
		Gun
	}

	// Token: 0x020001B2 RID: 434
	public enum Handedness
	{
		// Token: 0x04000D1D RID: 3357
		Right,
		// Token: 0x04000D1E RID: 3358
		Left
	}
}
