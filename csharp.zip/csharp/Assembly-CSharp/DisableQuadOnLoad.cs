﻿using System;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x02000009 RID: 9
public class DisableQuadOnLoad : MonoBehaviour
{
	// Token: 0x06000031 RID: 49 RVA: 0x0000316C File Offset: 0x0000136C
	private void Start()
	{
		this.quadRenderer = base.GetComponent<MeshRenderer>();
		SceneManager.sceneLoaded += this.DisableQuad;
	}

	// Token: 0x06000032 RID: 50 RVA: 0x0000318B File Offset: 0x0000138B
	private void DisableQuad(Scene scene, LoadSceneMode mode)
	{
		this.quadRenderer.enabled = false;
	}

	// Token: 0x06000033 RID: 51 RVA: 0x00003199 File Offset: 0x00001399
	private void OnDestroy()
	{
		SceneManager.sceneLoaded -= this.DisableQuad;
	}

	// Token: 0x04000030 RID: 48
	private MeshRenderer quadRenderer;
}
