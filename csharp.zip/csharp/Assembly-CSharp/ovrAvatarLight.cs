﻿using System;
using UnityEngine;

// Token: 0x020000F1 RID: 241
public struct ovrAvatarLight
{
	// Token: 0x04000886 RID: 2182
	public uint id;

	// Token: 0x04000887 RID: 2183
	public ovrAvatarLightType type;

	// Token: 0x04000888 RID: 2184
	public float intensity;

	// Token: 0x04000889 RID: 2185
	public Vector3 worldDirection;

	// Token: 0x0400088A RID: 2186
	public Vector3 worldPosition;

	// Token: 0x0400088B RID: 2187
	public float range;

	// Token: 0x0400088C RID: 2188
	public float spotAngleDeg;
}
