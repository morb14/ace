﻿using System;
using UnityEngine;

// Token: 0x02000045 RID: 69
public class OtherTarget : MonoBehaviour
{
	// Token: 0x06000232 RID: 562 RVA: 0x0000C668 File Offset: 0x0000A868
	public void Reaction(Vector3 hitPos, Quaternion hitRot, float energy)
	{
		this.hit = true;
		if (!this.targetInfoCreated)
		{
			this.targetInfoCreated = true;
			this.CreateTargetInfo();
		}
		switch (this.type)
		{
		case OtherTarget.PropType.Bottle:
		{
			int num = Random.Range(-2000, 2000);
			this.impactEffect.transform.position = hitPos;
			this.impactEffect.transform.rotation = hitRot;
			this.impactEffect.SetActive(true);
			if (this.hitToRB && this.hitCount == 0)
			{
				base.GetComponent<Rigidbody>().isKinematic = false;
				base.GetComponent<Rigidbody>().AddTorque(hitPos.normalized * (float)num, ForceMode.Acceleration);
			}
			this.hitCount++;
			if (this.hitCount > 1 || energy > 500f)
			{
				this.destroyEffect.SetActive(true);
				this.destroyEffect.transform.parent = null;
				this.destroyEffect.transform.localScale = base.transform.localScale;
				Object.Destroy(base.gameObject);
				return;
			}
			break;
		}
		case OtherTarget.PropType.Clay:
			if (this.compObject != null)
			{
				this.clayHit = true;
			}
			Object.Destroy(base.gameObject);
			return;
		case OtherTarget.PropType.Robot:
			if (this.robotController != null)
			{
				this.robotController.TargetHit(this.hitZone, energy);
				return;
			}
			break;
		case OtherTarget.PropType.BasicRB:
		{
			int num2 = Random.Range(-200, 200);
			if (this.hitToRB)
			{
				base.GetComponent<MeshCollider>().convex = true;
				base.GetComponent<Rigidbody>().isKinematic = false;
				base.GetComponent<Rigidbody>().AddTorque(hitPos.normalized * (float)num2, ForceMode.Acceleration);
			}
			base.GetComponent<BonusTarget>().BonusTargetHit(true);
			break;
		}
		default:
			return;
		}
	}

	// Token: 0x06000233 RID: 563 RVA: 0x0000C824 File Offset: 0x0000AA24
	private void CreateTargetInfo()
	{
		GameObject gameObject = new GameObject();
		gameObject.name = base.name + "TargetInfo";
		gameObject.transform.position = base.transform.position;
		gameObject.transform.rotation = base.transform.rotation;
		TargetInfo targetInfo = gameObject.AddComponent<TargetInfo>();
		if (base.GetComponent<TargetInfo>() != null)
		{
			targetInfo.targetID = base.GetComponent<TargetInfo>().targetID;
		}
		gameObject.GetComponent<TargetInfo>().dontSave = true;
	}

	// Token: 0x06000234 RID: 564 RVA: 0x0000C8AC File Offset: 0x0000AAAC
	private void OnDestroy()
	{
		if (!this.hit)
		{
			return;
		}
		if (base.GetComponentsInChildren<TargetReaction>().Length != 0)
		{
			foreach (TargetReaction targetReaction in base.GetComponentsInChildren<TargetReaction>())
			{
				targetReaction.gameObject.transform.parent = null;
				targetReaction.gameObject.transform.position = new Vector3(0f, -10f, 0f);
			}
		}
		if (this.type == OtherTarget.PropType.Clay && this.hit)
		{
			GameObject gameObject = null;
			if (this.compObject != null)
			{
				gameObject = Object.Instantiate<GameObject>(this.compObject, Vector3.zero, Quaternion.identity);
				gameObject.transform.parent = null;
			}
			if (gameObject != null && gameObject.GetComponent<BonusTarget>())
			{
				if (this.clayHit)
				{
					gameObject.GetComponent<BonusTarget>().BonusTargetHit(true);
				}
				if (this.hasPenalty)
				{
					gameObject.GetComponent<BonusTarget>().hasPenalty = true;
				}
			}
		}
		if (this.destroyEffect != null)
		{
			this.destroyEffect.SetActive(true);
			this.destroyEffect.transform.parent = null;
			this.destroyEffect.transform.localScale = base.transform.localScale;
			this.destroyEffect.transform.rotation = Quaternion.identity;
		}
	}

	// Token: 0x04000215 RID: 533
	[SerializeField]
	private GameObject impactEffect;

	// Token: 0x04000216 RID: 534
	[SerializeField]
	private GameObject destroyEffect;

	// Token: 0x04000217 RID: 535
	[SerializeField]
	private OtherTarget.PropType type;

	// Token: 0x04000218 RID: 536
	[SerializeField]
	private bool hitToRB;

	// Token: 0x04000219 RID: 537
	[SerializeField]
	private bool destroyIfCollide;

	// Token: 0x0400021A RID: 538
	[SerializeField]
	public Rigidbody rigidbody;

	// Token: 0x0400021B RID: 539
	[Header("Clay Competition Objects")]
	[SerializeField]
	private GameObject compObject;

	// Token: 0x0400021C RID: 540
	[SerializeField]
	public bool hasPenalty;

	// Token: 0x0400021D RID: 541
	[Header("Robot Related")]
	[SerializeField]
	private RobotController robotController;

	// Token: 0x0400021E RID: 542
	[SerializeField]
	private RobotController.RobotHitZone hitZone;

	// Token: 0x0400021F RID: 543
	private int hitCount;

	// Token: 0x04000220 RID: 544
	private bool clayHit;

	// Token: 0x04000221 RID: 545
	private bool targetInfoCreated;

	// Token: 0x04000222 RID: 546
	private bool hit;

	// Token: 0x020001B9 RID: 441
	public enum PropType
	{
		// Token: 0x04000D47 RID: 3399
		Bottle,
		// Token: 0x04000D48 RID: 3400
		Clay,
		// Token: 0x04000D49 RID: 3401
		Robot,
		// Token: 0x04000D4A RID: 3402
		BasicRB
	}
}
