﻿using System;
using UnityEngine;

// Token: 0x0200000C RID: 12
public class ForceTubeManager : MonoBehaviour
{
	// Token: 0x0600003E RID: 62 RVA: 0x000033D4 File Offset: 0x000015D4
	private void Start()
	{
		GameEvents.current.onShotFired += this.OnShotFired;
		ForceTubeVRInterface.InitAsync(false);
	}

	// Token: 0x0600003F RID: 63 RVA: 0x000033F2 File Offset: 0x000015F2
	private void OnShotFired()
	{
		ForceTubeVRInterface.Kick(byte.MaxValue, ForceTubeVRChannel.all);
	}
}
