﻿using System;
using UnityEngine;

// Token: 0x02000108 RID: 264
public sealed class OVRTouchpadHelper : MonoBehaviour
{
	// Token: 0x0600069C RID: 1692 RVA: 0x0002B1FE File Offset: 0x000293FE
	private void Awake()
	{
		Object.DontDestroyOnLoad(base.gameObject);
	}

	// Token: 0x0600069D RID: 1693 RVA: 0x0002B20B File Offset: 0x0002940B
	private void Start()
	{
		OVRTouchpad.AddListener(new OVRTouchpad.OVRTouchpadCallback<OVRTouchpad.TouchEvent>(this.LocalTouchEventCallback));
	}

	// Token: 0x0600069E RID: 1694 RVA: 0x0002B21E File Offset: 0x0002941E
	private void Update()
	{
		OVRTouchpad.Update();
	}

	// Token: 0x0600069F RID: 1695 RVA: 0x0002B225 File Offset: 0x00029425
	public void OnDisable()
	{
		OVRTouchpad.OnDisable();
	}

	// Token: 0x060006A0 RID: 1696 RVA: 0x0002B22C File Offset: 0x0002942C
	private void LocalTouchEventCallback(OVRTouchpad.TouchEvent touchEvent)
	{
		switch (touchEvent)
		{
		default:
			return;
		}
	}
}
