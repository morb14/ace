﻿using System;
using System.Runtime.InteropServices;

// Token: 0x020000E7 RID: 231
public struct ovrAvatarBlendShapeParams
{
	// Token: 0x04000869 RID: 2153
	public uint blendShapeParamCount;

	// Token: 0x0400086A RID: 2154
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 64)]
	public float[] blendShapeParams;
}
