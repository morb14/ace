﻿using System;
using UnityEngine;

// Token: 0x02000049 RID: 73
public class RandomAnimationStarter : MonoBehaviour
{
	// Token: 0x0600024E RID: 590 RVA: 0x0000D04D File Offset: 0x0000B24D
	private void Start()
	{
		base.GetComponent<Animator>().Play(0, -1, Random.value);
	}
}
