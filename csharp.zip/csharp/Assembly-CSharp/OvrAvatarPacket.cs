﻿using System;
using System.Collections.Generic;
using System.IO;

// Token: 0x020000B6 RID: 182
public class OvrAvatarPacket
{
	// Token: 0x1700000B RID: 11
	// (get) Token: 0x0600060B RID: 1547 RVA: 0x00027C9E File Offset: 0x00025E9E
	public float Duration
	{
		get
		{
			return this.frameTimes[this.frameTimes.Count - 1];
		}
	}

	// Token: 0x1700000C RID: 12
	// (get) Token: 0x0600060C RID: 1548 RVA: 0x00027CB8 File Offset: 0x00025EB8
	public OvrAvatarDriver.PoseFrame FinalFrame
	{
		get
		{
			return this.frames[this.frames.Count - 1];
		}
	}

	// Token: 0x0600060D RID: 1549 RVA: 0x00027CD2 File Offset: 0x00025ED2
	public OvrAvatarPacket()
	{
	}

	// Token: 0x0600060E RID: 1550 RVA: 0x00027D08 File Offset: 0x00025F08
	public OvrAvatarPacket(OvrAvatarDriver.PoseFrame initialPose)
	{
		this.frameTimes.Add(0f);
		this.frames.Add(initialPose);
	}

	// Token: 0x0600060F RID: 1551 RVA: 0x00027D64 File Offset: 0x00025F64
	private OvrAvatarPacket(List<float> frameTimes, List<OvrAvatarDriver.PoseFrame> frames, List<byte[]> audioPackets)
	{
		this.frameTimes = frameTimes;
		this.frames = frames;
	}

	// Token: 0x06000610 RID: 1552 RVA: 0x00027DB1 File Offset: 0x00025FB1
	public void AddFrame(OvrAvatarDriver.PoseFrame frame, float deltaSeconds)
	{
		this.frameTimes.Add(this.Duration + deltaSeconds);
		this.frames.Add(frame);
	}

	// Token: 0x06000611 RID: 1553 RVA: 0x00027DD4 File Offset: 0x00025FD4
	public OvrAvatarDriver.PoseFrame GetPoseFrame(float seconds)
	{
		if (this.frames.Count == 1)
		{
			return this.frames[0];
		}
		int num = 1;
		while (num < this.frameTimes.Count && this.frameTimes[num] < seconds)
		{
			num++;
		}
		OvrAvatarDriver.PoseFrame a = this.frames[num - 1];
		OvrAvatarDriver.PoseFrame b = this.frames[num];
		float num2 = this.frameTimes[num - 1];
		float num3 = this.frameTimes[num];
		float t = (seconds - num2) / (num3 - num2);
		return OvrAvatarDriver.PoseFrame.Interpolate(a, b, t);
	}

	// Token: 0x06000612 RID: 1554 RVA: 0x00027E6C File Offset: 0x0002606C
	public static OvrAvatarPacket Read(Stream stream)
	{
		BinaryReader binaryReader = new BinaryReader(stream);
		int num = binaryReader.ReadInt32();
		List<float> list = new List<float>(num);
		for (int i = 0; i < num; i++)
		{
			list.Add(binaryReader.ReadSingle());
		}
		List<OvrAvatarDriver.PoseFrame> list2 = new List<OvrAvatarDriver.PoseFrame>(num);
		for (int j = 0; j < num; j++)
		{
			list2.Add(binaryReader.ReadPoseFrame());
		}
		int num2 = binaryReader.ReadInt32();
		List<byte[]> list3 = new List<byte[]>(num2);
		for (int k = 0; k < num2; k++)
		{
			int count = binaryReader.ReadInt32();
			byte[] item = binaryReader.ReadBytes(count);
			list3.Add(item);
		}
		return new OvrAvatarPacket(list, list2, list3);
	}

	// Token: 0x06000613 RID: 1555 RVA: 0x00027F14 File Offset: 0x00026114
	public void Write(Stream stream)
	{
		BinaryWriter binaryWriter = new BinaryWriter(stream);
		int count = this.frameTimes.Count;
		binaryWriter.Write(count);
		for (int i = 0; i < count; i++)
		{
			binaryWriter.Write(this.frameTimes[i]);
		}
		for (int j = 0; j < count; j++)
		{
			OvrAvatarDriver.PoseFrame frame = this.frames[j];
			binaryWriter.Write(frame);
		}
		int count2 = this.encodedAudioPackets.Count;
		binaryWriter.Write(count2);
		for (int k = 0; k < count2; k++)
		{
			byte[] array = this.encodedAudioPackets[k];
			binaryWriter.Write(array.Length);
			binaryWriter.Write(array);
		}
	}

	// Token: 0x0400074D RID: 1869
	public IntPtr ovrNativePacket = IntPtr.Zero;

	// Token: 0x0400074E RID: 1870
	private List<float> frameTimes = new List<float>();

	// Token: 0x0400074F RID: 1871
	private List<OvrAvatarDriver.PoseFrame> frames = new List<OvrAvatarDriver.PoseFrame>();

	// Token: 0x04000750 RID: 1872
	private List<byte[]> encodedAudioPackets = new List<byte[]>();
}
