﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

// Token: 0x02000056 RID: 86
public class ShotTimer : MonoBehaviour
{
	// Token: 0x0600033C RID: 828 RVA: 0x00014E58 File Offset: 0x00013058
	private void Start()
	{
		this.state = ShotTimer.State.Dormant;
		this.hapticManager = Object.FindObjectOfType<HapticManager>();
		this.outline = base.GetComponent<Outline>();
		this.grabbable = base.GetComponent<OVRGrabbable>();
		this.controlManager = Object.FindObjectOfType<ControlManager>();
		GameEvents.current.onShotFired += this.ShotFired;
		this.audioSource = base.GetComponent<AudioSource>();
		this.tmp_firstShotFixed.enabled = false;
		this.randomPattern = this.RandomBouncingPattern();
		this.thisCollider = base.GetComponent<Collider>();
		this.displayReviewShotCount = -1;
	}

	// Token: 0x0600033D RID: 829 RVA: 0x00014EE7 File Offset: 0x000130E7
	private void Update()
	{
		this.Test();
		this.UpdateDisplay();
		this.Control();
	}

	// Token: 0x0600033E RID: 830 RVA: 0x00014EFC File Offset: 0x000130FC
	private void Test()
	{
		if (this.testGo)
		{
			this.GoButtonPressed();
			this.testGo = false;
		}
		if (this.testShot)
		{
			this.ShotFired();
			this.testShot = false;
		}
		if (this.testReview)
		{
			this.ReviewButtonPressed();
			this.testReview = false;
		}
	}

	// Token: 0x0600033F RID: 831 RVA: 0x00014F48 File Offset: 0x00013148
	private void Reset()
	{
		this.shotList.Clear();
		this.displayReviewShotCount = -1;
		this.stringShotTime = "";
		this.stringShotCount = "";
		this.stringFirstShot = "";
		this.stringSplit = "";
	}

	// Token: 0x06000340 RID: 832 RVA: 0x00014F88 File Offset: 0x00013188
	private void UpdateDisplay()
	{
		if (this.state == ShotTimer.State.CountDown)
		{
			this.Reset();
			if (Time.time - this.goTime < this.countDownTime)
			{
				this.displayShotTime = this.countDownTime - (Time.time - this.goTime);
				this.stringShotTime = this.displayShotTime.ToString("F2");
			}
			else
			{
				this.audioSource.Play();
				this.sessionStartTime = Time.time;
				this.state = ShotTimer.State.Active;
			}
		}
		else if (this.state == ShotTimer.State.Active)
		{
			this.displayShotTime = Time.time - this.sessionStartTime;
			this.stringShotTime = this.displayShotTime.ToString("F2");
			if (this.shotList.Count == 0)
			{
				this.stringShotCount = this.AnimateBouncingIcons(0);
			}
			if (this.shotList.Count > 0 && this.shotList.Count < 100)
			{
				this.tmp_firstShotFixed.enabled = true;
				this.displayFirstShot = this.shotList[0];
				this.stringFirstShot = this.displayFirstShot.ToString("F2");
				if (this.shotList.Count == 1)
				{
					this.displayShotTime = this.shotList[0];
					this.displaySplit = this.shotList[0];
				}
				else if (this.shotList.Count > 0)
				{
					this.displayShotTime = this.shotList[this.shotList.Count - 1];
					this.displaySplit = this.shotList[this.shotList.Count - 1] - this.shotList[this.shotList.Count - 2];
				}
				this.stringSplit = this.displaySplit.ToString("F2");
				this.stringShotCount = this.shotList.Count.ToString();
				this.stringShotTime = this.displayShotTime.ToString("F2");
			}
		}
		else if (this.state == ShotTimer.State.StandBy)
		{
			this.stringSplit = "";
			if (Time.time <= this.reviewTime + 0.6f)
			{
				this.stringShotCount = "";
				if (this.shotList.Count > 0)
				{
					this.stringShotTime = "En d~";
				}
				else
				{
					this.stringShotTime = "no nE";
				}
			}
			else
			{
				this.stringShotTime = this.AnimateBouncingIcons(1);
			}
		}
		else if (this.state == ShotTimer.State.Review)
		{
			this.stringFirstShot = "";
			MonoBehaviour.print(this.displayReviewShotCount + "  " + this.shotList.Count);
			this.displayShotTime = this.shotList[this.displayReviewShotCount];
			this.stringShotTime = this.displayShotTime.ToString("F2");
			this.displayShotCount = this.displayReviewShotCount + 1;
			this.stringShotCount = this.displayShotCount.ToString();
			if (this.displayReviewShotCount == 0)
			{
				this.displaySplit = this.shotList[0];
			}
			else
			{
				this.displaySplit = this.shotList[this.displayReviewShotCount] - this.shotList[this.displayReviewShotCount - 1];
			}
			this.stringSplit = this.displaySplit.ToString("F2");
		}
		this.tmp_shotTime.text = this.StringFormat(12, this.stringShotTime);
		this.tmp_shotCount.text = "<mspace=mspace=12>" + this.stringShotCount + "</mspace>";
		this.tmp_firstShot.text = this.StringFormat(7, this.stringFirstShot);
		this.tmp_split.text = this.StringFormat(7, this.stringSplit);
	}

	// Token: 0x06000341 RID: 833 RVA: 0x0001535C File Offset: 0x0001355C
	private string StringFormat(int mspace, string input)
	{
		if (input.Length > 0)
		{
			string text = input.Substring(input.Length - 2, 2);
			string text2 = input.Substring(input.Length - 3, 1);
			string text3 = input.Substring(0, input.Length - 3);
			return string.Concat(new object[]
			{
				"<mspace=mspace=",
				mspace,
				">",
				text3,
				"</mspace><mspace=mspace=",
				mspace / 4,
				">",
				text2,
				"<mspace=mspace=",
				mspace,
				">",
				text,
				"</mspace>"
			});
		}
		return "";
	}

	// Token: 0x06000342 RID: 834 RVA: 0x0001541C File Offset: 0x0001361C
	private string AnimateBouncingIcons(int type)
	{
		if (this.bouncingAnimationStart == 0f)
		{
			this.bouncingAnimationStart = Time.time;
		}
		if (type == 0)
		{
			if (Time.time < this.bouncingAnimationStart + this.bouncingAnimationRate * 2f)
			{
				if (Time.time < this.bouncingAnimationStart + this.bouncingAnimationRate)
				{
					return "><";
				}
				return "<>";
			}
			else
			{
				this.bouncingAnimationStart = 0f;
			}
		}
		if (type == 1)
		{
			if (Time.time < this.bouncingAnimationStart + this.bouncingAnimationRate)
			{
				return this.randomPattern;
			}
			this.randomPattern = this.RandomBouncingPattern();
			this.bouncingAnimationStart = 0f;
		}
		return "";
	}

	// Token: 0x06000343 RID: 835 RVA: 0x000154C4 File Offset: 0x000136C4
	private string RandomBouncingPattern()
	{
		string[] array = new string[]
		{
			">~~ ~~",
			"<~~ ~~",
			" >~ ~~",
			" <~ ~~",
			"  > ~~",
			"  < ~~",
			"    >~",
			"    <~",
			"     >",
			"     <"
		};
		return array[Random.Range(0, array.Length)];
	}

	// Token: 0x06000344 RID: 836 RVA: 0x00015538 File Offset: 0x00013738
	private void GoButtonPressed()
	{
		if (this.state == ShotTimer.State.Dormant)
		{
			this.state = ShotTimer.State.CountDown;
			this.goTime = Time.time;
		}
		if (this.state == ShotTimer.State.Active || this.state == ShotTimer.State.Review || this.state == ShotTimer.State.StandBy)
		{
			this.state = ShotTimer.State.CountDown;
			this.goTime = Time.time;
		}
	}

	// Token: 0x06000345 RID: 837 RVA: 0x0001558C File Offset: 0x0001378C
	private void ReviewButtonPressed()
	{
		this.tmp_firstShotFixed.enabled = false;
		this.reviewTime = Time.time;
		if (this.state != ShotTimer.State.Active)
		{
			if (this.state == ShotTimer.State.Review)
			{
				this.displayReviewShotCount++;
				if (this.displayReviewShotCount > this.shotList.Count - 1)
				{
					this.state = ShotTimer.State.StandBy;
					return;
				}
			}
			else if (this.state == ShotTimer.State.StandBy)
			{
				if (this.shotList.Count == 0)
				{
					return;
				}
				this.state = ShotTimer.State.Review;
				this.displayReviewShotCount = 0;
			}
			return;
		}
		if (this.shotList.Count == 0)
		{
			this.state = ShotTimer.State.StandBy;
			return;
		}
		this.state = ShotTimer.State.Review;
		this.displayReviewShotCount++;
	}

	// Token: 0x06000346 RID: 838 RVA: 0x0001563D File Offset: 0x0001383D
	private void ShotFired()
	{
		if (this.state == ShotTimer.State.Active)
		{
			this.shotList.Add(Time.time - this.sessionStartTime);
		}
	}

	// Token: 0x06000347 RID: 839 RVA: 0x00015660 File Offset: 0x00013860
	private void OnTriggerEnter(Collider other)
	{
		if (other.GetComponent<OVRGrabber>())
		{
			this.grabber = other.GetComponent<OVRGrabber>();
			if (this.controlManager.EngagedByCollider() == null)
			{
				this.controlManager.Engage(true, this.thisCollider);
				this.colliding = true;
			}
		}
	}

	// Token: 0x06000348 RID: 840 RVA: 0x000156B4 File Offset: 0x000138B4
	private void OnTriggerExit(Collider other)
	{
		if (other.GetComponent<OVRGrabber>() && this.controlManager.EngagedByCollider() == this.thisCollider)
		{
			this.controlManager.Engage(false, this.thisCollider);
			this.colliding = false;
			this.grabber = null;
		}
	}

	// Token: 0x06000349 RID: 841 RVA: 0x00015708 File Offset: 0x00013908
	private void Control()
	{
		if (this.colliding && this.controlManager.status != ControlManager.Status.Gun && this.controlManager.EngagedByCollider() == this.thisCollider)
		{
			if (OVRInput.GetDown(OVRInput.Button.PrimaryIndexTrigger, this.grabber.controllerType))
			{
				this.hapticManager.VibrateStandard(0.5f, 0.2f, 0.1f, this.grabber.controllerType);
			}
			if (OVRInput.GetUp(OVRInput.Button.PrimaryIndexTrigger, this.grabber.controllerType))
			{
				this.hapticManager.VibrateStandard(0.5f, 0.5f, 0.1f, this.grabber.controllerType);
				this.GoButtonPressed();
			}
			if (OVRInput.GetDown(OVRInput.Button.One, this.grabber.controllerType))
			{
				this.hapticManager.VibrateStandard(0.5f, 0.5f, 0.1f, this.grabber.controllerType);
				this.ReviewButtonPressed();
			}
		}
	}

	// Token: 0x0600034A RID: 842 RVA: 0x00015808 File Offset: 0x00013A08
	private void OnDestroy()
	{
		GameEvents.current.onShotFired -= this.ShotFired;
	}

	// Token: 0x040003D5 RID: 981
	[SerializeField]
	private float countDownTime = 3f;

	// Token: 0x040003D6 RID: 982
	[SerializeField]
	private TMP_Text tmp_shotCount;

	// Token: 0x040003D7 RID: 983
	[SerializeField]
	private TMP_Text tmp_shotTime;

	// Token: 0x040003D8 RID: 984
	[SerializeField]
	private TMP_Text tmp_firstShot;

	// Token: 0x040003D9 RID: 985
	[SerializeField]
	private TMP_Text tmp_split;

	// Token: 0x040003DA RID: 986
	[SerializeField]
	private TMP_Text tmp_firstShotFixed;

	// Token: 0x040003DB RID: 987
	[SerializeField]
	private TMP_Text tmp_firstShotDot;

	// Token: 0x040003DC RID: 988
	[SerializeField]
	private TMP_Text tmp_shotTimeDot;

	// Token: 0x040003DD RID: 989
	[SerializeField]
	private TMP_Text tmp_splitDot;

	// Token: 0x040003DE RID: 990
	private AudioSource audioSource;

	// Token: 0x040003DF RID: 991
	private ShotTimer.State state;

	// Token: 0x040003E0 RID: 992
	private OVRGrabbable grabbable;

	// Token: 0x040003E1 RID: 993
	private OVRGrabber grabber;

	// Token: 0x040003E2 RID: 994
	private ControlManager controlManager;

	// Token: 0x040003E3 RID: 995
	private Collider thisCollider;

	// Token: 0x040003E4 RID: 996
	private HapticManager hapticManager;

	// Token: 0x040003E5 RID: 997
	private float goTime;

	// Token: 0x040003E6 RID: 998
	private float reviewTime;

	// Token: 0x040003E7 RID: 999
	private float countDownTimer;

	// Token: 0x040003E8 RID: 1000
	private float sessionStartTime;

	// Token: 0x040003E9 RID: 1001
	private float bouncingAnimationRate = 0.3f;

	// Token: 0x040003EA RID: 1002
	private float bouncingAnimationStart;

	// Token: 0x040003EB RID: 1003
	private float displayShotTime;

	// Token: 0x040003EC RID: 1004
	private float displaySplit;

	// Token: 0x040003ED RID: 1005
	private float displayFirstShot;

	// Token: 0x040003EE RID: 1006
	private int displayShotCount;

	// Token: 0x040003EF RID: 1007
	private int displayReviewShotCount;

	// Token: 0x040003F0 RID: 1008
	private List<float> shotList = new List<float>();

	// Token: 0x040003F1 RID: 1009
	private string stringShotTime = "";

	// Token: 0x040003F2 RID: 1010
	private string stringShotCount = "";

	// Token: 0x040003F3 RID: 1011
	private string stringFirstShot = "";

	// Token: 0x040003F4 RID: 1012
	private string stringSplit = "";

	// Token: 0x040003F5 RID: 1013
	private string randomPattern;

	// Token: 0x040003F6 RID: 1014
	private Outline outline;

	// Token: 0x040003F7 RID: 1015
	private bool colliding;

	// Token: 0x040003F8 RID: 1016
	[SerializeField]
	private bool testGo;

	// Token: 0x040003F9 RID: 1017
	[SerializeField]
	private bool testShot;

	// Token: 0x040003FA RID: 1018
	[SerializeField]
	private bool testReview;

	// Token: 0x020001D2 RID: 466
	public enum State
	{
		// Token: 0x04000DC6 RID: 3526
		Dormant,
		// Token: 0x04000DC7 RID: 3527
		CountDown,
		// Token: 0x04000DC8 RID: 3528
		Active,
		// Token: 0x04000DC9 RID: 3529
		Review,
		// Token: 0x04000DCA RID: 3530
		StandBy
	}
}
