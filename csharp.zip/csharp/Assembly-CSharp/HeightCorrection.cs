﻿using System;
using UnityEngine;

// Token: 0x0200000F RID: 15
public class HeightCorrection : MonoBehaviour
{
	// Token: 0x06000047 RID: 71 RVA: 0x00003297 File Offset: 0x00001497
	private void Start()
	{
	}

	// Token: 0x06000048 RID: 72 RVA: 0x00003297 File Offset: 0x00001497
	private void Update()
	{
	}
}
