﻿using System;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x0200000B RID: 11
public class FiberOpticManager : MonoBehaviour
{
	// Token: 0x06000038 RID: 56 RVA: 0x00003263 File Offset: 0x00001463
	private void Start()
	{
		this.gameManager = Object.FindObjectOfType<GameManager>();
		SceneManager.sceneLoaded += this.OnSceneLoaded;
		GameEvents.current.onWeaponModified += this.OnWeaponModified;
	}

	// Token: 0x06000039 RID: 57 RVA: 0x00003297 File Offset: 0x00001497
	private void OnWeaponModified()
	{
	}

	// Token: 0x0600003A RID: 58 RVA: 0x00003299 File Offset: 0x00001499
	private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
	{
		if (this.gameManager.GetSceneSettings().isNight)
		{
			this.ToggleToNightFibre(true);
			return;
		}
		this.ToggleToNightFibre(false);
	}

	// Token: 0x0600003B RID: 59 RVA: 0x000032BC File Offset: 0x000014BC
	private void ToggleToNightFibre(bool nightFibre)
	{
		float a = nightFibre ? 0.01f : 1f;
		foreach (MeshRenderer meshRenderer in base.GetComponentsInChildren<MeshRenderer>())
		{
			for (int j = 0; j < meshRenderer.materials.Length; j++)
			{
				if (meshRenderer.materials[j].name.Contains("Unlit-"))
				{
					Material material = meshRenderer.materials[j];
					float r = meshRenderer.materials[j].GetColor("_BaseColor").r;
					float g = meshRenderer.materials[j].GetColor("_BaseColor").g;
					float b = meshRenderer.materials[j].GetColor("_BaseColor").b;
					material.SetColor("_BaseColor", new Color(r, g, b, a));
					meshRenderer.materials[j] = material;
				}
			}
		}
	}

	// Token: 0x0600003C RID: 60 RVA: 0x000033AB File Offset: 0x000015AB
	private void OnDestroy()
	{
		SceneManager.sceneLoaded -= this.OnSceneLoaded;
		GameEvents.current.onWeaponModified -= this.OnWeaponModified;
	}

	// Token: 0x04000033 RID: 51
	private GameManager gameManager;
}
