﻿using System;
using UnityEngine;

// Token: 0x02000034 RID: 52
public class SoundManager : MonoBehaviour
{
	// Token: 0x060001DD RID: 477 RVA: 0x0000AA43 File Offset: 0x00008C43
	private void Start()
	{
		this.audioSource = base.GetComponent<AudioSource>();
	}

	// Token: 0x060001DE RID: 478 RVA: 0x0000AA51 File Offset: 0x00008C51
	public void Play(AudioClip clip)
	{
		this.audioSource.spatialBlend = 0f;
		this.audioSource.volume = 1f;
		this.audioSource.PlayOneShot(clip);
	}

	// Token: 0x060001DF RID: 479 RVA: 0x0000AA80 File Offset: 0x00008C80
	public void PlaySingle(AudioClip clip)
	{
		this.audioSource.Stop();
		this.audioSource.spatialBlend = 0f;
		this.audioSource.volume = 1f;
		this.audioSource.clip = clip;
		this.audioSource.Play();
	}

	// Token: 0x04000185 RID: 389
	public AudioSource audioSource;

	// Token: 0x04000186 RID: 390
	[Header("Stage Signals")]
	[SerializeField]
	public AudioClip signalStop;

	// Token: 0x04000187 RID: 391
	[SerializeField]
	public AudioClip signalReturnToStartingArea;

	// Token: 0x04000188 RID: 392
	[SerializeField]
	public AudioClip signalCreeping;

	// Token: 0x04000189 RID: 393
	[SerializeField]
	public AudioClip signalFaceStartingDirection;

	// Token: 0x0400018A RID: 394
	[SerializeField]
	public AudioClip signalMakeReady;

	// Token: 0x0400018B RID: 395
	[SerializeField]
	public AudioClip signalLoadMakeReady;

	// Token: 0x0400018C RID: 396
	[SerializeField]
	public AudioClip signalReady;

	// Token: 0x0400018D RID: 397
	[SerializeField]
	public AudioClip signalStandby;

	// Token: 0x0400018E RID: 398
	[SerializeField]
	public AudioClip signalBeep;

	// Token: 0x0400018F RID: 399
	[SerializeField]
	public AudioClip signalNextString;

	// Token: 0x04000190 RID: 400
	[SerializeField]
	public AudioClip signalIfFinished;

	// Token: 0x04000191 RID: 401
	[SerializeField]
	public AudioClip signalUnloadShowClear;

	// Token: 0x04000192 RID: 402
	[SerializeField]
	public AudioClip signalHammerDownHolster;

	// Token: 0x04000193 RID: 403
	[SerializeField]
	public AudioClip signalRangeIsClear;

	// Token: 0x04000194 RID: 404
	[Header("UI")]
	[SerializeField]
	public AudioClip UIerror;

	// Token: 0x04000195 RID: 405
	[SerializeField]
	public AudioClip UIclick;

	// Token: 0x04000196 RID: 406
	[SerializeField]
	public AudioClip UIcorrect;

	// Token: 0x04000197 RID: 407
	[SerializeField]
	public AudioClip UIKey;

	// Token: 0x04000198 RID: 408
	[Header("Control")]
	[SerializeField]
	public AudioClip breatheIn;

	// Token: 0x04000199 RID: 409
	[SerializeField]
	public AudioClip breatheOut;

	// Token: 0x0400019A RID: 410
	[Header("Secrets")]
	[SerializeField]
	public AudioClip secretUnlocked;
}
