﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000071 RID: 113
public class IntroPanel : MonoBehaviour
{
	// Token: 0x0600043A RID: 1082 RVA: 0x0001CCEC File Offset: 0x0001AEEC
	private void Start()
	{
		this.sceneSettings = Object.FindObjectOfType<SceneSettings>();
		if (this.sceneSettings.sceneType != SceneSettings.SceneType.Comp)
		{
			this.menuPanel.SetActive(false);
		}
		GameEvents.current.onHolsterDraw += this.OnHolsterDraw;
		GameEvents.current.onStagePlannerCompStart += this.OnStagePlannerCompStart;
		GameEvents.current.onStagePlannerCompEnd += this.OnStagePlannerEnd;
	}

	// Token: 0x0600043B RID: 1083 RVA: 0x0001CD60 File Offset: 0x0001AF60
	private void OnHolsterDraw()
	{
		this.menuPanel.SetActive(false);
	}

	// Token: 0x0600043C RID: 1084 RVA: 0x0001CD60 File Offset: 0x0001AF60
	private void OnStagePlannerEnd()
	{
		this.menuPanel.SetActive(false);
	}

	// Token: 0x0600043D RID: 1085 RVA: 0x0001CD6E File Offset: 0x0001AF6E
	private void OnStagePlannerCompStart()
	{
		base.Invoke("DelayPanelRepos", Time.deltaTime);
	}

	// Token: 0x0600043E RID: 1086 RVA: 0x0001CD80 File Offset: 0x0001AF80
	private void DelayPanelRepos()
	{
		this.menuPanel.SetActive(true);
		Vector3 position;
		Quaternion rotation;
		if (this.sceneSettings.introPanelPosition == null)
		{
			position = this.sceneSettings.defaultPanelPosition.position;
			rotation = this.sceneSettings.defaultPanelPosition.rotation;
		}
		else
		{
			position = this.sceneSettings.introPanelPosition.position;
			rotation = this.sceneSettings.introPanelPosition.rotation;
		}
		this.objectToReposition.transform.position = position;
		this.objectToReposition.transform.rotation = rotation;
	}

	// Token: 0x0600043F RID: 1087 RVA: 0x0001CE14 File Offset: 0x0001B014
	public void ReloadResults()
	{
		if (this.list != null)
		{
			this.InitiateResults(null);
		}
	}

	// Token: 0x06000440 RID: 1088 RVA: 0x0001CE28 File Offset: 0x0001B028
	public void InitiateResults(SaveManager.ResultList resultList)
	{
		this.list = resultList;
		if (this.sceneSettings == null)
		{
			this.sceneSettings = Object.FindObjectOfType<SceneSettings>();
		}
		this.shotCount.text = this.sceneSettings.GetStageShotCount().ToString();
		if (this.sceneSettings.startCondition == WeaponController.WeaponStatus.Loaded)
		{
			this.startingCondition.text = "ONE";
		}
		else if (this.sceneSettings.startCondition == WeaponController.WeaponStatus.LoadedEmptyChamber)
		{
			this.startingCondition.text = "THREE";
		}
		else if (this.sceneSettings.startCondition == WeaponController.WeaponStatus.Empty)
		{
			this.startingCondition.text = "FOUR";
		}
		if (Object.FindObjectOfType<StagePlanner>())
		{
			this.bronzeHF.text = "-";
			this.silverHF.text = "-";
			this.goldHF.text = "-";
		}
		else
		{
			this.bronzeHF.text = this.sceneSettings.bronzeHitFactor.ToString();
			this.silverHF.text = this.sceneSettings.silverHitFactor.ToString();
			this.goldHF.text = this.sceneSettings.goldHitFactor.ToString();
		}
		if (this.resultPanelBronzeHF != null && this.resultPanelSilverHF != null && this.resultPanelGoldHF != null)
		{
			this.resultPanelBronzeHF.text = this.bronzeHF.text;
			this.resultPanelSilverHF.text = this.silverHF.text;
			this.resultPanelGoldHF.text = this.goldHF.text;
		}
		if (resultList != null)
		{
			this.currentRecordTime.text = resultList.topTime.ToString();
			this.currentRecordHF.text = resultList.topHitFactor.ToString();
			this.recordWeapon.text = resultList.topWeapon.ToString();
		}
		else
		{
			string text = "-";
			this.currentRecordTime.text = text;
			this.currentRecordHF.text = text;
			this.recordWeapon.text = text;
		}
		if (this.sceneSettings.isSteelChallenge)
		{
			this.currentRecordHF.text = "-";
		}
	}

	// Token: 0x06000441 RID: 1089 RVA: 0x0001D05C File Offset: 0x0001B25C
	private void OnDestroy()
	{
		GameEvents.current.onHolsterDraw -= this.OnHolsterDraw;
		GameEvents.current.onStagePlannerCompStart -= this.OnStagePlannerCompStart;
		GameEvents.current.onStagePlannerCompEnd -= this.OnStagePlannerEnd;
	}

	// Token: 0x04000566 RID: 1382
	[SerializeField]
	private GameObject menuPanel;

	// Token: 0x04000567 RID: 1383
	[SerializeField]
	private TMP_Text shotCount;

	// Token: 0x04000568 RID: 1384
	[SerializeField]
	private TMP_Text startingCondition;

	// Token: 0x04000569 RID: 1385
	[SerializeField]
	private TMP_Text bronzeHF;

	// Token: 0x0400056A RID: 1386
	[SerializeField]
	private TMP_Text silverHF;

	// Token: 0x0400056B RID: 1387
	[SerializeField]
	private TMP_Text goldHF;

	// Token: 0x0400056C RID: 1388
	[SerializeField]
	private TMP_Text currentRecordTime;

	// Token: 0x0400056D RID: 1389
	[SerializeField]
	private TMP_Text currentRecordHF;

	// Token: 0x0400056E RID: 1390
	[SerializeField]
	private TMP_Text recordWeapon;

	// Token: 0x0400056F RID: 1391
	[SerializeField]
	private TMP_Text resultPanelBronzeHF;

	// Token: 0x04000570 RID: 1392
	[SerializeField]
	private TMP_Text resultPanelSilverHF;

	// Token: 0x04000571 RID: 1393
	[SerializeField]
	private TMP_Text resultPanelGoldHF;

	// Token: 0x04000572 RID: 1394
	[Header("StagePlanner")]
	[SerializeField]
	private GameObject objectToReposition;

	// Token: 0x04000573 RID: 1395
	private SceneSettings sceneSettings;

	// Token: 0x04000574 RID: 1396
	private SaveManager.ResultList list;
}
