﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

// Token: 0x02000083 RID: 131
[Serializable]
public struct Gesture
{
	// Token: 0x040005EA RID: 1514
	public string name;

	// Token: 0x040005EB RID: 1515
	public List<Vector3> fingerData;

	// Token: 0x040005EC RID: 1516
	public UnityEvent onRecognised;
}
