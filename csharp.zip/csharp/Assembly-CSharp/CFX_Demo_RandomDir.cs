﻿using System;
using UnityEngine;

// Token: 0x02000012 RID: 18
public class CFX_Demo_RandomDir : MonoBehaviour
{
	// Token: 0x06000050 RID: 80 RVA: 0x00003594 File Offset: 0x00001794
	private void Awake()
	{
		base.transform.eulerAngles = new Vector3(Random.Range(this.min.x, this.max.x), Random.Range(this.min.y, this.max.y), Random.Range(this.min.z, this.max.z));
	}

	// Token: 0x0400003D RID: 61
	public Vector3 min = new Vector3(0f, 0f, 0f);

	// Token: 0x0400003E RID: 62
	public Vector3 max = new Vector3(0f, 360f, 0f);
}
