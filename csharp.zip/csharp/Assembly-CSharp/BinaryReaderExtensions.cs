﻿using System;
using System.IO;
using UnityEngine;

// Token: 0x020000B8 RID: 184
internal static class BinaryReaderExtensions
{
	// Token: 0x06000619 RID: 1561 RVA: 0x00028108 File Offset: 0x00026308
	public static OvrAvatarDriver.PoseFrame ReadPoseFrame(this BinaryReader reader)
	{
		return new OvrAvatarDriver.PoseFrame
		{
			headPosition = reader.ReadVector3(),
			headRotation = reader.ReadQuaternion(),
			handLeftPosition = reader.ReadVector3(),
			handLeftRotation = reader.ReadQuaternion(),
			handRightPosition = reader.ReadVector3(),
			handRightRotation = reader.ReadQuaternion(),
			voiceAmplitude = reader.ReadSingle(),
			controllerLeftPose = reader.ReadControllerPose(),
			controllerRightPose = reader.ReadControllerPose()
		};
	}

	// Token: 0x0600061A RID: 1562 RVA: 0x00028194 File Offset: 0x00026394
	public static Vector2 ReadVector2(this BinaryReader reader)
	{
		return new Vector2
		{
			x = reader.ReadSingle(),
			y = reader.ReadSingle()
		};
	}

	// Token: 0x0600061B RID: 1563 RVA: 0x000281C4 File Offset: 0x000263C4
	public static Vector3 ReadVector3(this BinaryReader reader)
	{
		return new Vector3
		{
			x = reader.ReadSingle(),
			y = reader.ReadSingle(),
			z = reader.ReadSingle()
		};
	}

	// Token: 0x0600061C RID: 1564 RVA: 0x00028204 File Offset: 0x00026404
	public static Quaternion ReadQuaternion(this BinaryReader reader)
	{
		return new Quaternion
		{
			x = reader.ReadSingle(),
			y = reader.ReadSingle(),
			z = reader.ReadSingle(),
			w = reader.ReadSingle()
		};
	}

	// Token: 0x0600061D RID: 1565 RVA: 0x00028250 File Offset: 0x00026450
	public static OvrAvatarDriver.ControllerPose ReadControllerPose(this BinaryReader reader)
	{
		return new OvrAvatarDriver.ControllerPose
		{
			buttons = (ovrAvatarButton)reader.ReadUInt32(),
			touches = (ovrAvatarTouch)reader.ReadUInt32(),
			joystickPosition = reader.ReadVector2(),
			indexTrigger = reader.ReadSingle(),
			handTrigger = reader.ReadSingle(),
			isActive = reader.ReadBoolean()
		};
	}
}
