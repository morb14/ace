﻿using System;
using UnityEngine;

// Token: 0x02000118 RID: 280
public class LocomotionController : MonoBehaviour
{
	// Token: 0x06000724 RID: 1828 RVA: 0x0002D9D4 File Offset: 0x0002BBD4
	private void Start()
	{
		if (this.CameraRig == null)
		{
			this.CameraRig = Object.FindObjectOfType<OVRCameraRig>();
		}
	}

	// Token: 0x0400095D RID: 2397
	public OVRCameraRig CameraRig;

	// Token: 0x0400095E RID: 2398
	public CapsuleCollider CharacterController;

	// Token: 0x0400095F RID: 2399
	public SimpleCapsuleWithStickMovement PlayerController;
}
