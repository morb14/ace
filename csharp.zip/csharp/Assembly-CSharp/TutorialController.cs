﻿using System;
using UnityEngine;

// Token: 0x0200006F RID: 111
public class TutorialController : MonoBehaviour
{
	// Token: 0x0600041F RID: 1055 RVA: 0x00003297 File Offset: 0x00001497
	private void Start()
	{
	}

	// Token: 0x06000420 RID: 1056 RVA: 0x0001C064 File Offset: 0x0001A264
	public void ResetMaterial()
	{
		this.gripRenderer.material = this.defaultGrey;
		this.triggerRenderer.material = this.defaultGrey;
		this.buttonARenderer.material = this.defaultGrey;
		this.buttonBRenderer.material = this.defaultGrey;
		this.joystickRenderer.material = this.defaultGrey;
	}

	// Token: 0x0400053F RID: 1343
	[SerializeField]
	public Material defaultGrey;

	// Token: 0x04000540 RID: 1344
	[SerializeField]
	public Material green;

	// Token: 0x04000541 RID: 1345
	[SerializeField]
	public MeshRenderer gripRenderer;

	// Token: 0x04000542 RID: 1346
	[SerializeField]
	public MeshRenderer triggerRenderer;

	// Token: 0x04000543 RID: 1347
	[SerializeField]
	public MeshRenderer buttonARenderer;

	// Token: 0x04000544 RID: 1348
	[SerializeField]
	public MeshRenderer buttonBRenderer;

	// Token: 0x04000545 RID: 1349
	[SerializeField]
	public MeshRenderer joystickRenderer;
}
