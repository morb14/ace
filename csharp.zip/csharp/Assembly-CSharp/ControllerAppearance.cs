﻿using System;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x02000028 RID: 40
public class ControllerAppearance : MonoBehaviour
{
	// Token: 0x060000BB RID: 187 RVA: 0x00005C3C File Offset: 0x00003E3C
	private void Awake()
	{
		this.controlManager = Object.FindObjectOfType<ControlManager>();
		this.gameManager = Object.FindObjectOfType<GameManager>();
		GameEvents.current.onControllerModeChange += this.ControllerModeChange;
		GameEvents.current.onHolster += this.ControllerAppearanceEnable;
		GameEvents.current.onHolsterDraw += this.ControllerAppearanceDisable;
		SceneManager.sceneLoaded += this.AutoSelectController;
	}

	// Token: 0x060000BC RID: 188 RVA: 0x00005CB2 File Offset: 0x00003EB2
	private void AutoSelectController(Scene scene, LoadSceneMode mode)
	{
		if (scene.buildIndex == 0)
		{
			this.checkForControllerPositions = true;
			return;
		}
		this.checkForControllerPositions = false;
	}

	// Token: 0x060000BD RID: 189 RVA: 0x00005CCC File Offset: 0x00003ECC
	private void ControllerAppearanceEnable()
	{
		if (this.controlManager.controllerMode == ControlManager.ControllerMode.ControlAR || this.controlManager.controllerMode == ControlManager.ControllerMode.ControlARPro)
		{
			this.controlAR.SetActive(true);
			this.controlManager.ShowController(OVRInput.Controller.RTouch);
			if (this.controlManager.controllerMode == ControlManager.ControllerMode.ControlARPro)
			{
				this.gameManager.handObjectLeft.SetActive(true);
				return;
			}
		}
		else
		{
			if (this.controlManager.controllerMode == ControlManager.ControllerMode.ControlAR2)
			{
				this.controlAR2.SetActive(true);
				this.controlManager.ShowController(OVRInput.Controller.RTouch);
				return;
			}
			if (this.controlManager.controllerMode == ControlManager.ControllerMode.OneHand)
			{
				if (this.controlManager.handedness == ControlManager.Handedness.Left)
				{
					this.leftHand.enabled = true;
					return;
				}
				this.rightHand.enabled = true;
				return;
			}
			else if (this.controlManager.controllerMode == ControlManager.ControllerMode.TwoHand)
			{
				this.leftHand.enabled = true;
				this.rightHand.enabled = true;
			}
		}
	}

	// Token: 0x060000BE RID: 190 RVA: 0x00005DB4 File Offset: 0x00003FB4
	public void ControllerAppearanceDisable()
	{
		this.controlAR.SetActive(false);
		this.controlAR2.SetActive(false);
		if (this.controlManager.controllerMode == ControlManager.ControllerMode.TwoHand)
		{
			if (this.controlManager.handedness == ControlManager.Handedness.Left)
			{
				this.leftHand.enabled = false;
			}
			else
			{
				this.rightHand.enabled = false;
			}
		}
		if (this.controlManager.controllerMode == ControlManager.ControllerMode.OneHand)
		{
			this.leftHand.enabled = false;
			this.rightHand.enabled = false;
		}
		if (this.controlManager.controllerMode == ControlManager.ControllerMode.ControlARPro)
		{
			this.leftHand.enabled = false;
			this.rightHand.enabled = false;
		}
	}

	// Token: 0x060000BF RID: 191 RVA: 0x00003297 File Offset: 0x00001497
	private void Update()
	{
	}

	// Token: 0x060000C0 RID: 192 RVA: 0x00005E5C File Offset: 0x0000405C
	private void ControllersPositionDetection()
	{
		float num = Vector3.Distance(this.leftHandTransform.position, this.rightHandTransform.position);
		float num2 = Quaternion.Angle(this.leftHandTransform.rotation, this.rightHandTransform.rotation);
		if (this.checkForControllerPositions)
		{
			if ((double)num > 0.18 && (double)num < 0.19 && num2 > 175f && num2 < 180f)
			{
				this.correctPositionsDetected = true;
				if (this.positionHeldTime == 0f)
				{
					this.positionHeldTime = Time.time;
					return;
				}
			}
			else
			{
				this.correctPositionsDetected = false;
			}
		}
	}

	// Token: 0x060000C1 RID: 193 RVA: 0x00005EFC File Offset: 0x000040FC
	private void PositionHeldCountDown()
	{
		if (this.correctPositionsDetected && Time.time >= this.positionHeldTime + this.positionHeldThreshold)
		{
			MonoBehaviour.print("CONTROLLER MODE AUTO CHANGED");
			this.controlManager.ChangeControllerMode(ControlManager.ControllerMode.ControlAR2);
			this.checkForControllerPositions = false;
			this.correctPositionsDetected = false;
			this.positionHeldTime = 0f;
		}
	}

	// Token: 0x060000C2 RID: 194 RVA: 0x00005F54 File Offset: 0x00004154
	private void ControllerModeChange()
	{
		if (this.controlManager.controllerMode == ControlManager.ControllerMode.ControlAR2)
		{
			this.colliderToDisable.enabled = false;
			this.controlAR.SetActive(false);
			this.controlAR2.SetActive(true);
			MonoBehaviour.print(this.colliderToDisable + " disabled");
			this.rightHand.enabled = false;
			this.leftHand.enabled = false;
			return;
		}
		if (this.controlManager.controllerMode == ControlManager.ControllerMode.ControlAR || this.controlManager.controllerMode == ControlManager.ControllerMode.ControlARPro)
		{
			this.controlAR.SetActive(true);
			this.controlAR2.SetActive(false);
			this.colliderToDisable.enabled = false;
			this.rightHand.enabled = false;
			this.leftHand.enabled = false;
			return;
		}
		if (this.controlManager.controllerMode == ControlManager.ControllerMode.TwoHand)
		{
			this.controlManager.ShowController(OVRInput.Controller.All);
			return;
		}
		this.rightHand.enabled = true;
		this.leftHand.enabled = true;
		this.controlAR.SetActive(false);
		this.controlAR2.SetActive(false);
		this.colliderToDisable.enabled = true;
	}

	// Token: 0x060000C3 RID: 195 RVA: 0x00006074 File Offset: 0x00004274
	private void OnDestroy()
	{
		GameEvents.current.onControllerModeChange -= this.ControllerModeChange;
		SceneManager.sceneLoaded -= this.AutoSelectController;
		GameEvents.current.onHolster -= this.ControllerAppearanceEnable;
		GameEvents.current.onHolsterDraw -= this.ControllerAppearanceEnable;
	}

	// Token: 0x040000BB RID: 187
	[SerializeField]
	private GameObject controlAR;

	// Token: 0x040000BC RID: 188
	[SerializeField]
	private GameObject controlAR2;

	// Token: 0x040000BD RID: 189
	[SerializeField]
	public SkinnedMeshRenderer leftHand;

	// Token: 0x040000BE RID: 190
	[SerializeField]
	public SkinnedMeshRenderer rightHand;

	// Token: 0x040000BF RID: 191
	[SerializeField]
	private Transform leftHandTransform;

	// Token: 0x040000C0 RID: 192
	[SerializeField]
	private Transform rightHandTransform;

	// Token: 0x040000C1 RID: 193
	[SerializeField]
	private Collider colliderToDisable;

	// Token: 0x040000C2 RID: 194
	[SerializeField]
	private float positionHeldThreshold = 2f;

	// Token: 0x040000C3 RID: 195
	[SerializeField]
	private GameObject tutorialController;

	// Token: 0x040000C4 RID: 196
	private ControlManager controlManager;

	// Token: 0x040000C5 RID: 197
	private GameManager gameManager;

	// Token: 0x040000C6 RID: 198
	private bool checkForControllerPositions;

	// Token: 0x040000C7 RID: 199
	private bool correctPositionsDetected;

	// Token: 0x040000C8 RID: 200
	private float positionHeldTime;
}
