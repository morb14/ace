﻿using System;
using Oculus.Avatar;
using UnityEngine;

// Token: 0x020000FE RID: 254
public class OvrAvatarSkinnedMeshRenderPBSComponent : OvrAvatarRenderComponent
{
	// Token: 0x06000665 RID: 1637 RVA: 0x00029A84 File Offset: 0x00027C84
	internal void Initialize(ovrAvatarRenderPart_SkinnedMeshRenderPBS skinnedMeshRenderPBS, Shader shader, int thirdPersonLayer, int firstPersonLayer)
	{
		if (shader == null)
		{
			shader = Shader.Find("OvrAvatar/AvatarSurfaceShaderPBS");
		}
		this.mesh = base.CreateSkinnedMesh(skinnedMeshRenderPBS.meshAssetID, skinnedMeshRenderPBS.visibilityMask, thirdPersonLayer, firstPersonLayer);
		this.mesh.sharedMaterial = base.CreateAvatarMaterial(base.gameObject.name + "_material", shader);
		this.bones = this.mesh.bones;
	}

	// Token: 0x06000666 RID: 1638 RVA: 0x00029AFC File Offset: 0x00027CFC
	internal void UpdateSkinnedMeshRenderPBS(OvrAvatar avatar, IntPtr renderPart, Material mat)
	{
		if (!this.isMaterialInitilized)
		{
			this.isMaterialInitilized = true;
			ulong assetId = CAPI.ovrAvatarSkinnedMeshRenderPBS_GetAlbedoTextureAssetID(renderPart);
			ulong assetId2 = CAPI.ovrAvatarSkinnedMeshRenderPBS_GetSurfaceTextureAssetID(renderPart);
			mat.SetTexture("_Albedo", OvrAvatarComponent.GetLoadedTexture(assetId));
			mat.SetTexture("_Surface", OvrAvatarComponent.GetLoadedTexture(assetId2));
		}
		ovrAvatarVisibilityFlags visibilityMask = CAPI.ovrAvatarSkinnedMeshRenderPBS_GetVisibilityMask(renderPart);
		ovrAvatarTransform localTransform = CAPI.ovrAvatarSkinnedMeshRenderPBS_GetTransform(renderPart);
		base.UpdateSkinnedMesh(avatar, this.bones, localTransform, visibilityMask, renderPart);
	}

	// Token: 0x040008B9 RID: 2233
	private bool isMaterialInitilized;
}
