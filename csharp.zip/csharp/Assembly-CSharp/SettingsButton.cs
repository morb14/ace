﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000088 RID: 136
public class SettingsButton : MonoBehaviour
{
	// Token: 0x060004CA RID: 1226 RVA: 0x0001FCE8 File Offset: 0x0001DEE8
	private void Start()
	{
		this.soundManager = Object.FindObjectOfType<SoundManager>();
		this.settingsManager = Object.FindObjectOfType<SettingsManager>();
		this.playerData = Object.FindObjectOfType<PlayerData>();
		this.UpdatePaperIcon();
		if (this.settingType == SettingsManager.TargetType.PaperTarget)
		{
			this.UpdateTargetIcons(this.settingsManager.targetPaperIndex);
		}
		else if (this.settingType == SettingsManager.TargetType.SteelTarget)
		{
			this.UpdateTargetIcons(this.settingsManager.targetSteelIndex);
		}
		else if (this.settingType == SettingsManager.TargetType.ReloadSensitivity)
		{
			this.UpdateReloadSensitivity();
		}
		else if (this.settingType == SettingsManager.TargetType.OpticOpacity)
		{
			this.UpdateOpticOpacity();
		}
		this.SetPageNumbers();
	}

	// Token: 0x060004CB RID: 1227 RVA: 0x0001FD7C File Offset: 0x0001DF7C
	private void SetPageNumbers()
	{
		if (this.pageText != null)
		{
			this.pageText.text = "PAGE 1 OF " + this.pages.Length.ToString();
		}
	}

	// Token: 0x060004CC RID: 1228 RVA: 0x0001FDBC File Offset: 0x0001DFBC
	private void Update()
	{
		if (this.highLightObject != null && this.highLightObject.activeSelf)
		{
			this.highLightObject.SetActive(false);
		}
		if (this.testCycle)
		{
			this.Select();
			this.testCycle = false;
		}
	}

	// Token: 0x060004CD RID: 1229 RVA: 0x0001FDFA File Offset: 0x0001DFFA
	public void Highlight()
	{
		if (this.highLightObject == null)
		{
			return;
		}
		this.highLightObject.SetActive(true);
	}

	// Token: 0x060004CE RID: 1230 RVA: 0x0001FE18 File Offset: 0x0001E018
	public void Select()
	{
		this.soundManager.Play(this.soundManager.UIclick);
		if (this.settingType == SettingsManager.TargetType.PaperTarget)
		{
			if (this.settingsManager.targetPaperIndex < this.targetPairs.Length - 1)
			{
				this.settingsManager.targetPaperIndex++;
			}
			else
			{
				this.settingsManager.targetPaperIndex = 0;
			}
			this.UpdateTargetIcons(this.settingsManager.targetPaperIndex);
			this.settingsManager.ToggleScoring(this.settingType, this.settingsManager.targetPaperIndex);
		}
		if (this.settingType == SettingsManager.TargetType.SteelTarget)
		{
			if (this.settingsManager.targetSteelIndex < this.targetPairs.Length - 1)
			{
				this.settingsManager.targetSteelIndex++;
			}
			else
			{
				this.settingsManager.targetSteelIndex = 0;
			}
			this.UpdateTargetIcons(this.settingsManager.targetSteelIndex);
			this.settingsManager.ToggleScoring(this.settingType, this.settingsManager.targetSteelIndex);
		}
		if (this.settingType == SettingsManager.TargetType.PaperType)
		{
			this.settingsManager.TogglePaperType();
			this.UpdatePaperIcon();
		}
		if (this.settingType == SettingsManager.TargetType.ReflexColour)
		{
			this.settingsManager.ToggleReticle();
			this.UpdateReticle();
		}
		if (this.settingType == SettingsManager.TargetType.Recenter)
		{
			this.settingsManager.doNotRecenter = !this.settingsManager.doNotRecenter;
			this.toggleObject.SetActive(this.settingsManager.doNotRecenter);
		}
		if (this.settingType == SettingsManager.TargetType.OpticOpacity)
		{
			if (this.opticOpacity < 1f)
			{
				this.opticOpacity += 0.15f;
			}
			else
			{
				this.opticOpacity = 0.15f;
			}
			if (this.opticOpacity >= 1f)
			{
				this.opticOpacity = 1f;
			}
			this.playerData.opticOpacity = this.opticOpacity;
			this.UpdateOpticOpacity();
		}
		if (this.settingType == SettingsManager.TargetType.TriggerDetection)
		{
			this.settingsManager.doNotDetectTrigger = !this.settingsManager.doNotDetectTrigger;
			this.toggleObject.SetActive(this.settingsManager.doNotDetectTrigger);
			if (this.settingsManager.doNotDetectTrigger)
			{
				GameEvents.current.BroadcastMessage("Trigger capacitive sensing for draw is now off.", false);
			}
		}
		if (this.settingType == SettingsManager.TargetType.ReloadSensitivity)
		{
			if (this.reloadMultiplier > 0.3f)
			{
				this.reloadMultiplier -= 0.2f;
				GameEvents.current.BroadcastMessage("Warning: Lowering reload sensitivity could cause false positives", false);
			}
			else
			{
				this.reloadMultiplier = 1f;
			}
			this.playerData.reloadMultiplier = this.reloadMultiplier;
			this.UpdateReloadSensitivity();
		}
		if (this.settingType == SettingsManager.TargetType.PageTurn)
		{
			int num = 0;
			for (int i = 0; i < this.pages.Length; i++)
			{
				if (this.pages[i].activeSelf)
				{
					num = i;
					this.pages[i].SetActive(false);
				}
			}
			if (this.previousPage)
			{
				num--;
			}
			else
			{
				num++;
			}
			if (num > this.pages.Length - 1)
			{
				num = 0;
			}
			else if (num < 0)
			{
				num = this.pages.Length - 1;
			}
			this.pages[num].SetActive(true);
			if (this.pageText != null)
			{
				this.pageText.text = "PAGE " + (num + 1).ToString() + " OF " + this.pages.Length.ToString();
			}
		}
	}

	// Token: 0x060004CF RID: 1231 RVA: 0x0002015A File Offset: 0x0001E35A
	private void UpdateOpticOpacity()
	{
		this.opticOpacityText.text = this.playerData.opticOpacity.ToString("F2");
		this.opticOpacity = this.playerData.opticOpacity;
	}

	// Token: 0x060004D0 RID: 1232 RVA: 0x0002018D File Offset: 0x0001E38D
	private void UpdateReticle()
	{
		if (this.settingsManager.reflexColour == SettingsManager.ReflexColour.Red)
		{
			this.redReticle.SetActive(true);
			this.greenReticle.SetActive(false);
			return;
		}
		this.redReticle.SetActive(false);
		this.greenReticle.SetActive(true);
	}

	// Token: 0x060004D1 RID: 1233 RVA: 0x000201D0 File Offset: 0x0001E3D0
	private void UpdateReloadSensitivity()
	{
		this.reloadMultiplier = this.playerData.reloadMultiplier;
		if (this.reloadMultiplier == 0f)
		{
			this.reloadMultiplier = 1f;
		}
		this.reloadMultiplierText.text = this.reloadMultiplier.ToString("F1") + "X";
	}

	// Token: 0x060004D2 RID: 1234 RVA: 0x0002022C File Offset: 0x0001E42C
	private void UpdatePaperIcon()
	{
		if (this.settingType == SettingsManager.TargetType.PaperType)
		{
			if (this.settingsManager.paperType == SettingsManager.PaperType.IPSC)
			{
				this.IPSC.SetActive(true);
				this.USPSA.SetActive(false);
				return;
			}
			this.IPSC.SetActive(false);
			this.USPSA.SetActive(true);
		}
	}

	// Token: 0x060004D3 RID: 1235 RVA: 0x00020280 File Offset: 0x0001E480
	public void UpdateTargetIcons(int index)
	{
		foreach (GameObject gameObject in this.targetPairs)
		{
			if (gameObject != this.targetPairs[index])
			{
				gameObject.SetActive(false);
			}
			else
			{
				gameObject.SetActive(true);
			}
		}
	}

	// Token: 0x04000612 RID: 1554
	[SerializeField]
	private SettingsManager.TargetType settingType;

	// Token: 0x04000613 RID: 1555
	[SerializeField]
	private GameObject highLightObject;

	// Token: 0x04000614 RID: 1556
	[Header("Target Colours")]
	[SerializeField]
	private GameObject[] targetPairs;

	// Token: 0x04000615 RID: 1557
	[Header("IPSC / USPSA")]
	[SerializeField]
	private GameObject IPSC;

	// Token: 0x04000616 RID: 1558
	[SerializeField]
	private GameObject USPSA;

	// Token: 0x04000617 RID: 1559
	[SerializeField]
	private GameObject toggleObject;

	// Token: 0x04000618 RID: 1560
	[Header("Reticle Colour")]
	[SerializeField]
	private SettingsManager.ReflexColour reflexColour;

	// Token: 0x04000619 RID: 1561
	[SerializeField]
	private GameObject redReticle;

	// Token: 0x0400061A RID: 1562
	[SerializeField]
	private GameObject greenReticle;

	// Token: 0x0400061B RID: 1563
	[Header("Reload")]
	[SerializeField]
	private float reloadMultiplier = 1f;

	// Token: 0x0400061C RID: 1564
	[SerializeField]
	private TMP_Text reloadMultiplierText;

	// Token: 0x0400061D RID: 1565
	[Header("Optic Opacity")]
	[SerializeField]
	private float opticOpacity = 0.15f;

	// Token: 0x0400061E RID: 1566
	[SerializeField]
	private TMP_Text opticOpacityText;

	// Token: 0x0400061F RID: 1567
	[Header("Menu Page")]
	[SerializeField]
	private bool previousPage;

	// Token: 0x04000620 RID: 1568
	[SerializeField]
	private GameObject[] pages;

	// Token: 0x04000621 RID: 1569
	[SerializeField]
	private TMP_Text pageText;

	// Token: 0x04000622 RID: 1570
	private int paperIndex;

	// Token: 0x04000623 RID: 1571
	private int steelIndex;

	// Token: 0x04000624 RID: 1572
	public bool testCycle;

	// Token: 0x04000625 RID: 1573
	private SettingsManager settingsManager;

	// Token: 0x04000626 RID: 1574
	private PlayerData playerData;

	// Token: 0x04000627 RID: 1575
	private SoundManager soundManager;
}
