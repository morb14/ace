﻿using System;

// Token: 0x0200012F RID: 303
public class TeleportTransitionInstant : TeleportTransition
{
	// Token: 0x060007C8 RID: 1992 RVA: 0x0002FA8C File Offset: 0x0002DC8C
	protected override void LocomotionTeleportOnEnterStateTeleporting()
	{
		base.LocomotionTeleport.DoTeleport();
	}
}
