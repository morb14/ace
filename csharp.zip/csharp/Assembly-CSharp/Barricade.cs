﻿using System;
using UnityEngine;

// Token: 0x02000024 RID: 36
public class Barricade : MonoBehaviour
{
	// Token: 0x060000AF RID: 175 RVA: 0x00003297 File Offset: 0x00001497
	private void Start()
	{
	}

	// Token: 0x060000B0 RID: 176 RVA: 0x00003297 File Offset: 0x00001497
	private void Update()
	{
	}
}
