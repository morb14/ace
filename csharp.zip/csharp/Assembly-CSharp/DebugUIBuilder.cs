﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// Token: 0x02000111 RID: 273
public class DebugUIBuilder : MonoBehaviour
{
	// Token: 0x060006F2 RID: 1778 RVA: 0x0002C658 File Offset: 0x0002A858
	public void Awake()
	{
		DebugUIBuilder.instance = this;
		this.menuOffset = base.transform.position;
		base.gameObject.SetActive(false);
		this.rig = Object.FindObjectOfType<OVRCameraRig>();
		for (int i = 0; i < this.toEnable.Count; i++)
		{
			this.toEnable[i].SetActive(false);
		}
		this.insertPositions = new Vector2[this.targetContentPanels.Length];
		for (int j = 0; j < this.insertPositions.Length; j++)
		{
			this.insertPositions[j].x = 16f;
			this.insertPositions[j].y = -16f;
		}
		this.insertedElements = new List<RectTransform>[this.targetContentPanels.Length];
		for (int k = 0; k < this.insertedElements.Length; k++)
		{
			this.insertedElements[k] = new List<RectTransform>();
		}
		if (this.uiHelpersToInstantiate)
		{
			Object.Instantiate<GameObject>(this.uiHelpersToInstantiate);
		}
		this.lp = Object.FindObjectOfType<LaserPointer>();
		if (!this.lp)
		{
			Debug.LogError("Debug UI requires use of a LaserPointer and will not function without it. Add one to your scene, or assign the UIHelpers prefab to the DebugUIBuilder in the inspector.");
			return;
		}
		this.lp.laserBeamBehavior = this.laserBeamBehavior;
		if (!this.toEnable.Contains(this.lp.gameObject))
		{
			this.toEnable.Add(this.lp.gameObject);
		}
		base.GetComponent<OVRRaycaster>().pointer = this.lp.gameObject;
		this.lp.gameObject.SetActive(false);
	}

	// Token: 0x060006F3 RID: 1779 RVA: 0x0002C7E4 File Offset: 0x0002A9E4
	public void Show()
	{
		this.Relayout();
		base.gameObject.SetActive(true);
		base.transform.position = this.rig.transform.TransformPoint(this.menuOffset);
		Vector3 eulerAngles = this.rig.transform.rotation.eulerAngles;
		eulerAngles.x = 0f;
		eulerAngles.z = 0f;
		base.transform.eulerAngles = eulerAngles;
		if (this.reEnable == null || this.reEnable.Length < this.toDisable.Count)
		{
			this.reEnable = new bool[this.toDisable.Count];
		}
		this.reEnable.Initialize();
		int count = this.toDisable.Count;
		for (int i = 0; i < count; i++)
		{
			if (this.toDisable[i])
			{
				this.reEnable[i] = this.toDisable[i].activeSelf;
				this.toDisable[i].SetActive(false);
			}
		}
		count = this.toEnable.Count;
		for (int j = 0; j < count; j++)
		{
			this.toEnable[j].SetActive(true);
		}
		int num = this.targetContentPanels.Length;
		for (int k = 0; k < num; k++)
		{
			this.targetContentPanels[k].gameObject.SetActive(this.insertedElements[k].Count > 0);
		}
	}

	// Token: 0x060006F4 RID: 1780 RVA: 0x0002C96C File Offset: 0x0002AB6C
	public void Hide()
	{
		base.gameObject.SetActive(false);
		for (int i = 0; i < this.reEnable.Length; i++)
		{
			if (this.toDisable[i] && this.reEnable[i])
			{
				this.toDisable[i].SetActive(true);
			}
		}
		int count = this.toEnable.Count;
		for (int j = 0; j < count; j++)
		{
			this.toEnable[j].SetActive(false);
		}
	}

	// Token: 0x060006F5 RID: 1781 RVA: 0x0002C9F4 File Offset: 0x0002ABF4
	private void Relayout()
	{
		for (int i = 0; i < this.targetContentPanels.Length; i++)
		{
			RectTransform component = this.targetContentPanels[i].GetComponent<RectTransform>();
			List<RectTransform> list = this.insertedElements[i];
			int count = list.Count;
			float x = 16f;
			float num = -16f;
			float num2 = 0f;
			for (int j = 0; j < count; j++)
			{
				RectTransform rectTransform = list[j];
				rectTransform.anchoredPosition = new Vector2(x, num);
				num -= rectTransform.rect.height + 16f;
				num2 = Mathf.Max(rectTransform.rect.width + 32f, num2);
			}
			component.SetSizeWithCurrentAnchors(RectTransform.Axis.Horizontal, num2);
			component.SetSizeWithCurrentAnchors(RectTransform.Axis.Vertical, -num + 16f);
		}
	}

	// Token: 0x060006F6 RID: 1782 RVA: 0x0002CACC File Offset: 0x0002ACCC
	private void AddRect(RectTransform r, int targetCanvas)
	{
		if (targetCanvas > this.targetContentPanels.Length)
		{
			Debug.LogError(string.Concat(new object[]
			{
				"Attempted to add debug panel to canvas ",
				targetCanvas,
				", but only ",
				this.targetContentPanels.Length,
				" panels were provided. Fix in the inspector or pass a lower value for target canvas."
			}));
			return;
		}
		r.transform.SetParent(this.targetContentPanels[targetCanvas], false);
		this.insertedElements[targetCanvas].Add(r);
		if (base.gameObject.activeInHierarchy)
		{
			this.Relayout();
		}
	}

	// Token: 0x060006F7 RID: 1783 RVA: 0x0002CB5C File Offset: 0x0002AD5C
	public RectTransform AddButton(string label, DebugUIBuilder.OnClick handler, int targetCanvas = 0)
	{
		RectTransform component = Object.Instantiate<RectTransform>(this.buttonPrefab).GetComponent<RectTransform>();
		component.GetComponentInChildren<Button>().onClick.AddListener(delegate()
		{
			handler();
		});
		((Text)component.GetComponentsInChildren(typeof(Text), true)[0]).text = label;
		this.AddRect(component, targetCanvas);
		return component;
	}

	// Token: 0x060006F8 RID: 1784 RVA: 0x0002CBCC File Offset: 0x0002ADCC
	public RectTransform AddLabel(string label, int targetCanvas = 0)
	{
		RectTransform component = Object.Instantiate<RectTransform>(this.labelPrefab).GetComponent<RectTransform>();
		component.GetComponent<Text>().text = label;
		this.AddRect(component, targetCanvas);
		return component;
	}

	// Token: 0x060006F9 RID: 1785 RVA: 0x0002CC00 File Offset: 0x0002AE00
	public RectTransform AddSlider(string label, float min, float max, DebugUIBuilder.OnSlider onValueChanged, bool wholeNumbersOnly = false, int targetCanvas = 0)
	{
		RectTransform rectTransform = Object.Instantiate<RectTransform>(this.sliderPrefab);
		Slider componentInChildren = rectTransform.GetComponentInChildren<Slider>();
		componentInChildren.minValue = min;
		componentInChildren.maxValue = max;
		componentInChildren.onValueChanged.AddListener(delegate(float f)
		{
			onValueChanged(f);
		});
		componentInChildren.wholeNumbers = wholeNumbersOnly;
		this.AddRect(rectTransform, targetCanvas);
		return rectTransform;
	}

	// Token: 0x060006FA RID: 1786 RVA: 0x0002CC64 File Offset: 0x0002AE64
	public RectTransform AddDivider(int targetCanvas = 0)
	{
		RectTransform rectTransform = Object.Instantiate<RectTransform>(this.dividerPrefab);
		this.AddRect(rectTransform, targetCanvas);
		return rectTransform;
	}

	// Token: 0x060006FB RID: 1787 RVA: 0x0002CC88 File Offset: 0x0002AE88
	public RectTransform AddToggle(string label, DebugUIBuilder.OnToggleValueChange onValueChanged, int targetCanvas = 0)
	{
		RectTransform rectTransform = Object.Instantiate<RectTransform>(this.togglePrefab);
		this.AddRect(rectTransform, targetCanvas);
		rectTransform.GetComponentInChildren<Text>().text = label;
		Toggle t = rectTransform.GetComponentInChildren<Toggle>();
		t.onValueChanged.AddListener(delegate(bool <p0>)
		{
			onValueChanged(t);
		});
		return rectTransform;
	}

	// Token: 0x060006FC RID: 1788 RVA: 0x0002CCEC File Offset: 0x0002AEEC
	public RectTransform AddToggle(string label, DebugUIBuilder.OnToggleValueChange onValueChanged, bool defaultValue, int targetCanvas = 0)
	{
		RectTransform rectTransform = Object.Instantiate<RectTransform>(this.togglePrefab);
		this.AddRect(rectTransform, targetCanvas);
		rectTransform.GetComponentInChildren<Text>().text = label;
		Toggle t = rectTransform.GetComponentInChildren<Toggle>();
		t.isOn = defaultValue;
		t.onValueChanged.AddListener(delegate(bool <p0>)
		{
			onValueChanged(t);
		});
		return rectTransform;
	}

	// Token: 0x060006FD RID: 1789 RVA: 0x0002CD5C File Offset: 0x0002AF5C
	public RectTransform AddRadio(string label, string group, DebugUIBuilder.OnToggleValueChange handler, int targetCanvas = 0)
	{
		RectTransform rectTransform = Object.Instantiate<RectTransform>(this.radioPrefab);
		this.AddRect(rectTransform, targetCanvas);
		rectTransform.GetComponentInChildren<Text>().text = label;
		Toggle tb = rectTransform.GetComponentInChildren<Toggle>();
		if (group == null)
		{
			group = "default";
		}
		bool isOn = false;
		ToggleGroup toggleGroup;
		if (!this.radioGroups.ContainsKey(group))
		{
			toggleGroup = tb.gameObject.AddComponent<ToggleGroup>();
			this.radioGroups[group] = toggleGroup;
			isOn = true;
		}
		else
		{
			toggleGroup = this.radioGroups[group];
		}
		tb.group = toggleGroup;
		tb.isOn = isOn;
		tb.onValueChanged.AddListener(delegate(bool <p0>)
		{
			handler(tb);
		});
		return rectTransform;
	}

	// Token: 0x060006FE RID: 1790 RVA: 0x0002CE23 File Offset: 0x0002B023
	public void ToggleLaserPointer(bool isOn)
	{
		if (this.lp)
		{
			if (isOn)
			{
				this.lp.enabled = true;
				return;
			}
			this.lp.enabled = false;
		}
	}

	// Token: 0x0400091F RID: 2335
	public const int DEBUG_PANE_CENTER = 0;

	// Token: 0x04000920 RID: 2336
	public const int DEBUG_PANE_RIGHT = 1;

	// Token: 0x04000921 RID: 2337
	public const int DEBUG_PANE_LEFT = 2;

	// Token: 0x04000922 RID: 2338
	[SerializeField]
	private RectTransform buttonPrefab;

	// Token: 0x04000923 RID: 2339
	[SerializeField]
	private RectTransform labelPrefab;

	// Token: 0x04000924 RID: 2340
	[SerializeField]
	private RectTransform sliderPrefab;

	// Token: 0x04000925 RID: 2341
	[SerializeField]
	private RectTransform dividerPrefab;

	// Token: 0x04000926 RID: 2342
	[SerializeField]
	private RectTransform togglePrefab;

	// Token: 0x04000927 RID: 2343
	[SerializeField]
	private RectTransform radioPrefab;

	// Token: 0x04000928 RID: 2344
	[SerializeField]
	private GameObject uiHelpersToInstantiate;

	// Token: 0x04000929 RID: 2345
	[SerializeField]
	private Transform[] targetContentPanels;

	// Token: 0x0400092A RID: 2346
	private bool[] reEnable;

	// Token: 0x0400092B RID: 2347
	[SerializeField]
	private List<GameObject> toEnable;

	// Token: 0x0400092C RID: 2348
	[SerializeField]
	private List<GameObject> toDisable;

	// Token: 0x0400092D RID: 2349
	public static DebugUIBuilder instance;

	// Token: 0x0400092E RID: 2350
	private const float elementSpacing = 16f;

	// Token: 0x0400092F RID: 2351
	private const float marginH = 16f;

	// Token: 0x04000930 RID: 2352
	private const float marginV = 16f;

	// Token: 0x04000931 RID: 2353
	private Vector2[] insertPositions;

	// Token: 0x04000932 RID: 2354
	private List<RectTransform>[] insertedElements;

	// Token: 0x04000933 RID: 2355
	private Vector3 menuOffset;

	// Token: 0x04000934 RID: 2356
	private OVRCameraRig rig;

	// Token: 0x04000935 RID: 2357
	private Dictionary<string, ToggleGroup> radioGroups = new Dictionary<string, ToggleGroup>();

	// Token: 0x04000936 RID: 2358
	private LaserPointer lp;

	// Token: 0x04000937 RID: 2359
	private LineRenderer lr;

	// Token: 0x04000938 RID: 2360
	public LaserPointer.LaserBeamBehavior laserBeamBehavior;

	// Token: 0x02000203 RID: 515
	// (Invoke) Token: 0x06000C53 RID: 3155
	public delegate void OnClick();

	// Token: 0x02000204 RID: 516
	// (Invoke) Token: 0x06000C57 RID: 3159
	public delegate void OnToggleValueChange(Toggle t);

	// Token: 0x02000205 RID: 517
	// (Invoke) Token: 0x06000C5B RID: 3163
	public delegate void OnSlider(float f);

	// Token: 0x02000206 RID: 518
	// (Invoke) Token: 0x06000C5F RID: 3167
	public delegate bool ActiveUpdate();
}
