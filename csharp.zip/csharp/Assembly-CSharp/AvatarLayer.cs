﻿using System;

// Token: 0x020000A9 RID: 169
[Serializable]
public class AvatarLayer
{
	// Token: 0x040006B3 RID: 1715
	public int layerIndex;
}
