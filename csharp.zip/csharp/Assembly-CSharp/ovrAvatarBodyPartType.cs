﻿using System;

// Token: 0x020000E6 RID: 230
public enum ovrAvatarBodyPartType
{
	// Token: 0x04000863 RID: 2147
	Body,
	// Token: 0x04000864 RID: 2148
	Clothing,
	// Token: 0x04000865 RID: 2149
	Eyewear,
	// Token: 0x04000866 RID: 2150
	Hair,
	// Token: 0x04000867 RID: 2151
	Beard,
	// Token: 0x04000868 RID: 2152
	Count
}
