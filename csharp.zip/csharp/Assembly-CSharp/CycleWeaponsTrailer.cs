﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000036 RID: 54
public class CycleWeaponsTrailer : MonoBehaviour
{
	// Token: 0x060001EA RID: 490 RVA: 0x0000AC50 File Offset: 0x00008E50
	private void Start()
	{
		foreach (GameObject gameObject in this.weaponsToShow)
		{
			Object.Instantiate<GameObject>(gameObject, base.transform);
			this.weapons.Add(gameObject);
			gameObject.SetActive(false);
		}
		this.currentWeaponIndex = 0;
		this.weapons[this.currentWeaponIndex].SetActive(true);
		base.Invoke("NextWeapon", this.timeToCycle);
	}

	// Token: 0x060001EB RID: 491 RVA: 0x0000ACC8 File Offset: 0x00008EC8
	private void NextWeapon()
	{
		MonoBehaviour.print("NEXT WEAPON " + this.currentWeaponIndex);
		this.currentWeaponIndex++;
		if (this.currentWeaponIndex < this.weapons.Count)
		{
			foreach (GameObject gameObject in this.weapons)
			{
				gameObject.SetActive(false);
			}
			MonoBehaviour.print(this.weapons[this.currentWeaponIndex]);
			this.weapons[this.currentWeaponIndex].SetActive(true);
			base.Invoke("NextWeapon", this.timeToCycle);
		}
	}

	// Token: 0x040001A4 RID: 420
	[SerializeField]
	private GameObject[] weaponsToShow;

	// Token: 0x040001A5 RID: 421
	[SerializeField]
	private float timeToCycle;

	// Token: 0x040001A6 RID: 422
	private List<GameObject> weapons = new List<GameObject>();

	// Token: 0x040001A7 RID: 423
	private int currentWeaponIndex;
}
