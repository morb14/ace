﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

// Token: 0x02000147 RID: 327
public class ONSPVersion : MonoBehaviour
{
	// Token: 0x060008AA RID: 2218
	[DllImport("AudioPluginOculusSpatializer")]
	private static extern void ONSP_GetVersion(ref int Major, ref int Minor, ref int Patch);

	// Token: 0x060008AB RID: 2219 RVA: 0x00038AF8 File Offset: 0x00036CF8
	private void Awake()
	{
		int num = 0;
		int num2 = 0;
		int num3 = 0;
		ONSPVersion.ONSP_GetVersion(ref num, ref num2, ref num3);
		Debug.Log(string.Format("ONSP Version: {0:F0}.{1:F0}.{2:F0}", num, num2, num3));
	}

	// Token: 0x060008AC RID: 2220 RVA: 0x00003297 File Offset: 0x00001497
	private void Start()
	{
	}

	// Token: 0x060008AD RID: 2221 RVA: 0x00003297 File Offset: 0x00001497
	private void Update()
	{
	}

	// Token: 0x04000A78 RID: 2680
	public const string strONSPS = "AudioPluginOculusSpatializer";
}
