﻿using System;

// Token: 0x020000EB RID: 235
public enum ovrAvatarGazeTargetType
{
	// Token: 0x04000872 RID: 2162
	AvatarHead,
	// Token: 0x04000873 RID: 2163
	AvatarHand,
	// Token: 0x04000874 RID: 2164
	Object,
	// Token: 0x04000875 RID: 2165
	ObjectStatic,
	// Token: 0x04000876 RID: 2166
	Count
}
