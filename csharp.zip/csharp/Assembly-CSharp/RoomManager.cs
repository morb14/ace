﻿using System;
using Oculus.Platform;
using Oculus.Platform.Models;

// Token: 0x020000A5 RID: 165
public class RoomManager
{
	// Token: 0x06000570 RID: 1392 RVA: 0x00022946 File Offset: 0x00020B46
	public RoomManager()
	{
		this.amIServer = false;
		this.startupDone = false;
		Rooms.SetRoomInviteAcceptedNotificationCallback(new Message<string>.Callback(this.AcceptingInviteCallback));
		Rooms.SetUpdateNotificationCallback(new Message<Room>.Callback(this.RoomUpdateCallback));
	}

	// Token: 0x06000571 RID: 1393 RVA: 0x00022980 File Offset: 0x00020B80
	private void AcceptingInviteCallback(Message<string> msg)
	{
		if (msg.IsError)
		{
			SocialPlatformManager.TerminateWithError(msg);
			return;
		}
		SocialPlatformManager.LogOutput("Launched Invite to join Room: " + msg.Data);
		this.invitedRoomID = Convert.ToUInt64(msg.GetString());
		if (this.startupDone)
		{
			this.CheckForInvite();
		}
	}

	// Token: 0x06000572 RID: 1394 RVA: 0x000229D1 File Offset: 0x00020BD1
	public bool CheckForInvite()
	{
		this.startupDone = true;
		if (this.invitedRoomID != 0UL)
		{
			this.JoinExistingRoom(this.invitedRoomID);
			return true;
		}
		return false;
	}

	// Token: 0x06000573 RID: 1395 RVA: 0x000229F1 File Offset: 0x00020BF1
	public void CreateRoom()
	{
		Rooms.CreateAndJoinPrivate(RoomJoinPolicy.FriendsOfOwner, 4U, true).OnComplete(new Message<Room>.Callback(this.CreateAndJoinPrivateRoomCallback));
	}

	// Token: 0x06000574 RID: 1396 RVA: 0x00022A10 File Offset: 0x00020C10
	private void CreateAndJoinPrivateRoomCallback(Message<Room> msg)
	{
		if (msg.IsError)
		{
			SocialPlatformManager.TerminateWithError(msg);
			return;
		}
		this.roomID = msg.Data.ID;
		if (msg.Data.OwnerOptional != null && msg.Data.OwnerOptional.ID == SocialPlatformManager.MyID)
		{
			this.amIServer = true;
		}
		else
		{
			this.amIServer = false;
		}
		SocialPlatformManager.TransitionToState(SocialPlatformManager.State.WAITING_IN_A_ROOM);
		SocialPlatformManager.SetFloorColorForState(this.amIServer);
	}

	// Token: 0x06000575 RID: 1397 RVA: 0x00022A82 File Offset: 0x00020C82
	private void OnLaunchInviteWorkflowComplete(Message msg)
	{
		if (msg.IsError)
		{
			SocialPlatformManager.TerminateWithError(msg);
			return;
		}
	}

	// Token: 0x06000576 RID: 1398 RVA: 0x00022A93 File Offset: 0x00020C93
	public void JoinExistingRoom(ulong roomID)
	{
		SocialPlatformManager.TransitionToState(SocialPlatformManager.State.JOINING_A_ROOM);
		Rooms.Join(roomID, true).OnComplete(new Message<Room>.Callback(this.JoinRoomCallback));
	}

	// Token: 0x06000577 RID: 1399 RVA: 0x00022AB4 File Offset: 0x00020CB4
	private void JoinRoomCallback(Message<Room> msg)
	{
		if (msg.IsError)
		{
			return;
		}
		string text = (msg.Data.OwnerOptional != null) ? msg.Data.OwnerOptional.OculusID : "null";
		int num = (msg.Data.UsersOptional != null) ? msg.Data.UsersOptional.Count : 0;
		SocialPlatformManager.LogOutput(string.Concat(new object[]
		{
			"Joined Room ",
			msg.Data.ID,
			" owner: ",
			text,
			" count: ",
			num
		}));
		this.roomID = msg.Data.ID;
		this.ProcessRoomData(msg);
	}

	// Token: 0x06000578 RID: 1400 RVA: 0x00022B70 File Offset: 0x00020D70
	private void RoomUpdateCallback(Message<Room> msg)
	{
		if (msg.IsError)
		{
			SocialPlatformManager.TerminateWithError(msg);
			return;
		}
		string text = (msg.Data.OwnerOptional != null) ? msg.Data.OwnerOptional.OculusID : "null";
		int num = (msg.Data.UsersOptional != null) ? msg.Data.UsersOptional.Count : 0;
		SocialPlatformManager.LogOutput(string.Concat(new object[]
		{
			"Room Update ",
			msg.Data.ID,
			" owner: ",
			text,
			" count: ",
			num
		}));
		this.ProcessRoomData(msg);
	}

	// Token: 0x06000579 RID: 1401 RVA: 0x00022C21 File Offset: 0x00020E21
	public void LeaveCurrentRoom()
	{
		if (this.roomID != 0UL)
		{
			Rooms.Leave(this.roomID);
			this.roomID = 0UL;
		}
		SocialPlatformManager.TransitionToState(SocialPlatformManager.State.LEAVING_A_ROOM);
	}

	// Token: 0x0600057A RID: 1402 RVA: 0x00022C48 File Offset: 0x00020E48
	private void ProcessRoomData(Message<Room> msg)
	{
		if (msg.Data.OwnerOptional != null && msg.Data.OwnerOptional.ID == SocialPlatformManager.MyID)
		{
			this.amIServer = true;
		}
		else
		{
			this.amIServer = false;
		}
		if (msg.Data.UsersOptional != null && msg.Data.UsersOptional.Count == 1)
		{
			SocialPlatformManager.TransitionToState(SocialPlatformManager.State.WAITING_IN_A_ROOM);
		}
		else
		{
			SocialPlatformManager.TransitionToState(SocialPlatformManager.State.CONNECTED_IN_A_ROOM);
		}
		SocialPlatformManager.MarkAllRemoteUsersAsNotInRoom();
		if (msg.Data.UsersOptional != null)
		{
			foreach (User user in msg.Data.UsersOptional)
			{
				if (user.ID != SocialPlatformManager.MyID)
				{
					if (!SocialPlatformManager.IsUserInRoom(user.ID))
					{
						SocialPlatformManager.AddRemoteUser(user.ID);
					}
					else
					{
						SocialPlatformManager.MarkRemoteUserInRoom(user.ID);
					}
				}
			}
		}
		SocialPlatformManager.ForgetRemoteUsersNotInRoom();
		SocialPlatformManager.SetFloorColorForState(this.amIServer);
	}

	// Token: 0x04000688 RID: 1672
	public ulong roomID;

	// Token: 0x04000689 RID: 1673
	private ulong invitedRoomID;

	// Token: 0x0400068A RID: 1674
	private bool amIServer;

	// Token: 0x0400068B RID: 1675
	private bool startupDone;
}
