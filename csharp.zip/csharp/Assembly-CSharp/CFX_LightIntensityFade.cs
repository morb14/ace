﻿using System;
using UnityEngine;

// Token: 0x0200001B RID: 27
[RequireComponent(typeof(Light))]
public class CFX_LightIntensityFade : MonoBehaviour
{
	// Token: 0x06000080 RID: 128 RVA: 0x00004EA5 File Offset: 0x000030A5
	private void Start()
	{
		this.baseIntensity = base.GetComponent<Light>().intensity;
	}

	// Token: 0x06000081 RID: 129 RVA: 0x00004EB8 File Offset: 0x000030B8
	private void OnEnable()
	{
		this.p_lifetime = 0f;
		this.p_delay = this.delay;
		if (this.delay > 0f)
		{
			base.GetComponent<Light>().enabled = false;
		}
	}

	// Token: 0x06000082 RID: 130 RVA: 0x00004EEC File Offset: 0x000030EC
	private void Update()
	{
		if (this.p_delay > 0f)
		{
			this.p_delay -= Time.deltaTime;
			if (this.p_delay <= 0f)
			{
				base.GetComponent<Light>().enabled = true;
			}
			return;
		}
		if (this.p_lifetime / this.duration < 1f)
		{
			base.GetComponent<Light>().intensity = Mathf.Lerp(this.baseIntensity, this.finalIntensity, this.p_lifetime / this.duration);
			this.p_lifetime += Time.deltaTime;
			return;
		}
		if (this.autodestruct)
		{
			Object.Destroy(base.gameObject);
		}
	}

	// Token: 0x04000086 RID: 134
	public float duration = 1f;

	// Token: 0x04000087 RID: 135
	public float delay;

	// Token: 0x04000088 RID: 136
	public float finalIntensity;

	// Token: 0x04000089 RID: 137
	private float baseIntensity;

	// Token: 0x0400008A RID: 138
	public bool autodestruct;

	// Token: 0x0400008B RID: 139
	private float p_lifetime;

	// Token: 0x0400008C RID: 140
	private float p_delay;
}
