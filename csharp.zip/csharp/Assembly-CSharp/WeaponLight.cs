﻿using System;
using UnityEngine;

// Token: 0x02000097 RID: 151
public class WeaponLight : MonoBehaviour
{
	// Token: 0x0600050E RID: 1294 RVA: 0x00020D00 File Offset: 0x0001EF00
	private void Start()
	{
		this.gameManager = Object.FindObjectOfType<GameManager>();
		this.controlManager = Object.FindObjectOfType<ControlManager>();
		this.controller = this.controlManager.controller;
		GameEvents.current.onHolsterDraw += this.OnHolsterDraw;
		GameEvents.current.onHolster += this.OnHolster;
		this.ToggleLights(false);
		this.ToggleLasers(false);
	}

	// Token: 0x0600050F RID: 1295 RVA: 0x00020D6E File Offset: 0x0001EF6E
	private void Update()
	{
		if (this.drawn)
		{
			this.LightControl();
			if (this.lineRenderer.enabled)
			{
				this.ShineLaser();
			}
		}
	}

	// Token: 0x06000510 RID: 1296 RVA: 0x00020D94 File Offset: 0x0001EF94
	private void ToggleLights(bool turnOn)
	{
		foreach (Light light in this.lightSources)
		{
			if (this.gameManager.GetSceneSettings().isNight)
			{
				light.enabled = turnOn;
			}
		}
		if (turnOn)
		{
			this.lens.material = this.lensOnMaterial;
			return;
		}
		this.lens.material = this.lensOffMaterial;
	}

	// Token: 0x06000511 RID: 1297 RVA: 0x00020DF9 File Offset: 0x0001EFF9
	private bool HasLasers()
	{
		return this.laserTransform != null && this.lineRenderer != null;
	}

	// Token: 0x06000512 RID: 1298 RVA: 0x00020E1A File Offset: 0x0001F01A
	private void ToggleLasers(bool turnOn)
	{
		if (!this.HasLasers())
		{
			return;
		}
		if (turnOn)
		{
			this.lineRenderer.enabled = true;
			return;
		}
		this.laserDot.SetActive(false);
		this.lineRenderer.enabled = false;
	}

	// Token: 0x06000513 RID: 1299 RVA: 0x00020E4D File Offset: 0x0001F04D
	private void OnHolsterDraw()
	{
		this.ToggleLights(true);
		this.ToggleLasers(true);
		this.drawn = true;
	}

	// Token: 0x06000514 RID: 1300 RVA: 0x00020E64 File Offset: 0x0001F064
	private void OnHolster()
	{
		this.ToggleLights(false);
		this.ToggleLasers(false);
		this.drawn = false;
	}

	// Token: 0x06000515 RID: 1301 RVA: 0x00020E7C File Offset: 0x0001F07C
	private void LightControl()
	{
		if (OVRInput.GetDown(OVRInput.Button.PrimaryHandTrigger, this.controller))
		{
			this.ToggleLights(true);
			this.ToggleLasers(true);
		}
		if (OVRInput.GetUp(OVRInput.Button.PrimaryHandTrigger, this.controller))
		{
			this.ToggleLights(false);
			this.ToggleLasers(false);
		}
	}

	// Token: 0x06000516 RID: 1302 RVA: 0x00020ECC File Offset: 0x0001F0CC
	private void ShineLaser()
	{
		this.lineRenderer.SetPosition(0, this.laserTransform.position);
		this.lineRenderer.SetPosition(1, this.laserTransform.position + base.transform.forward * this.visibleLineRange);
		RaycastHit raycastHit;
		if (Physics.Raycast(this.laserTransform.position, base.transform.TransformDirection(Vector3.forward), out raycastHit, float.PositiveInfinity, this.layerMask))
		{
			this.laserDot.SetActive(true);
			this.laserDot.transform.position = raycastHit.point - base.transform.TransformDirection(raycastHit.point - base.transform.position).normalized / 100f;
			if (Vector3.Distance(raycastHit.point, this.laserTransform.position) < this.visibleLineRange)
			{
				this.lineRenderer.SetPosition(1, raycastHit.point);
				return;
			}
		}
		else
		{
			this.laserDot.SetActive(false);
		}
	}

	// Token: 0x06000517 RID: 1303 RVA: 0x00020FF4 File Offset: 0x0001F1F4
	private void OnDestroy()
	{
		GameEvents.current.onHolsterDraw -= this.OnHolsterDraw;
		GameEvents.current.onHolster -= this.OnHolster;
	}

	// Token: 0x04000649 RID: 1609
	[Header("Light")]
	[SerializeField]
	private Light[] lightSources;

	// Token: 0x0400064A RID: 1610
	[SerializeField]
	private MeshRenderer lens;

	// Token: 0x0400064B RID: 1611
	[SerializeField]
	private Material lensOffMaterial;

	// Token: 0x0400064C RID: 1612
	[SerializeField]
	private Material lensOnMaterial;

	// Token: 0x0400064D RID: 1613
	[Header("Laser")]
	[SerializeField]
	private Transform laserTransform;

	// Token: 0x0400064E RID: 1614
	[SerializeField]
	private Material laserLine;

	// Token: 0x0400064F RID: 1615
	[SerializeField]
	private GameObject laserDot;

	// Token: 0x04000650 RID: 1616
	[SerializeField]
	private LineRenderer lineRenderer;

	// Token: 0x04000651 RID: 1617
	[SerializeField]
	private LayerMask layerMask;

	// Token: 0x04000652 RID: 1618
	[SerializeField]
	private float visibleLineRange = 5f;

	// Token: 0x04000653 RID: 1619
	private GameManager gameManager;

	// Token: 0x04000654 RID: 1620
	private ControlManager controlManager;

	// Token: 0x04000655 RID: 1621
	private OVRInput.Controller controller;

	// Token: 0x04000656 RID: 1622
	private bool drawn;
}
