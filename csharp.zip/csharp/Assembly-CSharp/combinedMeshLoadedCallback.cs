﻿using System;

// Token: 0x020000FA RID: 250
// (Invoke) Token: 0x06000646 RID: 1606
public delegate void combinedMeshLoadedCallback(IntPtr asset);
