﻿using System;

// Token: 0x020000C5 RID: 197
public enum ovrAvatarTextureFormat
{
	// Token: 0x040007A9 RID: 1961
	RGB24,
	// Token: 0x040007AA RID: 1962
	DXT1,
	// Token: 0x040007AB RID: 1963
	DXT5,
	// Token: 0x040007AC RID: 1964
	ASTC_RGB_6x6,
	// Token: 0x040007AD RID: 1965
	ASTC_RGB_6x6_MIPMAPS,
	// Token: 0x040007AE RID: 1966
	Count
}
