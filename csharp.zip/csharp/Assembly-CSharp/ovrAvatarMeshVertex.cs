﻿using System;
using System.Runtime.InteropServices;

// Token: 0x020000C0 RID: 192
public struct ovrAvatarMeshVertex
{
	// Token: 0x04000775 RID: 1909
	public float x;

	// Token: 0x04000776 RID: 1910
	public float y;

	// Token: 0x04000777 RID: 1911
	public float z;

	// Token: 0x04000778 RID: 1912
	public float nx;

	// Token: 0x04000779 RID: 1913
	public float ny;

	// Token: 0x0400077A RID: 1914
	public float nz;

	// Token: 0x0400077B RID: 1915
	public float tx;

	// Token: 0x0400077C RID: 1916
	public float ty;

	// Token: 0x0400077D RID: 1917
	public float tz;

	// Token: 0x0400077E RID: 1918
	public float tw;

	// Token: 0x0400077F RID: 1919
	public float u;

	// Token: 0x04000780 RID: 1920
	public float v;

	// Token: 0x04000781 RID: 1921
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
	public byte[] blendIndices;

	// Token: 0x04000782 RID: 1922
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 4)]
	public float[] blendWeights;
}
