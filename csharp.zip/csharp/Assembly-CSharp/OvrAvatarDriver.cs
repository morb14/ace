﻿using System;
using Oculus.Avatar;
using UnityEngine;

// Token: 0x020000B2 RID: 178
public abstract class OvrAvatarDriver : MonoBehaviour
{
	// Token: 0x060005EF RID: 1519 RVA: 0x00026D6D File Offset: 0x00024F6D
	public OvrAvatarDriver.PoseFrame GetCurrentPose()
	{
		return this.CurrentPose;
	}

	// Token: 0x060005F0 RID: 1520
	public abstract void UpdateTransforms(IntPtr sdkAvatar);

	// Token: 0x060005F1 RID: 1521 RVA: 0x00026D78 File Offset: 0x00024F78
	private void Start()
	{
		OVRPlugin.SystemHeadset systemHeadsetType = OVRPlugin.GetSystemHeadsetType();
		switch (systemHeadsetType)
		{
		case OVRPlugin.SystemHeadset.GearVR_R320:
		case OVRPlugin.SystemHeadset.GearVR_R321:
		case OVRPlugin.SystemHeadset.GearVR_R322:
		case OVRPlugin.SystemHeadset.GearVR_R323:
		case OVRPlugin.SystemHeadset.GearVR_R324:
		case OVRPlugin.SystemHeadset.GearVR_R325:
			this.ControllerType = ovrAvatarControllerType.Malibu;
			return;
		case OVRPlugin.SystemHeadset.Oculus_Go:
			this.ControllerType = ovrAvatarControllerType.Go;
			return;
		case OVRPlugin.SystemHeadset.Oculus_Quest:
			break;
		default:
			if (systemHeadsetType - OVRPlugin.SystemHeadset.Rift_DK1 > 2)
			{
				if (systemHeadsetType == OVRPlugin.SystemHeadset.Rift_S)
				{
					break;
				}
			}
			this.ControllerType = ovrAvatarControllerType.Touch;
			return;
		}
		this.ControllerType = ovrAvatarControllerType.Quest;
	}

	// Token: 0x060005F2 RID: 1522 RVA: 0x00026DE8 File Offset: 0x00024FE8
	public void UpdateTransformsFromPose(IntPtr sdkAvatar)
	{
		if (sdkAvatar != IntPtr.Zero)
		{
			ovrAvatarTransform headPose = OvrAvatar.CreateOvrAvatarTransform(this.CurrentPose.headPosition, this.CurrentPose.headRotation);
			ovrAvatarHandInputState inputStateLeft = OvrAvatar.CreateInputState(OvrAvatar.CreateOvrAvatarTransform(this.CurrentPose.handLeftPosition, this.CurrentPose.handLeftRotation), this.CurrentPose.controllerLeftPose);
			ovrAvatarHandInputState inputStateRight = OvrAvatar.CreateInputState(OvrAvatar.CreateOvrAvatarTransform(this.CurrentPose.handRightPosition, this.CurrentPose.handRightRotation), this.CurrentPose.controllerRightPose);
			CAPI.ovrAvatarPose_UpdateBody(sdkAvatar, headPose);
			CAPI.ovrAvatarPose_UpdateHandsWithType(sdkAvatar, inputStateLeft, inputStateRight, this.ControllerType);
		}
	}

	// Token: 0x060005F3 RID: 1523 RVA: 0x00026E8E File Offset: 0x0002508E
	public static bool GetIsTrackedRemote()
	{
		return OVRInput.IsControllerConnected(OVRInput.Controller.RTrackedRemote) || OVRInput.IsControllerConnected(OVRInput.Controller.LTrackedRemote);
	}

	// Token: 0x04000725 RID: 1829
	public OvrAvatarDriver.PacketMode Mode;

	// Token: 0x04000726 RID: 1830
	protected OvrAvatarDriver.PoseFrame CurrentPose;

	// Token: 0x04000727 RID: 1831
	private ovrAvatarControllerType ControllerType = ovrAvatarControllerType.Quest;

	// Token: 0x020001EC RID: 492
	public enum PacketMode
	{
		// Token: 0x04000E47 RID: 3655
		SDK,
		// Token: 0x04000E48 RID: 3656
		Unity
	}

	// Token: 0x020001ED RID: 493
	public struct ControllerPose
	{
		// Token: 0x06000C39 RID: 3129 RVA: 0x00044144 File Offset: 0x00042344
		public static OvrAvatarDriver.ControllerPose Interpolate(OvrAvatarDriver.ControllerPose a, OvrAvatarDriver.ControllerPose b, float t)
		{
			return new OvrAvatarDriver.ControllerPose
			{
				buttons = ((t < 0.5f) ? a.buttons : b.buttons),
				touches = ((t < 0.5f) ? a.touches : b.touches),
				joystickPosition = Vector2.Lerp(a.joystickPosition, b.joystickPosition, t),
				indexTrigger = Mathf.Lerp(a.indexTrigger, b.indexTrigger, t),
				handTrigger = Mathf.Lerp(a.handTrigger, b.handTrigger, t),
				isActive = ((t < 0.5f) ? a.isActive : b.isActive)
			};
		}

		// Token: 0x04000E49 RID: 3657
		public ovrAvatarButton buttons;

		// Token: 0x04000E4A RID: 3658
		public ovrAvatarTouch touches;

		// Token: 0x04000E4B RID: 3659
		public Vector2 joystickPosition;

		// Token: 0x04000E4C RID: 3660
		public float indexTrigger;

		// Token: 0x04000E4D RID: 3661
		public float handTrigger;

		// Token: 0x04000E4E RID: 3662
		public bool isActive;
	}

	// Token: 0x020001EE RID: 494
	public struct PoseFrame
	{
		// Token: 0x06000C3A RID: 3130 RVA: 0x000441FC File Offset: 0x000423FC
		public static OvrAvatarDriver.PoseFrame Interpolate(OvrAvatarDriver.PoseFrame a, OvrAvatarDriver.PoseFrame b, float t)
		{
			return new OvrAvatarDriver.PoseFrame
			{
				headPosition = Vector3.Lerp(a.headPosition, b.headPosition, t),
				headRotation = Quaternion.Slerp(a.headRotation, b.headRotation, t),
				handLeftPosition = Vector3.Lerp(a.handLeftPosition, b.handLeftPosition, t),
				handLeftRotation = Quaternion.Slerp(a.handLeftRotation, b.handLeftRotation, t),
				handRightPosition = Vector3.Lerp(a.handRightPosition, b.handRightPosition, t),
				handRightRotation = Quaternion.Slerp(a.handRightRotation, b.handRightRotation, t),
				voiceAmplitude = Mathf.Lerp(a.voiceAmplitude, b.voiceAmplitude, t),
				controllerLeftPose = OvrAvatarDriver.ControllerPose.Interpolate(a.controllerLeftPose, b.controllerLeftPose, t),
				controllerRightPose = OvrAvatarDriver.ControllerPose.Interpolate(a.controllerRightPose, b.controllerRightPose, t)
			};
		}

		// Token: 0x04000E4F RID: 3663
		public Vector3 headPosition;

		// Token: 0x04000E50 RID: 3664
		public Quaternion headRotation;

		// Token: 0x04000E51 RID: 3665
		public Vector3 handLeftPosition;

		// Token: 0x04000E52 RID: 3666
		public Quaternion handLeftRotation;

		// Token: 0x04000E53 RID: 3667
		public Vector3 handRightPosition;

		// Token: 0x04000E54 RID: 3668
		public Quaternion handRightRotation;

		// Token: 0x04000E55 RID: 3669
		public float voiceAmplitude;

		// Token: 0x04000E56 RID: 3670
		public OvrAvatarDriver.ControllerPose controllerLeftPose;

		// Token: 0x04000E57 RID: 3671
		public OvrAvatarDriver.ControllerPose controllerRightPose;
	}
}
