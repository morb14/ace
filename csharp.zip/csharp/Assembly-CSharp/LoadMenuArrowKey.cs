﻿using System;
using UnityEngine;

// Token: 0x02000075 RID: 117
public class LoadMenuArrowKey : MonoBehaviour
{
	// Token: 0x06000454 RID: 1108 RVA: 0x0001D55E File Offset: 0x0001B75E
	private void Start()
	{
		this.originalScale = base.transform.localScale;
	}

	// Token: 0x06000455 RID: 1109 RVA: 0x0001D571 File Offset: 0x0001B771
	private void FixedUpdate()
	{
		if (this.highlightActivated)
		{
			this.highlightObject.SetActive(false);
			this.highlightActivated = false;
		}
	}

	// Token: 0x06000456 RID: 1110 RVA: 0x0001D590 File Offset: 0x0001B790
	public void Select()
	{
		if (this.soundManager == null)
		{
			this.soundManager = Object.FindObjectOfType<SoundManager>();
		}
		base.transform.localScale = new Vector3(base.transform.localScale.x * 1.1f, base.transform.localScale.y * 1.1f, base.transform.localScale.z * 1.1f);
		base.Invoke("ResizeButton", 0.1f);
		this.soundManager.Play(this.soundManager.UIclick);
		this.menu.TurnPage(this.nextPage);
	}

	// Token: 0x06000457 RID: 1111 RVA: 0x0001D63F File Offset: 0x0001B83F
	public void Highlight()
	{
		this.highlightObject.SetActive(true);
		this.highlightObject.transform.localPosition = base.transform.localPosition;
		this.highlightActivated = true;
		this.menu.DelayRescale();
	}

	// Token: 0x06000458 RID: 1112 RVA: 0x0001D67A File Offset: 0x0001B87A
	private void ResizeButton()
	{
		base.transform.localScale = this.originalScale;
	}

	// Token: 0x04000588 RID: 1416
	[SerializeField]
	private CustomStageMenu menu;

	// Token: 0x04000589 RID: 1417
	[SerializeField]
	private bool nextPage;

	// Token: 0x0400058A RID: 1418
	[SerializeField]
	private GameObject highlightObject;

	// Token: 0x0400058B RID: 1419
	private bool highlightActivated;

	// Token: 0x0400058C RID: 1420
	private SoundManager soundManager;

	// Token: 0x0400058D RID: 1421
	private Vector3 originalScale;
}
