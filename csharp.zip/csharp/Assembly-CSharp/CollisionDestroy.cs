﻿using System;
using UnityEngine;

// Token: 0x02000027 RID: 39
public class CollisionDestroy : MonoBehaviour
{
	// Token: 0x060000B9 RID: 185 RVA: 0x00005BC8 File Offset: 0x00003DC8
	private void OnCollisionEnter(Collision other)
	{
		if (this.collisionDestroyFX != null)
		{
			this.collisionDestroyFX.transform.parent = null;
			this.collisionDestroyFX.transform.position = base.transform.position;
			this.collisionDestroyFX.transform.eulerAngles = Vector3.up;
			this.collisionDestroyFX.SetActive(true);
		}
		Object.Destroy(this.gameObjectToDestroy);
	}

	// Token: 0x040000B9 RID: 185
	[SerializeField]
	private GameObject gameObjectToDestroy;

	// Token: 0x040000BA RID: 186
	[SerializeField]
	private GameObject collisionDestroyFX;
}
