﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.XR;

// Token: 0x02000002 RID: 2
public class AAFix : MonoBehaviour
{
	// Token: 0x06000001 RID: 1 RVA: 0x00002050 File Offset: 0x00000250
	private void Start()
	{
		base.StartCoroutine("Fix");
	}

	// Token: 0x06000002 RID: 2 RVA: 0x0000205E File Offset: 0x0000025E
	private IEnumerator Fix()
	{
		XRSettings.eyeTextureResolutionScale = 0.5f;
		yield return new WaitForEndOfFrame();
		XRSettings.eyeTextureResolutionScale = this.resolutionScale;
		Object.Destroy(this);
		yield break;
	}

	// Token: 0x04000001 RID: 1
	[SerializeField]
	private float resolutionScale = 1f;
}
