﻿using System;
using Oculus.Avatar;
using UnityEngine;

// Token: 0x020000AF RID: 175
public class OvrAvatarBase : OvrAvatarComponent
{
	// Token: 0x060005E3 RID: 1507 RVA: 0x000264A4 File Offset: 0x000246A4
	private void Update()
	{
		if (this.owner == null)
		{
			return;
		}
		if (CAPI.ovrAvatarPose_GetBaseComponent(this.owner.sdkAvatar, ref this.component))
		{
			base.UpdateAvatar(this.component.renderComponent);
			return;
		}
		this.owner.Base = null;
		Object.Destroy(this);
	}

	// Token: 0x04000716 RID: 1814
	private ovrAvatarBaseComponent component;
}
