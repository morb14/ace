﻿using System;

// Token: 0x020000C4 RID: 196
public struct ovrAvatarMeshAssetDataV2
{
	// Token: 0x040007A3 RID: 1955
	public uint vertexCount;

	// Token: 0x040007A4 RID: 1956
	public IntPtr vertexBuffer;

	// Token: 0x040007A5 RID: 1957
	public uint indexCount;

	// Token: 0x040007A6 RID: 1958
	public IntPtr indexBuffer;

	// Token: 0x040007A7 RID: 1959
	public ovrAvatarSkinnedMeshPose skinnedBindPose;
}
