﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200011C RID: 284
public class TeleportAimHandlerLaser : TeleportAimHandler
{
	// Token: 0x06000769 RID: 1897 RVA: 0x0002E718 File Offset: 0x0002C918
	public override void GetPoints(List<Vector3> points)
	{
		Ray ray;
		base.LocomotionTeleport.InputHandler.GetAimData(out ray);
		points.Add(ray.origin);
		points.Add(ray.origin + ray.direction * this.Range);
	}

	// Token: 0x0400098D RID: 2445
	[Tooltip("Maximum range for aiming.")]
	public float Range = 100f;
}
