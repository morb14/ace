﻿using System;
using UnityEngine;

// Token: 0x02000010 RID: 16
public class HideMenu : MonoBehaviour
{
	// Token: 0x0600004A RID: 74 RVA: 0x00003297 File Offset: 0x00001497
	private void Start()
	{
	}

	// Token: 0x0600004B RID: 75 RVA: 0x00003297 File Offset: 0x00001497
	private void Update()
	{
	}
}
