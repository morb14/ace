﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200004E RID: 78
public class SaveManager : MonoBehaviour
{
	// Token: 0x06000274 RID: 628 RVA: 0x0000E477 File Offset: 0x0000C677
	public void Start()
	{
		SaveSystem.SortFolders();
	}

	// Token: 0x06000275 RID: 629 RVA: 0x0000E47E File Offset: 0x0000C67E
	public void UpdateCurrentFile(string file)
	{
		this.currentOpenedFile = file;
		GameEvents.current.NewCustomStageLoad();
	}

	// Token: 0x06000276 RID: 630 RVA: 0x0000E494 File Offset: 0x0000C694
	public void ListTest(string name, float number, float anotherNumber)
	{
		SaveManager.ResultObject resultObject = new SaveManager.ResultObject();
		resultObject.weaponID = name;
		resultObject.hitFactor = number;
		resultObject.time = anotherNumber;
		SaveManager.ResultObject resultObject2 = new SaveManager.ResultObject();
		resultObject2.weaponID = "Two";
		resultObject2.hitFactor = number * 2f;
		resultObject2.time = anotherNumber * 2f;
		SaveSystem.Save(JsonUtility.ToJson(new SaveManager.ResultList
		{
			resultObjectList = 
			{
				resultObject,
				resultObject2
			}
		}), "ListTest");
	}

	// Token: 0x06000277 RID: 631 RVA: 0x0000E514 File Offset: 0x0000C714
	public void ListTestLoad()
	{
		foreach (SaveManager.ResultObject resultObject in JsonUtility.FromJson<SaveManager.ResultList>(SaveSystem.Load("ListTest")).resultObjectList)
		{
			MonoBehaviour.print(resultObject.weaponID);
			MonoBehaviour.print(resultObject.time);
			MonoBehaviour.print(resultObject.hitFactor);
		}
	}

	// Token: 0x06000278 RID: 632 RVA: 0x0000E598 File Offset: 0x0000C798
	public void ResetCustomStage()
	{
		string filename = "CustomStage_Temp_FileName";
		this.Save(filename);
		this.Load(filename, false);
	}

	// Token: 0x06000279 RID: 633 RVA: 0x0000E5BA File Offset: 0x0000C7BA
	public void Save(string filename = "")
	{
		this.InitiateSave(filename);
	}

	// Token: 0x0600027A RID: 634 RVA: 0x0000E5C3 File Offset: 0x0000C7C3
	public void UpdateResults(string sceneID, SaveManager.ResultList listObject)
	{
		SaveSystem.Save(JsonUtility.ToJson(listObject), sceneID + "_Results");
	}

	// Token: 0x0600027B RID: 635 RVA: 0x0000E5DC File Offset: 0x0000C7DC
	public SaveManager.ResultList LoadResults(string sceneID)
	{
		if (SaveSystem.Load(sceneID + "_Results") != "FileNotFound")
		{
			try
			{
				SaveManager.ResultList result = JsonUtility.FromJson<SaveManager.ResultList>(SaveSystem.Load(sceneID + "_Results"));
				MonoBehaviour.print("RESULTS LOADED");
				return result;
			}
			catch
			{
				MonoBehaviour.print("FILE IS CORRUPTED");
				return null;
			}
		}
		return null;
	}

	// Token: 0x0600027C RID: 636 RVA: 0x0000E64C File Offset: 0x0000C84C
	private void InitiateSave(string filename = "")
	{
		TargetInfo[] array = Object.FindObjectsOfType<TargetInfo>();
		int num = array.Length;
		SaveManager.SaveObject saveObject = new SaveManager.SaveObject();
		saveObject.objectsToSave = new SaveManager.ObjectToSave[num];
		for (int i = 0; i < num; i++)
		{
			if (!array[i].dontSave)
			{
				SaveManager.ObjectToSave objectToSave = new SaveManager.ObjectToSave
				{
					targetID = array[i].targetID,
					instanceID = array[i].instanceID,
					linkID = array[i].linkID,
					targetPosition = array[i].transform.position,
					targetRotation = array[i].transform.rotation
				};
				saveObject.objectsToSave[i] = objectToSave;
			}
		}
		SaveSystem.Save(JsonUtility.ToJson(saveObject), filename);
		MonoBehaviour.print("SAVED");
	}

	// Token: 0x0600027D RID: 637 RVA: 0x0000E704 File Offset: 0x0000C904
	public void Load(string filename = "", bool noSceneReload = false)
	{
		if (SaveSystem.Load(filename) != "FileNotFound")
		{
			try
			{
				SaveManager.SaveObject saveObject = JsonUtility.FromJson<SaveManager.SaveObject>(SaveSystem.Load(filename));
				MonoBehaviour.print(saveObject.objectsToSave.Length);
				this.sceneLoader.Populate(saveObject, noSceneReload);
				MonoBehaviour.print("FILE LOADED");
			}
			catch
			{
				MonoBehaviour.print("FILE IS CORRUPTED");
			}
		}
	}

	// Token: 0x0400028A RID: 650
	[SerializeField]
	private SceneLoader sceneLoader;

	// Token: 0x0400028B RID: 651
	[SerializeField]
	public string currentOpenedFile;

	// Token: 0x020001BC RID: 444
	[Serializable]
	public class ObjectToSave
	{
		// Token: 0x04000D54 RID: 3412
		public string targetID;

		// Token: 0x04000D55 RID: 3413
		public int instanceID;

		// Token: 0x04000D56 RID: 3414
		public int[] linkID;

		// Token: 0x04000D57 RID: 3415
		public Vector3 targetPosition;

		// Token: 0x04000D58 RID: 3416
		public Quaternion targetRotation;
	}

	// Token: 0x020001BD RID: 445
	[Serializable]
	public class SaveObject
	{
		// Token: 0x04000D59 RID: 3417
		public SaveManager.ObjectToSave[] objectsToSave;
	}

	// Token: 0x020001BE RID: 446
	[Serializable]
	public class ResultObject
	{
		// Token: 0x04000D5A RID: 3418
		public string weaponID;

		// Token: 0x04000D5B RID: 3419
		public float hitFactor;

		// Token: 0x04000D5C RID: 3420
		public float time;
	}

	// Token: 0x020001BF RID: 447
	[Serializable]
	public class ResultList
	{
		// Token: 0x04000D5D RID: 3421
		public bool played;

		// Token: 0x04000D5E RID: 3422
		public bool virginiaCount;

		// Token: 0x04000D5F RID: 3423
		public bool bronzeShield;

		// Token: 0x04000D60 RID: 3424
		public bool silverShield;

		// Token: 0x04000D61 RID: 3425
		public bool goldShield;

		// Token: 0x04000D62 RID: 3426
		public string topWeapon;

		// Token: 0x04000D63 RID: 3427
		public float topHitFactor;

		// Token: 0x04000D64 RID: 3428
		public float topTime;

		// Token: 0x04000D65 RID: 3429
		public List<SaveManager.ResultObject> resultObjectList = new List<SaveManager.ResultObject>();
	}

	// Token: 0x020001C0 RID: 448
	[Serializable]
	public class CalibrationData
	{
		// Token: 0x04000D66 RID: 3430
		public string weaponID;

		// Token: 0x04000D67 RID: 3431
		public Vector3 weaponPosition;

		// Token: 0x04000D68 RID: 3432
		public Quaternion weaponRotation;
	}

	// Token: 0x020001C1 RID: 449
	public class UserData
	{
		// Token: 0x04000D69 RID: 3433
		public float reloadMultiplier;

		// Token: 0x04000D6A RID: 3434
		public List<SaveManager.CalibrationData> calibrationDataList = new List<SaveManager.CalibrationData>();
	}
}
