﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

// Token: 0x0200014A RID: 330
public class ONSPReflectionZone : MonoBehaviour
{
	// Token: 0x060008C0 RID: 2240 RVA: 0x00003297 File Offset: 0x00001497
	private void Start()
	{
	}

	// Token: 0x060008C1 RID: 2241 RVA: 0x00003297 File Offset: 0x00001497
	private void Update()
	{
	}

	// Token: 0x060008C2 RID: 2242 RVA: 0x000395B7 File Offset: 0x000377B7
	private void OnTriggerEnter(Collider other)
	{
		if (this.CheckForAudioListener(other.gameObject))
		{
			this.PushCurrentMixerShapshot();
		}
	}

	// Token: 0x060008C3 RID: 2243 RVA: 0x000395CD File Offset: 0x000377CD
	private void OnTriggerExit(Collider other)
	{
		if (this.CheckForAudioListener(other.gameObject))
		{
			this.PopCurrentMixerSnapshot();
		}
	}

	// Token: 0x060008C4 RID: 2244 RVA: 0x000395E3 File Offset: 0x000377E3
	private bool CheckForAudioListener(GameObject gameObject)
	{
		return gameObject.GetComponentInChildren<AudioListener>() != null;
	}

	// Token: 0x060008C5 RID: 2245 RVA: 0x000395F8 File Offset: 0x000377F8
	private void PushCurrentMixerShapshot()
	{
		ReflectionSnapshot item = ONSPReflectionZone.currentSnapshot;
		ONSPReflectionZone.snapshotList.Push(item);
		this.SetReflectionValues();
	}

	// Token: 0x060008C6 RID: 2246 RVA: 0x0003961C File Offset: 0x0003781C
	private void PopCurrentMixerSnapshot()
	{
		ReflectionSnapshot reflectionSnapshot = ONSPReflectionZone.snapshotList.Pop();
		this.SetReflectionValues(ref reflectionSnapshot);
	}

	// Token: 0x060008C7 RID: 2247 RVA: 0x0003963C File Offset: 0x0003783C
	private void SetReflectionValues()
	{
		if (this.mixerSnapshot != null)
		{
			Debug.Log("Setting off snapshot " + this.mixerSnapshot.name);
			this.mixerSnapshot.TransitionTo(this.fadeTime);
			ONSPReflectionZone.currentSnapshot.mixerSnapshot = this.mixerSnapshot;
			ONSPReflectionZone.currentSnapshot.fadeTime = this.fadeTime;
			return;
		}
		Debug.Log("Mixer snapshot not set - Please ensure play area has at least one encompassing snapshot.");
	}

	// Token: 0x060008C8 RID: 2248 RVA: 0x000396B0 File Offset: 0x000378B0
	private void SetReflectionValues(ref ReflectionSnapshot mss)
	{
		if (mss.mixerSnapshot != null)
		{
			Debug.Log("Setting off snapshot " + mss.mixerSnapshot.name);
			mss.mixerSnapshot.TransitionTo(mss.fadeTime);
			ONSPReflectionZone.currentSnapshot.mixerSnapshot = mss.mixerSnapshot;
			ONSPReflectionZone.currentSnapshot.fadeTime = mss.fadeTime;
			return;
		}
		Debug.Log("Mixer snapshot not set - Please ensure play area has at least one encompassing snapshot.");
	}

	// Token: 0x04000A91 RID: 2705
	public AudioMixerSnapshot mixerSnapshot;

	// Token: 0x04000A92 RID: 2706
	public float fadeTime;

	// Token: 0x04000A93 RID: 2707
	private static Stack<ReflectionSnapshot> snapshotList = new Stack<ReflectionSnapshot>();

	// Token: 0x04000A94 RID: 2708
	private static ReflectionSnapshot currentSnapshot = default(ReflectionSnapshot);
}
