﻿using System;
using UnityEngine;

// Token: 0x0200009C RID: 156
public class InspectorNoteAttribute : PropertyAttribute
{
	// Token: 0x06000543 RID: 1347 RVA: 0x00021B01 File Offset: 0x0001FD01
	public InspectorNoteAttribute(string header, string message = "")
	{
		this.header = header;
		this.message = message;
	}

	// Token: 0x0400066B RID: 1643
	public readonly string header;

	// Token: 0x0400066C RID: 1644
	public readonly string message;
}
