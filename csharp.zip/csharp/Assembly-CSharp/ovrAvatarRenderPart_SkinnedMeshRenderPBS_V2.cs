﻿using System;

// Token: 0x020000E4 RID: 228
public struct ovrAvatarRenderPart_SkinnedMeshRenderPBS_V2
{
	// Token: 0x04000858 RID: 2136
	public ovrAvatarTransform localTransform;

	// Token: 0x04000859 RID: 2137
	public ovrAvatarVisibilityFlags visibilityMask;

	// Token: 0x0400085A RID: 2138
	public ulong meshAssetID;

	// Token: 0x0400085B RID: 2139
	public ovrAvatarPBSMaterialState materialState;

	// Token: 0x0400085C RID: 2140
	public ovrAvatarSkinnedMeshPose skinnedPose;
}
