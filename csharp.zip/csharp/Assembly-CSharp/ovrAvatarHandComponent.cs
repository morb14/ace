﻿using System;

// Token: 0x020000D3 RID: 211
public struct ovrAvatarHandComponent
{
	// Token: 0x040007F1 RID: 2033
	public ovrAvatarHandInputState inputState;

	// Token: 0x040007F2 RID: 2034
	public IntPtr renderComponent;
}
