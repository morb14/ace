﻿using System;
using UnityEngine;

// Token: 0x02000020 RID: 32
public class AccessoryManager : MonoBehaviour
{
	// Token: 0x0600009B RID: 155 RVA: 0x0000585B File Offset: 0x00003A5B
	private void Start()
	{
		if (this.type == AccessoryManager.AccessoryType.Choke && base.gameObject.activeSelf && !Object.FindObjectOfType<WeaponModification>())
		{
			base.GetComponent<MeshRenderer>().enabled = false;
		}
	}

	// Token: 0x040000A7 RID: 167
	[SerializeField]
	private AccessoryManager.AccessoryType type;

	// Token: 0x040000A8 RID: 168
	[Header("Magazine")]
	[SerializeField]
	public int roundCount;

	// Token: 0x040000A9 RID: 169
	[Header("Choke")]
	[SerializeField]
	public float spread;

	// Token: 0x020001AD RID: 429
	public enum AccessoryType
	{
		// Token: 0x04000D04 RID: 3332
		Optic,
		// Token: 0x04000D05 RID: 3333
		Magazine,
		// Token: 0x04000D06 RID: 3334
		BackupOptic,
		// Token: 0x04000D07 RID: 3335
		Choke,
		// Token: 0x04000D08 RID: 3336
		MaterialColour,
		// Token: 0x04000D09 RID: 3337
		Zero,
		// Token: 0x04000D0A RID: 3338
		MagazineAdjustment,
		// Token: 0x04000D0B RID: 3339
		Preset
	}
}
