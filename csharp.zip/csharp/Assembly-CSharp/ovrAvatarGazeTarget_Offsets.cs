﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

// Token: 0x020000ED RID: 237
internal struct ovrAvatarGazeTarget_Offsets
{
	// Token: 0x0400087A RID: 2170
	public static int id = 0;

	// Token: 0x0400087B RID: 2171
	public static int worldPosition = Marshal.SizeOf(typeof(uint));

	// Token: 0x0400087C RID: 2172
	public static int type = ovrAvatarGazeTarget_Offsets.worldPosition + Marshal.SizeOf(typeof(Vector3));
}
