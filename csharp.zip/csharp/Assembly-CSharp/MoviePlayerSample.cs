﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Video;

// Token: 0x02000134 RID: 308
public class MoviePlayerSample : MonoBehaviour
{
	// Token: 0x17000025 RID: 37
	// (get) Token: 0x060007E4 RID: 2020 RVA: 0x00030B5F File Offset: 0x0002ED5F
	// (set) Token: 0x060007E5 RID: 2021 RVA: 0x00030B67 File Offset: 0x0002ED67
	public bool IsPlaying { get; private set; }

	// Token: 0x17000026 RID: 38
	// (get) Token: 0x060007E6 RID: 2022 RVA: 0x00030B70 File Offset: 0x0002ED70
	// (set) Token: 0x060007E7 RID: 2023 RVA: 0x00030B78 File Offset: 0x0002ED78
	public long Duration { get; private set; }

	// Token: 0x17000027 RID: 39
	// (get) Token: 0x060007E8 RID: 2024 RVA: 0x00030B81 File Offset: 0x0002ED81
	// (set) Token: 0x060007E9 RID: 2025 RVA: 0x00030B89 File Offset: 0x0002ED89
	public long PlaybackPosition { get; private set; }

	// Token: 0x060007EA RID: 2026 RVA: 0x00030B94 File Offset: 0x0002ED94
	private void Awake()
	{
		Debug.Log("MovieSample Awake");
		this.mediaRenderer = base.GetComponent<Renderer>();
		this.videoPlayer = base.GetComponent<VideoPlayer>();
		if (this.videoPlayer == null)
		{
			this.videoPlayer = base.gameObject.AddComponent<VideoPlayer>();
		}
		this.videoPlayer.isLooping = this.LoopVideo;
		this.overlay = base.GetComponent<OVROverlay>();
		if (this.overlay == null)
		{
			this.overlay = base.gameObject.AddComponent<OVROverlay>();
		}
		this.overlay.enabled = false;
		this.overlay.isExternalSurface = NativeVideoPlayer.IsAvailable;
		this.overlay.enabled = (this.overlay.currentOverlayShape != OVROverlay.OverlayShape.Equirect || Application.platform == RuntimePlatform.Android);
	}

	// Token: 0x060007EB RID: 2027 RVA: 0x00030C5F File Offset: 0x0002EE5F
	private bool IsLocalVideo(string movieName)
	{
		return !movieName.Contains("://");
	}

	// Token: 0x060007EC RID: 2028 RVA: 0x00030C70 File Offset: 0x0002EE70
	private void UpdateShapeAndStereo()
	{
		if (this.Shape != this._LastShape || this.Stereo != this._LastStereo || this.DisplayMono != this._LastDisplayMono)
		{
			Rect rect = new Rect(0f, 0f, 1f, 1f);
			switch (this.Shape)
			{
			case MoviePlayerSample.VideoShape._360:
				this.overlay.currentOverlayShape = OVROverlay.OverlayShape.Equirect;
				goto IL_A6;
			case MoviePlayerSample.VideoShape._180:
				this.overlay.currentOverlayShape = OVROverlay.OverlayShape.Equirect;
				rect = new Rect(0.25f, 0f, 0.5f, 1f);
				goto IL_A6;
			}
			this.overlay.currentOverlayShape = OVROverlay.OverlayShape.Quad;
			IL_A6:
			this.overlay.overrideTextureRectMatrix = true;
			Rect rect2 = new Rect(0f, 0f, 1f, 1f);
			Rect rect3 = new Rect(0f, 0f, 1f, 1f);
			MoviePlayerSample.VideoStereo stereo = this.Stereo;
			if (stereo != MoviePlayerSample.VideoStereo.TopBottom)
			{
				if (stereo == MoviePlayerSample.VideoStereo.LeftRight)
				{
					rect2 = new Rect(0f, 0f, 0.5f, 1f);
					rect3 = new Rect(0.5f, 0f, 0.5f, 1f);
				}
			}
			else
			{
				rect2 = new Rect(0f, 0f, 1f, 0.5f);
				rect3 = new Rect(0f, 0.5f, 1f, 0.5f);
			}
			this.overlay.SetSrcDestRects(rect2, this.DisplayMono ? rect2 : rect3, rect, rect);
			this._LastDisplayMono = this.DisplayMono;
			this._LastStereo = this.Stereo;
			this._LastShape = this.Shape;
		}
	}

	// Token: 0x060007ED RID: 2029 RVA: 0x00030E23 File Offset: 0x0002F023
	private IEnumerator Start()
	{
		if (this.mediaRenderer.material == null)
		{
			Debug.LogError("No material for movie surface");
			yield break;
		}
		yield return new WaitForSeconds(1f);
		if (!string.IsNullOrEmpty(this.MovieName))
		{
			if (this.IsLocalVideo(this.MovieName))
			{
				this.Play(Application.streamingAssetsPath + "/" + this.MovieName, null);
			}
			else
			{
				this.Play(this.MovieName, this.DrmLicenseUrl);
			}
		}
		yield break;
	}

	// Token: 0x060007EE RID: 2030 RVA: 0x00030E34 File Offset: 0x0002F034
	public void Play(string moviePath, string drmLicencesUrl)
	{
		if (moviePath != string.Empty)
		{
			Debug.Log("Playing Video: " + moviePath);
			if (this.overlay.isExternalSurface)
			{
				OVROverlay.ExternalSurfaceObjectCreated externalSurfaceObjectCreated = delegate()
				{
					Debug.Log("Playing ExoPlayer with SurfaceObject");
					NativeVideoPlayer.PlayVideo(moviePath, drmLicencesUrl, this.overlay.externalSurfaceObject);
					NativeVideoPlayer.SetLooping(this.LoopVideo);
				};
				if (this.overlay.externalSurfaceObject == IntPtr.Zero)
				{
					this.overlay.externalSurfaceObjectCreated = externalSurfaceObjectCreated;
				}
				else
				{
					externalSurfaceObjectCreated();
				}
			}
			else
			{
				Debug.Log("Playing Unity VideoPlayer");
				this.videoPlayer.url = moviePath;
				this.videoPlayer.Prepare();
				this.videoPlayer.Play();
			}
			Debug.Log("MovieSample Start");
			this.IsPlaying = true;
			return;
		}
		Debug.LogError("No media file name provided");
	}

	// Token: 0x060007EF RID: 2031 RVA: 0x00030F1A File Offset: 0x0002F11A
	public void Play()
	{
		if (this.overlay.isExternalSurface)
		{
			NativeVideoPlayer.Play();
		}
		else
		{
			this.videoPlayer.Play();
		}
		this.IsPlaying = true;
	}

	// Token: 0x060007F0 RID: 2032 RVA: 0x00030F42 File Offset: 0x0002F142
	public void Pause()
	{
		if (this.overlay.isExternalSurface)
		{
			NativeVideoPlayer.Pause();
		}
		else
		{
			this.videoPlayer.Pause();
		}
		this.IsPlaying = false;
	}

	// Token: 0x060007F1 RID: 2033 RVA: 0x00030F6C File Offset: 0x0002F16C
	public void SeekTo(long position)
	{
		long num = Math.Max(0L, Math.Min(this.Duration, position));
		if (this.overlay.isExternalSurface)
		{
			NativeVideoPlayer.PlaybackPosition = num;
			return;
		}
		this.videoPlayer.time = (double)num / 1000.0;
	}

	// Token: 0x060007F2 RID: 2034 RVA: 0x00030FB8 File Offset: 0x0002F1B8
	private void Update()
	{
		this.UpdateShapeAndStereo();
		if (!this.overlay.isExternalSurface)
		{
			Texture texture = (this.videoPlayer.texture != null) ? this.videoPlayer.texture : Texture2D.blackTexture;
			if (this.overlay.enabled)
			{
				if (this.overlay.textures[0] != texture)
				{
					this.overlay.enabled = false;
					this.overlay.textures[0] = texture;
					this.overlay.enabled = true;
				}
			}
			else
			{
				this.mediaRenderer.material.mainTexture = texture;
				this.mediaRenderer.material.SetVector("_SrcRectLeft", this.overlay.srcRectLeft.ToVector());
				this.mediaRenderer.material.SetVector("_SrcRectRight", this.overlay.srcRectRight.ToVector());
			}
			this.IsPlaying = this.videoPlayer.isPlaying;
			this.PlaybackPosition = (long)(this.videoPlayer.time * 1000.0);
			this.Duration = (long)(this.videoPlayer.length * 1000.0);
			return;
		}
		NativeVideoPlayer.SetListenerRotation(Camera.main.transform.rotation);
		this.IsPlaying = NativeVideoPlayer.IsPlaying;
		this.PlaybackPosition = NativeVideoPlayer.PlaybackPosition;
		this.Duration = NativeVideoPlayer.Duration;
		if (this.IsPlaying && (int)OVRManager.display.displayFrequency != 60)
		{
			OVRManager.display.displayFrequency = 60f;
			return;
		}
		if (!this.IsPlaying && (int)OVRManager.display.displayFrequency != 72)
		{
			OVRManager.display.displayFrequency = 72f;
		}
	}

	// Token: 0x060007F3 RID: 2035 RVA: 0x00031175 File Offset: 0x0002F375
	public void SetPlaybackSpeed(float speed)
	{
		speed = Mathf.Max(0f, speed);
		if (this.overlay.isExternalSurface)
		{
			NativeVideoPlayer.SetPlaybackSpeed(speed);
			return;
		}
		this.videoPlayer.playbackSpeed = speed;
	}

	// Token: 0x060007F4 RID: 2036 RVA: 0x000311A4 File Offset: 0x0002F3A4
	public void Stop()
	{
		if (this.overlay.isExternalSurface)
		{
			NativeVideoPlayer.Stop();
		}
		else
		{
			this.videoPlayer.Stop();
		}
		this.IsPlaying = false;
	}

	// Token: 0x060007F5 RID: 2037 RVA: 0x000311CC File Offset: 0x0002F3CC
	private void OnApplicationPause(bool appWasPaused)
	{
		Debug.Log("OnApplicationPause: " + appWasPaused.ToString());
		if (appWasPaused)
		{
			this.videoPausedBeforeAppPause = !this.IsPlaying;
		}
		if (!this.videoPausedBeforeAppPause)
		{
			if (appWasPaused)
			{
				this.Pause();
				return;
			}
			this.Play();
		}
	}

	// Token: 0x040009E9 RID: 2537
	private bool videoPausedBeforeAppPause;

	// Token: 0x040009EA RID: 2538
	private VideoPlayer videoPlayer;

	// Token: 0x040009EB RID: 2539
	private OVROverlay overlay;

	// Token: 0x040009EC RID: 2540
	private Renderer mediaRenderer;

	// Token: 0x040009F0 RID: 2544
	private RenderTexture copyTexture;

	// Token: 0x040009F1 RID: 2545
	private Material externalTex2DMaterial;

	// Token: 0x040009F2 RID: 2546
	public string MovieName;

	// Token: 0x040009F3 RID: 2547
	public string DrmLicenseUrl;

	// Token: 0x040009F4 RID: 2548
	public bool LoopVideo;

	// Token: 0x040009F5 RID: 2549
	public MoviePlayerSample.VideoShape Shape;

	// Token: 0x040009F6 RID: 2550
	public MoviePlayerSample.VideoStereo Stereo;

	// Token: 0x040009F7 RID: 2551
	public bool DisplayMono;

	// Token: 0x040009F8 RID: 2552
	private MoviePlayerSample.VideoShape _LastShape = (MoviePlayerSample.VideoShape)(-1);

	// Token: 0x040009F9 RID: 2553
	private MoviePlayerSample.VideoStereo _LastStereo = (MoviePlayerSample.VideoStereo)(-1);

	// Token: 0x040009FA RID: 2554
	private bool _LastDisplayMono;

	// Token: 0x02000222 RID: 546
	public enum VideoShape
	{
		// Token: 0x04000F2D RID: 3885
		_360,
		// Token: 0x04000F2E RID: 3886
		_180,
		// Token: 0x04000F2F RID: 3887
		Quad
	}

	// Token: 0x02000223 RID: 547
	public enum VideoStereo
	{
		// Token: 0x04000F31 RID: 3889
		Mono,
		// Token: 0x04000F32 RID: 3890
		TopBottom,
		// Token: 0x04000F33 RID: 3891
		LeftRight
	}
}
