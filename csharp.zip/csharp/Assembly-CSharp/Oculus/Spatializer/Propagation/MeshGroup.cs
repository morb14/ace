﻿using System;
using System.Runtime.InteropServices;

namespace Oculus.Spatializer.Propagation
{
	// Token: 0x02000181 RID: 385
	[StructLayout(LayoutKind.Sequential, Pack = 1)]
	public struct MeshGroup
	{
		// Token: 0x04000C14 RID: 3092
		public UIntPtr indexOffset;

		// Token: 0x04000C15 RID: 3093
		public UIntPtr faceCount;

		// Token: 0x04000C16 RID: 3094
		[MarshalAs(UnmanagedType.U4)]
		public FaceType faceType;

		// Token: 0x04000C17 RID: 3095
		public IntPtr material;
	}
}
