﻿using System;

namespace Oculus.Spatializer.Propagation
{
	// Token: 0x02000180 RID: 384
	public enum MaterialProperty : uint
	{
		// Token: 0x04000C11 RID: 3089
		ABSORPTION,
		// Token: 0x04000C12 RID: 3090
		TRANSMISSION,
		// Token: 0x04000C13 RID: 3091
		SCATTERING
	}
}
