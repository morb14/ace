﻿using System;

namespace Oculus.Spatializer.Propagation
{
	// Token: 0x0200017F RID: 383
	public enum FaceType : uint
	{
		// Token: 0x04000C0E RID: 3086
		TRIANGLES,
		// Token: 0x04000C0F RID: 3087
		QUADS
	}
}
