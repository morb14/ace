﻿using System;
using System.Runtime.InteropServices;
using AOT;
using UnityEngine;

namespace Oculus.Avatar
{
	// Token: 0x02000183 RID: 387
	public class CAPI
	{
		// Token: 0x06000A50 RID: 2640
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_InitializeAndroidUnity(string appID);

		// Token: 0x06000A51 RID: 2641 RVA: 0x0003F214 File Offset: 0x0003D414
		public static void Initialize()
		{
			CAPI.nativeVisemeData = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(ovrAvatarVisemes)));
			CAPI.nativeGazeTargetsData = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(ovrAvatarGazeTargets)));
			CAPI.nativeAvatarLightsData = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(ovrAvatarLights)));
			CAPI.DebugLineCountData = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(uint)));
			CAPI.debugLineGo = new GameObject();
			CAPI.debugLineGo.name = "AvatarSDKDebugDrawHelper";
		}

		// Token: 0x06000A52 RID: 2642 RVA: 0x0003F29E File Offset: 0x0003D49E
		public static void Shutdown()
		{
			Marshal.FreeHGlobal(CAPI.nativeVisemeData);
			Marshal.FreeHGlobal(CAPI.nativeGazeTargetsData);
			Marshal.FreeHGlobal(CAPI.nativeAvatarLightsData);
			Marshal.FreeHGlobal(CAPI.DebugLineCountData);
			CAPI.debugLineGo = null;
		}

		// Token: 0x06000A53 RID: 2643
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_Shutdown();

		// Token: 0x06000A54 RID: 2644
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr ovrAvatarMessage_Pop();

		// Token: 0x06000A55 RID: 2645
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern ovrAvatarMessageType ovrAvatarMessage_GetType(IntPtr msg);

		// Token: 0x06000A56 RID: 2646 RVA: 0x0003F2CE File Offset: 0x0003D4CE
		public static ovrAvatarMessage_AvatarSpecification ovrAvatarMessage_GetAvatarSpecification(IntPtr msg)
		{
			return (ovrAvatarMessage_AvatarSpecification)Marshal.PtrToStructure(CAPI.ovrAvatarMessage_GetAvatarSpecification_Native(msg), typeof(ovrAvatarMessage_AvatarSpecification));
		}

		// Token: 0x06000A57 RID: 2647
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatarMessage_GetAvatarSpecification")]
		private static extern IntPtr ovrAvatarMessage_GetAvatarSpecification_Native(IntPtr msg);

		// Token: 0x06000A58 RID: 2648 RVA: 0x0003F2EA File Offset: 0x0003D4EA
		public static ovrAvatarMessage_AssetLoaded ovrAvatarMessage_GetAssetLoaded(IntPtr msg)
		{
			return (ovrAvatarMessage_AssetLoaded)Marshal.PtrToStructure(CAPI.ovrAvatarMessage_GetAssetLoaded_Native(msg), typeof(ovrAvatarMessage_AssetLoaded));
		}

		// Token: 0x06000A59 RID: 2649
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatarMessage_GetAssetLoaded")]
		private static extern IntPtr ovrAvatarMessage_GetAssetLoaded_Native(IntPtr msg);

		// Token: 0x06000A5A RID: 2650
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatarMessage_Free(IntPtr msg);

		// Token: 0x06000A5B RID: 2651
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr ovrAvatarSpecificationRequest_Create(ulong userID);

		// Token: 0x06000A5C RID: 2652
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatarSpecificationRequest_Destroy(IntPtr specificationRequest);

		// Token: 0x06000A5D RID: 2653
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatarSpecificationRequest_SetCombineMeshes(IntPtr specificationRequest, bool useCombinedMesh);

		// Token: 0x06000A5E RID: 2654
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatarSpecificationRequest_SetLookAndFeelVersion(IntPtr specificationRequest, ovrAvatarLookAndFeelVersion version);

		// Token: 0x06000A5F RID: 2655
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatarSpecificationRequest_SetLevelOfDetail(IntPtr specificationRequest, ovrAvatarAssetLevelOfDetail lod);

		// Token: 0x06000A60 RID: 2656
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_RequestAvatarSpecification(ulong userID);

		// Token: 0x06000A61 RID: 2657
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_RequestAvatarSpecificationFromSpecRequest(IntPtr specificationRequest);

		// Token: 0x06000A62 RID: 2658
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatarSpecificationRequest_SetFallbackLookAndFeelVersion(IntPtr specificationRequest, ovrAvatarLookAndFeelVersion version);

		// Token: 0x06000A63 RID: 2659
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatarSpecificationRequest_SetExpressiveFlag(IntPtr specificationRequest, bool enable);

		// Token: 0x06000A64 RID: 2660
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr ovrAvatar_Create(IntPtr avatarSpecification, ovrAvatarCapabilities capabilities);

		// Token: 0x06000A65 RID: 2661
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_Destroy(IntPtr avatar);

		// Token: 0x06000A66 RID: 2662
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatarPose_UpdateBody(IntPtr avatar, ovrAvatarTransform headPose);

		// Token: 0x06000A67 RID: 2663 RVA: 0x0003F306 File Offset: 0x0003D506
		public static void ovrAvatarPose_UpdateVoiceVisualization(IntPtr avatar, float[] pcmData)
		{
			CAPI.ovrAvatarPose_UpdateVoiceVisualization_Native(avatar, (uint)pcmData.Length, pcmData);
		}

		// Token: 0x06000A68 RID: 2664
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatarPose_UpdateVoiceVisualization")]
		private static extern void ovrAvatarPose_UpdateVoiceVisualization_Native(IntPtr avatar, uint pcmDataSize, [In] float[] pcmData);

		// Token: 0x06000A69 RID: 2665
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatarPose_UpdateHands(IntPtr avatar, ovrAvatarHandInputState inputStateLeft, ovrAvatarHandInputState inputStateRight);

		// Token: 0x06000A6A RID: 2666
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatarPose_UpdateHandsWithType(IntPtr avatar, ovrAvatarHandInputState inputStateLeft, ovrAvatarHandInputState inputStateRight, ovrAvatarControllerType type);

		// Token: 0x06000A6B RID: 2667
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatarPose_Finalize(IntPtr avatar, float elapsedSeconds);

		// Token: 0x06000A6C RID: 2668
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_SetLeftControllerVisibility(IntPtr avatar, bool show);

		// Token: 0x06000A6D RID: 2669
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_SetRightControllerVisibility(IntPtr avatar, bool show);

		// Token: 0x06000A6E RID: 2670
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_SetLeftHandVisibility(IntPtr avatar, bool show);

		// Token: 0x06000A6F RID: 2671
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_SetRightHandVisibility(IntPtr avatar, bool show);

		// Token: 0x06000A70 RID: 2672
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern uint ovrAvatarComponent_Count(IntPtr avatar);

		// Token: 0x06000A71 RID: 2673 RVA: 0x0003F312 File Offset: 0x0003D512
		public static void ovrAvatarComponent_Get(IntPtr avatar, uint index, bool includeName, ref ovrAvatarComponent component)
		{
			CAPI.ovrAvatarComponent_Get(CAPI.ovrAvatarComponent_Get_Native(avatar, index), includeName, ref component);
		}

		// Token: 0x06000A72 RID: 2674 RVA: 0x0003F324 File Offset: 0x0003D524
		public static void ovrAvatarComponent_Get(IntPtr componentPtr, bool includeName, ref ovrAvatarComponent component)
		{
			Marshal.Copy(new IntPtr(componentPtr.ToInt64() + ovrAvatarComponent_Offsets.transform), CAPI.scratchBufferFloat, 0, 10);
			OvrAvatar.ConvertTransform(CAPI.scratchBufferFloat, ref component.transform);
			component.renderPartCount = (uint)Marshal.ReadInt32(componentPtr, ovrAvatarComponent_Offsets.renderPartCount);
			component.renderParts = Marshal.ReadIntPtr(componentPtr, ovrAvatarComponent_Offsets.renderParts);
			if (includeName)
			{
				IntPtr ptr = Marshal.ReadIntPtr(componentPtr, ovrAvatarComponent_Offsets.name);
				component.name = Marshal.PtrToStringAnsi(ptr);
			}
		}

		// Token: 0x06000A73 RID: 2675
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatarComponent_Get")]
		public static extern IntPtr ovrAvatarComponent_Get_Native(IntPtr avatar, uint index);

		// Token: 0x06000A74 RID: 2676 RVA: 0x0003F3A0 File Offset: 0x0003D5A0
		public static bool ovrAvatarPose_GetBaseComponent(IntPtr avatar, ref ovrAvatarBaseComponent component)
		{
			IntPtr intPtr = CAPI.ovrAvatarPose_GetBaseComponent_Native(avatar);
			if (intPtr == IntPtr.Zero)
			{
				return false;
			}
			int ofs = Marshal.SizeOf(typeof(ovrAvatarBaseComponent)) - Marshal.SizeOf(typeof(IntPtr));
			component.renderComponent = Marshal.ReadIntPtr(intPtr, ofs);
			return true;
		}

		// Token: 0x06000A75 RID: 2677
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatarPose_GetBaseComponent")]
		private static extern IntPtr ovrAvatarPose_GetBaseComponent_Native(IntPtr avatar);

		// Token: 0x06000A76 RID: 2678 RVA: 0x0003F3F4 File Offset: 0x0003D5F4
		public static IntPtr MarshalRenderComponent<T>(IntPtr ptr) where T : struct
		{
			return Marshal.ReadIntPtr(new IntPtr(ptr.ToInt64() + Marshal.OffsetOf(typeof(T), "renderComponent").ToInt64()));
		}

		// Token: 0x06000A77 RID: 2679 RVA: 0x0003F430 File Offset: 0x0003D630
		public static bool ovrAvatarPose_GetBodyComponent(IntPtr avatar, ref ovrAvatarBodyComponent component)
		{
			IntPtr intPtr = CAPI.ovrAvatarPose_GetBodyComponent_Native(avatar);
			if (intPtr == IntPtr.Zero)
			{
				return false;
			}
			Marshal.Copy(new IntPtr(intPtr.ToInt64() + ovrAvatarBodyComponent_Offsets.leftEyeTransform), CAPI.scratchBufferFloat, 0, 10);
			OvrAvatar.ConvertTransform(CAPI.scratchBufferFloat, ref component.leftEyeTransform);
			Marshal.Copy(new IntPtr(intPtr.ToInt64() + ovrAvatarBodyComponent_Offsets.rightEyeTransform), CAPI.scratchBufferFloat, 0, 10);
			OvrAvatar.ConvertTransform(CAPI.scratchBufferFloat, ref component.rightEyeTransform);
			Marshal.Copy(new IntPtr(intPtr.ToInt64() + ovrAvatarBodyComponent_Offsets.centerEyeTransform), CAPI.scratchBufferFloat, 0, 10);
			OvrAvatar.ConvertTransform(CAPI.scratchBufferFloat, ref component.centerEyeTransform);
			component.renderComponent = CAPI.MarshalRenderComponent<ovrAvatarBodyComponent>(intPtr);
			return true;
		}

		// Token: 0x06000A78 RID: 2680
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatarPose_GetBodyComponent")]
		private static extern IntPtr ovrAvatarPose_GetBodyComponent_Native(IntPtr avatar);

		// Token: 0x06000A79 RID: 2681 RVA: 0x0003F4F0 File Offset: 0x0003D6F0
		public static bool ovrAvatarPose_GetLeftControllerComponent(IntPtr avatar, ref ovrAvatarControllerComponent component)
		{
			IntPtr intPtr = CAPI.ovrAvatarPose_GetLeftControllerComponent_Native(avatar);
			if (intPtr == IntPtr.Zero)
			{
				return false;
			}
			int ofs = Marshal.SizeOf(typeof(ovrAvatarControllerComponent)) - Marshal.SizeOf(typeof(IntPtr));
			component.renderComponent = Marshal.ReadIntPtr(intPtr, ofs);
			return true;
		}

		// Token: 0x06000A7A RID: 2682
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatarPose_GetLeftControllerComponent")]
		private static extern IntPtr ovrAvatarPose_GetLeftControllerComponent_Native(IntPtr avatar);

		// Token: 0x06000A7B RID: 2683 RVA: 0x0003F544 File Offset: 0x0003D744
		public static bool ovrAvatarPose_GetRightControllerComponent(IntPtr avatar, ref ovrAvatarControllerComponent component)
		{
			IntPtr intPtr = CAPI.ovrAvatarPose_GetRightControllerComponent_Native(avatar);
			if (intPtr == IntPtr.Zero)
			{
				return false;
			}
			int ofs = Marshal.SizeOf(typeof(ovrAvatarControllerComponent)) - Marshal.SizeOf(typeof(IntPtr));
			component.renderComponent = Marshal.ReadIntPtr(intPtr, ofs);
			return true;
		}

		// Token: 0x06000A7C RID: 2684
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatarPose_GetRightControllerComponent")]
		private static extern IntPtr ovrAvatarPose_GetRightControllerComponent_Native(IntPtr avatar);

		// Token: 0x06000A7D RID: 2685 RVA: 0x0003F598 File Offset: 0x0003D798
		public static bool ovrAvatarPose_GetLeftHandComponent(IntPtr avatar, ref ovrAvatarHandComponent component)
		{
			IntPtr intPtr = CAPI.ovrAvatarPose_GetLeftHandComponent_Native(avatar);
			if (intPtr == IntPtr.Zero)
			{
				return false;
			}
			int ofs = Marshal.SizeOf(typeof(ovrAvatarHandComponent)) - Marshal.SizeOf(typeof(IntPtr));
			component.renderComponent = Marshal.ReadIntPtr(intPtr, ofs);
			return true;
		}

		// Token: 0x06000A7E RID: 2686
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatarPose_GetLeftHandComponent")]
		private static extern IntPtr ovrAvatarPose_GetLeftHandComponent_Native(IntPtr avatar);

		// Token: 0x06000A7F RID: 2687 RVA: 0x0003F5EC File Offset: 0x0003D7EC
		public static bool ovrAvatarPose_GetRightHandComponent(IntPtr avatar, ref ovrAvatarHandComponent component)
		{
			IntPtr intPtr = CAPI.ovrAvatarPose_GetRightHandComponent_Native(avatar);
			if (intPtr == IntPtr.Zero)
			{
				return false;
			}
			int ofs = Marshal.SizeOf(typeof(ovrAvatarHandComponent)) - Marshal.SizeOf(typeof(IntPtr));
			component.renderComponent = Marshal.ReadIntPtr(intPtr, ofs);
			return true;
		}

		// Token: 0x06000A80 RID: 2688
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatarPose_GetRightHandComponent")]
		private static extern IntPtr ovrAvatarPose_GetRightHandComponent_Native(IntPtr avatar);

		// Token: 0x06000A81 RID: 2689
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatarAsset_BeginLoading(ulong assetID);

		// Token: 0x06000A82 RID: 2690
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern bool ovrAvatarAsset_BeginLoadingLOD(ulong assetId, ovrAvatarAssetLevelOfDetail lod);

		// Token: 0x06000A83 RID: 2691
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern ovrAvatarAssetType ovrAvatarAsset_GetType(IntPtr assetHandle);

		// Token: 0x06000A84 RID: 2692 RVA: 0x0003F63D File Offset: 0x0003D83D
		public static ovrAvatarMeshAssetData ovrAvatarAsset_GetMeshData(IntPtr assetPtr)
		{
			return (ovrAvatarMeshAssetData)Marshal.PtrToStructure(CAPI.ovrAvatarAsset_GetMeshData_Native(assetPtr), typeof(ovrAvatarMeshAssetData));
		}

		// Token: 0x06000A85 RID: 2693 RVA: 0x0003F659 File Offset: 0x0003D859
		public static ovrAvatarMeshAssetDataV2 ovrAvatarAsset_GetCombinedMeshData(IntPtr assetPtr)
		{
			return (ovrAvatarMeshAssetDataV2)Marshal.PtrToStructure(CAPI.ovrAvatarAsset_GetCombinedMeshData_Native(assetPtr), typeof(ovrAvatarMeshAssetDataV2));
		}

		// Token: 0x06000A86 RID: 2694
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatarAsset_GetCombinedMeshData")]
		private static extern IntPtr ovrAvatarAsset_GetCombinedMeshData_Native(IntPtr assetPtr);

		// Token: 0x06000A87 RID: 2695
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatarAsset_GetMeshData")]
		private static extern IntPtr ovrAvatarAsset_GetMeshData_Native(IntPtr assetPtr);

		// Token: 0x06000A88 RID: 2696
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern uint ovrAvatarAsset_GetMeshBlendShapeCount(IntPtr assetPtr);

		// Token: 0x06000A89 RID: 2697
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr ovrAvatarAsset_GetMeshBlendShapeName(IntPtr assetPtr, uint index);

		// Token: 0x06000A8A RID: 2698
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern uint ovrAvatarAsset_GetSubmeshCount(IntPtr assetPtr);

		// Token: 0x06000A8B RID: 2699
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern uint ovrAvatarAsset_GetSubmeshLastIndex(IntPtr assetPtr, uint index);

		// Token: 0x06000A8C RID: 2700
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr ovrAvatarAsset_GetMeshBlendShapeVertices(IntPtr assetPtr);

		// Token: 0x06000A8D RID: 2701
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr ovrAvatarAsset_GetAvatar(IntPtr assetHandle);

		// Token: 0x06000A8E RID: 2702 RVA: 0x0003F678 File Offset: 0x0003D878
		public static ulong[] ovrAvatarAsset_GetCombinedMeshIDs(IntPtr assetHandle)
		{
			uint num = 0U;
			IntPtr intPtr = Marshal.AllocHGlobal(Marshal.SizeOf<uint>(num));
			IntPtr ptr = CAPI.ovrAvatarAsset_GetCombinedMeshIDs_Native(assetHandle, intPtr);
			num = (uint)Marshal.PtrToStructure(intPtr, typeof(uint));
			ulong[] array = new ulong[num];
			int num2 = 0;
			while ((long)num2 < (long)((ulong)num))
			{
				array[num2] = (ulong)Marshal.ReadInt64(ptr, num2 * Marshal.SizeOf(typeof(ulong)));
				num2++;
			}
			Marshal.FreeHGlobal(intPtr);
			return array;
		}

		// Token: 0x06000A8F RID: 2703
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatarAsset_GetCombinedMeshIDs")]
		public static extern IntPtr ovrAvatarAsset_GetCombinedMeshIDs_Native(IntPtr assetHandle, IntPtr count);

		// Token: 0x06000A90 RID: 2704 RVA: 0x0003F6F0 File Offset: 0x0003D8F0
		public static void ovrAvatar_GetCombinedMeshAlphaData(IntPtr avatar, ref ulong textureID, ref Vector4 offset)
		{
			IntPtr intPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(ulong)));
			IntPtr intPtr2 = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(Vector4)));
			CAPI.ovrAvatar_GetCombinedMeshAlphaData_Native(avatar, intPtr, intPtr2);
			textureID = (ulong)Marshal.PtrToStructure(intPtr, typeof(ulong));
			offset = (Vector4)Marshal.PtrToStructure(intPtr2, typeof(Vector4));
			Marshal.FreeHGlobal(intPtr);
			Marshal.FreeHGlobal(intPtr2);
		}

		// Token: 0x06000A91 RID: 2705
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatar_GetCombinedMeshAlphaData")]
		public static extern IntPtr ovrAvatar_GetCombinedMeshAlphaData_Native(IntPtr avatar, IntPtr textureIDPtr, IntPtr offsetPtr);

		// Token: 0x06000A92 RID: 2706 RVA: 0x0003F76E File Offset: 0x0003D96E
		public static ovrAvatarTextureAssetData ovrAvatarAsset_GetTextureData(IntPtr assetPtr)
		{
			return (ovrAvatarTextureAssetData)Marshal.PtrToStructure(CAPI.ovrAvatarAsset_GetTextureData_Native(assetPtr), typeof(ovrAvatarTextureAssetData));
		}

		// Token: 0x06000A93 RID: 2707
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatarAsset_GetTextureData")]
		private static extern IntPtr ovrAvatarAsset_GetTextureData_Native(IntPtr assetPtr);

		// Token: 0x06000A94 RID: 2708
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatarAsset_GetMaterialData")]
		private static extern IntPtr ovrAvatarAsset_GetMaterialData_Native(IntPtr assetPtr);

		// Token: 0x06000A95 RID: 2709 RVA: 0x0003F78A File Offset: 0x0003D98A
		public static ovrAvatarMaterialState ovrAvatarAsset_GetMaterialState(IntPtr assetPtr)
		{
			return (ovrAvatarMaterialState)Marshal.PtrToStructure(CAPI.ovrAvatarAsset_GetMaterialData_Native(assetPtr), typeof(ovrAvatarMaterialState));
		}

		// Token: 0x06000A96 RID: 2710
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern ovrAvatarRenderPartType ovrAvatarRenderPart_GetType(IntPtr renderPart);

		// Token: 0x06000A97 RID: 2711 RVA: 0x0003F7A6 File Offset: 0x0003D9A6
		public static ovrAvatarRenderPart_SkinnedMeshRender ovrAvatarRenderPart_GetSkinnedMeshRender(IntPtr renderPart)
		{
			return (ovrAvatarRenderPart_SkinnedMeshRender)Marshal.PtrToStructure(CAPI.ovrAvatarRenderPart_GetSkinnedMeshRender_Native(renderPart), typeof(ovrAvatarRenderPart_SkinnedMeshRender));
		}

		// Token: 0x06000A98 RID: 2712
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatarRenderPart_GetSkinnedMeshRender")]
		private static extern IntPtr ovrAvatarRenderPart_GetSkinnedMeshRender_Native(IntPtr renderPart);

		// Token: 0x06000A99 RID: 2713
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern ovrAvatarTransform ovrAvatarSkinnedMeshRender_GetTransform(IntPtr renderPart);

		// Token: 0x06000A9A RID: 2714
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern ovrAvatarTransform ovrAvatarSkinnedMeshRenderPBS_GetTransform(IntPtr renderPart);

		// Token: 0x06000A9B RID: 2715
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern ovrAvatarTransform ovrAvatarSkinnedMeshRenderPBSV2_GetTransform(IntPtr renderPart);

		// Token: 0x06000A9C RID: 2716
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern ovrAvatarVisibilityFlags ovrAvatarSkinnedMeshRender_GetVisibilityMask(IntPtr renderPart);

		// Token: 0x06000A9D RID: 2717
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern bool ovrAvatarSkinnedMeshRender_MaterialStateChanged(IntPtr renderPart);

		// Token: 0x06000A9E RID: 2718
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern bool ovrAvatarSkinnedMeshRenderPBSV2_MaterialStateChanged(IntPtr renderPart);

		// Token: 0x06000A9F RID: 2719
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern ovrAvatarVisibilityFlags ovrAvatarSkinnedMeshRenderPBS_GetVisibilityMask(IntPtr renderPart);

		// Token: 0x06000AA0 RID: 2720
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern ovrAvatarVisibilityFlags ovrAvatarSkinnedMeshRenderPBSV2_GetVisibilityMask(IntPtr renderPart);

		// Token: 0x06000AA1 RID: 2721
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern ovrAvatarMaterialState ovrAvatarSkinnedMeshRender_GetMaterialState(IntPtr renderPart);

		// Token: 0x06000AA2 RID: 2722
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern ovrAvatarPBSMaterialState ovrAvatarSkinnedMeshRenderPBSV2_GetPBSMaterialState(IntPtr renderPart);

		// Token: 0x06000AA3 RID: 2723
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern ovrAvatarExpressiveParameters ovrAvatar_GetExpressiveParameters(IntPtr avatar);

		// Token: 0x06000AA4 RID: 2724
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern ulong ovrAvatarSkinnedMeshRender_GetDirtyJoints(IntPtr renderPart);

		// Token: 0x06000AA5 RID: 2725
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern ulong ovrAvatarSkinnedMeshRenderPBS_GetDirtyJoints(IntPtr renderPart);

		// Token: 0x06000AA6 RID: 2726
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern ulong ovrAvatarSkinnedMeshRenderPBSV2_GetDirtyJoints(IntPtr renderPart);

		// Token: 0x06000AA7 RID: 2727
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern ovrAvatarTransform ovrAvatarSkinnedMeshRender_GetJointTransform(IntPtr renderPart, uint jointIndex);

		// Token: 0x06000AA8 RID: 2728
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_SetActionUnitOnsetSpeed(IntPtr avatar, float onsetSpeed);

		// Token: 0x06000AA9 RID: 2729
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_SetActionUnitFalloffSpeed(IntPtr avatar, float falloffSpeed);

		// Token: 0x06000AAA RID: 2730
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_SetVisemeMultiplier(IntPtr avatar, float visemeMultiplier);

		// Token: 0x06000AAB RID: 2731
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern ovrAvatarTransform ovrAvatarSkinnedMeshRenderPBS_GetJointTransform(IntPtr renderPart, uint jointIndex);

		// Token: 0x06000AAC RID: 2732
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern ovrAvatarTransform ovrAvatarSkinnedMeshRenderPBSV2_GetJointTransform(IntPtr renderPart, uint jointIndex);

		// Token: 0x06000AAD RID: 2733
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern ulong ovrAvatarSkinnedMeshRenderPBS_GetAlbedoTextureAssetID(IntPtr renderPart);

		// Token: 0x06000AAE RID: 2734
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern ulong ovrAvatarSkinnedMeshRenderPBS_GetSurfaceTextureAssetID(IntPtr renderPart);

		// Token: 0x06000AAF RID: 2735 RVA: 0x0003F7C2 File Offset: 0x0003D9C2
		public static ovrAvatarRenderPart_SkinnedMeshRenderPBS ovrAvatarRenderPart_GetSkinnedMeshRenderPBS(IntPtr renderPart)
		{
			return (ovrAvatarRenderPart_SkinnedMeshRenderPBS)Marshal.PtrToStructure(CAPI.ovrAvatarRenderPart_GetSkinnedMeshRenderPBS_Native(renderPart), typeof(ovrAvatarRenderPart_SkinnedMeshRenderPBS));
		}

		// Token: 0x06000AB0 RID: 2736
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatarRenderPart_GetSkinnedMeshRenderPBS")]
		private static extern IntPtr ovrAvatarRenderPart_GetSkinnedMeshRenderPBS_Native(IntPtr renderPart);

		// Token: 0x06000AB1 RID: 2737 RVA: 0x0003F7DE File Offset: 0x0003D9DE
		public static ovrAvatarRenderPart_SkinnedMeshRenderPBS_V2 ovrAvatarRenderPart_GetSkinnedMeshRenderPBSV2(IntPtr renderPart)
		{
			return (ovrAvatarRenderPart_SkinnedMeshRenderPBS_V2)Marshal.PtrToStructure(CAPI.ovrAvatarRenderPart_GetSkinnedMeshRenderPBSV2_Native(renderPart), typeof(ovrAvatarRenderPart_SkinnedMeshRenderPBS_V2));
		}

		// Token: 0x06000AB2 RID: 2738
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatarRenderPart_GetSkinnedMeshRenderPBSV2")]
		private static extern IntPtr ovrAvatarRenderPart_GetSkinnedMeshRenderPBSV2_Native(IntPtr renderPart);

		// Token: 0x06000AB3 RID: 2739 RVA: 0x0003F7FC File Offset: 0x0003D9FC
		public static void ovrAvatarSkinnedMeshRender_GetBlendShapeParams(IntPtr renderPart, ref ovrAvatarBlendShapeParams blendParams)
		{
			IntPtr ptr = CAPI.ovrAvatarSkinnedMeshRender_GetBlendShapeParams_Native(renderPart);
			blendParams.blendShapeParamCount = (uint)Marshal.ReadInt32(ptr);
			Marshal.Copy(new IntPtr(ptr.ToInt64() + ovrAvatarBlendShapeParams_Offsets.blendShapeParams), blendParams.blendShapeParams, 0, (int)blendParams.blendShapeParamCount);
		}

		// Token: 0x06000AB4 RID: 2740
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatarSkinnedMeshRender_GetBlendShapeParams")]
		private static extern IntPtr ovrAvatarSkinnedMeshRender_GetBlendShapeParams_Native(IntPtr renderPart);

		// Token: 0x06000AB5 RID: 2741 RVA: 0x0003F840 File Offset: 0x0003DA40
		public static ovrAvatarRenderPart_ProjectorRender ovrAvatarRenderPart_GetProjectorRender(IntPtr renderPart)
		{
			return (ovrAvatarRenderPart_ProjectorRender)Marshal.PtrToStructure(CAPI.ovrAvatarRenderPart_GetProjectorRender_Native(renderPart), typeof(ovrAvatarRenderPart_ProjectorRender));
		}

		// Token: 0x06000AB6 RID: 2742 RVA: 0x0003F85C File Offset: 0x0003DA5C
		public static ovrAvatarPBSMaterialState[] ovrAvatar_GetBodyPBSMaterialStates(IntPtr renderPart)
		{
			IntPtr intPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(uint)));
			IntPtr intPtr2 = CAPI.ovrAvatar_GetBodyPBSMaterialStates_Native(renderPart, intPtr);
			ovrAvatarPBSMaterialState[] array = new ovrAvatarPBSMaterialState[Marshal.ReadInt32(intPtr)];
			for (int i = 0; i < array.Length; i++)
			{
				IntPtr ptr = new IntPtr(intPtr2.ToInt64() + (long)(i * Marshal.SizeOf(typeof(ovrAvatarPBSMaterialState))));
				array[i] = (ovrAvatarPBSMaterialState)Marshal.PtrToStructure(ptr, typeof(ovrAvatarPBSMaterialState));
			}
			Marshal.FreeHGlobal(intPtr);
			return array;
		}

		// Token: 0x06000AB7 RID: 2743
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatar_GetBodyPBSMaterialStates")]
		private static extern IntPtr ovrAvatar_GetBodyPBSMaterialStates_Native(IntPtr avatar, IntPtr count);

		// Token: 0x06000AB8 RID: 2744
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatarRenderPart_GetProjectorRender")]
		private static extern IntPtr ovrAvatarRenderPart_GetProjectorRender_Native(IntPtr renderPart);

		// Token: 0x06000AB9 RID: 2745
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern uint ovrAvatar_GetReferencedAssetCount(IntPtr avatar);

		// Token: 0x06000ABA RID: 2746
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern ulong ovrAvatar_GetReferencedAsset(IntPtr avatar, uint index);

		// Token: 0x06000ABB RID: 2747
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_SetLeftHandGesture(IntPtr avatar, ovrAvatarHandGesture gesture);

		// Token: 0x06000ABC RID: 2748
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_SetRightHandGesture(IntPtr avatar, ovrAvatarHandGesture gesture);

		// Token: 0x06000ABD RID: 2749
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_SetLeftHandCustomGesture(IntPtr avatar, uint jointCount, [In] ovrAvatarTransform[] customJointTransforms);

		// Token: 0x06000ABE RID: 2750
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_SetRightHandCustomGesture(IntPtr avatar, uint jointCount, [In] ovrAvatarTransform[] customJointTransforms);

		// Token: 0x06000ABF RID: 2751
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_UpdatePoseFromPacket(IntPtr avatar, IntPtr packet, float secondsFromStart);

		// Token: 0x06000AC0 RID: 2752
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatarPacket_BeginRecording(IntPtr avatar);

		// Token: 0x06000AC1 RID: 2753
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr ovrAvatarPacket_EndRecording(IntPtr avatar);

		// Token: 0x06000AC2 RID: 2754
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern uint ovrAvatarPacket_GetSize(IntPtr packet);

		// Token: 0x06000AC3 RID: 2755
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern float ovrAvatarPacket_GetDurationSeconds(IntPtr packet);

		// Token: 0x06000AC4 RID: 2756
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatarPacket_Free(IntPtr packet);

		// Token: 0x06000AC5 RID: 2757
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern bool ovrAvatarPacket_Write(IntPtr packet, uint bufferSize, [Out] byte[] buffer);

		// Token: 0x06000AC6 RID: 2758
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr ovrAvatarPacket_Read(uint bufferSize, [In] byte[] buffer);

		// Token: 0x06000AC7 RID: 2759
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		private static extern void ovrAvatar_SetInternalForceASTCTextures(bool value);

		// Token: 0x06000AC8 RID: 2760 RVA: 0x0003F8E5 File Offset: 0x0003DAE5
		public static void ovrAvatar_SetForceASTCTextures(bool value)
		{
			CAPI.ovrAvatar_SetInternalForceASTCTextures(value);
		}

		// Token: 0x06000AC9 RID: 2761 RVA: 0x0003F8F0 File Offset: 0x0003DAF0
		public static void ovrAvatar_OverrideExpressiveLogic(IntPtr avatar, ovrAvatarBlendShapeParams blendParams)
		{
			IntPtr intPtr = Marshal.AllocHGlobal(Marshal.SizeOf(typeof(ovrAvatarBlendShapeParams)));
			Marshal.StructureToPtr<ovrAvatarBlendShapeParams>(blendParams, intPtr, false);
			CAPI.ovrAvatar_OverrideExpressiveLogic_Native(avatar, intPtr);
			Marshal.FreeHGlobal(intPtr);
		}

		// Token: 0x06000ACA RID: 2762
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatar_OverrideExpressiveLogic")]
		private static extern void ovrAvatar_OverrideExpressiveLogic_Native(IntPtr avatar, IntPtr state);

		// Token: 0x06000ACB RID: 2763 RVA: 0x0003F928 File Offset: 0x0003DB28
		public static void ovrAvatar_SetVisemes(IntPtr avatar, ovrAvatarVisemes visemes)
		{
			Marshal.WriteInt32(CAPI.nativeVisemeData, (int)visemes.visemeParamCount);
			Marshal.Copy(visemes.visemeParams, 0, new IntPtr(CAPI.nativeVisemeData.ToInt64() + ovrAvatarVisemes_Offsets.visemeParams), (int)visemes.visemeParamCount);
			CAPI.ovrAvatar_SetVisemes_Native(avatar, CAPI.nativeVisemeData);
		}

		// Token: 0x06000ACC RID: 2764
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatar_SetVisemes")]
		private static extern void ovrAvatar_SetVisemes_Native(IntPtr avatar, IntPtr visemes);

		// Token: 0x06000ACD RID: 2765
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_UpdateWorldTransform(IntPtr avatar, ovrAvatarTransform transform);

		// Token: 0x06000ACE RID: 2766 RVA: 0x0003F978 File Offset: 0x0003DB78
		public static void ovrAvatar_UpdateGazeTargets(ovrAvatarGazeTargets targets)
		{
			Marshal.WriteInt32(CAPI.nativeGazeTargetsData, (int)targets.targetCount);
			long targets2 = ovrAvatarGazeTargets_Offsets.targets;
			for (uint num = 0U; num < targets.targetCount; num += 1U)
			{
				long num2 = targets2 + (long)((ulong)num * (ulong)((long)Marshal.SizeOf(typeof(ovrAvatarGazeTarget))));
				Marshal.WriteInt32(new IntPtr(CAPI.nativeGazeTargetsData.ToInt64() + num2 + (long)ovrAvatarGazeTarget_Offsets.id), (int)targets.targets[(int)num].id);
				CAPI.scratchBufferFloat[0] = targets.targets[(int)num].worldPosition.x;
				CAPI.scratchBufferFloat[1] = targets.targets[(int)num].worldPosition.y;
				CAPI.scratchBufferFloat[2] = targets.targets[(int)num].worldPosition.z;
				Marshal.Copy(CAPI.scratchBufferFloat, 0, new IntPtr(CAPI.nativeGazeTargetsData.ToInt64() + num2 + (long)ovrAvatarGazeTarget_Offsets.worldPosition), 3);
				Marshal.WriteInt32(new IntPtr(CAPI.nativeGazeTargetsData.ToInt64() + num2 + (long)ovrAvatarGazeTarget_Offsets.type), (int)targets.targets[(int)num].type);
			}
			CAPI.ovrAvatar_UpdateGazeTargets_Native(CAPI.nativeGazeTargetsData);
		}

		// Token: 0x06000ACF RID: 2767
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatar_UpdateGazeTargets")]
		private static extern void ovrAvatar_UpdateGazeTargets_Native(IntPtr targets);

		// Token: 0x06000AD0 RID: 2768
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_RemoveGazeTargets(uint targetCount, uint[] ids);

		// Token: 0x06000AD1 RID: 2769 RVA: 0x0003FAAC File Offset: 0x0003DCAC
		public static void ovrAvatar_UpdateLights(ovrAvatarLights lights)
		{
			CAPI.scratchBufferFloat[0] = lights.ambientIntensity;
			Marshal.Copy(CAPI.scratchBufferFloat, 0, CAPI.nativeAvatarLightsData, 1);
			Marshal.WriteInt32(new IntPtr(CAPI.nativeAvatarLightsData.ToInt64() + Marshal.OffsetOf(typeof(ovrAvatarLights), "lightCount").ToInt64()), (int)lights.lightCount);
			long num = Marshal.OffsetOf(typeof(ovrAvatarLights), "lights").ToInt64();
			for (uint num2 = 0U; num2 < lights.lightCount; num2 += 1U)
			{
				long num3 = num + (long)((ulong)num2 * (ulong)((long)Marshal.SizeOf(typeof(ovrAvatarLight))));
				Marshal.WriteInt32(new IntPtr(CAPI.nativeAvatarLightsData.ToInt64() + num3 + Marshal.OffsetOf(typeof(ovrAvatarLight), "id").ToInt64()), (int)lights.lights[(int)num2].id);
				Marshal.WriteInt32(new IntPtr(CAPI.nativeAvatarLightsData.ToInt64() + num3 + Marshal.OffsetOf(typeof(ovrAvatarLight), "type").ToInt64()), (int)lights.lights[(int)num2].type);
				CAPI.scratchBufferFloat[0] = lights.lights[(int)num2].intensity;
				Marshal.Copy(CAPI.scratchBufferFloat, 0, new IntPtr(CAPI.nativeAvatarLightsData.ToInt64() + num3 + Marshal.OffsetOf(typeof(ovrAvatarLight), "intensity").ToInt64()), 1);
				CAPI.scratchBufferFloat[0] = lights.lights[(int)num2].worldDirection.x;
				CAPI.scratchBufferFloat[1] = lights.lights[(int)num2].worldDirection.y;
				CAPI.scratchBufferFloat[2] = lights.lights[(int)num2].worldDirection.z;
				Marshal.Copy(CAPI.scratchBufferFloat, 0, new IntPtr(CAPI.nativeAvatarLightsData.ToInt64() + num3 + Marshal.OffsetOf(typeof(ovrAvatarLight), "worldDirection").ToInt64()), 3);
				CAPI.scratchBufferFloat[0] = lights.lights[(int)num2].worldPosition.x;
				CAPI.scratchBufferFloat[1] = lights.lights[(int)num2].worldPosition.y;
				CAPI.scratchBufferFloat[2] = lights.lights[(int)num2].worldPosition.z;
				Marshal.Copy(CAPI.scratchBufferFloat, 0, new IntPtr(CAPI.nativeAvatarLightsData.ToInt64() + num3 + Marshal.OffsetOf(typeof(ovrAvatarLight), "worldPosition").ToInt64()), 3);
				CAPI.scratchBufferFloat[0] = lights.lights[(int)num2].range;
				Marshal.Copy(CAPI.scratchBufferFloat, 0, new IntPtr(CAPI.nativeAvatarLightsData.ToInt64() + num3 + Marshal.OffsetOf(typeof(ovrAvatarLight), "range").ToInt64()), 1);
				CAPI.scratchBufferFloat[0] = lights.lights[(int)num2].spotAngleDeg;
				Marshal.Copy(CAPI.scratchBufferFloat, 0, new IntPtr(CAPI.nativeAvatarLightsData.ToInt64() + num3 + Marshal.OffsetOf(typeof(ovrAvatarLight), "spotAngleDeg").ToInt64()), 1);
			}
			CAPI.ovrAvatar_UpdateLights_Native(CAPI.nativeAvatarLightsData);
		}

		// Token: 0x06000AD2 RID: 2770
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatar_UpdateLights")]
		private static extern void ovrAvatar_UpdateLights_Native(IntPtr lights);

		// Token: 0x06000AD3 RID: 2771
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_RemoveLights(uint lightCount, uint[] ids);

		// Token: 0x06000AD4 RID: 2772 RVA: 0x0003FE02 File Offset: 0x0003E002
		[MonoPInvokeCallback(typeof(CAPI.LoggingDelegate))]
		public static void LoggingCallback(IntPtr str)
		{
			Marshal.PtrToStringAnsi(str);
		}

		// Token: 0x06000AD5 RID: 2773
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_RegisterLoggingCallback(CAPI.LoggingDelegate callback);

		// Token: 0x06000AD6 RID: 2774
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_SetLoggingLevel(ovrAvatarLogLevel level);

		// Token: 0x06000AD7 RID: 2775
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatar_GetDebugTransforms")]
		public static extern IntPtr ovrAvatar_GetDebugTransforms_Native(IntPtr count);

		// Token: 0x06000AD8 RID: 2776
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrAvatar_GetDebugLines")]
		public static extern IntPtr ovrAvatar_GetDebugLines_Native(IntPtr count);

		// Token: 0x06000AD9 RID: 2777 RVA: 0x0003FE0C File Offset: 0x0003E00C
		public static void ovrAvatar_DrawDebugLines()
		{
			IntPtr intPtr = CAPI.ovrAvatar_GetDebugLines_Native(CAPI.DebugLineCountData);
			int num = Marshal.ReadInt32(CAPI.DebugLineCountData);
			ovrAvatarDebugLine ovrAvatarDebugLine = default(ovrAvatarDebugLine);
			for (int i = 0; i < num; i++)
			{
				int num2 = i * Marshal.SizeOf(typeof(ovrAvatarDebugLine));
				Marshal.Copy(new IntPtr(intPtr.ToInt64() + (long)num2), CAPI.scratchBufferFloat, 0, 9);
				ovrAvatarDebugLine.startPoint.x = CAPI.scratchBufferFloat[0];
				ovrAvatarDebugLine.startPoint.y = CAPI.scratchBufferFloat[1];
				ovrAvatarDebugLine.startPoint.z = -CAPI.scratchBufferFloat[2];
				ovrAvatarDebugLine.endPoint.x = CAPI.scratchBufferFloat[3];
				ovrAvatarDebugLine.endPoint.y = CAPI.scratchBufferFloat[4];
				ovrAvatarDebugLine.endPoint.z = -CAPI.scratchBufferFloat[5];
				ovrAvatarDebugLine.color.x = CAPI.scratchBufferFloat[6];
				ovrAvatarDebugLine.color.y = CAPI.scratchBufferFloat[7];
				ovrAvatarDebugLine.color.z = CAPI.scratchBufferFloat[8];
				ovrAvatarDebugLine.context = (ovrAvatarDebugContext)Marshal.ReadInt32(new IntPtr(intPtr.ToInt64() + (long)num2 + Marshal.OffsetOf(typeof(ovrAvatarDebugLine), "context").ToInt64()));
				ovrAvatarDebugLine.text = Marshal.ReadIntPtr(new IntPtr(intPtr.ToInt64() + (long)num2 + Marshal.OffsetOf(typeof(ovrAvatarDebugLine), "text").ToInt64()));
				Debug.DrawLine(ovrAvatarDebugLine.startPoint, ovrAvatarDebugLine.endPoint, new Color(ovrAvatarDebugLine.color.x, ovrAvatarDebugLine.color.y, ovrAvatarDebugLine.color.z));
			}
			intPtr = CAPI.ovrAvatar_GetDebugTransforms_Native(CAPI.DebugLineCountData);
			num = Marshal.ReadInt32(CAPI.DebugLineCountData);
			ovrAvatarDebugTransform ovrAvatarDebugTransform = default(ovrAvatarDebugTransform);
			for (int j = 0; j < num; j++)
			{
				int num3 = j * Marshal.SizeOf(typeof(ovrAvatarDebugTransform));
				Marshal.Copy(new IntPtr(intPtr.ToInt64() + (long)num3), CAPI.scratchBufferFloat, 0, 10);
				OvrAvatar.ConvertTransform(CAPI.scratchBufferFloat, ref ovrAvatarDebugTransform.transform);
				OvrAvatar.ConvertTransform(ovrAvatarDebugTransform.transform, CAPI.debugLineGo.transform);
				ovrAvatarDebugTransform.context = (ovrAvatarDebugContext)Marshal.ReadInt32(new IntPtr(intPtr.ToInt64() + (long)num3 + Marshal.OffsetOf(typeof(ovrAvatarDebugTransform), "context").ToInt64()));
				ovrAvatarDebugTransform.text = Marshal.ReadIntPtr(new IntPtr(intPtr.ToInt64() + (long)num3 + Marshal.OffsetOf(typeof(ovrAvatarDebugTransform), "text").ToInt64()));
				Vector3 b = 0.1f * CAPI.debugLineGo.transform.TransformVector(Vector3.up);
				Vector3 b2 = 0.1f * CAPI.debugLineGo.transform.TransformVector(Vector3.right);
				Vector3 b3 = 0.1f * CAPI.debugLineGo.transform.TransformVector(Vector3.forward);
				Debug.DrawLine(CAPI.debugLineGo.transform.position, CAPI.debugLineGo.transform.position + b, Color.green);
				Debug.DrawLine(CAPI.debugLineGo.transform.position, CAPI.debugLineGo.transform.position + b2, Color.red);
				Debug.DrawLine(CAPI.debugLineGo.transform.position, CAPI.debugLineGo.transform.position + b3, Color.blue);
			}
		}

		// Token: 0x06000ADA RID: 2778
		[DllImport("ovravatarloader", CallingConvention = CallingConvention.Cdecl)]
		public static extern void ovrAvatar_SetDebugDrawContext(uint context);

		// Token: 0x06000ADB RID: 2779 RVA: 0x000401C4 File Offset: 0x0003E3C4
		public static bool SendEvent(string name, string param = "", string source = "")
		{
			bool result;
			try
			{
				if (CAPI.ovrPluginVersion == null)
				{
					string text = CAPI.ovrp_GetVersion();
					if (!string.IsNullOrEmpty(text))
					{
						CAPI.ovrPluginVersion = new Version(text.Split(new char[]
						{
							'-'
						})[0]);
					}
					else
					{
						CAPI.ovrPluginVersion = new Version(0, 0, 0);
					}
				}
				if (CAPI.ovrPluginVersion >= CAPI.OVRP_1_30_0.version)
				{
					result = (CAPI.OVRP_1_30_0.ovrp_SendEvent2(name, param, (source.Length == 0) ? "avatar_sdk" : source) == CAPI.Result.Success);
				}
				else
				{
					result = false;
				}
			}
			catch (Exception)
			{
				result = false;
			}
			return result;
		}

		// Token: 0x06000ADC RID: 2780
		[DllImport("OVRPlugin", CallingConvention = CallingConvention.Cdecl, EntryPoint = "ovrp_GetVersion")]
		private static extern IntPtr _ovrp_GetVersion();

		// Token: 0x06000ADD RID: 2781 RVA: 0x00040260 File Offset: 0x0003E460
		public static string ovrp_GetVersion()
		{
			return Marshal.PtrToStringAnsi(CAPI._ovrp_GetVersion());
		}

		// Token: 0x04000C1A RID: 3098
		private const string LibFile = "ovravatarloader";

		// Token: 0x04000C1B RID: 3099
		private static IntPtr nativeVisemeData = IntPtr.Zero;

		// Token: 0x04000C1C RID: 3100
		private static IntPtr nativeGazeTargetsData = IntPtr.Zero;

		// Token: 0x04000C1D RID: 3101
		private static IntPtr nativeAvatarLightsData = IntPtr.Zero;

		// Token: 0x04000C1E RID: 3102
		private static IntPtr DebugLineCountData = IntPtr.Zero;

		// Token: 0x04000C1F RID: 3103
		private static float[] scratchBufferFloat = new float[16];

		// Token: 0x04000C20 RID: 3104
		private static GameObject debugLineGo;

		// Token: 0x04000C21 RID: 3105
		private static string SDKRuntimePrefix = "[RUNTIME] - ";

		// Token: 0x04000C22 RID: 3106
		private const string ovrPluginDLL = "OVRPlugin";

		// Token: 0x04000C23 RID: 3107
		private static Version ovrPluginVersion;

		// Token: 0x0200024E RID: 590
		// (Invoke) Token: 0x06000D8D RID: 3469
		public delegate void LoggingDelegate(IntPtr str);

		// Token: 0x0200024F RID: 591
		public enum Result
		{
			// Token: 0x04001013 RID: 4115
			Success,
			// Token: 0x04001014 RID: 4116
			Failure = -1000,
			// Token: 0x04001015 RID: 4117
			Failure_InvalidParameter = -1001,
			// Token: 0x04001016 RID: 4118
			Failure_NotInitialized = -1002,
			// Token: 0x04001017 RID: 4119
			Failure_InvalidOperation = -1003,
			// Token: 0x04001018 RID: 4120
			Failure_Unsupported = -1004,
			// Token: 0x04001019 RID: 4121
			Failure_NotYetImplemented = -1005,
			// Token: 0x0400101A RID: 4122
			Failure_OperationFailed = -1006,
			// Token: 0x0400101B RID: 4123
			Failure_InsufficientSize = -1007
		}

		// Token: 0x02000250 RID: 592
		private static class OVRP_1_30_0
		{
			// Token: 0x06000D90 RID: 3472
			[DllImport("OVRPlugin", CallingConvention = CallingConvention.Cdecl)]
			public static extern CAPI.Result ovrp_SendEvent2(string name, string param, string source);

			// Token: 0x0400101C RID: 4124
			public static readonly Version version = new Version(1, 30, 0);
		}
	}
}
