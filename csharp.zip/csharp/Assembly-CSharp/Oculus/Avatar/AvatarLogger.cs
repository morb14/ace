﻿using System;
using System.Diagnostics;
using UnityEngine;

namespace Oculus.Avatar
{
	// Token: 0x02000182 RID: 386
	public static class AvatarLogger
	{
		// Token: 0x06000A4B RID: 2635 RVA: 0x0003F1B8 File Offset: 0x0003D3B8
		[Conditional("ENABLE_AVATAR_LOGS")]
		[Conditional("ENABLE_AVATAR_LOG_BASIC")]
		public static void Log(string logMsg)
		{
			Debug.Log("[Avatars] - " + logMsg);
		}

		// Token: 0x06000A4C RID: 2636 RVA: 0x0003F1CA File Offset: 0x0003D3CA
		[Conditional("ENABLE_AVATAR_LOGS")]
		[Conditional("ENABLE_AVATAR_LOG_BASIC")]
		public static void Log(string logMsg, Object context)
		{
			Debug.Log("[Avatars] - " + logMsg, context);
		}

		// Token: 0x06000A4D RID: 2637 RVA: 0x0003F1DD File Offset: 0x0003D3DD
		[Conditional("ENABLE_AVATAR_LOGS")]
		[Conditional("ENABLE_AVATAR_LOG_WARNING")]
		public static void LogWarning(string logMsg)
		{
			Debug.LogWarning("[Avatars] - " + logMsg);
		}

		// Token: 0x06000A4E RID: 2638 RVA: 0x0003F1EF File Offset: 0x0003D3EF
		[Conditional("ENABLE_AVATAR_LOGS")]
		[Conditional("ENABLE_AVATAR_LOG_ERROR")]
		public static void LogError(string logMsg)
		{
			Debug.LogError("[Avatars] - " + logMsg);
		}

		// Token: 0x06000A4F RID: 2639 RVA: 0x0003F201 File Offset: 0x0003D401
		[Conditional("ENABLE_AVATAR_LOGS")]
		[Conditional("ENABLE_AVATAR_LOG_ERROR")]
		public static void LogError(string logMsg, Object context)
		{
			Debug.LogError("[Avatars] - " + logMsg, context);
		}

		// Token: 0x04000C18 RID: 3096
		public const string LogAvatar = "[Avatars] - ";

		// Token: 0x04000C19 RID: 3097
		public const string Tab = "    ";
	}
}
