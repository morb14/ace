﻿using System;
using UnityEngine;

// Token: 0x02000019 RID: 25
public class WFX_Demo_Wall : MonoBehaviour
{
	// Token: 0x0600007B RID: 123 RVA: 0x00004E18 File Offset: 0x00003018
	private void OnMouseDown()
	{
		RaycastHit raycastHit = default(RaycastHit);
		if (base.GetComponent<Collider>().Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out raycastHit, 9999f))
		{
			GameObject gameObject = this.demo.spawnParticle();
			gameObject.transform.position = raycastHit.point;
			gameObject.transform.rotation = Quaternion.FromToRotation(Vector3.forward, raycastHit.normal);
		}
	}

	// Token: 0x04000084 RID: 132
	public WFX_Demo_New demo;
}
