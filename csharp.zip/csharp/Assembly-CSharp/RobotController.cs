﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

// Token: 0x0200004C RID: 76
[RequireComponent(typeof(Animator))]
public class RobotController : MonoBehaviour
{
	// Token: 0x06000268 RID: 616 RVA: 0x0000E0CB File Offset: 0x0000C2CB
	private void Start()
	{
		this.hitCount = 0;
		this.animator = base.GetComponent<Animator>();
		this.agent = base.GetComponent<NavMeshAgent>();
		this.InitiateDestinations();
		this.ChangeDestination();
	}

	// Token: 0x06000269 RID: 617 RVA: 0x0000E0F8 File Offset: 0x0000C2F8
	private void InitiateDestinations()
	{
		this.robotStatus = RobotController.Status.Roam;
		foreach (Transform transform in this.pathObject.GetComponentsInChildren<Transform>())
		{
			if (transform.gameObject != this.pathObject)
			{
				this.destinations.Add(transform.position);
			}
		}
	}

	// Token: 0x0600026A RID: 618 RVA: 0x0000E14E File Offset: 0x0000C34E
	private void Update()
	{
		this.MovementChecker();
	}

	// Token: 0x0600026B RID: 619 RVA: 0x0000E158 File Offset: 0x0000C358
	private void MovementChecker()
	{
		if (this.robotStatus == RobotController.Status.Roam)
		{
			this.agent.speed = this.roamSpeed;
		}
		else if (this.robotStatus == RobotController.Status.Panic)
		{
			this.agent.speed = this.panicSpeed;
			if (Time.time > this.timeSincePanic + this.panicTimeChange)
			{
				this.timeSincePanic = Time.time;
				this.ChangeDestination();
			}
		}
		else if (this.robotStatus == RobotController.Status.Charge)
		{
			this.agent.speed = this.chargeSpeed;
		}
		if (Vector3.Distance(base.transform.position, this.currentDestination) <= this.waypointThreshold)
		{
			this.ChangeDestination();
		}
	}

	// Token: 0x0600026C RID: 620 RVA: 0x0000E200 File Offset: 0x0000C400
	private void ChangeDestination()
	{
		if (this.robotStatus == RobotController.Status.Charge)
		{
			this.currentDestination = new Vector3(0f, 0f, 0f);
		}
		else
		{
			this.currentDestination = this.destinations[Random.Range(0, this.destinations.Count - 1)];
		}
		this.agent.destination = this.currentDestination;
	}

	// Token: 0x0600026D RID: 621 RVA: 0x0000E268 File Offset: 0x0000C468
	public void TargetHit(RobotController.RobotHitZone hitZone, float energy)
	{
		if (this.resetCoolDown)
		{
			return;
		}
		switch (hitZone)
		{
		case RobotController.RobotHitZone.Head:
			this.hitCount += 5;
			break;
		case RobotController.RobotHitZone.Spine:
			this.hitCount += Random.Range(3, 7);
			break;
		case RobotController.RobotHitZone.Body:
			this.hitCount++;
			break;
		}
		if (Random.Range(0, 2) == 0 && this.robotStatus != RobotController.Status.Charge)
		{
			this.robotStatus = RobotController.Status.Panic;
			this.timeSincePanic = Time.time;
		}
		else
		{
			this.robotStatus = RobotController.Status.Charge;
		}
		if (this.hitCount >= 5)
		{
			this.resetCoolDown = true;
			this.robotStatus = RobotController.Status.Dead;
			this.animator.SetTrigger("Hit");
			base.Invoke("ResetAnimation", this.resetTime);
			this.agent.isStopped = true;
		}
	}

	// Token: 0x0600026E RID: 622 RVA: 0x0000E337 File Offset: 0x0000C537
	private void ResetAnimation()
	{
		this.animator.SetTrigger("Reset");
	}

	// Token: 0x0600026F RID: 623 RVA: 0x0000E349 File Offset: 0x0000C549
	private void Reset()
	{
		this.agent.isStopped = false;
		this.resetCoolDown = false;
		this.charging = false;
		this.robotStatus = RobotController.Status.Roam;
		this.ChangeDestination();
		this.hitCount = 0;
	}

	// Token: 0x04000272 RID: 626
	[SerializeField]
	private GameObject pathObject;

	// Token: 0x04000273 RID: 627
	[SerializeField]
	private float resetTime = 2f;

	// Token: 0x04000274 RID: 628
	[SerializeField]
	private float waypointThreshold = 1f;

	// Token: 0x04000275 RID: 629
	[SerializeField]
	private float roamSpeed = 2f;

	// Token: 0x04000276 RID: 630
	[SerializeField]
	private float panicSpeed = 3f;

	// Token: 0x04000277 RID: 631
	[SerializeField]
	private float chargeSpeed = 3f;

	// Token: 0x04000278 RID: 632
	[SerializeField]
	private float panicTimeChange = 1f;

	// Token: 0x04000279 RID: 633
	public RobotController.Status robotStatus;

	// Token: 0x0400027A RID: 634
	private Animator animator;

	// Token: 0x0400027B RID: 635
	private NavMeshAgent agent;

	// Token: 0x0400027C RID: 636
	public List<Vector3> destinations = new List<Vector3>();

	// Token: 0x0400027D RID: 637
	private Vector3 currentDestination;

	// Token: 0x0400027E RID: 638
	private bool resetCoolDown;

	// Token: 0x0400027F RID: 639
	private bool onTheWay;

	// Token: 0x04000280 RID: 640
	private bool charging;

	// Token: 0x04000281 RID: 641
	private bool panicBegin;

	// Token: 0x04000282 RID: 642
	private int hitCount;

	// Token: 0x04000283 RID: 643
	private float timeSincePanic;

	// Token: 0x020001BA RID: 442
	public enum RobotHitZone
	{
		// Token: 0x04000D4C RID: 3404
		Head,
		// Token: 0x04000D4D RID: 3405
		Spine,
		// Token: 0x04000D4E RID: 3406
		Body
	}

	// Token: 0x020001BB RID: 443
	public enum Status
	{
		// Token: 0x04000D50 RID: 3408
		Roam,
		// Token: 0x04000D51 RID: 3409
		Panic,
		// Token: 0x04000D52 RID: 3410
		Charge,
		// Token: 0x04000D53 RID: 3411
		Dead
	}
}
