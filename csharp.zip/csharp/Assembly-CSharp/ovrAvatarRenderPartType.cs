﻿using System;

// Token: 0x020000C7 RID: 199
public enum ovrAvatarRenderPartType
{
	// Token: 0x040007B6 RID: 1974
	SkinnedMeshRender,
	// Token: 0x040007B7 RID: 1975
	SkinnedMeshRenderPBS,
	// Token: 0x040007B8 RID: 1976
	ProjectorRender,
	// Token: 0x040007B9 RID: 1977
	SkinnedMeshRenderPBS_V2,
	// Token: 0x040007BA RID: 1978
	Count
}
