﻿using System;

// Token: 0x020000D0 RID: 208
public struct ovrAvatarBodyComponent
{
	// Token: 0x040007E7 RID: 2023
	public ovrAvatarTransform leftEyeTransform;

	// Token: 0x040007E8 RID: 2024
	public ovrAvatarTransform rightEyeTransform;

	// Token: 0x040007E9 RID: 2025
	public ovrAvatarTransform centerEyeTransform;

	// Token: 0x040007EA RID: 2026
	public IntPtr renderComponent;
}
