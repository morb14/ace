﻿using System;
using UnityEngine;

// Token: 0x02000090 RID: 144
public class Test : MonoBehaviour
{
	// Token: 0x060004F3 RID: 1267 RVA: 0x00003297 File Offset: 0x00001497
	private void Start()
	{
	}

	// Token: 0x060004F4 RID: 1268 RVA: 0x00003297 File Offset: 0x00001497
	private void Update()
	{
	}
}
