﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x02000123 RID: 291
public abstract class TeleportOrientationHandler : TeleportSupport
{
	// Token: 0x06000791 RID: 1937 RVA: 0x0002F09C File Offset: 0x0002D29C
	protected TeleportOrientationHandler()
	{
		this._updateOrientationAction = delegate()
		{
			base.StartCoroutine(this.UpdateOrientationCoroutine());
		};
		this._updateAimDataAction = new Action<LocomotionTeleport.AimData>(this.UpdateAimData);
	}

	// Token: 0x06000792 RID: 1938 RVA: 0x0002F0C8 File Offset: 0x0002D2C8
	private void UpdateAimData(LocomotionTeleport.AimData aimData)
	{
		this.AimData = aimData;
	}

	// Token: 0x06000793 RID: 1939 RVA: 0x0002F0D1 File Offset: 0x0002D2D1
	protected override void AddEventHandlers()
	{
		base.AddEventHandlers();
		base.LocomotionTeleport.EnterStateAim += this._updateOrientationAction;
		base.LocomotionTeleport.UpdateAimData += this._updateAimDataAction;
	}

	// Token: 0x06000794 RID: 1940 RVA: 0x0002F0FB File Offset: 0x0002D2FB
	protected override void RemoveEventHandlers()
	{
		base.RemoveEventHandlers();
		base.LocomotionTeleport.EnterStateAim -= this._updateOrientationAction;
		base.LocomotionTeleport.UpdateAimData -= this._updateAimDataAction;
	}

	// Token: 0x06000795 RID: 1941 RVA: 0x0002F125 File Offset: 0x0002D325
	private IEnumerator UpdateOrientationCoroutine()
	{
		this.InitializeTeleportDestination();
		while (base.LocomotionTeleport.CurrentState == LocomotionTeleport.States.Aim || base.LocomotionTeleport.CurrentState == LocomotionTeleport.States.PreTeleport)
		{
			if (this.AimData != null)
			{
				this.UpdateTeleportDestination();
			}
			yield return null;
		}
		yield break;
	}

	// Token: 0x06000796 RID: 1942
	protected abstract void InitializeTeleportDestination();

	// Token: 0x06000797 RID: 1943
	protected abstract void UpdateTeleportDestination();

	// Token: 0x06000798 RID: 1944 RVA: 0x0002F134 File Offset: 0x0002D334
	protected Quaternion GetLandingOrientation(TeleportOrientationHandler.OrientationModes mode, Quaternion rotation)
	{
		if (mode != TeleportOrientationHandler.OrientationModes.HeadRelative)
		{
			return rotation * Quaternion.Euler(0f, -base.LocomotionTeleport.LocomotionController.CameraRig.trackingSpace.localEulerAngles.y, 0f);
		}
		return rotation;
	}

	// Token: 0x040009B1 RID: 2481
	private readonly Action _updateOrientationAction;

	// Token: 0x040009B2 RID: 2482
	private readonly Action<LocomotionTeleport.AimData> _updateAimDataAction;

	// Token: 0x040009B3 RID: 2483
	protected LocomotionTeleport.AimData AimData;

	// Token: 0x0200021C RID: 540
	public enum OrientationModes
	{
		// Token: 0x04000F11 RID: 3857
		HeadRelative,
		// Token: 0x04000F12 RID: 3858
		ForwardFacing
	}
}
