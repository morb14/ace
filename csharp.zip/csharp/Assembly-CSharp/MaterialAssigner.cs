﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200003C RID: 60
public class MaterialAssigner : MonoBehaviour
{
	// Token: 0x06000201 RID: 513 RVA: 0x0000B28B File Offset: 0x0000948B
	private void Awake()
	{
		this.grabbable = base.GetComponent<OVRGrabbable>();
		if (this.renderersList == null)
		{
			this.renderersList = new List<Renderer>();
		}
		this.DelayedMaterialAssign();
	}

	// Token: 0x06000202 RID: 514 RVA: 0x0000B2B4 File Offset: 0x000094B4
	private void DelayedMaterialAssign()
	{
		if (this.renderersList.Count <= 0)
		{
			foreach (Renderer renderer in base.GetComponentsInChildren<Renderer>())
			{
				this.renderersList.Add(renderer);
				this.meshRenMat.Add(renderer, renderer.sharedMaterials);
			}
		}
	}

	// Token: 0x06000203 RID: 515 RVA: 0x0000B306 File Offset: 0x00009506
	private void Update()
	{
		if (this.testSwap)
		{
			this.SwitchMaterial(true, null);
		}
		if (this.swapBack)
		{
			this.SwitchMaterial(false, null);
			this.testSwap = false;
			this.swapBack = false;
		}
	}

	// Token: 0x06000204 RID: 516 RVA: 0x0000B338 File Offset: 0x00009538
	public void SwitchSpecificMaterials()
	{
		MonoBehaviour.print("MATERIAL COLOUR 3");
		if (this.colorIndex < this.colorHex.Length - 1)
		{
			this.colorIndex++;
		}
		else
		{
			this.colorIndex = 0;
		}
		Color value;
		ColorUtility.TryParseHtmlString("#" + this.colorHex[this.colorIndex], out value);
		if (this.specificRenderers.Length != 0)
		{
			foreach (Renderer renderer in this.specificRenderers)
			{
				if (renderer.materials.Length > 1)
				{
					foreach (Material material in renderer.materials)
					{
						MonoBehaviour.print(material.name + "  " + this.materialToChangeColor.name);
						if (material.name.Contains(this.materialToChangeColor.name))
						{
							material.SetColor("_BaseColor", value);
						}
					}
				}
				else
				{
					renderer.material.SetColor("_BaseColor", value);
				}
				if (this.meshRenMat.ContainsKey(renderer))
				{
					this.meshRenMat[renderer] = renderer.sharedMaterials;
				}
			}
		}
	}

	// Token: 0x06000205 RID: 517 RVA: 0x0000B46C File Offset: 0x0000966C
	public void SwitchMaterial(bool status, Material toMaterial = null)
	{
		if (toMaterial == null)
		{
			toMaterial = this.materialOne;
		}
		if (!status)
		{
			foreach (Renderer renderer in this.renderersList)
			{
				if (renderer.materials.Length > 1)
				{
					Material[] materials = renderer.materials;
					for (int i = 0; i < materials.Length; i++)
					{
						materials[i] = toMaterial;
					}
					renderer.materials = materials;
				}
				else
				{
					renderer.material = toMaterial;
				}
			}
			if (this.grabbable != null)
			{
				this.grabbable.isGrabbable = false;
				return;
			}
		}
		else
		{
			foreach (Renderer renderer2 in this.renderersList)
			{
				Material[] materials2;
				this.meshRenMat.TryGetValue(renderer2, out materials2);
				renderer2.materials = materials2;
			}
			if (this.grabbable != null)
			{
				this.grabbable.isGrabbable = true;
			}
		}
	}

	// Token: 0x040001B8 RID: 440
	[SerializeField]
	private Material materialOne;

	// Token: 0x040001B9 RID: 441
	private Material materialTwo;

	// Token: 0x040001BA RID: 442
	public List<Renderer> renderersList;

	// Token: 0x040001BB RID: 443
	[SerializeField]
	private Renderer[] specificRenderers;

	// Token: 0x040001BC RID: 444
	[SerializeField]
	public Material materialToChangeColor;

	// Token: 0x040001BD RID: 445
	[SerializeField]
	private string[] colorHex;

	// Token: 0x040001BE RID: 446
	private OVRGrabbable grabbable;

	// Token: 0x040001BF RID: 447
	public Dictionary<Renderer, Material[]> meshRenMat = new Dictionary<Renderer, Material[]>();

	// Token: 0x040001C0 RID: 448
	public bool testSwap;

	// Token: 0x040001C1 RID: 449
	public bool swapBack;

	// Token: 0x040001C2 RID: 450
	private int colorIndex;
}
