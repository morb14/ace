﻿using System;
using UnityEngine;

// Token: 0x020000CF RID: 207
public struct ovrAvatarBaseComponent
{
	// Token: 0x040007E5 RID: 2021
	public Vector3 basePosition;

	// Token: 0x040007E6 RID: 2022
	public IntPtr renderComponent;
}
