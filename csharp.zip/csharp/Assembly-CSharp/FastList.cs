﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x0200009B RID: 155
public class FastList<T>
{
	// Token: 0x06000529 RID: 1321 RVA: 0x0002137C File Offset: 0x0001F57C
	public FastList()
	{
	}

	// Token: 0x0600052A RID: 1322 RVA: 0x00021384 File Offset: 0x0001F584
	public FastList(int size)
	{
		if (size > 0)
		{
			this.size = 0;
			this.array = new T[size];
			return;
		}
		this.size = 0;
	}

	// Token: 0x17000005 RID: 5
	// (get) Token: 0x0600052B RID: 1323 RVA: 0x000213AB File Offset: 0x0001F5AB
	// (set) Token: 0x0600052C RID: 1324 RVA: 0x00003297 File Offset: 0x00001497
	public int Count
	{
		get
		{
			return this.size;
		}
		set
		{
		}
	}

	// Token: 0x17000006 RID: 6
	public T this[int i]
	{
		get
		{
			return this.array[i];
		}
		set
		{
			this.array[i] = value;
		}
	}

	// Token: 0x0600052F RID: 1327 RVA: 0x000213D0 File Offset: 0x0001F5D0
	public void Add(T item)
	{
		if (this.array == null || this.size == this.array.Length)
		{
			this.Allocate();
		}
		this.array[this.size] = item;
		this.size++;
	}

	// Token: 0x06000530 RID: 1328 RVA: 0x00021410 File Offset: 0x0001F610
	public void AddUnique(T item)
	{
		if (this.array == null || this.size == this.array.Length)
		{
			this.Allocate();
		}
		if (!this.Contains(item))
		{
			this.array[this.size] = item;
			this.size++;
		}
	}

	// Token: 0x06000531 RID: 1329 RVA: 0x00021464 File Offset: 0x0001F664
	public void AddRange(IEnumerable<T> items)
	{
		foreach (T item in items)
		{
			this.Add(item);
		}
	}

	// Token: 0x06000532 RID: 1330 RVA: 0x000214AC File Offset: 0x0001F6AC
	public void Insert(int index, T item)
	{
		if (this.array == null || this.size == this.array.Length)
		{
			this.Allocate();
		}
		if (index < this.size)
		{
			for (int i = this.size; i > index; i--)
			{
				this.array[i] = this.array[i - 1];
			}
			this.array[index] = item;
			this.size++;
			return;
		}
		this.Add(item);
	}

	// Token: 0x06000533 RID: 1331 RVA: 0x00021530 File Offset: 0x0001F730
	public bool Remove(T item)
	{
		if (this.array != null)
		{
			for (int i = 0; i < this.size; i++)
			{
				if (item.Equals(this.array[i]))
				{
					this.size--;
					for (int j = i; j < this.size; j++)
					{
						this.array[j] = this.array[j + 1];
					}
					this.array[this.size] = default(T);
					return true;
				}
			}
		}
		return false;
	}

	// Token: 0x06000534 RID: 1332 RVA: 0x000215D4 File Offset: 0x0001F7D4
	public void RemoveAt(int index)
	{
		if (this.array != null && this.size > 0 && index < this.size)
		{
			this.size--;
			for (int i = index; i < this.size; i++)
			{
				this.array[i] = this.array[i + 1];
			}
			this.array[this.size] = default(T);
		}
	}

	// Token: 0x06000535 RID: 1333 RVA: 0x00021650 File Offset: 0x0001F850
	public bool RemoveFast(T item)
	{
		if (this.array != null)
		{
			for (int i = 0; i < this.size; i++)
			{
				if (item.Equals(this.array[i]))
				{
					if (i < this.size - 1)
					{
						T t = this.array[this.size - 1];
						this.array[this.size - 1] = default(T);
						this.array[i] = t;
					}
					else
					{
						this.array[i] = default(T);
					}
					this.size--;
					return true;
				}
			}
		}
		return false;
	}

	// Token: 0x06000536 RID: 1334 RVA: 0x00021710 File Offset: 0x0001F910
	public void RemoveAtFast(int index)
	{
		if (this.array != null && index < this.size && index >= 0)
		{
			if (index == this.size - 1)
			{
				this.array[index] = default(T);
			}
			else
			{
				T t = this.array[this.size - 1];
				this.array[index] = t;
				this.array[this.size - 1] = default(T);
			}
			this.size--;
		}
	}

	// Token: 0x06000537 RID: 1335 RVA: 0x000217A0 File Offset: 0x0001F9A0
	public bool Contains(T item)
	{
		if (this.array == null || this.size <= 0)
		{
			return false;
		}
		for (int i = 0; i < this.size; i++)
		{
			if (this.array[i].Equals(item))
			{
				return true;
			}
		}
		return false;
	}

	// Token: 0x06000538 RID: 1336 RVA: 0x000217F8 File Offset: 0x0001F9F8
	public int IndexOf(T item)
	{
		if (this.size <= 0 || this.array == null)
		{
			return -1;
		}
		for (int i = 0; i < this.size; i++)
		{
			if (item.Equals(this.array[i]))
			{
				return i;
			}
		}
		return -1;
	}

	// Token: 0x06000539 RID: 1337 RVA: 0x0002184C File Offset: 0x0001FA4C
	public T Pop()
	{
		if (this.array != null && this.size > 0)
		{
			T result = this.array[this.size - 1];
			this.array[this.size - 1] = default(T);
			this.size--;
			return result;
		}
		return default(T);
	}

	// Token: 0x0600053A RID: 1338 RVA: 0x000218B1 File Offset: 0x0001FAB1
	public T[] ToArray()
	{
		this.Trim();
		return this.array;
	}

	// Token: 0x0600053B RID: 1339 RVA: 0x000218C0 File Offset: 0x0001FAC0
	public void Sort(FastList<T>.CompareFunc comparer)
	{
		int num = 0;
		int num2 = this.size - 1;
		bool flag = true;
		while (flag)
		{
			flag = false;
			for (int i = num; i < num2; i++)
			{
				if (comparer(this.array[i], this.array[i + 1]) > 0)
				{
					T t = this.array[i];
					this.array[i] = this.array[i + 1];
					this.array[i + 1] = t;
					flag = true;
				}
				else if (!flag)
				{
					num = ((i == 0) ? 0 : (i - 1));
				}
			}
		}
	}

	// Token: 0x0600053C RID: 1340 RVA: 0x0002195C File Offset: 0x0001FB5C
	public void InsertionSort(FastList<T>.CompareFunc comparer)
	{
		for (int i = 1; i < this.size; i++)
		{
			T t = this.array[i];
			int num = i;
			while (num > 0 && comparer(this.array[num - 1], t) > 0)
			{
				this.array[num] = this.array[num - 1];
				num--;
			}
			this.array[num] = t;
		}
	}

	// Token: 0x0600053D RID: 1341 RVA: 0x000219D2 File Offset: 0x0001FBD2
	public IEnumerator<T> GetEnumerator()
	{
		if (this.array != null)
		{
			int num;
			for (int i = 0; i < this.size; i = num + 1)
			{
				yield return this.array[i];
				num = i;
			}
		}
		yield break;
	}

	// Token: 0x0600053E RID: 1342 RVA: 0x000219E4 File Offset: 0x0001FBE4
	public T Find(Predicate<T> match)
	{
		if (match != null && this.array != null)
		{
			for (int i = 0; i < this.size; i++)
			{
				if (match(this.array[i]))
				{
					return this.array[i];
				}
			}
		}
		return default(T);
	}

	// Token: 0x0600053F RID: 1343 RVA: 0x00021A38 File Offset: 0x0001FC38
	private void Allocate()
	{
		T[] array;
		if (this.array == null)
		{
			array = new T[32];
		}
		else
		{
			array = new T[Mathf.Max(this.array.Length << 1, 32)];
		}
		if (this.array != null && this.size > 0)
		{
			this.array.CopyTo(array, 0);
		}
		this.array = array;
	}

	// Token: 0x06000540 RID: 1344 RVA: 0x00021A94 File Offset: 0x0001FC94
	private void Trim()
	{
		if (this.size > 0)
		{
			T[] array = new T[this.size];
			for (int i = 0; i < this.size; i++)
			{
				array[i] = this.array[i];
			}
			this.array = array;
			return;
		}
		this.array = null;
	}

	// Token: 0x06000541 RID: 1345 RVA: 0x00021AE9 File Offset: 0x0001FCE9
	public void Clear()
	{
		this.size = 0;
	}

	// Token: 0x06000542 RID: 1346 RVA: 0x00021AF2 File Offset: 0x0001FCF2
	public void Release()
	{
		this.Clear();
		this.array = null;
	}

	// Token: 0x04000669 RID: 1641
	public T[] array;

	// Token: 0x0400066A RID: 1642
	public int size;

	// Token: 0x020001E2 RID: 482
	// (Invoke) Token: 0x06000C26 RID: 3110
	public delegate int CompareFunc(T left, T right);
}
