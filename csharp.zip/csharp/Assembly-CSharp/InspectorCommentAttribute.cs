﻿using System;
using UnityEngine;

// Token: 0x0200009D RID: 157
public class InspectorCommentAttribute : PropertyAttribute
{
	// Token: 0x06000544 RID: 1348 RVA: 0x00021B17 File Offset: 0x0001FD17
	public InspectorCommentAttribute(string message = "")
	{
		this.message = message;
	}

	// Token: 0x0400066D RID: 1645
	public readonly string message;
}
