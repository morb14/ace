﻿using System;
using System.Runtime.InteropServices;

// Token: 0x020000F3 RID: 243
public struct ovrAvatarLights
{
	// Token: 0x04000894 RID: 2196
	public float ambientIntensity;

	// Token: 0x04000895 RID: 2197
	public uint lightCount;

	// Token: 0x04000896 RID: 2198
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 16)]
	public ovrAvatarLight[] lights;
}
