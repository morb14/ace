﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000067 RID: 103
public class TestBreak90 : MonoBehaviour
{
	// Token: 0x060003C8 RID: 968 RVA: 0x000192AC File Offset: 0x000174AC
	private void Start()
	{
		base.Invoke("VariableSetup", 0.5f);
	}

	// Token: 0x060003C9 RID: 969 RVA: 0x000192BE File Offset: 0x000174BE
	private void VariableSetup()
	{
		this.sceneSettings = Object.FindObjectOfType<SceneSettings>();
		this.weaponController = Object.FindObjectOfType<WeaponController>();
		this.setupDone = true;
	}

	// Token: 0x060003CA RID: 970 RVA: 0x000192E0 File Offset: 0x000174E0
	private void Update()
	{
		if (this.setupDone)
		{
			float num = TestBreak90.WrapAngle(this.weaponController.transform.eulerAngles.y) - TestBreak90.WrapAngle(this.sceneSettings.downRange.eulerAngles.y);
			if (num < -90f || num > 90f)
			{
				this.textMeshPro.text = "BROKE 90";
				return;
			}
			this.textMeshPro.text = num.ToString("F0") + "\n";
			TMP_Text tmp_Text = this.textMeshPro;
			tmp_Text.text += "okay";
		}
	}

	// Token: 0x060003CB RID: 971 RVA: 0x00011988 File Offset: 0x0000FB88
	private static float WrapAngle(float angle)
	{
		angle %= 360f;
		if (angle > 180f)
		{
			return angle - 360f;
		}
		return angle;
	}

	// Token: 0x060003CC RID: 972 RVA: 0x0001938B File Offset: 0x0001758B
	private static float UnwrapAngle(float angle)
	{
		if (angle >= 0f)
		{
			return angle;
		}
		angle = -angle % 360f;
		return 360f - angle;
	}

	// Token: 0x040004B0 RID: 1200
	private SceneSettings sceneSettings;

	// Token: 0x040004B1 RID: 1201
	private WeaponController weaponController;

	// Token: 0x040004B2 RID: 1202
	[SerializeField]
	private TMP_Text textMeshPro;

	// Token: 0x040004B3 RID: 1203
	private bool setupDone;
}
