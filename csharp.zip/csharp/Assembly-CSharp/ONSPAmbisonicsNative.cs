﻿using System;
using UnityEngine;

// Token: 0x0200013F RID: 319
public class ONSPAmbisonicsNative : MonoBehaviour
{
	// Token: 0x1700002A RID: 42
	// (get) Token: 0x06000846 RID: 2118 RVA: 0x00034209 File Offset: 0x00032409
	// (set) Token: 0x06000847 RID: 2119 RVA: 0x00034211 File Offset: 0x00032411
	public bool UseVirtualSpeakers
	{
		get
		{
			return this.useVirtualSpeakers;
		}
		set
		{
			this.useVirtualSpeakers = value;
		}
	}

	// Token: 0x06000848 RID: 2120 RVA: 0x0003421C File Offset: 0x0003241C
	private void OnEnable()
	{
		AudioSource component = base.GetComponent<AudioSource>();
		this.currentStatus = ONSPAmbisonicsNative.ovrAmbisonicsNativeStatus.Uninitialized;
		if (component == null)
		{
			Debug.Log("Ambisonic ERROR: AudioSource does not exist.");
			return;
		}
		if (component.spatialize)
		{
			Debug.Log("Ambisonic WARNING: Turning spatialize field off for Ambisonic sources.");
			component.spatialize = false;
		}
		if (component.clip == null)
		{
			Debug.Log("Ambisonic ERROR: AudioSource does not contain an audio clip.");
			return;
		}
		if (component.clip.channels != ONSPAmbisonicsNative.numFOAChannels)
		{
			Debug.Log("Ambisonic ERROR: AudioSource clip does not have correct number of channels.");
		}
	}

	// Token: 0x06000849 RID: 2121 RVA: 0x0003429C File Offset: 0x0003249C
	private void Update()
	{
		AudioSource component = base.GetComponent<AudioSource>();
		if (component == null)
		{
			return;
		}
		if (this.useVirtualSpeakers)
		{
			component.SetAmbisonicDecoderFloat(ONSPAmbisonicsNative.paramVSpeakerMode, 1f);
		}
		else
		{
			component.SetAmbisonicDecoderFloat(ONSPAmbisonicsNative.paramVSpeakerMode, 0f);
		}
		float num = 0f;
		component.GetAmbisonicDecoderFloat(ONSPAmbisonicsNative.paramAmbiStat, out num);
		ONSPAmbisonicsNative.ovrAmbisonicsNativeStatus ovrAmbisonicsNativeStatus = (ONSPAmbisonicsNative.ovrAmbisonicsNativeStatus)num;
		if (ovrAmbisonicsNativeStatus != this.currentStatus)
		{
			switch (ovrAmbisonicsNativeStatus)
			{
			case ONSPAmbisonicsNative.ovrAmbisonicsNativeStatus.Uninitialized:
				Debug.Log("Ambisonic Native: Stream uninitialized");
				break;
			case ONSPAmbisonicsNative.ovrAmbisonicsNativeStatus.NotEnabled:
				Debug.Log("Ambisonic Native: Ambisonic not enabled on clip. Check clip field and turn it on");
				break;
			case ONSPAmbisonicsNative.ovrAmbisonicsNativeStatus.Success:
				Debug.Log("Ambisonic Native: Stream successfully initialized and playing/playable");
				break;
			case ONSPAmbisonicsNative.ovrAmbisonicsNativeStatus.StreamError:
				Debug.Log("Ambisonic Native WARNING: Stream error (bad input format?)");
				break;
			case ONSPAmbisonicsNative.ovrAmbisonicsNativeStatus.ProcessError:
				Debug.Log("Ambisonic Native WARNING: Stream process error (check default speaker setup)");
				break;
			}
		}
		this.currentStatus = ovrAmbisonicsNativeStatus;
	}

	// Token: 0x04000A54 RID: 2644
	private static int numFOAChannels = 4;

	// Token: 0x04000A55 RID: 2645
	private static int paramVSpeakerMode = 6;

	// Token: 0x04000A56 RID: 2646
	private static int paramAmbiStat = 7;

	// Token: 0x04000A57 RID: 2647
	private ONSPAmbisonicsNative.ovrAmbisonicsNativeStatus currentStatus = ONSPAmbisonicsNative.ovrAmbisonicsNativeStatus.Uninitialized;

	// Token: 0x04000A58 RID: 2648
	[SerializeField]
	private bool useVirtualSpeakers;

	// Token: 0x0200022C RID: 556
	public enum ovrAmbisonicsNativeStatus
	{
		// Token: 0x04000F56 RID: 3926
		Uninitialized = -1,
		// Token: 0x04000F57 RID: 3927
		NotEnabled,
		// Token: 0x04000F58 RID: 3928
		Success,
		// Token: 0x04000F59 RID: 3929
		StreamError,
		// Token: 0x04000F5A RID: 3930
		ProcessError,
		// Token: 0x04000F5B RID: 3931
		MaxStatValue
	}
}
