﻿using System;
using System.Collections.Generic;
using System.Linq;
using Oculus.Spatializer.Propagation;
using UnityEngine;

// Token: 0x02000144 RID: 324
public sealed class ONSPPropagationMaterial : MonoBehaviour
{
	// Token: 0x17000036 RID: 54
	// (get) Token: 0x06000880 RID: 2176 RVA: 0x000357D0 File Offset: 0x000339D0
	// (set) Token: 0x06000881 RID: 2177 RVA: 0x000357D8 File Offset: 0x000339D8
	public ONSPPropagationMaterial.Preset preset
	{
		get
		{
			return this.preset_;
		}
		set
		{
			this.SetPreset(value);
			this.preset_ = value;
		}
	}

	// Token: 0x06000882 RID: 2178 RVA: 0x000357E8 File Offset: 0x000339E8
	private void Start()
	{
		this.StartInternal();
	}

	// Token: 0x06000883 RID: 2179 RVA: 0x000357F0 File Offset: 0x000339F0
	public void StartInternal()
	{
		if (this.materialHandle != IntPtr.Zero)
		{
			return;
		}
		if (ONSPPropagation.Interface.CreateAudioMaterial(out this.materialHandle) != ONSPPropagationGeometry.OSPSuccess)
		{
			throw new Exception("Unable to create internal audio material");
		}
		this.UploadMaterial();
	}

	// Token: 0x06000884 RID: 2180 RVA: 0x0003582D File Offset: 0x00033A2D
	private void OnDestroy()
	{
		this.DestroyInternal();
	}

	// Token: 0x06000885 RID: 2181 RVA: 0x00035835 File Offset: 0x00033A35
	public void DestroyInternal()
	{
		if (this.materialHandle != IntPtr.Zero)
		{
			ONSPPropagation.Interface.DestroyAudioMaterial(this.materialHandle);
			this.materialHandle = IntPtr.Zero;
		}
	}

	// Token: 0x06000886 RID: 2182 RVA: 0x00035868 File Offset: 0x00033A68
	public void UploadMaterial()
	{
		if (this.materialHandle == IntPtr.Zero)
		{
			return;
		}
		ONSPPropagation.Interface.AudioMaterialReset(this.materialHandle, MaterialProperty.ABSORPTION);
		foreach (ONSPPropagationMaterial.Point point in this.absorption.points)
		{
			ONSPPropagation.Interface.AudioMaterialSetFrequency(this.materialHandle, MaterialProperty.ABSORPTION, point.frequency, point.data);
		}
		ONSPPropagation.Interface.AudioMaterialReset(this.materialHandle, MaterialProperty.TRANSMISSION);
		foreach (ONSPPropagationMaterial.Point point2 in this.transmission.points)
		{
			ONSPPropagation.Interface.AudioMaterialSetFrequency(this.materialHandle, MaterialProperty.TRANSMISSION, point2.frequency, point2.data);
		}
		ONSPPropagation.Interface.AudioMaterialReset(this.materialHandle, MaterialProperty.SCATTERING);
		foreach (ONSPPropagationMaterial.Point point3 in this.scattering.points)
		{
			ONSPPropagation.Interface.AudioMaterialSetFrequency(this.materialHandle, MaterialProperty.SCATTERING, point3.frequency, point3.data);
		}
	}

	// Token: 0x06000887 RID: 2183 RVA: 0x000359DC File Offset: 0x00033BDC
	public void SetPreset(ONSPPropagationMaterial.Preset preset)
	{
		ONSPPropagationMaterial onsppropagationMaterial = this;
		switch (preset)
		{
		case ONSPPropagationMaterial.Preset.Custom:
			break;
		case ONSPPropagationMaterial.Preset.AcousticTile:
			ONSPPropagationMaterial.AcousticTile(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.Brick:
			ONSPPropagationMaterial.Brick(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.BrickPainted:
			ONSPPropagationMaterial.BrickPainted(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.Carpet:
			ONSPPropagationMaterial.Carpet(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.CarpetHeavy:
			ONSPPropagationMaterial.CarpetHeavy(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.CarpetHeavyPadded:
			ONSPPropagationMaterial.CarpetHeavyPadded(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.CeramicTile:
			ONSPPropagationMaterial.CeramicTile(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.Concrete:
			ONSPPropagationMaterial.Concrete(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.ConcreteRough:
			ONSPPropagationMaterial.ConcreteRough(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.ConcreteBlock:
			ONSPPropagationMaterial.ConcreteBlock(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.ConcreteBlockPainted:
			ONSPPropagationMaterial.ConcreteBlockPainted(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.Curtain:
			ONSPPropagationMaterial.Curtain(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.Foliage:
			ONSPPropagationMaterial.Foliage(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.Glass:
			ONSPPropagationMaterial.Glass(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.GlassHeavy:
			ONSPPropagationMaterial.GlassHeavy(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.Grass:
			ONSPPropagationMaterial.Grass(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.Gravel:
			ONSPPropagationMaterial.Gravel(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.GypsumBoard:
			ONSPPropagationMaterial.GypsumBoard(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.PlasterOnBrick:
			ONSPPropagationMaterial.PlasterOnBrick(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.PlasterOnConcreteBlock:
			ONSPPropagationMaterial.PlasterOnConcreteBlock(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.Soil:
			ONSPPropagationMaterial.Soil(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.SoundProof:
			ONSPPropagationMaterial.SoundProof(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.Snow:
			ONSPPropagationMaterial.Snow(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.Steel:
			ONSPPropagationMaterial.Steel(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.Water:
			ONSPPropagationMaterial.Water(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.WoodThin:
			ONSPPropagationMaterial.WoodThin(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.WoodThick:
			ONSPPropagationMaterial.WoodThick(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.WoodFloor:
			ONSPPropagationMaterial.WoodFloor(ref onsppropagationMaterial);
			return;
		case ONSPPropagationMaterial.Preset.WoodOnConcrete:
			ONSPPropagationMaterial.WoodOnConcrete(ref onsppropagationMaterial);
			break;
		default:
			return;
		}
	}

	// Token: 0x06000888 RID: 2184 RVA: 0x00035B54 File Offset: 0x00033D54
	private static void AcousticTile(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.5f),
			new ONSPPropagationMaterial.Point(250f, 0.7f),
			new ONSPPropagationMaterial.Point(500f, 0.6f),
			new ONSPPropagationMaterial.Point(1000f, 0.7f),
			new ONSPPropagationMaterial.Point(2000f, 0.7f),
			new ONSPPropagationMaterial.Point(4000f, 0.5f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.1f),
			new ONSPPropagationMaterial.Point(250f, 0.15f),
			new ONSPPropagationMaterial.Point(500f, 0.2f),
			new ONSPPropagationMaterial.Point(1000f, 0.2f),
			new ONSPPropagationMaterial.Point(2000f, 0.25f),
			new ONSPPropagationMaterial.Point(4000f, 0.3f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.05f),
			new ONSPPropagationMaterial.Point(250f, 0.04f),
			new ONSPPropagationMaterial.Point(500f, 0.03f),
			new ONSPPropagationMaterial.Point(1000f, 0.02f),
			new ONSPPropagationMaterial.Point(2000f, 0.005f),
			new ONSPPropagationMaterial.Point(4000f, 0.002f)
		};
	}

	// Token: 0x06000889 RID: 2185 RVA: 0x00035D10 File Offset: 0x00033F10
	private static void Brick(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.02f),
			new ONSPPropagationMaterial.Point(250f, 0.02f),
			new ONSPPropagationMaterial.Point(500f, 0.03f),
			new ONSPPropagationMaterial.Point(1000f, 0.04f),
			new ONSPPropagationMaterial.Point(2000f, 0.05f),
			new ONSPPropagationMaterial.Point(4000f, 0.07f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.2f),
			new ONSPPropagationMaterial.Point(250f, 0.25f),
			new ONSPPropagationMaterial.Point(500f, 0.3f),
			new ONSPPropagationMaterial.Point(1000f, 0.35f),
			new ONSPPropagationMaterial.Point(2000f, 0.4f),
			new ONSPPropagationMaterial.Point(4000f, 0.45f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.025f),
			new ONSPPropagationMaterial.Point(250f, 0.019f),
			new ONSPPropagationMaterial.Point(500f, 0.01f),
			new ONSPPropagationMaterial.Point(1000f, 0.0045f),
			new ONSPPropagationMaterial.Point(2000f, 0.0018f),
			new ONSPPropagationMaterial.Point(4000f, 0.00089f)
		};
	}

	// Token: 0x0600088A RID: 2186 RVA: 0x00035ECC File Offset: 0x000340CC
	private static void BrickPainted(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.01f),
			new ONSPPropagationMaterial.Point(250f, 0.01f),
			new ONSPPropagationMaterial.Point(500f, 0.02f),
			new ONSPPropagationMaterial.Point(1000f, 0.02f),
			new ONSPPropagationMaterial.Point(2000f, 0.02f),
			new ONSPPropagationMaterial.Point(4000f, 0.03f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.15f),
			new ONSPPropagationMaterial.Point(250f, 0.15f),
			new ONSPPropagationMaterial.Point(500f, 0.2f),
			new ONSPPropagationMaterial.Point(1000f, 0.2f),
			new ONSPPropagationMaterial.Point(2000f, 0.2f),
			new ONSPPropagationMaterial.Point(4000f, 0.25f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.025f),
			new ONSPPropagationMaterial.Point(250f, 0.019f),
			new ONSPPropagationMaterial.Point(500f, 0.01f),
			new ONSPPropagationMaterial.Point(1000f, 0.0045f),
			new ONSPPropagationMaterial.Point(2000f, 0.0018f),
			new ONSPPropagationMaterial.Point(4000f, 0.00089f)
		};
	}

	// Token: 0x0600088B RID: 2187 RVA: 0x00036088 File Offset: 0x00034288
	private static void Carpet(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.01f),
			new ONSPPropagationMaterial.Point(250f, 0.05f),
			new ONSPPropagationMaterial.Point(500f, 0.1f),
			new ONSPPropagationMaterial.Point(1000f, 0.2f),
			new ONSPPropagationMaterial.Point(2000f, 0.45f),
			new ONSPPropagationMaterial.Point(4000f, 0.65f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.1f),
			new ONSPPropagationMaterial.Point(250f, 0.1f),
			new ONSPPropagationMaterial.Point(500f, 0.15f),
			new ONSPPropagationMaterial.Point(1000f, 0.2f),
			new ONSPPropagationMaterial.Point(2000f, 0.3f),
			new ONSPPropagationMaterial.Point(4000f, 0.45f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.004f),
			new ONSPPropagationMaterial.Point(250f, 0.0079f),
			new ONSPPropagationMaterial.Point(500f, 0.0056f),
			new ONSPPropagationMaterial.Point(1000f, 0.0016f),
			new ONSPPropagationMaterial.Point(2000f, 0.0014f),
			new ONSPPropagationMaterial.Point(4000f, 0.0005f)
		};
	}

	// Token: 0x0600088C RID: 2188 RVA: 0x00036244 File Offset: 0x00034444
	private static void CarpetHeavy(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.02f),
			new ONSPPropagationMaterial.Point(250f, 0.06f),
			new ONSPPropagationMaterial.Point(500f, 0.14f),
			new ONSPPropagationMaterial.Point(1000f, 0.37f),
			new ONSPPropagationMaterial.Point(2000f, 0.48f),
			new ONSPPropagationMaterial.Point(4000f, 0.63f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.1f),
			new ONSPPropagationMaterial.Point(250f, 0.15f),
			new ONSPPropagationMaterial.Point(500f, 0.2f),
			new ONSPPropagationMaterial.Point(1000f, 0.25f),
			new ONSPPropagationMaterial.Point(2000f, 0.35f),
			new ONSPPropagationMaterial.Point(4000f, 0.5f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.004f),
			new ONSPPropagationMaterial.Point(250f, 0.0079f),
			new ONSPPropagationMaterial.Point(500f, 0.0056f),
			new ONSPPropagationMaterial.Point(1000f, 0.0016f),
			new ONSPPropagationMaterial.Point(2000f, 0.0014f),
			new ONSPPropagationMaterial.Point(4000f, 0.0005f)
		};
	}

	// Token: 0x0600088D RID: 2189 RVA: 0x00036400 File Offset: 0x00034600
	private static void CarpetHeavyPadded(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.08f),
			new ONSPPropagationMaterial.Point(250f, 0.24f),
			new ONSPPropagationMaterial.Point(500f, 0.57f),
			new ONSPPropagationMaterial.Point(1000f, 0.69f),
			new ONSPPropagationMaterial.Point(2000f, 0.71f),
			new ONSPPropagationMaterial.Point(4000f, 0.73f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.1f),
			new ONSPPropagationMaterial.Point(250f, 0.15f),
			new ONSPPropagationMaterial.Point(500f, 0.2f),
			new ONSPPropagationMaterial.Point(1000f, 0.25f),
			new ONSPPropagationMaterial.Point(2000f, 0.35f),
			new ONSPPropagationMaterial.Point(4000f, 0.5f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.004f),
			new ONSPPropagationMaterial.Point(250f, 0.0079f),
			new ONSPPropagationMaterial.Point(500f, 0.0056f),
			new ONSPPropagationMaterial.Point(1000f, 0.0016f),
			new ONSPPropagationMaterial.Point(2000f, 0.0014f),
			new ONSPPropagationMaterial.Point(4000f, 0.0005f)
		};
	}

	// Token: 0x0600088E RID: 2190 RVA: 0x000365BC File Offset: 0x000347BC
	private static void CeramicTile(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.01f),
			new ONSPPropagationMaterial.Point(250f, 0.01f),
			new ONSPPropagationMaterial.Point(500f, 0.01f),
			new ONSPPropagationMaterial.Point(1000f, 0.01f),
			new ONSPPropagationMaterial.Point(2000f, 0.02f),
			new ONSPPropagationMaterial.Point(4000f, 0.02f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.1f),
			new ONSPPropagationMaterial.Point(250f, 0.12f),
			new ONSPPropagationMaterial.Point(500f, 0.14f),
			new ONSPPropagationMaterial.Point(1000f, 0.16f),
			new ONSPPropagationMaterial.Point(2000f, 0.18f),
			new ONSPPropagationMaterial.Point(4000f, 0.2f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.004f),
			new ONSPPropagationMaterial.Point(250f, 0.0079f),
			new ONSPPropagationMaterial.Point(500f, 0.0056f),
			new ONSPPropagationMaterial.Point(1000f, 0.0016f),
			new ONSPPropagationMaterial.Point(2000f, 0.0014f),
			new ONSPPropagationMaterial.Point(4000f, 0.0005f)
		};
	}

	// Token: 0x0600088F RID: 2191 RVA: 0x00036778 File Offset: 0x00034978
	private static void Concrete(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.01f),
			new ONSPPropagationMaterial.Point(250f, 0.01f),
			new ONSPPropagationMaterial.Point(500f, 0.02f),
			new ONSPPropagationMaterial.Point(1000f, 0.02f),
			new ONSPPropagationMaterial.Point(2000f, 0.02f),
			new ONSPPropagationMaterial.Point(4000f, 0.02f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.1f),
			new ONSPPropagationMaterial.Point(250f, 0.11f),
			new ONSPPropagationMaterial.Point(500f, 0.12f),
			new ONSPPropagationMaterial.Point(1000f, 0.13f),
			new ONSPPropagationMaterial.Point(2000f, 0.14f),
			new ONSPPropagationMaterial.Point(4000f, 0.15f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.004f),
			new ONSPPropagationMaterial.Point(250f, 0.0079f),
			new ONSPPropagationMaterial.Point(500f, 0.0056f),
			new ONSPPropagationMaterial.Point(1000f, 0.0016f),
			new ONSPPropagationMaterial.Point(2000f, 0.0014f),
			new ONSPPropagationMaterial.Point(4000f, 0.0005f)
		};
	}

	// Token: 0x06000890 RID: 2192 RVA: 0x00036934 File Offset: 0x00034B34
	private static void ConcreteRough(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.01f),
			new ONSPPropagationMaterial.Point(250f, 0.02f),
			new ONSPPropagationMaterial.Point(500f, 0.04f),
			new ONSPPropagationMaterial.Point(1000f, 0.06f),
			new ONSPPropagationMaterial.Point(2000f, 0.08f),
			new ONSPPropagationMaterial.Point(4000f, 0.1f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.1f),
			new ONSPPropagationMaterial.Point(250f, 0.12f),
			new ONSPPropagationMaterial.Point(500f, 0.15f),
			new ONSPPropagationMaterial.Point(1000f, 0.2f),
			new ONSPPropagationMaterial.Point(2000f, 0.25f),
			new ONSPPropagationMaterial.Point(4000f, 0.3f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.004f),
			new ONSPPropagationMaterial.Point(250f, 0.0079f),
			new ONSPPropagationMaterial.Point(500f, 0.0056f),
			new ONSPPropagationMaterial.Point(1000f, 0.0016f),
			new ONSPPropagationMaterial.Point(2000f, 0.0014f),
			new ONSPPropagationMaterial.Point(4000f, 0.0005f)
		};
	}

	// Token: 0x06000891 RID: 2193 RVA: 0x00036AF0 File Offset: 0x00034CF0
	private static void ConcreteBlock(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.36f),
			new ONSPPropagationMaterial.Point(250f, 0.44f),
			new ONSPPropagationMaterial.Point(500f, 0.31f),
			new ONSPPropagationMaterial.Point(1000f, 0.29f),
			new ONSPPropagationMaterial.Point(2000f, 0.39f),
			new ONSPPropagationMaterial.Point(4000f, 0.21f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.1f),
			new ONSPPropagationMaterial.Point(250f, 0.12f),
			new ONSPPropagationMaterial.Point(500f, 0.15f),
			new ONSPPropagationMaterial.Point(1000f, 0.2f),
			new ONSPPropagationMaterial.Point(2000f, 0.3f),
			new ONSPPropagationMaterial.Point(4000f, 0.4f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.02f),
			new ONSPPropagationMaterial.Point(250f, 0.01f),
			new ONSPPropagationMaterial.Point(500f, 0.0063f),
			new ONSPPropagationMaterial.Point(1000f, 0.0035f),
			new ONSPPropagationMaterial.Point(2000f, 0.00011f),
			new ONSPPropagationMaterial.Point(4000f, 0.00063f)
		};
	}

	// Token: 0x06000892 RID: 2194 RVA: 0x00036CAC File Offset: 0x00034EAC
	private static void ConcreteBlockPainted(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.1f),
			new ONSPPropagationMaterial.Point(250f, 0.05f),
			new ONSPPropagationMaterial.Point(500f, 0.06f),
			new ONSPPropagationMaterial.Point(1000f, 0.07f),
			new ONSPPropagationMaterial.Point(2000f, 0.09f),
			new ONSPPropagationMaterial.Point(4000f, 0.08f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.1f),
			new ONSPPropagationMaterial.Point(250f, 0.11f),
			new ONSPPropagationMaterial.Point(500f, 0.13f),
			new ONSPPropagationMaterial.Point(1000f, 0.15f),
			new ONSPPropagationMaterial.Point(2000f, 0.16f),
			new ONSPPropagationMaterial.Point(4000f, 0.2f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.02f),
			new ONSPPropagationMaterial.Point(250f, 0.01f),
			new ONSPPropagationMaterial.Point(500f, 0.0063f),
			new ONSPPropagationMaterial.Point(1000f, 0.0035f),
			new ONSPPropagationMaterial.Point(2000f, 0.00011f),
			new ONSPPropagationMaterial.Point(4000f, 0.00063f)
		};
	}

	// Token: 0x06000893 RID: 2195 RVA: 0x00036E68 File Offset: 0x00035068
	private static void Curtain(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.07f),
			new ONSPPropagationMaterial.Point(250f, 0.31f),
			new ONSPPropagationMaterial.Point(500f, 0.49f),
			new ONSPPropagationMaterial.Point(1000f, 0.75f),
			new ONSPPropagationMaterial.Point(2000f, 0.7f),
			new ONSPPropagationMaterial.Point(4000f, 0.6f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.1f),
			new ONSPPropagationMaterial.Point(250f, 0.15f),
			new ONSPPropagationMaterial.Point(500f, 0.2f),
			new ONSPPropagationMaterial.Point(1000f, 0.3f),
			new ONSPPropagationMaterial.Point(2000f, 0.4f),
			new ONSPPropagationMaterial.Point(4000f, 0.5f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.42f),
			new ONSPPropagationMaterial.Point(250f, 0.39f),
			new ONSPPropagationMaterial.Point(500f, 0.21f),
			new ONSPPropagationMaterial.Point(1000f, 0.14f),
			new ONSPPropagationMaterial.Point(2000f, 0.079f),
			new ONSPPropagationMaterial.Point(4000f, 0.045f)
		};
	}

	// Token: 0x06000894 RID: 2196 RVA: 0x00037024 File Offset: 0x00035224
	private static void Foliage(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.03f),
			new ONSPPropagationMaterial.Point(250f, 0.06f),
			new ONSPPropagationMaterial.Point(500f, 0.11f),
			new ONSPPropagationMaterial.Point(1000f, 0.17f),
			new ONSPPropagationMaterial.Point(2000f, 0.27f),
			new ONSPPropagationMaterial.Point(4000f, 0.31f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.2f),
			new ONSPPropagationMaterial.Point(250f, 0.3f),
			new ONSPPropagationMaterial.Point(500f, 0.4f),
			new ONSPPropagationMaterial.Point(1000f, 0.5f),
			new ONSPPropagationMaterial.Point(2000f, 0.7f),
			new ONSPPropagationMaterial.Point(4000f, 0.8f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.9f),
			new ONSPPropagationMaterial.Point(250f, 0.9f),
			new ONSPPropagationMaterial.Point(500f, 0.9f),
			new ONSPPropagationMaterial.Point(1000f, 0.8f),
			new ONSPPropagationMaterial.Point(2000f, 0.5f),
			new ONSPPropagationMaterial.Point(4000f, 0.3f)
		};
	}

	// Token: 0x06000895 RID: 2197 RVA: 0x000371E0 File Offset: 0x000353E0
	private static void Glass(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.35f),
			new ONSPPropagationMaterial.Point(250f, 0.25f),
			new ONSPPropagationMaterial.Point(500f, 0.18f),
			new ONSPPropagationMaterial.Point(1000f, 0.12f),
			new ONSPPropagationMaterial.Point(2000f, 0.07f),
			new ONSPPropagationMaterial.Point(4000f, 0.05f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.05f),
			new ONSPPropagationMaterial.Point(250f, 0.05f),
			new ONSPPropagationMaterial.Point(500f, 0.05f),
			new ONSPPropagationMaterial.Point(1000f, 0.05f),
			new ONSPPropagationMaterial.Point(2000f, 0.05f),
			new ONSPPropagationMaterial.Point(4000f, 0.05f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.125f),
			new ONSPPropagationMaterial.Point(250f, 0.089f),
			new ONSPPropagationMaterial.Point(500f, 0.05f),
			new ONSPPropagationMaterial.Point(1000f, 0.028f),
			new ONSPPropagationMaterial.Point(2000f, 0.022f),
			new ONSPPropagationMaterial.Point(4000f, 0.079f)
		};
	}

	// Token: 0x06000896 RID: 2198 RVA: 0x0003739C File Offset: 0x0003559C
	private static void GlassHeavy(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.18f),
			new ONSPPropagationMaterial.Point(250f, 0.06f),
			new ONSPPropagationMaterial.Point(500f, 0.04f),
			new ONSPPropagationMaterial.Point(1000f, 0.03f),
			new ONSPPropagationMaterial.Point(2000f, 0.02f),
			new ONSPPropagationMaterial.Point(4000f, 0.02f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.05f),
			new ONSPPropagationMaterial.Point(250f, 0.05f),
			new ONSPPropagationMaterial.Point(500f, 0.05f),
			new ONSPPropagationMaterial.Point(1000f, 0.05f),
			new ONSPPropagationMaterial.Point(2000f, 0.05f),
			new ONSPPropagationMaterial.Point(4000f, 0.05f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.056f),
			new ONSPPropagationMaterial.Point(250f, 0.039f),
			new ONSPPropagationMaterial.Point(500f, 0.028f),
			new ONSPPropagationMaterial.Point(1000f, 0.02f),
			new ONSPPropagationMaterial.Point(2000f, 0.032f),
			new ONSPPropagationMaterial.Point(4000f, 0.014f)
		};
	}

	// Token: 0x06000897 RID: 2199 RVA: 0x00037558 File Offset: 0x00035758
	private static void Grass(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.11f),
			new ONSPPropagationMaterial.Point(250f, 0.26f),
			new ONSPPropagationMaterial.Point(500f, 0.6f),
			new ONSPPropagationMaterial.Point(1000f, 0.69f),
			new ONSPPropagationMaterial.Point(2000f, 0.92f),
			new ONSPPropagationMaterial.Point(4000f, 0.99f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.3f),
			new ONSPPropagationMaterial.Point(250f, 0.3f),
			new ONSPPropagationMaterial.Point(500f, 0.4f),
			new ONSPPropagationMaterial.Point(1000f, 0.5f),
			new ONSPPropagationMaterial.Point(2000f, 0.6f),
			new ONSPPropagationMaterial.Point(4000f, 0.7f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>();
	}

	// Token: 0x06000898 RID: 2200 RVA: 0x00037694 File Offset: 0x00035894
	private static void Gravel(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.25f),
			new ONSPPropagationMaterial.Point(250f, 0.6f),
			new ONSPPropagationMaterial.Point(500f, 0.65f),
			new ONSPPropagationMaterial.Point(1000f, 0.7f),
			new ONSPPropagationMaterial.Point(2000f, 0.75f),
			new ONSPPropagationMaterial.Point(4000f, 0.8f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.2f),
			new ONSPPropagationMaterial.Point(250f, 0.3f),
			new ONSPPropagationMaterial.Point(500f, 0.4f),
			new ONSPPropagationMaterial.Point(1000f, 0.5f),
			new ONSPPropagationMaterial.Point(2000f, 0.6f),
			new ONSPPropagationMaterial.Point(4000f, 0.7f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>();
	}

	// Token: 0x06000899 RID: 2201 RVA: 0x000377D0 File Offset: 0x000359D0
	private static void GypsumBoard(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.29f),
			new ONSPPropagationMaterial.Point(250f, 0.1f),
			new ONSPPropagationMaterial.Point(500f, 0.05f),
			new ONSPPropagationMaterial.Point(1000f, 0.04f),
			new ONSPPropagationMaterial.Point(2000f, 0.07f),
			new ONSPPropagationMaterial.Point(4000f, 0.09f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.1f),
			new ONSPPropagationMaterial.Point(250f, 0.11f),
			new ONSPPropagationMaterial.Point(500f, 0.12f),
			new ONSPPropagationMaterial.Point(1000f, 0.13f),
			new ONSPPropagationMaterial.Point(2000f, 0.14f),
			new ONSPPropagationMaterial.Point(4000f, 0.15f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.035f),
			new ONSPPropagationMaterial.Point(250f, 0.0125f),
			new ONSPPropagationMaterial.Point(500f, 0.0056f),
			new ONSPPropagationMaterial.Point(1000f, 0.0025f),
			new ONSPPropagationMaterial.Point(2000f, 0.0013f),
			new ONSPPropagationMaterial.Point(4000f, 0.0032f)
		};
	}

	// Token: 0x0600089A RID: 2202 RVA: 0x0003798C File Offset: 0x00035B8C
	private static void PlasterOnBrick(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.01f),
			new ONSPPropagationMaterial.Point(250f, 0.02f),
			new ONSPPropagationMaterial.Point(500f, 0.02f),
			new ONSPPropagationMaterial.Point(1000f, 0.03f),
			new ONSPPropagationMaterial.Point(2000f, 0.04f),
			new ONSPPropagationMaterial.Point(4000f, 0.05f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.2f),
			new ONSPPropagationMaterial.Point(250f, 0.25f),
			new ONSPPropagationMaterial.Point(500f, 0.3f),
			new ONSPPropagationMaterial.Point(1000f, 0.35f),
			new ONSPPropagationMaterial.Point(2000f, 0.4f),
			new ONSPPropagationMaterial.Point(4000f, 0.45f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.025f),
			new ONSPPropagationMaterial.Point(250f, 0.019f),
			new ONSPPropagationMaterial.Point(500f, 0.01f),
			new ONSPPropagationMaterial.Point(1000f, 0.0045f),
			new ONSPPropagationMaterial.Point(2000f, 0.0018f),
			new ONSPPropagationMaterial.Point(4000f, 0.00089f)
		};
	}

	// Token: 0x0600089B RID: 2203 RVA: 0x00037B48 File Offset: 0x00035D48
	private static void PlasterOnConcreteBlock(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.12f),
			new ONSPPropagationMaterial.Point(250f, 0.09f),
			new ONSPPropagationMaterial.Point(500f, 0.07f),
			new ONSPPropagationMaterial.Point(1000f, 0.05f),
			new ONSPPropagationMaterial.Point(2000f, 0.05f),
			new ONSPPropagationMaterial.Point(4000f, 0.04f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.2f),
			new ONSPPropagationMaterial.Point(250f, 0.25f),
			new ONSPPropagationMaterial.Point(500f, 0.3f),
			new ONSPPropagationMaterial.Point(1000f, 0.35f),
			new ONSPPropagationMaterial.Point(2000f, 0.4f),
			new ONSPPropagationMaterial.Point(4000f, 0.45f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.02f),
			new ONSPPropagationMaterial.Point(250f, 0.01f),
			new ONSPPropagationMaterial.Point(500f, 0.0063f),
			new ONSPPropagationMaterial.Point(1000f, 0.0035f),
			new ONSPPropagationMaterial.Point(2000f, 0.00011f),
			new ONSPPropagationMaterial.Point(4000f, 0.00063f)
		};
	}

	// Token: 0x0600089C RID: 2204 RVA: 0x00037D04 File Offset: 0x00035F04
	private static void Soil(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.15f),
			new ONSPPropagationMaterial.Point(250f, 0.25f),
			new ONSPPropagationMaterial.Point(500f, 0.4f),
			new ONSPPropagationMaterial.Point(1000f, 0.55f),
			new ONSPPropagationMaterial.Point(2000f, 0.6f),
			new ONSPPropagationMaterial.Point(4000f, 0.6f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.1f),
			new ONSPPropagationMaterial.Point(250f, 0.2f),
			new ONSPPropagationMaterial.Point(500f, 0.25f),
			new ONSPPropagationMaterial.Point(1000f, 0.4f),
			new ONSPPropagationMaterial.Point(2000f, 0.55f),
			new ONSPPropagationMaterial.Point(4000f, 0.7f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>();
	}

	// Token: 0x0600089D RID: 2205 RVA: 0x00037E40 File Offset: 0x00036040
	private static void SoundProof(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(1000f, 1f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(1000f, 0f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>();
	}

	// Token: 0x0600089E RID: 2206 RVA: 0x00037EAC File Offset: 0x000360AC
	private static void Snow(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.45f),
			new ONSPPropagationMaterial.Point(250f, 0.75f),
			new ONSPPropagationMaterial.Point(500f, 0.9f),
			new ONSPPropagationMaterial.Point(1000f, 0.95f),
			new ONSPPropagationMaterial.Point(2000f, 0.95f),
			new ONSPPropagationMaterial.Point(4000f, 0.95f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.2f),
			new ONSPPropagationMaterial.Point(250f, 0.3f),
			new ONSPPropagationMaterial.Point(500f, 0.4f),
			new ONSPPropagationMaterial.Point(1000f, 0.5f),
			new ONSPPropagationMaterial.Point(2000f, 0.6f),
			new ONSPPropagationMaterial.Point(4000f, 0.75f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>();
	}

	// Token: 0x0600089F RID: 2207 RVA: 0x00037FE8 File Offset: 0x000361E8
	private static void Steel(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.05f),
			new ONSPPropagationMaterial.Point(250f, 0.1f),
			new ONSPPropagationMaterial.Point(500f, 0.1f),
			new ONSPPropagationMaterial.Point(1000f, 0.1f),
			new ONSPPropagationMaterial.Point(2000f, 0.07f),
			new ONSPPropagationMaterial.Point(4000f, 0.02f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.1f),
			new ONSPPropagationMaterial.Point(250f, 0.1f),
			new ONSPPropagationMaterial.Point(500f, 0.1f),
			new ONSPPropagationMaterial.Point(1000f, 0.1f),
			new ONSPPropagationMaterial.Point(2000f, 0.1f),
			new ONSPPropagationMaterial.Point(4000f, 0.1f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.25f),
			new ONSPPropagationMaterial.Point(250f, 0.2f),
			new ONSPPropagationMaterial.Point(500f, 0.17f),
			new ONSPPropagationMaterial.Point(1000f, 0.089f),
			new ONSPPropagationMaterial.Point(2000f, 0.089f),
			new ONSPPropagationMaterial.Point(4000f, 0.0056f)
		};
	}

	// Token: 0x060008A0 RID: 2208 RVA: 0x000381A4 File Offset: 0x000363A4
	private static void Water(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.01f),
			new ONSPPropagationMaterial.Point(250f, 0.01f),
			new ONSPPropagationMaterial.Point(500f, 0.01f),
			new ONSPPropagationMaterial.Point(1000f, 0.02f),
			new ONSPPropagationMaterial.Point(2000f, 0.02f),
			new ONSPPropagationMaterial.Point(4000f, 0.03f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.1f),
			new ONSPPropagationMaterial.Point(250f, 0.1f),
			new ONSPPropagationMaterial.Point(500f, 0.1f),
			new ONSPPropagationMaterial.Point(1000f, 0.07f),
			new ONSPPropagationMaterial.Point(2000f, 0.05f),
			new ONSPPropagationMaterial.Point(4000f, 0.05f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.03f),
			new ONSPPropagationMaterial.Point(250f, 0.03f),
			new ONSPPropagationMaterial.Point(500f, 0.03f),
			new ONSPPropagationMaterial.Point(1000f, 0.02f),
			new ONSPPropagationMaterial.Point(2000f, 0.015f),
			new ONSPPropagationMaterial.Point(4000f, 0.01f)
		};
	}

	// Token: 0x060008A1 RID: 2209 RVA: 0x00038360 File Offset: 0x00036560
	private static void WoodThin(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.42f),
			new ONSPPropagationMaterial.Point(250f, 0.21f),
			new ONSPPropagationMaterial.Point(500f, 0.1f),
			new ONSPPropagationMaterial.Point(1000f, 0.08f),
			new ONSPPropagationMaterial.Point(2000f, 0.06f),
			new ONSPPropagationMaterial.Point(4000f, 0.06f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.1f),
			new ONSPPropagationMaterial.Point(250f, 0.1f),
			new ONSPPropagationMaterial.Point(500f, 0.1f),
			new ONSPPropagationMaterial.Point(1000f, 0.1f),
			new ONSPPropagationMaterial.Point(2000f, 0.1f),
			new ONSPPropagationMaterial.Point(4000f, 0.15f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.2f),
			new ONSPPropagationMaterial.Point(250f, 0.125f),
			new ONSPPropagationMaterial.Point(500f, 0.079f),
			new ONSPPropagationMaterial.Point(1000f, 0.1f),
			new ONSPPropagationMaterial.Point(2000f, 0.089f),
			new ONSPPropagationMaterial.Point(4000f, 0.05f)
		};
	}

	// Token: 0x060008A2 RID: 2210 RVA: 0x0003851C File Offset: 0x0003671C
	private static void WoodThick(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.19f),
			new ONSPPropagationMaterial.Point(250f, 0.14f),
			new ONSPPropagationMaterial.Point(500f, 0.09f),
			new ONSPPropagationMaterial.Point(1000f, 0.06f),
			new ONSPPropagationMaterial.Point(2000f, 0.06f),
			new ONSPPropagationMaterial.Point(4000f, 0.05f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.1f),
			new ONSPPropagationMaterial.Point(250f, 0.1f),
			new ONSPPropagationMaterial.Point(500f, 0.1f),
			new ONSPPropagationMaterial.Point(1000f, 0.1f),
			new ONSPPropagationMaterial.Point(2000f, 0.1f),
			new ONSPPropagationMaterial.Point(4000f, 0.15f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.035f),
			new ONSPPropagationMaterial.Point(250f, 0.028f),
			new ONSPPropagationMaterial.Point(500f, 0.028f),
			new ONSPPropagationMaterial.Point(1000f, 0.028f),
			new ONSPPropagationMaterial.Point(2000f, 0.011f),
			new ONSPPropagationMaterial.Point(4000f, 0.0071f)
		};
	}

	// Token: 0x060008A3 RID: 2211 RVA: 0x000386D8 File Offset: 0x000368D8
	private static void WoodFloor(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.15f),
			new ONSPPropagationMaterial.Point(250f, 0.11f),
			new ONSPPropagationMaterial.Point(500f, 0.1f),
			new ONSPPropagationMaterial.Point(1000f, 0.07f),
			new ONSPPropagationMaterial.Point(2000f, 0.06f),
			new ONSPPropagationMaterial.Point(4000f, 0.07f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.1f),
			new ONSPPropagationMaterial.Point(250f, 0.1f),
			new ONSPPropagationMaterial.Point(500f, 0.1f),
			new ONSPPropagationMaterial.Point(1000f, 0.1f),
			new ONSPPropagationMaterial.Point(2000f, 0.1f),
			new ONSPPropagationMaterial.Point(4000f, 0.15f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.071f),
			new ONSPPropagationMaterial.Point(250f, 0.025f),
			new ONSPPropagationMaterial.Point(500f, 0.0158f),
			new ONSPPropagationMaterial.Point(1000f, 0.0056f),
			new ONSPPropagationMaterial.Point(2000f, 0.0035f),
			new ONSPPropagationMaterial.Point(4000f, 0.0016f)
		};
	}

	// Token: 0x060008A4 RID: 2212 RVA: 0x00038894 File Offset: 0x00036A94
	private static void WoodOnConcrete(ref ONSPPropagationMaterial material)
	{
		material.absorption.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.04f),
			new ONSPPropagationMaterial.Point(250f, 0.04f),
			new ONSPPropagationMaterial.Point(500f, 0.07f),
			new ONSPPropagationMaterial.Point(1000f, 0.06f),
			new ONSPPropagationMaterial.Point(2000f, 0.06f),
			new ONSPPropagationMaterial.Point(4000f, 0.07f)
		};
		material.scattering.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.1f),
			new ONSPPropagationMaterial.Point(250f, 0.1f),
			new ONSPPropagationMaterial.Point(500f, 0.1f),
			new ONSPPropagationMaterial.Point(1000f, 0.1f),
			new ONSPPropagationMaterial.Point(2000f, 0.1f),
			new ONSPPropagationMaterial.Point(4000f, 0.15f)
		};
		material.transmission.points = new List<ONSPPropagationMaterial.Point>
		{
			new ONSPPropagationMaterial.Point(125f, 0.004f),
			new ONSPPropagationMaterial.Point(250f, 0.0079f),
			new ONSPPropagationMaterial.Point(500f, 0.0056f),
			new ONSPPropagationMaterial.Point(1000f, 0.0016f),
			new ONSPPropagationMaterial.Point(2000f, 0.0014f),
			new ONSPPropagationMaterial.Point(4000f, 0.0005f)
		};
	}

	// Token: 0x04000A70 RID: 2672
	public IntPtr materialHandle = IntPtr.Zero;

	// Token: 0x04000A71 RID: 2673
	[Tooltip("Absorption")]
	public ONSPPropagationMaterial.Spectrum absorption = new ONSPPropagationMaterial.Spectrum();

	// Token: 0x04000A72 RID: 2674
	[Tooltip("Transmission")]
	public ONSPPropagationMaterial.Spectrum transmission = new ONSPPropagationMaterial.Spectrum();

	// Token: 0x04000A73 RID: 2675
	[Tooltip("Scattering")]
	public ONSPPropagationMaterial.Spectrum scattering = new ONSPPropagationMaterial.Spectrum();

	// Token: 0x04000A74 RID: 2676
	[SerializeField]
	private ONSPPropagationMaterial.Preset preset_;

	// Token: 0x02000236 RID: 566
	public enum Preset
	{
		// Token: 0x04000F8F RID: 3983
		Custom,
		// Token: 0x04000F90 RID: 3984
		AcousticTile,
		// Token: 0x04000F91 RID: 3985
		Brick,
		// Token: 0x04000F92 RID: 3986
		BrickPainted,
		// Token: 0x04000F93 RID: 3987
		Carpet,
		// Token: 0x04000F94 RID: 3988
		CarpetHeavy,
		// Token: 0x04000F95 RID: 3989
		CarpetHeavyPadded,
		// Token: 0x04000F96 RID: 3990
		CeramicTile,
		// Token: 0x04000F97 RID: 3991
		Concrete,
		// Token: 0x04000F98 RID: 3992
		ConcreteRough,
		// Token: 0x04000F99 RID: 3993
		ConcreteBlock,
		// Token: 0x04000F9A RID: 3994
		ConcreteBlockPainted,
		// Token: 0x04000F9B RID: 3995
		Curtain,
		// Token: 0x04000F9C RID: 3996
		Foliage,
		// Token: 0x04000F9D RID: 3997
		Glass,
		// Token: 0x04000F9E RID: 3998
		GlassHeavy,
		// Token: 0x04000F9F RID: 3999
		Grass,
		// Token: 0x04000FA0 RID: 4000
		Gravel,
		// Token: 0x04000FA1 RID: 4001
		GypsumBoard,
		// Token: 0x04000FA2 RID: 4002
		PlasterOnBrick,
		// Token: 0x04000FA3 RID: 4003
		PlasterOnConcreteBlock,
		// Token: 0x04000FA4 RID: 4004
		Soil,
		// Token: 0x04000FA5 RID: 4005
		SoundProof,
		// Token: 0x04000FA6 RID: 4006
		Snow,
		// Token: 0x04000FA7 RID: 4007
		Steel,
		// Token: 0x04000FA8 RID: 4008
		Water,
		// Token: 0x04000FA9 RID: 4009
		WoodThin,
		// Token: 0x04000FAA RID: 4010
		WoodThick,
		// Token: 0x04000FAB RID: 4011
		WoodFloor,
		// Token: 0x04000FAC RID: 4012
		WoodOnConcrete
	}

	// Token: 0x02000237 RID: 567
	[Serializable]
	public sealed class Point
	{
		// Token: 0x06000D41 RID: 3393 RVA: 0x000458F8 File Offset: 0x00043AF8
		public Point(float frequency = 0f, float data = 0f)
		{
			this.frequency = frequency;
			this.data = data;
		}

		// Token: 0x06000D42 RID: 3394 RVA: 0x0004590E File Offset: 0x00043B0E
		public static implicit operator ONSPPropagationMaterial.Point(Vector2 v)
		{
			return new ONSPPropagationMaterial.Point(v.x, v.y);
		}

		// Token: 0x06000D43 RID: 3395 RVA: 0x00045921 File Offset: 0x00043B21
		public static implicit operator Vector2(ONSPPropagationMaterial.Point point)
		{
			return new Vector2(point.frequency, point.data);
		}

		// Token: 0x04000FAD RID: 4013
		public float frequency;

		// Token: 0x04000FAE RID: 4014
		public float data;
	}

	// Token: 0x02000238 RID: 568
	[Serializable]
	public sealed class Spectrum
	{
		// Token: 0x170000ED RID: 237
		public float this[float f]
		{
			get
			{
				if (this.points.Count > 0)
				{
					ONSPPropagationMaterial.Point point = new ONSPPropagationMaterial.Point(float.MinValue, 0f);
					ONSPPropagationMaterial.Point point2 = new ONSPPropagationMaterial.Point(float.MaxValue, 0f);
					foreach (ONSPPropagationMaterial.Point point3 in this.points)
					{
						if (point3.frequency < f)
						{
							if (point3.frequency > point.frequency)
							{
								point = point3;
							}
						}
						else if (point3.frequency < point2.frequency)
						{
							point2 = point3;
						}
					}
					if (point.frequency == -3.4028235E+38f)
					{
						point.data = (from p in this.points
						orderby p.frequency
						select p).First<ONSPPropagationMaterial.Point>().data;
					}
					if (point2.frequency == 3.4028235E+38f)
					{
						point2.data = (from p in this.points
						orderby p.frequency
						select p).Last<ONSPPropagationMaterial.Point>().data;
					}
					return point.data + (f - point.frequency) * (point2.data - point.data) / (point2.frequency - point.frequency);
				}
				return 0f;
			}
		}

		// Token: 0x04000FAF RID: 4015
		public int selection = int.MaxValue;

		// Token: 0x04000FB0 RID: 4016
		public List<ONSPPropagationMaterial.Point> points = new List<ONSPPropagationMaterial.Point>();
	}
}
