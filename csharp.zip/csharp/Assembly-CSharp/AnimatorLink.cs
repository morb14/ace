﻿using System;
using UnityEngine;

// Token: 0x02000023 RID: 35
public class AnimatorLink : MonoBehaviour
{
	// Token: 0x060000AB RID: 171 RVA: 0x00003297 File Offset: 0x00001497
	private void Start()
	{
	}

	// Token: 0x060000AC RID: 172 RVA: 0x00005ADA File Offset: 0x00003CDA
	public void ReloadAnimationComplete()
	{
		this.weaponController.ShotgunReloadOver();
	}

	// Token: 0x060000AD RID: 173 RVA: 0x00005AE7 File Offset: 0x00003CE7
	public void LifterRoundReleased()
	{
		this.weaponController.LifterRoundReleased();
	}

	// Token: 0x040000B2 RID: 178
	[SerializeField]
	private WeaponController weaponController;
}
