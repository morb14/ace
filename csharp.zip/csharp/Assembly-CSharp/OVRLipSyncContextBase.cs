﻿using System;
using UnityEngine;

// Token: 0x0200010B RID: 267
[RequireComponent(typeof(AudioSource))]
public class OVRLipSyncContextBase : MonoBehaviour
{
	// Token: 0x17000012 RID: 18
	// (get) Token: 0x060006C8 RID: 1736 RVA: 0x0002BB1C File Offset: 0x00029D1C
	// (set) Token: 0x060006C7 RID: 1735 RVA: 0x0002BAD8 File Offset: 0x00029CD8
	public int Smoothing
	{
		get
		{
			return this._smoothing;
		}
		set
		{
			OVRLipSync.Result result = OVRLipSync.SendSignal(this.context, OVRLipSync.Signals.VisemeSmoothing, value, 0);
			if (result != OVRLipSync.Result.Success)
			{
				if (result == OVRLipSync.Result.InvalidParam)
				{
					Debug.LogError("OVRLipSyncContextBase.SetSmoothing: A viseme smoothing parameter is invalid, it should be between 1 and 100!");
				}
				else
				{
					Debug.LogError("OVRLipSyncContextBase.SetSmoothing: An unexpected error occured.");
				}
			}
			this._smoothing = value;
		}
	}

	// Token: 0x17000013 RID: 19
	// (get) Token: 0x060006C9 RID: 1737 RVA: 0x0002BB24 File Offset: 0x00029D24
	public uint Context
	{
		get
		{
			return this.context;
		}
	}

	// Token: 0x17000014 RID: 20
	// (get) Token: 0x060006CA RID: 1738 RVA: 0x0002BB2C File Offset: 0x00029D2C
	protected OVRLipSync.Frame Frame
	{
		get
		{
			return this.frame;
		}
	}

	// Token: 0x060006CB RID: 1739 RVA: 0x0002BB34 File Offset: 0x00029D34
	private void Awake()
	{
		if (!this.audioSource)
		{
			this.audioSource = base.GetComponent<AudioSource>();
		}
		lock (this)
		{
			if (this.context == 0U && OVRLipSync.CreateContext(ref this.context, this.provider, 0, this.enableAcceleration) != OVRLipSync.Result.Success)
			{
				Debug.LogError("OVRLipSyncContextBase.Start ERROR: Could not create Phoneme context.");
			}
		}
	}

	// Token: 0x060006CC RID: 1740 RVA: 0x0002BBB0 File Offset: 0x00029DB0
	private void OnDestroy()
	{
		lock (this)
		{
			if (this.context != 0U && OVRLipSync.DestroyContext(this.context) != OVRLipSync.Result.Success)
			{
				Debug.LogError("OVRLipSyncContextBase.OnDestroy ERROR: Could not delete Phoneme context.");
			}
		}
	}

	// Token: 0x060006CD RID: 1741 RVA: 0x0002BB2C File Offset: 0x00029D2C
	public OVRLipSync.Frame GetCurrentPhonemeFrame()
	{
		return this.frame;
	}

	// Token: 0x060006CE RID: 1742 RVA: 0x0002BC04 File Offset: 0x00029E04
	public void SetVisemeBlend(int viseme, int amount)
	{
		OVRLipSync.Result result = OVRLipSync.SendSignal(this.context, OVRLipSync.Signals.VisemeAmount, viseme, amount);
		if (result != OVRLipSync.Result.Success)
		{
			if (result == OVRLipSync.Result.InvalidParam)
			{
				Debug.LogError("OVRLipSyncContextBase.SetVisemeBlend: Viseme ID is invalid.");
				return;
			}
			Debug.LogError("OVRLipSyncContextBase.SetVisemeBlend: An unexpected error occured.");
		}
	}

	// Token: 0x060006CF RID: 1743 RVA: 0x0002BC40 File Offset: 0x00029E40
	public void SetLaughterBlend(int amount)
	{
		if (OVRLipSync.SendSignal(this.context, OVRLipSync.Signals.LaughterAmount, amount, 0) != OVRLipSync.Result.Success)
		{
			Debug.LogError("OVRLipSyncContextBase.SetLaughterBlend: An unexpected error occured.");
		}
	}

	// Token: 0x060006D0 RID: 1744 RVA: 0x0002BC5C File Offset: 0x00029E5C
	public OVRLipSync.Result ResetContext()
	{
		this.frame.Reset();
		return OVRLipSync.ResetContext(this.context);
	}

	// Token: 0x040008FA RID: 2298
	public AudioSource audioSource;

	// Token: 0x040008FB RID: 2299
	[Tooltip("Which lip sync provider to use for viseme computation.")]
	public OVRLipSync.ContextProviders provider = OVRLipSync.ContextProviders.Enhanced;

	// Token: 0x040008FC RID: 2300
	[Tooltip("Enable DSP offload on supported Android devices.")]
	public bool enableAcceleration = true;

	// Token: 0x040008FD RID: 2301
	private OVRLipSync.Frame frame = new OVRLipSync.Frame();

	// Token: 0x040008FE RID: 2302
	private uint context;

	// Token: 0x040008FF RID: 2303
	private int _smoothing;
}
