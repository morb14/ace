﻿using System;
using UnityEngine;

// Token: 0x02000051 RID: 81
public class SettingsManager : MonoBehaviour
{
	// Token: 0x060002C9 RID: 713 RVA: 0x000101C9 File Offset: 0x0000E3C9
	public bool MaterialToggled()
	{
		return this.paperColour != SettingsManager.PaperColours.BrownScoreWhitePenalty || this.steelColour != SettingsManager.SteelColours.WhiteScoreRedPenalty;
	}

	// Token: 0x060002CA RID: 714 RVA: 0x000101DE File Offset: 0x0000E3DE
	public void TogglePaperType()
	{
		if (this.paperType == SettingsManager.PaperType.IPSC)
		{
			this.paperType = SettingsManager.PaperType.USPSA;
		}
		else
		{
			this.paperType = SettingsManager.PaperType.IPSC;
		}
		GameEvents.current.TargetTypeChange();
	}

	// Token: 0x060002CB RID: 715 RVA: 0x00010202 File Offset: 0x0000E402
	public void ToggleReticle()
	{
		if (this.reflexColour == SettingsManager.ReflexColour.Red)
		{
			this.reflexColour = SettingsManager.ReflexColour.Green;
			return;
		}
		this.reflexColour = SettingsManager.ReflexColour.Red;
	}

	// Token: 0x060002CC RID: 716 RVA: 0x0001021B File Offset: 0x0000E41B
	public Material ReflexMaterial()
	{
		if (this.reflexColour == SettingsManager.ReflexColour.Red)
		{
			return this.reflexRed;
		}
		return this.reflexGreen;
	}

	// Token: 0x060002CD RID: 717 RVA: 0x00010232 File Offset: 0x0000E432
	public Material NoneReflexMaterial(Material uniqueMaterialOriginal = null, Material uniqueMaterialAlt = null)
	{
		if (this.reflexColour == SettingsManager.ReflexColour.Red)
		{
			if (uniqueMaterialOriginal != null)
			{
				return uniqueMaterialOriginal;
			}
			return this.noneReflexRed;
		}
		else
		{
			if (uniqueMaterialAlt != null)
			{
				return uniqueMaterialAlt;
			}
			return this.noneReflexGreen;
		}
	}

	// Token: 0x060002CE RID: 718 RVA: 0x00010260 File Offset: 0x0000E460
	public void ToggleScoring(SettingsManager.TargetType type, int index)
	{
		if (type != SettingsManager.TargetType.PaperTarget)
		{
			if (type == SettingsManager.TargetType.SteelTarget)
			{
				switch (index)
				{
				case 0:
					this.steelColour = SettingsManager.SteelColours.WhiteScoreRedPenalty;
					return;
				case 1:
					this.steelColour = SettingsManager.SteelColours.BlueScoreWhitePenalty;
					return;
				case 2:
					this.steelColour = SettingsManager.SteelColours.BlueScoreRedPenalty;
					break;
				default:
					return;
				}
			}
			return;
		}
		switch (index)
		{
		case 0:
			this.paperColour = SettingsManager.PaperColours.BrownScoreWhitePenalty;
			return;
		case 1:
			this.paperColour = SettingsManager.PaperColours.WhiteScoreBrownPenalty;
			return;
		case 2:
			this.paperColour = SettingsManager.PaperColours.WhiteScoreRedPenalty;
			return;
		default:
			return;
		}
	}

	// Token: 0x040002F0 RID: 752
	[SerializeField]
	private bool brownScoringWhitePenalty = true;

	// Token: 0x040002F1 RID: 753
	[SerializeField]
	public SettingsManager.PaperType paperType;

	// Token: 0x040002F2 RID: 754
	[SerializeField]
	public SettingsManager.PaperColours paperColour;

	// Token: 0x040002F3 RID: 755
	[SerializeField]
	public SettingsManager.SteelColours steelColour = SettingsManager.SteelColours.BlueScoreWhitePenalty;

	// Token: 0x040002F4 RID: 756
	[Header("Defaults")]
	[SerializeField]
	public Material paperNoShootDefault;

	// Token: 0x040002F5 RID: 757
	[SerializeField]
	public Material paperDefault;

	// Token: 0x040002F6 RID: 758
	[SerializeField]
	public Material steelNoShootDefault;

	// Token: 0x040002F7 RID: 759
	[SerializeField]
	public Material steelDefault;

	// Token: 0x040002F8 RID: 760
	[Header("Materials")]
	[SerializeField]
	public Material paperBrown;

	// Token: 0x040002F9 RID: 761
	[SerializeField]
	public Material paperRed;

	// Token: 0x040002FA RID: 762
	[SerializeField]
	public Material paperWhite;

	// Token: 0x040002FB RID: 763
	[SerializeField]
	public Material steelWhite;

	// Token: 0x040002FC RID: 764
	[SerializeField]
	public Material steelRed;

	// Token: 0x040002FD RID: 765
	[SerializeField]
	public Material steelBlue;

	// Token: 0x040002FE RID: 766
	[SerializeField]
	public Material uspsaBrown;

	// Token: 0x040002FF RID: 767
	[SerializeField]
	public Material uspsaRed;

	// Token: 0x04000300 RID: 768
	[SerializeField]
	public Material uspsaWhite;

	// Token: 0x04000301 RID: 769
	[Header("Mechanics")]
	public bool doNotRecenter;

	// Token: 0x04000302 RID: 770
	public bool doNotDetectTrigger;

	// Token: 0x04000303 RID: 771
	public float triggerBreakOverride;

	// Token: 0x04000304 RID: 772
	public float triggerResetOverride;

	// Token: 0x04000305 RID: 773
	[SerializeField]
	public Material reflexRed;

	// Token: 0x04000306 RID: 774
	[SerializeField]
	public Material reflexGreen;

	// Token: 0x04000307 RID: 775
	[SerializeField]
	public Material noneReflexRed;

	// Token: 0x04000308 RID: 776
	[SerializeField]
	public Material noneReflexGreen;

	// Token: 0x04000309 RID: 777
	[SerializeField]
	public SettingsManager.ReflexColour reflexColour;

	// Token: 0x0400030A RID: 778
	public int targetPaperIndex;

	// Token: 0x0400030B RID: 779
	public int targetSteelIndex;

	// Token: 0x020001C5 RID: 453
	public enum TargetType
	{
		// Token: 0x04000D80 RID: 3456
		PaperTarget,
		// Token: 0x04000D81 RID: 3457
		SteelTarget,
		// Token: 0x04000D82 RID: 3458
		PaperType,
		// Token: 0x04000D83 RID: 3459
		Recenter,
		// Token: 0x04000D84 RID: 3460
		ReflexColour,
		// Token: 0x04000D85 RID: 3461
		ReloadSensitivity,
		// Token: 0x04000D86 RID: 3462
		PageTurn,
		// Token: 0x04000D87 RID: 3463
		OpticOpacity,
		// Token: 0x04000D88 RID: 3464
		TriggerDetection
	}

	// Token: 0x020001C6 RID: 454
	public enum PaperType
	{
		// Token: 0x04000D8A RID: 3466
		IPSC,
		// Token: 0x04000D8B RID: 3467
		USPSA
	}

	// Token: 0x020001C7 RID: 455
	public enum PaperColours
	{
		// Token: 0x04000D8D RID: 3469
		BrownScoreWhitePenalty,
		// Token: 0x04000D8E RID: 3470
		WhiteScoreBrownPenalty,
		// Token: 0x04000D8F RID: 3471
		WhiteScoreRedPenalty
	}

	// Token: 0x020001C8 RID: 456
	public enum SteelColours
	{
		// Token: 0x04000D91 RID: 3473
		WhiteScoreRedPenalty,
		// Token: 0x04000D92 RID: 3474
		BlueScoreWhitePenalty,
		// Token: 0x04000D93 RID: 3475
		BlueScoreRedPenalty
	}

	// Token: 0x020001C9 RID: 457
	public enum ReflexColour
	{
		// Token: 0x04000D95 RID: 3477
		Red,
		// Token: 0x04000D96 RID: 3478
		Green
	}
}
