﻿using System;
using System.Linq;
using System.Runtime.CompilerServices;
using UnityEngine;

// Token: 0x0200010D RID: 269
public class OVRLipSyncContextMorphTarget : MonoBehaviour
{
	// Token: 0x060006D4 RID: 1748 RVA: 0x0002BCEC File Offset: 0x00029EEC
	private void Start()
	{
		if (this.skinnedMeshRenderer == null)
		{
			Debug.LogError("LipSyncContextMorphTarget.Start Error: Please set the target Skinned Mesh Renderer to be controlled!");
			return;
		}
		this.lipsyncContext = base.GetComponent<OVRLipSyncContextBase>();
		if (this.lipsyncContext == null)
		{
			Debug.LogError("LipSyncContextMorphTarget.Start Error: No OVRLipSyncContext component on this object!");
			return;
		}
		this.lipsyncContext.Smoothing = this.smoothAmount;
	}

	// Token: 0x060006D5 RID: 1749 RVA: 0x0002BD48 File Offset: 0x00029F48
	private void Update()
	{
		if (this.lipsyncContext != null && this.skinnedMeshRenderer != null)
		{
			OVRLipSync.Frame currentPhonemeFrame = this.lipsyncContext.GetCurrentPhonemeFrame();
			if (currentPhonemeFrame != null)
			{
				this.SetVisemeToMorphTarget(currentPhonemeFrame);
				this.SetLaughterToMorphTarget(currentPhonemeFrame);
			}
			this.CheckForKeys();
			if (this.smoothAmount != this.lipsyncContext.Smoothing)
			{
				this.lipsyncContext.Smoothing = this.smoothAmount;
			}
		}
	}

	// Token: 0x060006D6 RID: 1750 RVA: 0x0002BDB8 File Offset: 0x00029FB8
	private void CheckForKeys()
	{
		if (this.enableVisemeTestKeys)
		{
			for (int i = 0; i < OVRLipSync.VisemeCount; i++)
			{
				this.CheckVisemeKey(this.visemeTestKeys[i], i, 100);
			}
		}
		this.CheckLaughterKey();
	}

	// Token: 0x060006D7 RID: 1751 RVA: 0x0002BDF4 File Offset: 0x00029FF4
	private void SetVisemeToMorphTarget(OVRLipSync.Frame frame)
	{
		for (int i = 0; i < this.visemeToBlendTargets.Length; i++)
		{
			if (this.visemeToBlendTargets[i] != -1)
			{
				this.skinnedMeshRenderer.SetBlendShapeWeight(this.visemeToBlendTargets[i], frame.Visemes[i] * 100f);
			}
		}
	}

	// Token: 0x060006D8 RID: 1752 RVA: 0x0002BE40 File Offset: 0x0002A040
	private void SetLaughterToMorphTarget(OVRLipSync.Frame frame)
	{
		if (this.laughterBlendTarget != -1)
		{
			float num = frame.laughterScore;
			num = ((num < this.laughterThreshold) ? 0f : (num - this.laughterThreshold));
			num = Mathf.Min(num * this.laughterMultiplier, 1f);
			num *= 1f / this.laughterThreshold;
			this.skinnedMeshRenderer.SetBlendShapeWeight(this.laughterBlendTarget, num * 100f);
		}
	}

	// Token: 0x060006D9 RID: 1753 RVA: 0x0002BEB0 File Offset: 0x0002A0B0
	private void CheckVisemeKey(KeyCode key, int viseme, int amount)
	{
		if (Input.GetKeyDown(key))
		{
			this.lipsyncContext.SetVisemeBlend(this.visemeToBlendTargets[viseme], amount);
		}
		if (Input.GetKeyUp(key))
		{
			this.lipsyncContext.SetVisemeBlend(this.visemeToBlendTargets[viseme], 0);
		}
	}

	// Token: 0x060006DA RID: 1754 RVA: 0x0002BEEA File Offset: 0x0002A0EA
	private void CheckLaughterKey()
	{
		if (Input.GetKeyDown(this.laughterKey))
		{
			this.lipsyncContext.SetLaughterBlend(100);
		}
		if (Input.GetKeyUp(this.laughterKey))
		{
			this.lipsyncContext.SetLaughterBlend(0);
		}
	}

	// Token: 0x060006DB RID: 1755 RVA: 0x0002BF20 File Offset: 0x0002A120
	public OVRLipSyncContextMorphTarget()
	{
		KeyCode[] array = new KeyCode[15];
		RuntimeHelpers.InitializeArray(array, fieldof(<PrivateImplementationDetails>.B41C3C29C4987C4B4A3CA4117D1A12093AAF458A).FieldHandle);
		this.visemeTestKeys = array;
		this.laughterKey = KeyCode.CapsLock;
		this.laughterBlendTarget = OVRLipSync.VisemeCount;
		this.laughterThreshold = 0.5f;
		this.laughterMultiplier = 1.5f;
		this.smoothAmount = 70;
		base..ctor();
	}

	// Token: 0x04000901 RID: 2305
	[Tooltip("Skinned Mesh Rendered target to be driven by Oculus Lipsync")]
	public SkinnedMeshRenderer skinnedMeshRenderer;

	// Token: 0x04000902 RID: 2306
	[Tooltip("Blendshape index to trigger for each viseme.")]
	public int[] visemeToBlendTargets = Enumerable.Range(0, OVRLipSync.VisemeCount).ToArray<int>();

	// Token: 0x04000903 RID: 2307
	[Tooltip("Enable using the test keys defined below to manually trigger each viseme.")]
	public bool enableVisemeTestKeys;

	// Token: 0x04000904 RID: 2308
	[Tooltip("Test keys used to manually trigger an individual viseme - by default the QWERTY row of a US keyboard.")]
	public KeyCode[] visemeTestKeys;

	// Token: 0x04000905 RID: 2309
	[Tooltip("Test key used to manually trigger laughter and visualise the results")]
	public KeyCode laughterKey;

	// Token: 0x04000906 RID: 2310
	[Tooltip("Blendshape index to trigger for laughter")]
	public int laughterBlendTarget;

	// Token: 0x04000907 RID: 2311
	[Range(0f, 1f)]
	[Tooltip("Laughter probability threshold above which the laughter blendshape will be activated")]
	public float laughterThreshold;

	// Token: 0x04000908 RID: 2312
	[Range(0f, 3f)]
	[Tooltip("Laughter animation linear multiplier, the final output will be clamped to 1.0")]
	public float laughterMultiplier;

	// Token: 0x04000909 RID: 2313
	[Range(1f, 100f)]
	[Tooltip("Smoothing of 1 will yield only the current predicted viseme, 100 will yield an extremely smooth viseme response.")]
	public int smoothAmount;

	// Token: 0x0400090A RID: 2314
	private OVRLipSyncContextBase lipsyncContext;
}
