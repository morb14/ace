﻿using System;
using UnityEngine;

// Token: 0x02000016 RID: 22
public class WFX_Demo_DeleteAfterDelay : MonoBehaviour
{
	// Token: 0x06000065 RID: 101 RVA: 0x00004293 File Offset: 0x00002493
	private void Update()
	{
		this.delay -= Time.deltaTime;
		if (this.delay < 0f)
		{
			Object.Destroy(base.gameObject);
		}
	}

	// Token: 0x04000061 RID: 97
	public float delay = 1f;
}
