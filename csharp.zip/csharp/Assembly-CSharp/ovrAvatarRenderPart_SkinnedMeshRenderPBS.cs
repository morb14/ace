﻿using System;

// Token: 0x020000E2 RID: 226
public struct ovrAvatarRenderPart_SkinnedMeshRenderPBS
{
	// Token: 0x0400084E RID: 2126
	public ovrAvatarTransform localTransform;

	// Token: 0x0400084F RID: 2127
	public ovrAvatarVisibilityFlags visibilityMask;

	// Token: 0x04000850 RID: 2128
	public ulong meshAssetID;

	// Token: 0x04000851 RID: 2129
	public ulong albedoTextureAssetID;

	// Token: 0x04000852 RID: 2130
	public ulong surfaceTextureAssetID;

	// Token: 0x04000853 RID: 2131
	public ovrAvatarSkinnedMeshPose skinnedPose;
}
