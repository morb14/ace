﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000047 RID: 71
public class PlayerData : MonoBehaviour
{
	// Token: 0x0600023D RID: 573 RVA: 0x0000CB31 File Offset: 0x0000AD31
	private void Start()
	{
		this.cameraRigLocalY = -0.83f;
		this.InitiateSavedData();
	}

	// Token: 0x0600023E RID: 574 RVA: 0x0000CB44 File Offset: 0x0000AD44
	private void InitiateSavedData()
	{
		this.LoadData();
	}

	// Token: 0x0600023F RID: 575 RVA: 0x0000CB4C File Offset: 0x0000AD4C
	private void Update()
	{
		if (Input.GetKeyDown(KeyCode.S))
		{
			this.SaveData();
		}
	}

	// Token: 0x06000240 RID: 576 RVA: 0x0000CB60 File Offset: 0x0000AD60
	public void SaveWeaponTransform(string weaponID, Vector3 position, Quaternion rotation)
	{
		if (!this.weaponPositions.ContainsKey(weaponID))
		{
			this.weaponPositions.Add(weaponID, position);
			this.weaponRotation.Add(weaponID, rotation);
		}
		else
		{
			this.weaponPositions[weaponID] = position;
			this.weaponRotation[weaponID] = rotation;
		}
		this.SaveData();
	}

	// Token: 0x06000241 RID: 577 RVA: 0x0000CBB7 File Offset: 0x0000ADB7
	public void DeleteCalibration()
	{
		this.weaponPositions.Clear();
		this.weaponRotation.Clear();
		this.SaveData();
	}

	// Token: 0x06000242 RID: 578 RVA: 0x0000CBD8 File Offset: 0x0000ADD8
	public void SaveData()
	{
		SaveManager.UserData userData = new SaveManager.UserData();
		List<SaveManager.CalibrationData> list = new List<SaveManager.CalibrationData>();
		foreach (KeyValuePair<string, Vector3> keyValuePair in this.weaponPositions)
		{
			SaveManager.CalibrationData calibrationData = new SaveManager.CalibrationData();
			Quaternion quaternion;
			this.weaponRotation.TryGetValue(keyValuePair.Key, out quaternion);
			calibrationData.weaponID = keyValuePair.Key;
			calibrationData.weaponPosition = keyValuePair.Value;
			calibrationData.weaponRotation = quaternion;
			list.Add(calibrationData);
		}
		userData.calibrationDataList = list;
		SaveSystem.Save(JsonUtility.ToJson(userData), "UserSettings");
	}

	// Token: 0x06000243 RID: 579 RVA: 0x0000CC90 File Offset: 0x0000AE90
	public void LoadData()
	{
		string text = SaveSystem.Load("UserSettings");
		if (text != "FileNotFound")
		{
			SaveManager.UserData userData = new SaveManager.UserData();
			userData = JsonUtility.FromJson<SaveManager.UserData>(text);
			if (userData.calibrationDataList.Count > 0)
			{
				foreach (SaveManager.CalibrationData calibrationData in userData.calibrationDataList)
				{
					string weaponID = calibrationData.weaponID;
					Vector3 weaponPosition = calibrationData.weaponPosition;
					Quaternion value = calibrationData.weaponRotation;
					this.weaponPositions.Add(weaponID, weaponPosition);
					this.weaponRotation.Add(weaponID, value);
				}
			}
			if (userData.reloadMultiplier != 0f)
			{
				this.reloadMultiplier = userData.reloadMultiplier;
			}
		}
	}

	// Token: 0x06000244 RID: 580 RVA: 0x0000CD5C File Offset: 0x0000AF5C
	public Vector3 GetWeaponPosition(string weaponID)
	{
		if (this.weaponPositions.ContainsKey(weaponID))
		{
			return this.weaponPositions[weaponID];
		}
		return Vector3.zero;
	}

	// Token: 0x06000245 RID: 581 RVA: 0x0000CD7E File Offset: 0x0000AF7E
	public Quaternion GetWeaponRotation(string weaponID)
	{
		if (this.weaponRotation.ContainsKey(weaponID))
		{
			return this.weaponRotation[weaponID];
		}
		return Quaternion.identity;
	}

	// Token: 0x04000225 RID: 549
	private Dictionary<string, Vector3> weaponPositions = new Dictionary<string, Vector3>();

	// Token: 0x04000226 RID: 550
	private Dictionary<string, Quaternion> weaponRotation = new Dictionary<string, Quaternion>();

	// Token: 0x04000227 RID: 551
	[SerializeField]
	public float cameraRigLocalY;

	// Token: 0x04000228 RID: 552
	[SerializeField]
	public float reloadMultiplier = 1f;

	// Token: 0x04000229 RID: 553
	[SerializeField]
	public float opticOpacity = 0.15f;
}
