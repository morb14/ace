﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x0200000D RID: 13
public class HandedTest : MonoBehaviour
{
	// Token: 0x06000041 RID: 65 RVA: 0x000033FF File Offset: 0x000015FF
	private void Start()
	{
		this.controlManager = Object.FindObjectOfType<ControlManager>();
	}

	// Token: 0x06000042 RID: 66 RVA: 0x0000340C File Offset: 0x0000160C
	private void Update()
	{
		this.text.text = this.controlManager.handedness.ToString();
	}

	// Token: 0x04000034 RID: 52
	[SerializeField]
	private TMP_Text text;

	// Token: 0x04000035 RID: 53
	private ControlManager controlManager;
}
