﻿using System;

// Token: 0x020000D2 RID: 210
public struct ovrAvatarControllerComponent
{
	// Token: 0x040007EF RID: 2031
	public ovrAvatarHandInputState inputState;

	// Token: 0x040007F0 RID: 2032
	public IntPtr renderComponent;
}
