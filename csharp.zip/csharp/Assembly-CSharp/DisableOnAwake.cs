﻿using System;
using UnityEngine;

// Token: 0x02000038 RID: 56
public class DisableOnAwake : MonoBehaviour
{
	// Token: 0x060001F0 RID: 496 RVA: 0x0000ADD4 File Offset: 0x00008FD4
	private void Start()
	{
		base.gameObject.SetActive(false);
	}
}
