﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

// Token: 0x02000061 RID: 97
public class PaperTarget : MonoBehaviour
{
	// Token: 0x06000393 RID: 915 RVA: 0x00017984 File Offset: 0x00015B84
	private void Start()
	{
		this.settingsManager = Object.FindObjectOfType<SettingsManager>();
		this.UpdatePaperType();
		this.SwitchBackLayer();
		GameEvents.current.onHolsterDraw += this.SwitchLayer;
		GameEvents.current.onHolster += this.SwitchBackLayer;
		GameEvents.current.onTargetTypeChange += this.UpdatePaperType;
		if (!this.liveScore)
		{
			if (this.scoreText != null)
			{
				this.scoreText.gameObject.SetActive(false);
			}
			GameEvents.current.onHolster += this.UnhideScore;
			GameEvents.current.onHolsterDraw += this.HideScore;
		}
		this.scores.Add(PaperTarget.TargetScore.Mike, 0);
		this.scores.Add(PaperTarget.TargetScore.Delta, 0);
		this.scores.Add(PaperTarget.TargetScore.Charlie, 0);
		this.scores.Add(PaperTarget.TargetScore.Alpha, 0);
		if (Object.FindObjectOfType<StagePlanner>())
		{
			this.SwitchLayer(this.objectToToggleLayer, "Default");
			if (this.objectsToToggleLayer.Length != 0)
			{
				foreach (GameObject gameObject in this.objectsToToggleLayer)
				{
					this.SwitchLayer(this.objectToToggleLayer, "Default");
				}
			}
		}
	}

	// Token: 0x06000394 RID: 916 RVA: 0x00017AC4 File Offset: 0x00015CC4
	private void SwitchLayer()
	{
		if (this.sceneSettings == null)
		{
			this.sceneSettings = Object.FindObjectOfType<SceneSettings>();
		}
		if (this.sceneSettings.sceneType == SceneSettings.SceneType.Comp && this.sceneSettings.status == SceneSettings.CompStatus.Cold)
		{
			return;
		}
		this.SwitchLayer(this.objectToToggleLayer, "SeeThrough");
		if (this.objectsToToggleLayer != null && this.objectsToToggleLayer.Length != 0)
		{
			foreach (GameObject gameObject in this.objectsToToggleLayer)
			{
				if (gameObject != null)
				{
					this.SwitchLayer(gameObject, "SeeThrough");
				}
			}
		}
	}

	// Token: 0x06000395 RID: 917 RVA: 0x00017B58 File Offset: 0x00015D58
	private void SwitchBackLayer()
	{
		this.SwitchLayer(this.objectToToggleLayer, "Default");
		if (this.objectsToToggleLayer != null && this.objectsToToggleLayer.Length != 0)
		{
			foreach (GameObject switchObject in this.objectsToToggleLayer)
			{
				this.SwitchLayer(switchObject, "Default");
			}
		}
	}

	// Token: 0x06000396 RID: 918 RVA: 0x00017BAC File Offset: 0x00015DAC
	private void SwitchLayer(GameObject switchObject, string layerName)
	{
		switchObject.layer = LayerMask.NameToLayer(layerName);
	}

	// Token: 0x06000397 RID: 919 RVA: 0x00017BBA File Offset: 0x00015DBA
	public int RoundCount()
	{
		if (this.targetMode == PaperTarget.TargetMode.Classic)
		{
			return 2;
		}
		return this.countBestOfShots;
	}

	// Token: 0x06000398 RID: 920 RVA: 0x00017BCC File Offset: 0x00015DCC
	private void UpdatePaperType()
	{
		if (this.paperObjectUSPSA == null || this.paperObjectIPSC == null)
		{
			return;
		}
		if (this.settingsManager.paperType == SettingsManager.PaperType.IPSC)
		{
			this.paperObjectIPSC.SetActive(true);
			this.paperObjectUSPSA.SetActive(false);
			return;
		}
		this.paperObjectIPSC.SetActive(false);
		this.paperObjectUSPSA.SetActive(true);
	}

	// Token: 0x06000399 RID: 921 RVA: 0x00017C34 File Offset: 0x00015E34
	public void Score(Vector3 hitPos, float size, int muzzleEnergy)
	{
		Collider[] array = Physics.OverlapSphere(hitPos, size / 2f);
		if (muzzleEnergy > 615)
		{
			this.major = true;
		}
		else
		{
			this.major = false;
		}
		Collider[] array2 = array;
		for (int i = 0; i < array2.Length; i++)
		{
			string tag = array2[i].gameObject.tag;
			if (tag == "Alpha")
			{
				this.alphaHit = true;
			}
			if (tag == "Charlie")
			{
				this.charlieHit = true;
			}
			if (tag == "Delta")
			{
				this.deltaHit = true;
			}
			if (tag == "Mike")
			{
				this.mikeHit = true;
			}
		}
		this.ScoreCalculation();
		this.ScoreUpdate();
	}

	// Token: 0x0600039A RID: 922 RVA: 0x00017CE0 File Offset: 0x00015EE0
	private void ScoreCalculation()
	{
		if (this.alphaHit)
		{
			this.scores[PaperTarget.TargetScore.Alpha] = this.scores[PaperTarget.TargetScore.Alpha] + 1;
			return;
		}
		if (this.charlieHit)
		{
			this.scores[PaperTarget.TargetScore.Charlie] = this.scores[PaperTarget.TargetScore.Charlie] + 1;
			return;
		}
		if (this.deltaHit)
		{
			this.scores[PaperTarget.TargetScore.Delta] = this.scores[PaperTarget.TargetScore.Delta] + 1;
			return;
		}
		if (this.mikeHit)
		{
			this.scores[PaperTarget.TargetScore.Mike] = this.scores[PaperTarget.TargetScore.Mike] + 1;
		}
	}

	// Token: 0x0600039B RID: 923 RVA: 0x00017D78 File Offset: 0x00015F78
	public int GetMisses()
	{
		if (this.noShoot)
		{
			return 0;
		}
		int num = this.RoundCount() - this.alphaCount - this.charlieCount - this.deltaCount;
		if (num <= 0)
		{
			num = 0;
		}
		return num;
	}

	// Token: 0x0600039C RID: 924 RVA: 0x00017DB4 File Offset: 0x00015FB4
	public int GetScore(PaperTarget.TargetScore type = PaperTarget.TargetScore.None)
	{
		if (type != PaperTarget.TargetScore.None)
		{
			switch (type)
			{
			case PaperTarget.TargetScore.Alpha:
				return this.scores[PaperTarget.TargetScore.Alpha];
			case PaperTarget.TargetScore.Charlie:
				return this.scores[PaperTarget.TargetScore.Charlie];
			case PaperTarget.TargetScore.Delta:
				return this.scores[PaperTarget.TargetScore.Delta];
			case PaperTarget.TargetScore.NoShoot:
				return this.noShootCount;
			}
		}
		return this.targetScore;
	}

	// Token: 0x0600039D RID: 925 RVA: 0x00017E18 File Offset: 0x00016018
	private void ScoreUpdate()
	{
		if (this.noShoot)
		{
			if (this.alphaHit || this.charlieHit || this.deltaHit)
			{
				this.noShootCount++;
				if (this.noShootCount >= 2)
				{
					this.noShootCount = 2;
				}
			}
			return;
		}
		this.alphaHit = false;
		this.charlieHit = false;
		this.deltaHit = false;
		this.mikeHit = false;
		int num = 5;
		int num2;
		int num3;
		if (this.major)
		{
			num2 = 4;
			num3 = 2;
		}
		else
		{
			num2 = 3;
			num3 = 1;
		}
		if (this.targetMode == PaperTarget.TargetMode.Classic || this.targetMode == PaperTarget.TargetMode.ClassicExtra)
		{
			if (this.targetMode == PaperTarget.TargetMode.Classic)
			{
				this.maxResultsToShow = 2;
			}
			else
			{
				this.maxResultsToShow = this.countBestOfShots;
			}
			this.alphaCount = this.scores[PaperTarget.TargetScore.Alpha];
			this.charlieCount = this.scores[PaperTarget.TargetScore.Charlie];
			this.deltaCount = this.scores[PaperTarget.TargetScore.Delta];
			if (this.alphaCount >= this.maxResultsToShow)
			{
				this.alphaCount = this.maxResultsToShow;
			}
			if (this.charlieCount >= this.maxResultsToShow)
			{
				this.charlieCount = this.maxResultsToShow;
			}
			if (this.deltaCount >= this.maxResultsToShow)
			{
				this.deltaCount = this.maxResultsToShow;
			}
			this.alphaToDisplay = "";
			this.charlieToDisplay = "";
			this.deltaToDisplay = "";
			this.targetScore = 0;
			if (this.alphaCount > 0)
			{
				this.maxResultsToShow -= this.alphaCount;
				this.alphaToDisplay = this.ScoreToString(PaperTarget.TargetScore.Alpha, this.alphaCount);
				this.targetScore += this.alphaCount * num;
			}
			if (this.charlieCount > 0 && this.maxResultsToShow > 0)
			{
				if (this.charlieCount > this.maxResultsToShow)
				{
					this.charlieCount = this.maxResultsToShow;
				}
				this.maxResultsToShow -= this.charlieCount;
				this.charlieToDisplay = this.ScoreToString(PaperTarget.TargetScore.Charlie, this.charlieCount);
				this.targetScore += this.charlieCount * num2;
			}
			if (this.deltaCount > 0 && this.maxResultsToShow > 0)
			{
				if (this.deltaCount > this.maxResultsToShow)
				{
					this.deltaCount = this.maxResultsToShow;
				}
				this.maxResultsToShow -= this.deltaCount;
				this.deltaToDisplay = this.ScoreToString(PaperTarget.TargetScore.Delta, this.deltaCount);
				this.targetScore += this.deltaCount * num3;
			}
		}
		if (this.targetMode == PaperTarget.TargetMode.CountAll)
		{
			if (this.scores[PaperTarget.TargetScore.Alpha] > 0)
			{
				this.alphaToDisplay = this.ScoreToString(PaperTarget.TargetScore.Alpha, this.scores[PaperTarget.TargetScore.Alpha]);
			}
			if (this.scores[PaperTarget.TargetScore.Charlie] > 0)
			{
				this.charlieToDisplay = this.ScoreToString(PaperTarget.TargetScore.Charlie, this.scores[PaperTarget.TargetScore.Charlie]);
			}
			if (this.scores[PaperTarget.TargetScore.Delta] > 0)
			{
				this.deltaToDisplay = this.ScoreToString(PaperTarget.TargetScore.Delta, this.scores[PaperTarget.TargetScore.Delta]);
			}
			if (this.scores[PaperTarget.TargetScore.Mike] > 0)
			{
				this.mikeToDisplay = this.ScoreToString(PaperTarget.TargetScore.Mike, this.scores[PaperTarget.TargetScore.Mike]);
			}
		}
		this.DisplayScore(this.alphaToDisplay, this.charlieToDisplay, this.deltaToDisplay, this.mikeToDisplay);
	}

	// Token: 0x0600039E RID: 926 RVA: 0x00018150 File Offset: 0x00016350
	private string ScoreToString(PaperTarget.TargetScore type, int hits)
	{
		switch (type)
		{
		case PaperTarget.TargetScore.Alpha:
			return "\nAlpha x " + hits;
		case PaperTarget.TargetScore.Charlie:
			return "\nCharlie x " + hits;
		case PaperTarget.TargetScore.Delta:
			return "\nDelta x " + hits;
		case PaperTarget.TargetScore.Mike:
			return "\nEdgeMike x " + hits;
		default:
			return "";
		}
	}

	// Token: 0x0600039F RID: 927 RVA: 0x000181C0 File Offset: 0x000163C0
	public int GetCountedHits(PaperTarget.TargetScore scoreType, bool getCounted)
	{
		int result = 0;
		int result2 = 0;
		int result3 = 0;
		int result4 = 0;
		int result5 = 0;
		int result6 = 0;
		this.alphaCount = this.scores[PaperTarget.TargetScore.Alpha];
		this.charlieCount = this.scores[PaperTarget.TargetScore.Charlie];
		this.deltaCount = this.scores[PaperTarget.TargetScore.Delta];
		if (this.targetMode == PaperTarget.TargetMode.Classic || this.targetMode == PaperTarget.TargetMode.ClassicExtra)
		{
			if (this.targetMode == PaperTarget.TargetMode.Classic)
			{
				this.maxResultsToShow = 2;
			}
			else
			{
				this.maxResultsToShow = this.countBestOfShots;
			}
			if (this.alphaCount > 0)
			{
				if (this.alphaCount >= this.maxResultsToShow)
				{
					if (this.alphaCount > this.maxResultsToShow)
					{
						result4 = this.alphaCount - this.maxResultsToShow;
					}
					result = this.maxResultsToShow;
				}
				else
				{
					result = this.alphaCount;
				}
				this.maxResultsToShow -= this.alphaCount;
			}
			if (this.maxResultsToShow <= 0 && (this.charlieCount > 0 || this.deltaCount > 0))
			{
				result5 = this.charlieCount;
				result6 = this.deltaCount;
			}
			if (this.charlieCount > 0 && this.maxResultsToShow > 0)
			{
				if (this.charlieCount >= this.maxResultsToShow)
				{
					if (this.charlieCount > this.maxResultsToShow)
					{
						result5 = this.charlieCount - this.maxResultsToShow;
						result2 = this.maxResultsToShow;
					}
					else
					{
						result2 = this.maxResultsToShow;
					}
				}
				else
				{
					result2 = this.charlieCount;
				}
				this.maxResultsToShow -= this.charlieCount;
			}
			if (this.maxResultsToShow <= 0 && this.deltaCount > 0)
			{
				result6 = this.deltaCount;
			}
			if (this.deltaCount > 0 && this.maxResultsToShow > 0)
			{
				if (this.deltaCount >= this.maxResultsToShow)
				{
					if (this.deltaCount > this.maxResultsToShow)
					{
						result6 = this.deltaCount - this.maxResultsToShow;
						result3 = this.maxResultsToShow;
					}
					else
					{
						result3 = this.maxResultsToShow;
					}
				}
				else
				{
					result3 = this.deltaCount;
					this.maxResultsToShow -= this.deltaCount;
				}
				this.maxResultsToShow -= this.deltaCount;
			}
		}
		if (scoreType == PaperTarget.TargetScore.Alpha)
		{
			if (getCounted)
			{
				return result;
			}
			return result4;
		}
		else if (scoreType == PaperTarget.TargetScore.Charlie)
		{
			if (getCounted)
			{
				return result2;
			}
			return result5;
		}
		else
		{
			if (scoreType != PaperTarget.TargetScore.Delta)
			{
				return 0;
			}
			if (getCounted)
			{
				return result3;
			}
			return result6;
		}
	}

	// Token: 0x060003A0 RID: 928 RVA: 0x00003297 File Offset: 0x00001497
	private void DisplayScore(string m, string d, string c, string a)
	{
	}

	// Token: 0x060003A1 RID: 929 RVA: 0x000183E8 File Offset: 0x000165E8
	private void HideScore()
	{
		if (base.GetComponentInChildren<TargetReaction>())
		{
			SceneSettings sceneSettings = Object.FindObjectOfType<SceneSettings>();
			if (sceneSettings.sceneType != SceneSettings.SceneType.Comp || (sceneSettings.sceneType == SceneSettings.SceneType.Comp && sceneSettings.status != SceneSettings.CompStatus.Cold))
			{
				TargetReaction[] componentsInChildren = base.GetComponentsInChildren<TargetReaction>();
				for (int i = 0; i < componentsInChildren.Length; i++)
				{
					componentsInChildren[i].ToggleHitIndicator(false);
				}
			}
		}
	}

	// Token: 0x060003A2 RID: 930 RVA: 0x00018440 File Offset: 0x00016640
	private void UnhideScore()
	{
		if (base.GetComponentInChildren<TargetReaction>())
		{
			TargetReaction[] componentsInChildren = base.GetComponentsInChildren<TargetReaction>();
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].ToggleHitIndicator(true);
			}
		}
	}

	// Token: 0x060003A3 RID: 931 RVA: 0x00018478 File Offset: 0x00016678
	private void ToggleHitIndicator(GameObject hitIndicator)
	{
		if (hitIndicator.tag == "HitIndicator" && (this.sceneSettings.sceneType != SceneSettings.SceneType.Comp || (this.sceneSettings.sceneType == SceneSettings.SceneType.Comp && this.sceneSettings.status != SceneSettings.CompStatus.Cold)))
		{
			hitIndicator.GetComponent<TargetReaction>().ToggleHitIndicator(false);
		}
	}

	// Token: 0x060003A4 RID: 932 RVA: 0x000184CC File Offset: 0x000166CC
	private void OnDestroy()
	{
		if (!this.liveScore)
		{
			GameEvents.current.onHolster -= this.UnhideScore;
			GameEvents.current.onHolsterDraw -= this.HideScore;
		}
		GameEvents.current.onHolsterDraw -= this.SwitchLayer;
		GameEvents.current.onHolster -= this.SwitchBackLayer;
		GameEvents.current.onTargetTypeChange -= this.UpdatePaperType;
	}

	// Token: 0x04000452 RID: 1106
	[SerializeField]
	private TMP_Text scoreText;

	// Token: 0x04000453 RID: 1107
	[SerializeField]
	private PaperTarget.TargetMode targetMode = PaperTarget.TargetMode.CountAll;

	// Token: 0x04000454 RID: 1108
	[SerializeField]
	private int countBestOfShots = 4;

	// Token: 0x04000455 RID: 1109
	[SerializeField]
	private bool liveScore;

	// Token: 0x04000456 RID: 1110
	[SerializeField]
	private GameObject paperObjectIPSC;

	// Token: 0x04000457 RID: 1111
	[SerializeField]
	private GameObject paperObjectUSPSA;

	// Token: 0x04000458 RID: 1112
	[SerializeField]
	public bool noShoot;

	// Token: 0x04000459 RID: 1113
	[SerializeField]
	public bool dormant;

	// Token: 0x0400045A RID: 1114
	[Header("Stage Planner")]
	[SerializeField]
	private GameObject objectToToggleLayer;

	// Token: 0x0400045B RID: 1115
	[SerializeField]
	private GameObject[] objectsToToggleLayer;

	// Token: 0x0400045C RID: 1116
	public int targetScore;

	// Token: 0x0400045D RID: 1117
	private Dictionary<PaperTarget.TargetScore, int> scores = new Dictionary<PaperTarget.TargetScore, int>();

	// Token: 0x0400045E RID: 1118
	private bool alphaHit;

	// Token: 0x0400045F RID: 1119
	private bool charlieHit;

	// Token: 0x04000460 RID: 1120
	private bool deltaHit;

	// Token: 0x04000461 RID: 1121
	private bool mikeHit;

	// Token: 0x04000462 RID: 1122
	private bool major;

	// Token: 0x04000463 RID: 1123
	private string alphaToDisplay;

	// Token: 0x04000464 RID: 1124
	private string charlieToDisplay;

	// Token: 0x04000465 RID: 1125
	private string deltaToDisplay;

	// Token: 0x04000466 RID: 1126
	private string mikeToDisplay;

	// Token: 0x04000467 RID: 1127
	private int alphaCount;

	// Token: 0x04000468 RID: 1128
	private int charlieCount;

	// Token: 0x04000469 RID: 1129
	private int deltaCount;

	// Token: 0x0400046A RID: 1130
	private int mikeCount;

	// Token: 0x0400046B RID: 1131
	private int noShootCount;

	// Token: 0x0400046C RID: 1132
	private int finalAlphaCount;

	// Token: 0x0400046D RID: 1133
	private int finalCharlieCount;

	// Token: 0x0400046E RID: 1134
	private int finalDeltaCount;

	// Token: 0x0400046F RID: 1135
	private int finalMikeCount;

	// Token: 0x04000470 RID: 1136
	private int maxResultsToShow;

	// Token: 0x04000471 RID: 1137
	private SceneSettings sceneSettings;

	// Token: 0x04000472 RID: 1138
	private SettingsManager settingsManager;

	// Token: 0x020001D4 RID: 468
	public enum TargetScore
	{
		// Token: 0x04000DD0 RID: 3536
		Alpha,
		// Token: 0x04000DD1 RID: 3537
		Charlie,
		// Token: 0x04000DD2 RID: 3538
		Delta,
		// Token: 0x04000DD3 RID: 3539
		Mike,
		// Token: 0x04000DD4 RID: 3540
		NoShoot,
		// Token: 0x04000DD5 RID: 3541
		None
	}

	// Token: 0x020001D5 RID: 469
	public enum TargetMode
	{
		// Token: 0x04000DD7 RID: 3543
		Classic,
		// Token: 0x04000DD8 RID: 3544
		ClassicExtra,
		// Token: 0x04000DD9 RID: 3545
		CountAll
	}
}
