﻿using System;
using UnityEngine;

// Token: 0x02000096 RID: 150
public class UnparentOnLoad : MonoBehaviour
{
	// Token: 0x0600050C RID: 1292 RVA: 0x00020CE8 File Offset: 0x0001EEE8
	private void Start()
	{
		if (!this.disable)
		{
			base.transform.parent = null;
		}
	}

	// Token: 0x04000648 RID: 1608
	[SerializeField]
	private bool disable;
}
