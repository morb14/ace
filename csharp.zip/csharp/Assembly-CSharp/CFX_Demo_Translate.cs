﻿using System;
using UnityEngine;

// Token: 0x02000014 RID: 20
public class CFX_Demo_Translate : MonoBehaviour
{
	// Token: 0x06000055 RID: 85 RVA: 0x0000368C File Offset: 0x0000188C
	private void Start()
	{
		this.dir = new Vector3(Random.Range(0f, 360f), Random.Range(0f, 360f), Random.Range(0f, 360f));
		this.dir.Scale(this.rotation);
		base.transform.localEulerAngles = this.dir;
	}

	// Token: 0x06000056 RID: 86 RVA: 0x000036F3 File Offset: 0x000018F3
	private void Update()
	{
		base.transform.Translate(this.axis * this.speed * Time.deltaTime, Space.Self);
	}

	// Token: 0x04000042 RID: 66
	public float speed = 30f;

	// Token: 0x04000043 RID: 67
	public Vector3 rotation = Vector3.forward;

	// Token: 0x04000044 RID: 68
	public Vector3 axis = Vector3.forward;

	// Token: 0x04000045 RID: 69
	public bool gravity;

	// Token: 0x04000046 RID: 70
	private Vector3 dir;
}
