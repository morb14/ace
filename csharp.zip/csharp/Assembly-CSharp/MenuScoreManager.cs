﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000076 RID: 118
public class MenuScoreManager : MonoBehaviour
{
	// Token: 0x0600045A RID: 1114 RVA: 0x0001D690 File Offset: 0x0001B890
	private void Start()
	{
		this.compMenus = this.compMenuObject.GetComponentsInChildren<CompMenu>(true);
		MonoBehaviour.print("compMenu " + this.compMenus.Length);
		this.saveManager = Object.FindObjectOfType<SaveManager>();
		this.LoadResults();
	}

	// Token: 0x0600045B RID: 1115 RVA: 0x0001D6DC File Offset: 0x0001B8DC
	private void LoadResults()
	{
		foreach (CompMenu compMenu in this.compMenus)
		{
			SaveManager.ResultList resultList = this.saveManager.LoadResults(compMenu.stageID);
			if (resultList != null)
			{
				this.topScore.Add(compMenu.stageID, resultList);
			}
		}
	}

	// Token: 0x0600045C RID: 1116 RVA: 0x0001D72C File Offset: 0x0001B92C
	public SaveManager.ResultList GetTopScore(string stageID)
	{
		SaveManager.ResultList result;
		this.topScore.TryGetValue(stageID, out result);
		return result;
	}

	// Token: 0x0400058E RID: 1422
	[SerializeField]
	private GameObject compMenuObject;

	// Token: 0x0400058F RID: 1423
	public CompMenu[] compMenus;

	// Token: 0x04000590 RID: 1424
	private Dictionary<string, SaveManager.ResultList> topScore = new Dictionary<string, SaveManager.ResultList>();

	// Token: 0x04000591 RID: 1425
	private SaveManager saveManager;
}
