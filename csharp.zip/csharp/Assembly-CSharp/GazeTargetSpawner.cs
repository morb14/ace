﻿using System;
using UnityEngine;

// Token: 0x020000A0 RID: 160
public class GazeTargetSpawner : MonoBehaviour
{
	// Token: 0x17000007 RID: 7
	// (get) Token: 0x0600054D RID: 1357 RVA: 0x00021EC2 File Offset: 0x000200C2
	// (set) Token: 0x0600054E RID: 1358 RVA: 0x00021ECC File Offset: 0x000200CC
	public bool IsVisible
	{
		get
		{
			return this.isVisible;
		}
		set
		{
			this.isVisible = value;
			GazeTarget[] componentsInChildren = base.gameObject.GetComponentsInChildren<GazeTarget>();
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				MeshRenderer component = componentsInChildren[i].GetComponent<MeshRenderer>();
				if (component != null)
				{
					component.enabled = this.isVisible;
				}
			}
		}
	}

	// Token: 0x0600054F RID: 1359 RVA: 0x00021F18 File Offset: 0x00020118
	private void Start()
	{
		for (int i = 0; i < this.NumberOfDummyTargets; i++)
		{
			GameObject gameObject = Object.Instantiate<GameObject>(this.GazeTargetPrefab, base.transform);
			gameObject.name = gameObject.name + "_" + i;
			gameObject.transform.localPosition = Random.insideUnitSphere * (float)this.RadiusMultiplier;
			gameObject.transform.rotation = Quaternion.identity;
			gameObject.GetComponent<MeshRenderer>().enabled = this.IsVisible;
		}
	}

	// Token: 0x06000550 RID: 1360 RVA: 0x00021F9F File Offset: 0x0002019F
	private void OnValidate()
	{
		this.IsVisible = this.isVisible;
	}

	// Token: 0x04000672 RID: 1650
	public GameObject GazeTargetPrefab;

	// Token: 0x04000673 RID: 1651
	public int NumberOfDummyTargets = 100;

	// Token: 0x04000674 RID: 1652
	public int RadiusMultiplier = 3;

	// Token: 0x04000675 RID: 1653
	[SerializeField]
	private bool isVisible;
}
