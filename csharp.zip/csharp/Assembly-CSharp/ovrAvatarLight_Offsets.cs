﻿using System;
using System.Runtime.InteropServices;

// Token: 0x020000F2 RID: 242
internal struct ovrAvatarLight_Offsets
{
	// Token: 0x0400088D RID: 2189
	public static long id = Marshal.OffsetOf(typeof(ovrAvatarLight), "id").ToInt64();

	// Token: 0x0400088E RID: 2190
	public static long type = Marshal.OffsetOf(typeof(ovrAvatarLight), "type").ToInt64();

	// Token: 0x0400088F RID: 2191
	public static long intensity = Marshal.OffsetOf(typeof(ovrAvatarLight), "intensity").ToInt64();

	// Token: 0x04000890 RID: 2192
	public static long worldDirection = Marshal.OffsetOf(typeof(ovrAvatarLight), "worldDirection").ToInt64();

	// Token: 0x04000891 RID: 2193
	public static long worldPosition = Marshal.OffsetOf(typeof(ovrAvatarLight), "worldPosition").ToInt64();

	// Token: 0x04000892 RID: 2194
	public static long range = Marshal.OffsetOf(typeof(ovrAvatarLight), "range").ToInt64();

	// Token: 0x04000893 RID: 2195
	public static long spotAngleDeg = Marshal.OffsetOf(typeof(ovrAvatarLight), "spotAngleDeg").ToInt64();
}
