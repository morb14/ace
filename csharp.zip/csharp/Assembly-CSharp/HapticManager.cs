﻿using System;
using System.Collections;
using UnityEngine;

// Token: 0x0200002D RID: 45
public class HapticManager : MonoBehaviour
{
	// Token: 0x0600018E RID: 398 RVA: 0x0000866C File Offset: 0x0000686C
	public void VibrateAudio(AudioClip vibrationAudio, OVRInput.Controller controller)
	{
		OVRHapticsClip clip = new OVRHapticsClip(vibrationAudio, 0);
		if (controller == OVRInput.Controller.LTouch)
		{
			OVRHaptics.LeftChannel.Preempt(clip);
			return;
		}
		if (controller == OVRInput.Controller.RTouch)
		{
			OVRHaptics.RightChannel.Preempt(clip);
		}
	}

	// Token: 0x0600018F RID: 399 RVA: 0x000086A0 File Offset: 0x000068A0
	public void VibrationStop(OVRInput.Controller controller)
	{
		if (controller == OVRInput.Controller.LTouch || controller == OVRInput.Controller.RTouch || controller == OVRInput.Controller.Active)
		{
			OVRInput.SetControllerVibration(0f, 0f, controller);
		}
	}

	// Token: 0x06000190 RID: 400 RVA: 0x000086C2 File Offset: 0x000068C2
	public void VibrateStandard(float frequency = 0.5f, float amplitude = 0.5f, float duration = 0.5f, OVRInput.Controller controller = OVRInput.Controller.Active)
	{
		base.StartCoroutine(this.Haptics(frequency, amplitude, duration, controller));
	}

	// Token: 0x06000191 RID: 401 RVA: 0x000086D6 File Offset: 0x000068D6
	private IEnumerator Haptics(float frequency = 0.5f, float amplitude = 0.5f, float duration = 0.5f, OVRInput.Controller controller = OVRInput.Controller.Active)
	{
		if (controller == OVRInput.Controller.LTouch || controller == OVRInput.Controller.RTouch || controller == OVRInput.Controller.Active)
		{
			OVRInput.SetControllerVibration(frequency, amplitude, controller);
		}
		yield return new WaitForSeconds(duration);
		if (controller == OVRInput.Controller.LTouch || controller == OVRInput.Controller.RTouch)
		{
			OVRInput.SetControllerVibration(0f, 0f, controller);
		}
		yield break;
	}

	// Token: 0x0400012A RID: 298
	private bool vibrating;
}
