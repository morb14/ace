﻿using System;

// Token: 0x02000124 RID: 292
public class TeleportOrientationHandler360 : TeleportOrientationHandler
{
	// Token: 0x0600079A RID: 1946 RVA: 0x00003297 File Offset: 0x00001497
	protected override void InitializeTeleportDestination()
	{
	}

	// Token: 0x0600079B RID: 1947 RVA: 0x0002F180 File Offset: 0x0002D380
	protected override void UpdateTeleportDestination()
	{
		base.LocomotionTeleport.OnUpdateTeleportDestination(this.AimData.TargetValid, this.AimData.Destination, null, null);
	}
}
