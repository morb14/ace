﻿using System;

// Token: 0x020000BC RID: 188
public enum ovrAvatarMessageType
{
	// Token: 0x04000765 RID: 1893
	AvatarSpecification,
	// Token: 0x04000766 RID: 1894
	AssetLoaded,
	// Token: 0x04000767 RID: 1895
	Count
}
