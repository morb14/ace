﻿using System;
using UnityEngine;

// Token: 0x0200004A RID: 74
public class RendererEnabler : MonoBehaviour
{
	// Token: 0x06000250 RID: 592 RVA: 0x0000D064 File Offset: 0x0000B264
	private void Start()
	{
		GameEvents.current.onStickRelease += this.OnStickRelease;
		GameEvents.current.onStickForward += this.OnStickForward;
		this.meshRenderer = base.GetComponent<MeshRenderer>();
		this.meshRenderer.enabled = false;
	}

	// Token: 0x06000251 RID: 593 RVA: 0x0000D0B5 File Offset: 0x0000B2B5
	private void LateUpdate()
	{
		if (this.active)
		{
			this.MaterialCheck();
		}
	}

	// Token: 0x06000252 RID: 594 RVA: 0x0000D0C5 File Offset: 0x0000B2C5
	private void OnStickForward()
	{
		this.active = true;
		this.meshRenderer.enabled = true;
	}

	// Token: 0x06000253 RID: 595 RVA: 0x0000D0DA File Offset: 0x0000B2DA
	private void OnStickRelease()
	{
		this.active = false;
		this.meshRenderer.enabled = false;
	}

	// Token: 0x06000254 RID: 596 RVA: 0x0000D0EF File Offset: 0x0000B2EF
	private void MaterialCheck()
	{
		if (this.highlighted)
		{
			this.meshRenderer.material = this.selectMaterial;
		}
		else
		{
			this.meshRenderer.material = this.defaultMaterial;
		}
		this.highlighted = false;
	}

	// Token: 0x06000255 RID: 597 RVA: 0x0000D124 File Offset: 0x0000B324
	public void Highlighted()
	{
		this.highlighted = true;
	}

	// Token: 0x06000256 RID: 598 RVA: 0x0000D12D File Offset: 0x0000B32D
	private void OnDestroy()
	{
		GameEvents.current.onStickRelease -= this.OnStickRelease;
		GameEvents.current.onStickForward -= this.OnStickForward;
	}

	// Token: 0x04000232 RID: 562
	[SerializeField]
	private Material defaultMaterial;

	// Token: 0x04000233 RID: 563
	[SerializeField]
	private Material selectMaterial;

	// Token: 0x04000234 RID: 564
	private MeshRenderer meshRenderer;

	// Token: 0x04000235 RID: 565
	private bool active;

	// Token: 0x04000236 RID: 566
	private bool highlighted;
}
