﻿using System;

// Token: 0x020000BE RID: 190
public struct ovrAvatarMessage_AssetLoaded
{
	// Token: 0x0400076A RID: 1898
	public ulong assetID;

	// Token: 0x0400076B RID: 1899
	public IntPtr asset;
}
