﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

// Token: 0x02000053 RID: 83
public class WeaponController : MonoBehaviour
{
	// Token: 0x060002DD RID: 733 RVA: 0x00010F20 File Offset: 0x0000F120
	private void Start()
	{
		this.gameManager = Object.FindObjectOfType<GameManager>();
		this.settingsManager = this.gameManager.GetComponent<SettingsManager>();
		this.objectManager = this.gameManager.GetComponent<ObjectManager>();
		this.controlManager = this.gameManager.GetComponent<ControlManager>();
		this.hapticManager = this.gameManager.GetComponent<HapticManager>();
		this.playerData = this.gameManager.GetComponent<PlayerData>();
		this.audioSource = base.gameObject.AddComponent<AudioSource>();
		if (base.GetComponentInParent<HolsterControl>())
		{
			this.holsterControl = base.GetComponentInParent<HolsterControl>();
		}
		if (this.animator == null)
		{
			this.animator = base.GetComponentInChildren<Animator>();
		}
		if (this.conditionTest)
		{
			if (this.testPro != null)
			{
				this.testPro.enabled = true;
			}
		}
		else if (this.testPro != null)
		{
			this.testPro.enabled = false;
		}
		GameEvents.current.onHolsterDraw += this.OnHolsterDraw;
		this.currentMagazineMax = this.magazineCapacity;
		this.doubleActionReset = true;
		this.audioSource.spatialBlend = 1f;
		this.lastPos = Vector3.zero;
		this.InitiatePresets();
		this.Load();
	}

	// Token: 0x060002DE RID: 734 RVA: 0x00011060 File Offset: 0x0000F260
	private void OnHolsterDraw()
	{
		if (this.settingsManager.triggerBreakOverride != 0f || this.settingsManager.triggerResetOverride != 0f)
		{
			this.triggerWallPositionTemp = this.settingsManager.triggerBreakOverride;
			this.triggerResetPositionTemp = this.settingsManager.triggerResetOverride;
			return;
		}
		this.triggerWallPositionTemp = this.triggerWallPosition;
		this.triggerResetPositionTemp = this.triggerResetPosition;
	}

	// Token: 0x060002DF RID: 735 RVA: 0x000110CC File Offset: 0x0000F2CC
	private void InitiatePresets()
	{
		if (this.presets.Length <= 1)
		{
			return;
		}
		if (this.startPreset == "")
		{
			this.currentPreset = this.presets[0];
			return;
		}
		this.currentPreset = this.GetPreset(this.startPreset);
		this.ChoosePreset(this.currentPreset);
	}

	// Token: 0x060002E0 RID: 736 RVA: 0x00011124 File Offset: 0x0000F324
	public WeaponController.Preset GetPreset(string name)
	{
		foreach (WeaponController.Preset preset in this.presets)
		{
			if (preset.presetName == name)
			{
				return preset;
			}
		}
		return null;
	}

	// Token: 0x060002E1 RID: 737 RVA: 0x0001115C File Offset: 0x0000F35C
	public void CyclePreset(bool includeLocked = false)
	{
		int num = 0;
		int num2 = 0;
		for (int i = 0; i < this.presets.Length; i++)
		{
			if (this.presets[i] == this.currentPreset)
			{
				num = i;
			}
			num2 = num + 1;
			if (num2 >= this.presets.Length)
			{
				num2 = 0;
			}
			if (!this.presets[num2].unlocked)
			{
				num++;
			}
		}
		this.ChoosePreset(this.presets[num2]);
	}

	// Token: 0x060002E2 RID: 738 RVA: 0x000111C4 File Offset: 0x0000F3C4
	public void ChoosePreset(WeaponController.Preset chosenPreset)
	{
		if (chosenPreset == null)
		{
			return;
		}
		List<GameObject> list = new List<GameObject>();
		foreach (WeaponController.Preset preset in this.presets)
		{
			if (preset == chosenPreset)
			{
				foreach (GameObject gameObject in preset.presetParts)
				{
					list.Add(gameObject);
					gameObject.SetActive(true);
				}
				this.previousPreset = this.currentPreset;
				this.currentPreset = preset;
			}
			else
			{
				foreach (GameObject gameObject2 in preset.presetParts)
				{
					if (!list.Contains(gameObject2))
					{
						gameObject2.SetActive(false);
					}
				}
			}
		}
		list.Clear();
	}

	// Token: 0x060002E3 RID: 739 RVA: 0x0001127F File Offset: 0x0000F47F
	public Transform MuzzlePosition()
	{
		return this.muzzlePosition;
	}

	// Token: 0x060002E4 RID: 740 RVA: 0x00011287 File Offset: 0x0000F487
	public GameObject GetProjectile()
	{
		return this.projectilePrefab;
	}

	// Token: 0x060002E5 RID: 741 RVA: 0x0001128F File Offset: 0x0000F48F
	public int GetCurrentAmmo()
	{
		return this.currentAmmo;
	}

	// Token: 0x060002E6 RID: 742 RVA: 0x00011297 File Offset: 0x0000F497
	public int GetCurrentCapacity()
	{
		return this.magazineCapacity;
	}

	// Token: 0x060002E7 RID: 743 RVA: 0x000112A0 File Offset: 0x0000F4A0
	private void Load()
	{
		if (this.weaponType == WeaponController.WeaponType.Revolver)
		{
			this.currentAmmo = this.magazineCapacity;
			this.moonClip.SetActive(true);
			this.status = WeaponController.WeaponStatus.Loaded;
			this.Cock(false);
			return;
		}
		if (this.spawnStatus == WeaponController.WeaponStatus.Empty)
		{
			this.Cock(false);
			this.magazineToBeDisabled.SetActive(false);
			this.hasMagazine = false;
			this.currentAmmo = 0;
			this.pressCheckRound.enabled = false;
			return;
		}
		this.animator.SetLayerWeight(this.animator.GetLayerIndex("SlideMovement"), 0f);
		if (this.currentAmmo == 0)
		{
			this.currentAmmo = this.magazineCapacity + 1;
			this.status = WeaponController.WeaponStatus.Loaded;
		}
		if (base.GetComponent<AmmoTypeManager>())
		{
			this.hasAltAmmo = true;
			this.ammoTypeManager = base.GetComponent<AmmoTypeManager>();
			this.ammoTypeManager.InitiateRounds(this);
			this.defaultMaterial = this.ammoTypeManager.defaultAmmoMaterial;
			this.altMaterial = this.ammoTypeManager.altAmmoMaterial;
		}
		if (this.chokes.Length != 0)
		{
			foreach (GameObject gameObject in this.chokes)
			{
				if (gameObject.activeSelf)
				{
					this.chokeSpread = gameObject.GetComponent<AccessoryManager>().spread;
				}
			}
		}
		this.triggerReset = true;
		this.hasMagazine = true;
		this.shotgunRoundInLifter = true;
		this.Cock(true);
	}

	// Token: 0x060002E8 RID: 744 RVA: 0x000113F8 File Offset: 0x0000F5F8
	public bool IsSafe()
	{
		if (this.isDoubleAction)
		{
			if (!this.IsCocked())
			{
				return true;
			}
			if (this.hasSafety && this.cocked)
			{
				return this.safetyOn;
			}
		}
		return !this.hasSafety || !this.cocked || this.safetyOn;
	}

	// Token: 0x060002E9 RID: 745 RVA: 0x00011446 File Offset: 0x0000F646
	public bool IsCocked()
	{
		return this.weaponType != WeaponController.WeaponType.Revolver && this.cocked;
	}

	// Token: 0x060002EA RID: 746 RVA: 0x0001145C File Offset: 0x0000F65C
	private bool CanShoot()
	{
		return !this.safetyOn && (this.cocked || this.isDoubleAction) && this.animator.GetFloat("SlidePull") >= 0f && this.status != WeaponController.WeaponStatus.LoadedSlideLockedBack && this.status != WeaponController.WeaponStatus.SlideLockedBack && this.status != WeaponController.WeaponStatus.EmptySlideLockedBack;
	}

	// Token: 0x060002EB RID: 747 RVA: 0x000114BC File Offset: 0x0000F6BC
	private void TestFunctions()
	{
		if (this.testFire)
		{
			this.HammerDrop();
			this.testFire = false;
		}
		if (this.testShotgunReload)
		{
			this.ShotgunReload();
			this.testShotgunReload = false;
		}
		if (this.testBoltRelease)
		{
			this.SlideRelease();
			this.testBoltRelease = false;
		}
	}

	// Token: 0x060002EC RID: 748 RVA: 0x00011508 File Offset: 0x0000F708
	private void Update()
	{
		this.TestFunctions();
		if (this.testPro != null && this.conditionTest)
		{
			this.testPro.text = this.status.ToString();
			if (this.CanShoot())
			{
				this.testPro.fontStyle = FontStyles.Bold;
			}
			else
			{
				this.testPro.fontStyle = FontStyles.Normal;
			}
			if (!this.cocked)
			{
				TMP_Text tmp_Text = this.testPro;
				tmp_Text.text += " (Uncocked)";
			}
			else
			{
				this.testPro.text = this.status.ToString();
			}
			if (this.shotgunRoundInLifter)
			{
				TMP_Text tmp_Text2 = this.testPro;
				tmp_Text2.text += " (RIL)";
			}
			else
			{
				this.testPro.text = this.status.ToString();
			}
			Vector2 vector = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, this.controlManager.controller);
			TMP_Text tmp_Text3 = this.testPro;
			tmp_Text3.text = tmp_Text3.text + " " + this.currentAmmo;
			TMP_Text tmp_Text4 = this.testPro;
			tmp_Text4.text = string.Concat(new string[]
			{
				tmp_Text4.text,
				"\n",
				vector.y.ToString("F2"),
				"SB: ",
				this.slideBack.ToString()
			});
		}
		if (!this.holstered || this.testMode)
		{
			this.ShotgunReload();
			this.TapDetection();
			this.InputControl();
			this.MuzzleDetection();
		}
	}

	// Token: 0x060002ED RID: 749 RVA: 0x000116AA File Offset: 0x0000F8AA
	public bool IsHolstered()
	{
		return this.holstered;
	}

	// Token: 0x060002EE RID: 750 RVA: 0x000116B2 File Offset: 0x0000F8B2
	public void DisableControls(bool value)
	{
		if (value)
		{
			this.disableControls = true;
			return;
		}
		this.disableControls = false;
	}

	// Token: 0x060002EF RID: 751 RVA: 0x000116C6 File Offset: 0x0000F8C6
	public bool IsEquipped(bool equip = false)
	{
		if (equip != this.isEquipped)
		{
			this.isEquipped = equip;
		}
		return this.isEquipped;
	}

	// Token: 0x060002F0 RID: 752 RVA: 0x000116E0 File Offset: 0x0000F8E0
	private void InputControl()
	{
		if (!this.isEquipped && !this.testMode)
		{
			return;
		}
		if (this.disableControls)
		{
			return;
		}
		this.Decocking();
		this.ScopeAdjustment();
		this.TriggerControl();
		this.EjectMagazine();
		this.SlideManipulation();
		this.SafetyLever();
		this.SlideReleaseInput();
	}

	// Token: 0x060002F1 RID: 753 RVA: 0x00011734 File Offset: 0x0000F934
	private void Decocking()
	{
		if (this.isDoubleAction && this.IsCocked() && OVRInput.Get(OVRInput.Touch.PrimaryIndexTrigger, this.controlManager.controller) && OVRInput.GetDown(OVRInput.Button.Two, this.controlManager.controller))
		{
			this.animator.SetLayerWeight(this.animator.GetLayerIndex("DoubleAction"), 1f);
			this.audioSource.PlayOneShot(this.audioFireEmpty);
			this.doubleActionReset = true;
			this.Cock(false);
		}
	}

	// Token: 0x060002F2 RID: 754 RVA: 0x000117BC File Offset: 0x0000F9BC
	private void ScopeAdjustment()
	{
		if (OVRInput.GetDown(OVRInput.Button.PrimaryThumbstick, this.controlManager.controller) && this.optics.Length != 0 && this.optics[0].transform.parent.GetComponentInChildren<OpticZoomAdjustment>())
		{
			this.optics[0].transform.parent.GetComponentInChildren<OpticZoomAdjustment>().Adjustment();
		}
	}

	// Token: 0x060002F3 RID: 755 RVA: 0x00011824 File Offset: 0x0000FA24
	private void MuzzleDetection()
	{
		if (this.gameManager.GetSceneSettings() != null)
		{
			if (this.sceneSettings == null)
			{
				this.sceneSettings = this.gameManager.GetSceneSettings();
			}
			if (this.sceneSettings.downRange != null)
			{
				float num = WeaponController.WrapAngle(base.transform.eulerAngles.y) - WeaponController.WrapAngle(this.sceneSettings.downRange.eulerAngles.y);
				if (num < -90f || num > 90f)
				{
					if (this.timeToBreak90 == 0f)
					{
						GameEvents.current.Breaking90();
						return;
					}
					if (this.timeSinceBreaking90 == 0f)
					{
						this.timeSinceBreaking90 = Time.time;
					}
					if (Time.time > this.timeSinceBreaking90 + this.timeToBreak90)
					{
						GameEvents.current.Breaking90();
						return;
					}
				}
				else
				{
					this.timeSinceBreaking90 = 0f;
				}
			}
		}
	}

	// Token: 0x060002F4 RID: 756 RVA: 0x00011918 File Offset: 0x0000FB18
	private void SlideReleaseInput()
	{
		if (this.weaponType != WeaponController.WeaponType.ShotgunField)
		{
			if (this.status != WeaponController.WeaponStatus.SlideLockedBack && this.status != WeaponController.WeaponStatus.EmptySlideLockedBack && this.status != WeaponController.WeaponStatus.LoadedSlideLockedBack)
			{
				return;
			}
		}
		else if (this.status != WeaponController.WeaponStatus.SlideLockedBack && this.status != WeaponController.WeaponStatus.EmptySlideLockedBack && this.status != WeaponController.WeaponStatus.LoadedSlideLockedBack && this.status != WeaponController.WeaponStatus.EmptyRoundInChamber)
		{
			return;
		}
		if (OVRInput.GetDown(OVRInput.Button.Two, this.controlManager.controller))
		{
			this.SlideRelease();
		}
	}

	// Token: 0x060002F5 RID: 757 RVA: 0x00011988 File Offset: 0x0000FB88
	private static float WrapAngle(float angle)
	{
		angle %= 360f;
		if (angle > 180f)
		{
			return angle - 360f;
		}
		return angle;
	}

	// Token: 0x060002F6 RID: 758 RVA: 0x000119A4 File Offset: 0x0000FBA4
	private void SlideRelease()
	{
		if (this.weaponType == WeaponController.WeaponType.ShotgunField)
		{
			if (this.status == WeaponController.WeaponStatus.SlideLockedBack)
			{
				this.status = WeaponController.WeaponStatus.Empty;
				this.animator.SetLayerWeight(this.animator.GetLayerIndex("SlideMovement"), 0f);
				this.animator.SetTrigger("SlideRelease");
				return;
			}
			if (this.status == WeaponController.WeaponStatus.EmptyRoundInChamber)
			{
				this.status = WeaponController.WeaponStatus.Loaded;
				this.ShotgunReturnBolt(this.ammoTypeInLifter);
				return;
			}
		}
		else
		{
			if (this.status == WeaponController.WeaponStatus.SlideLockedBack)
			{
				this.status = WeaponController.WeaponStatus.EmptySlideForwardEmptyMag;
			}
			if (this.status == WeaponController.WeaponStatus.EmptySlideLockedBack)
			{
				this.status = WeaponController.WeaponStatus.Empty;
			}
			if (this.status == WeaponController.WeaponStatus.LoadedSlideLockedBack)
			{
				if (this.hasAltAmmo)
				{
					this.ammoTypeManager.Chamber();
				}
				GameEvents.current.SlideRelease();
				this.status = WeaponController.WeaponStatus.Loaded;
			}
		}
		this.animator.SetLayerWeight(this.animator.GetLayerIndex("SlideMovement"), 0f);
		this.animator.SetFloat("SlideLock", 0f);
		this.audioSource.PlayOneShot(this.audioSlideRelease);
		this.ManualSlideRelease();
		this.animator.SetFloat("SlidePull", 0f);
		this.ShowRound(0);
		this.animator.SetLayerWeight(this.animator.GetLayerIndex("SlideMovement"), 1f);
	}

	// Token: 0x060002F7 RID: 759 RVA: 0x00011AED File Offset: 0x0000FCED
	private WeaponController.CurrentTriggerStatus TriggerStatus(float triggerValue)
	{
		if (this.lastTriggerValue > triggerValue)
		{
			this.lastTriggerValue = triggerValue;
			return WeaponController.CurrentTriggerStatus.Released;
		}
		if (this.lastTriggerValue < triggerValue)
		{
			this.lastTriggerValue = triggerValue;
			return WeaponController.CurrentTriggerStatus.Pulled;
		}
		this.lastTriggerValue = triggerValue;
		return WeaponController.CurrentTriggerStatus.Stationary;
	}

	// Token: 0x060002F8 RID: 760 RVA: 0x00011B1C File Offset: 0x0000FD1C
	private void SafetyLever()
	{
		if (!this.hasSafety)
		{
			return;
		}
		Vector2 vector = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, this.controlManager.controller);
		if (!this.cocked)
		{
			return;
		}
		if (vector.x > 0.8f && !this.safetyOn)
		{
			this.SafetyToggle(true);
			return;
		}
		if (vector.x < -0.5f && this.safetyOn)
		{
			this.SafetyToggle(false);
		}
	}

	// Token: 0x060002F9 RID: 761 RVA: 0x00011B88 File Offset: 0x0000FD88
	private void SafetyToggle(bool on)
	{
		if (on)
		{
			this.animator.ResetTrigger("SafetyOff");
			this.animator.SetTrigger("SafetyOn");
			this.hapticManager.VibrateStandard(0.8f, 0.6f, 0.05f, this.controlManager.controller);
			this.audioSource.PlayOneShot(this.audioTriggerReset);
			GameEvents.current.SafetyOn();
			this.safetyOn = true;
			return;
		}
		this.animator.ResetTrigger("SafetyOn");
		this.animator.SetTrigger("SafetyOff");
		this.hapticManager.VibrateStandard(0.8f, 0.6f, 0.05f, this.controlManager.controller);
		GameEvents.current.SafetyOff();
		this.safetyOn = false;
	}

	// Token: 0x060002FA RID: 762 RVA: 0x00011C58 File Offset: 0x0000FE58
	private void SlideActionType(bool lockSlide, bool returnSlide, bool reduceAmmo)
	{
		this.audioSource.PlayOneShot(this.audioSlideRelease);
		if (lockSlide)
		{
			this.status = WeaponController.WeaponStatus.SlideLockedBack;
			this.animator.SetFloat("SlidePull", 1f);
		}
		if (!lockSlide)
		{
		}
		if (reduceAmmo)
		{
			this.currentAmmo--;
			this.EjectionEffect(this.roundEjection);
			if (this.hasAltAmmo)
			{
				this.ammoTypeManager.UseRoundInChamber();
			}
			this.pressCheckRound.enabled = false;
			this.ShowRound(1);
		}
	}

	// Token: 0x060002FB RID: 763 RVA: 0x00011CE0 File Offset: 0x0000FEE0
	private void EjectionEffect(ParticleSystem effect)
	{
		float d = 3f;
		float size = 1f;
		float lifetime = 2f;
		Color white = Color.white;
		if (this.hasAltAmmo)
		{
			effect.GetComponent<ParticleSystemRenderer>().material = this.ammoTypeManager.GetChamberRoundMaterial();
		}
		effect.Emit(effect.transform.position, this.roundEjection.transform.forward * d, size, lifetime, white);
		if (effect.GetComponentsInChildren<ParticleSystem>().Length != 0)
		{
			ParticleSystem[] componentsInChildren = effect.GetComponentsInChildren<ParticleSystem>();
			for (int i = 0; i < componentsInChildren.Length; i++)
			{
				componentsInChildren[i].Emit(effect.transform.position, this.roundEjection.transform.forward * d, size, lifetime, white);
			}
		}
	}

	// Token: 0x060002FC RID: 764 RVA: 0x00011DA9 File Offset: 0x0000FFA9
	public void ClearMagazines()
	{
		this.magazineQueue.Clear();
	}

	// Token: 0x060002FD RID: 765 RVA: 0x00011DB8 File Offset: 0x0000FFB8
	private void SlideManipulation()
	{
		Vector2 vector = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, this.controlManager.controller);
		if (this.testStick != Vector2.zero)
		{
			vector = this.testStick;
			if (this.testStick.x > 1f)
			{
				this.testStick.x = 1f;
			}
			if (this.testStick.x < -1f)
			{
				this.testStick.x = -1f;
			}
			if (this.testStick.y > 0f)
			{
				this.testStick.y = 0f;
			}
			if (this.testStick.y < -1f)
			{
				this.testStick.y = -1f;
			}
		}
		if (this.weaponType == WeaponController.WeaponType.Revolver)
		{
			return;
		}
		if (this.weaponType == WeaponController.WeaponType.ShotgunField)
		{
			if (vector.y < 0f && (double)vector.x > -0.4 && (double)vector.x < 0.4)
			{
				if (this.status == WeaponController.WeaponStatus.SlideLockedBack || this.status == WeaponController.WeaponStatus.ManualSlideLocked || this.status == WeaponController.WeaponStatus.EmptySlideLockedBack || this.status == WeaponController.WeaponStatus.EmptySlideLockedBack || this.status == WeaponController.WeaponStatus.LoadedSlideLockedBack)
				{
					return;
				}
				this.animator.SetLayerWeight(this.animator.GetLayerIndex("SlideMovement"), 1f);
				if (this.status == WeaponController.WeaponStatus.Loaded)
				{
					this.animator.SetLayerWeight(this.animator.GetLayerIndex("SlideMovement"), 1f);
					this.animator.SetFloat("SlidePull", Mathf.Abs(vector.y));
					if (vector.y < -this.slideEjectThreshold && !this.slideBack)
					{
						this.slideBack = true;
						this.SlideActionType(false, false, true);
						this.Cock(true);
						if (this.currentAmmo <= 0)
						{
							this.animator.SetFloat("SlidePull", this.slideLockPosition);
							this.animator.SetTrigger("BoltLock");
							GameEvents.current.ChamberEmpty();
							this.status = WeaponController.WeaponStatus.SlideLockedBack;
						}
					}
					if (this.slideBack && this.SlideLockCheck())
					{
						this.animator.SetFloat("SlidePull", this.slideLockPosition);
						if (this.currentAmmo <= 0)
						{
							this.status = WeaponController.WeaponStatus.SlideLockedBack;
						}
						else
						{
							this.status = WeaponController.WeaponStatus.ManualSlideLocked;
						}
					}
					if (vector.y > -0.1f && this.slideBack)
					{
						this.canShoot = true;
					}
				}
				else if (this.status == WeaponController.WeaponStatus.Empty)
				{
					this.animator.SetLayerWeight(this.animator.GetLayerIndex("SlideMovement"), 1f);
					this.animator.SetFloat("SlidePull", Mathf.Abs(vector.y));
					if (vector.y < -this.slideEjectThreshold && !this.slideBack)
					{
						this.slideBack = true;
						this.Cock(true);
						this.animator.SetTrigger("BoltLock");
						this.animator.SetFloat("SlidePull", this.slideLockPosition);
						this.status = WeaponController.WeaponStatus.SlideLockedBack;
					}
				}
				else if (this.status == WeaponController.WeaponStatus.LoadedEmptyChamber)
				{
					this.animator.SetLayerWeight(this.animator.GetLayerIndex("SlideMovement"), 1f);
					this.animator.SetFloat("SlidePull", Mathf.Abs(vector.y));
					if (vector.y < -this.slideEjectThreshold)
					{
						this.animator.SetLayerWeight(this.animator.GetLayerIndex("DoubleAction"), 0f);
						this.slideBack = true;
						this.Cock(true);
					}
					if (this.slideBack)
					{
					}
				}
			}
		}
		else if (vector.y < 0f && (double)vector.x > -0.4 && (double)vector.x < 0.4)
		{
			this.joystickEngaged = true;
			if (this.safetyOn)
			{
				return;
			}
			if (this.status == WeaponController.WeaponStatus.SlideLockedBack || this.status == WeaponController.WeaponStatus.ManualSlideLocked)
			{
				return;
			}
			if (this.status == WeaponController.WeaponStatus.EmptySlideLockedBack)
			{
				if (vector.y < -this.slideEjectThreshold)
				{
					this.animator.SetLayerWeight(this.animator.GetLayerIndex("SlideMovement"), 1f);
					this.animator.SetFloat("SlidePull", Mathf.Abs(vector.y));
					this.ManualSlideRelease();
					this.status = WeaponController.WeaponStatus.Empty;
					this.audioSource.PlayOneShot(this.audioSlideRelease);
					this.Cock(true);
				}
			}
			else if (this.status == WeaponController.WeaponStatus.LoadedSlideLockedBack)
			{
				if (vector.y < -this.slideEjectThreshold && !this.slideBack)
				{
					this.slideBack = true;
					this.Cock(true);
				}
				if (this.slideBack)
				{
					this.animator.SetLayerWeight(this.animator.GetLayerIndex("SlideMovement"), 1f);
					this.animator.SetFloat("SlidePull", Mathf.Abs(vector.y));
				}
				if (vector.y > -this.slideEjectThreshold && this.slideBack)
				{
					this.status = WeaponController.WeaponStatus.Loaded;
					GameEvents.current.SlideRelease();
					this.ManualSlideRelease();
				}
			}
			else if (this.status == WeaponController.WeaponStatus.Loaded)
			{
				this.animator.SetLayerWeight(this.animator.GetLayerIndex("SlideMovement"), 1f);
				this.animator.SetFloat("SlidePull", Mathf.Abs(vector.y));
				if (vector.y < -this.slideEjectThreshold && !this.slideBack)
				{
					this.animator.SetLayerWeight(this.animator.GetLayerIndex("DoubleAction"), 0f);
					this.slideBack = true;
					this.SlideActionType(false, false, true);
					this.Cock(true);
					if (this.currentAmmo <= 0)
					{
						this.animator.SetFloat("SlidePull", this.slideLockPosition);
						this.status = WeaponController.WeaponStatus.SlideLockedBack;
					}
				}
				if (this.slideBack && this.SlideLockCheck())
				{
					this.animator.SetFloat("SlidePull", this.slideLockPosition);
					if (this.currentAmmo <= 0)
					{
						this.status = WeaponController.WeaponStatus.SlideLockedBack;
					}
					else
					{
						this.status = WeaponController.WeaponStatus.ManualSlideLocked;
					}
				}
				if (vector.y > -0.1f && this.slideBack)
				{
					this.canShoot = true;
				}
			}
			else if (this.status == WeaponController.WeaponStatus.Empty)
			{
				this.animator.SetLayerWeight(this.animator.GetLayerIndex("SlideMovement"), 1f);
				this.animator.SetFloat("SlidePull", Mathf.Abs(vector.y));
				if (vector.y < -this.slideEjectThreshold && !this.slideBack)
				{
					this.slideBack = true;
					this.Cock(true);
				}
				if (this.slideBack && this.SlideLockCheck())
				{
					this.ManualSlideLock();
				}
				if (vector.y > -0.1f && this.slideBack)
				{
				}
			}
			else if (this.status == WeaponController.WeaponStatus.LoadedEmptyChamber)
			{
				this.animator.SetLayerWeight(this.animator.GetLayerIndex("SlideMovement"), 1f);
				this.animator.SetFloat("SlidePull", Mathf.Abs(vector.y));
				if (vector.y < -this.slideEjectThreshold)
				{
					this.slideBack = true;
					this.Cock(true);
				}
				if (this.slideBack && this.SlideLockCheck())
				{
					this.ManualSlideLock();
				}
			}
			else if (this.status == WeaponController.WeaponStatus.EmptyRoundInChamber)
			{
				this.animator.SetLayerWeight(this.animator.GetLayerIndex("SlideMovement"), 1f);
				this.animator.SetFloat("SlidePull", Mathf.Abs(vector.y));
				if (vector.y < -0.8f)
				{
					this.slideBack = true;
					this.SlideActionType(false, false, true);
					GameEvents.current.ChamberEmpty();
					this.status = WeaponController.WeaponStatus.Empty;
					this.Cock(true);
				}
				if (this.slideBack && this.SlideLockCheck())
				{
					this.ManualSlideLock();
				}
			}
			else if (this.status == WeaponController.WeaponStatus.EmptySlideForwardEmptyMag)
			{
				this.animator.SetLayerWeight(this.animator.GetLayerIndex("SlideMovement"), 1f);
				this.animator.SetFloat("SlidePull", Mathf.Abs(vector.y));
				if (vector.y < -this.slideEjectThreshold && !this.slideBack)
				{
					this.slideBack = true;
					this.Cock(true);
					this.ManualSlideLock();
				}
			}
		}
		if ((double)vector.y < 0.01 && (double)vector.y > -0.01 && !this.slideBack && this.joystickEngaged && this.status != WeaponController.WeaponStatus.SlideLockedBack && this.status != WeaponController.WeaponStatus.LoadedSlideLockedBack && this.status != WeaponController.WeaponStatus.EmptySlideLockedBack)
		{
			this.animator.SetLayerWeight(this.animator.GetLayerIndex("SlideMovement"), 1f);
			this.animator.SetFloat("SlidePull", 0f);
			this.joystickEngaged = false;
		}
		if ((double)vector.y < 0.01 && (double)vector.y > -0.01 && this.slideBack && this.weaponType != WeaponController.WeaponType.Revolver)
		{
			if (this.status == WeaponController.WeaponStatus.LoadedEmptyChamber)
			{
				if (this.weaponType == WeaponController.WeaponType.ShotgunField)
				{
					if (this.shotgunRoundInLifter)
					{
						this.status = WeaponController.WeaponStatus.Loaded;
						this.canShoot = true;
						this.animator.SetTrigger("DisableLifterRound");
						this.lifterShell.SetActive(false);
					}
					else
					{
						this.canShoot = true;
					}
				}
				else
				{
					this.status = WeaponController.WeaponStatus.Loaded;
					this.canShoot = true;
				}
				GameEvents.current.RoundChambered();
			}
			MonoBehaviour.print("MANUAL CYCLE RESET");
			this.ShowRound(0);
			this.ShowRound(1);
			if (this.status == WeaponController.WeaponStatus.ManualSlideLocked)
			{
				if (this.currentAmmo > 0)
				{
					this.status = WeaponController.WeaponStatus.LoadedSlideLockedBack;
				}
				if (!this.hasMagazine)
				{
					this.status = WeaponController.WeaponStatus.EmptySlideLockedBack;
				}
			}
			if (this.status != WeaponController.WeaponStatus.SlideLockedBack && this.status != WeaponController.WeaponStatus.LoadedSlideLockedBack && this.status != WeaponController.WeaponStatus.EmptySlideLockedBack)
			{
				this.animator.SetLayerWeight(this.animator.GetLayerIndex("SlideMovement"), 1f);
				this.animator.SetFloat("SlidePull", 0f);
			}
			this.audioSource.PlayOneShot(this.audioSlideRelease);
			this.slideActionInProgress = false;
			this.slideBack = false;
			this.joystickEngaged = false;
		}
	}

	// Token: 0x060002FE RID: 766 RVA: 0x00012828 File Offset: 0x00010A28
	private void ShowRound(int mode = 0)
	{
		if (mode == 0)
		{
			if (this.status != WeaponController.WeaponStatus.Loaded && this.status != WeaponController.WeaponStatus.EmptyRoundInChamber)
			{
				this.pressCheckRound.enabled = false;
				return;
			}
			this.pressCheckRound.enabled = true;
			if (this.hasAltAmmo)
			{
				Material chamberRoundMaterial = base.GetComponent<AmmoTypeManager>().GetChamberRoundMaterial();
				Renderer component = this.pressCheckRound.GetComponent<MeshRenderer>();
				Material[] materials = this.pressCheckRound.GetComponent<MeshRenderer>().materials;
				materials[0] = chamberRoundMaterial;
				materials[1] = materials[1];
				component.materials = materials;
				return;
			}
		}
		else
		{
			if (mode == 1)
			{
				for (int i = 0; i < this.pressCheckRoundInMag.Length; i++)
				{
					if (i > this.currentAmmo - 1)
					{
						this.pressCheckRoundInMag[i].enabled = false;
					}
				}
				return;
			}
			if (mode == 2)
			{
				Renderer[] array = this.pressCheckRoundInMag;
				for (int j = 0; j < array.Length; j++)
				{
					array[j].enabled = true;
				}
			}
		}
	}

	// Token: 0x060002FF RID: 767 RVA: 0x000128FF File Offset: 0x00010AFF
	private bool SlideLockCheck()
	{
		if (OVRInput.Get(OVRInput.Button.Two, this.controlManager.controller))
		{
			this.animator.SetFloat("SlideLock", 1f);
			return true;
		}
		return false;
	}

	// Token: 0x06000300 RID: 768 RVA: 0x0001292C File Offset: 0x00010B2C
	private void ManualSlideLock()
	{
		this.animator.SetFloat("SlidePull", this.slideLockPosition);
		this.animator.SetFloat("SlideLock", 1f);
		this.status = WeaponController.WeaponStatus.ManualSlideLocked;
	}

	// Token: 0x06000301 RID: 769 RVA: 0x00012960 File Offset: 0x00010B60
	private void ManualSlideRelease()
	{
		this.animator.SetTrigger("SlideRelease");
		this.animator.SetFloat("SlideLock", 0f);
	}

	// Token: 0x06000302 RID: 770 RVA: 0x00012988 File Offset: 0x00010B88
	public void ShotgunReloadOver()
	{
		this.shotgunReloading = false;
		if (this.status == WeaponController.WeaponStatus.Loaded || this.status == WeaponController.WeaponStatus.EmptyRoundInChamber)
		{
			this.animator.SetFloat("SlideLock", 0f);
			this.animator.SetFloat("SlidePull", 0f);
		}
	}

	// Token: 0x06000303 RID: 771 RVA: 0x000129D8 File Offset: 0x00010BD8
	public void LifterRoundReleased()
	{
		this.lifterShell.SetActive(true);
	}

	// Token: 0x06000304 RID: 772 RVA: 0x000129E8 File Offset: 0x00010BE8
	private bool GunInQuadLoadRotation(float minOverRide = 0f, float maxOverRide = 0f)
	{
		float num = 110f;
		float num2 = 210f;
		if (minOverRide != 0f && maxOverRide != 0f)
		{
			num = minOverRide;
			num2 = maxOverRide;
		}
		return base.transform.rotation.eulerAngles.z >= num && base.transform.rotation.eulerAngles.z <= num2;
	}

	// Token: 0x06000305 RID: 773 RVA: 0x00012A50 File Offset: 0x00010C50
	public void ShotgunReloadRefactor()
	{
		int num;
		if (this.ammoTypeManager.PeekChamberRound() != null)
		{
			num = this.magazineCapacity + 1;
		}
		else
		{
			num = this.magazineCapacity;
		}
		if (this.shotgunReloading)
		{
			return;
		}
		AmmoTypeManager.AmmoType ammoType;
		if (OVRInput.Get(OVRInput.Touch.One, OVRInput.Controller.RTouch))
		{
			ammoType = AmmoTypeManager.AmmoType.Alternative;
		}
		else
		{
			ammoType = AmmoTypeManager.AmmoType.Default;
		}
		this.ShotgunLoadShell(ammoType);
		if (this.status == WeaponController.WeaponStatus.SlideLockedBack)
		{
			this.shotgunReloading = true;
			if (this.GunInQuadLoadRotation(0f, 0f))
			{
				this.animator.SetTrigger("DuoloadFail");
				return;
			}
			this.status = WeaponController.WeaponStatus.EmptyRoundInChamber;
			this.animator.SetLayerWeight(this.animator.GetLayerIndex("SlideMovement"), 0f);
			this.audioSource.PlayOneShot(this.audioMagazineInsert);
			this.animator.SetTrigger("MatchSaver");
			this.shotgunRoundInLifter = true;
			this.ammoTypeInLifter = ammoType;
			return;
		}
		else
		{
			if (this.status == WeaponController.WeaponStatus.EmptyRoundInChamber)
			{
				this.ShotgunReturnBolt(ammoType);
				return;
			}
			this.audioSource.PlayOneShot(this.audioMagazineInsert);
			int num2;
			if (this.GunInQuadLoadRotation(0f, 0f))
			{
				if (this.currentAmmo <= num - 2)
				{
					num2 = 2;
					this.currentAmmo += num2;
					this.animator.SetTrigger("Duoload");
				}
				else
				{
					if (this.currentAmmo != num - 1)
					{
						this.animator.SetTrigger("DuoloadFail");
						return;
					}
					num2 = 1;
					this.currentAmmo += num2;
					this.animator.SetTrigger("DuoloadOneOnly");
				}
			}
			else
			{
				if (this.currentAmmo > num - 1)
				{
					this.animator.SetTrigger("SingleLoadFail");
					return;
				}
				num2 = 1;
				this.currentAmmo += num2;
				this.animator.SetTrigger("SingleLoad");
			}
			if (this.status == WeaponController.WeaponStatus.Empty)
			{
				this.status = WeaponController.WeaponStatus.LoadedEmptyChamber;
			}
			this.shotgunReloading = true;
			this.ammoTypeManager.AddRound(ammoType, false, num2);
			if (this.currentAmmo > 1)
			{
				this.ShowRound(0);
				this.ShowRound(2);
			}
			return;
		}
	}

	// Token: 0x06000306 RID: 774 RVA: 0x00012C4D File Offset: 0x00010E4D
	private void ShotgunReload()
	{
		if (this.controlManager.controllerMode != ControlManager.ControllerMode.ControlAR2)
		{
			return;
		}
		if (OVRInput.GetDown(OVRInput.Button.PrimaryIndexTrigger, OVRInput.Controller.LTouch) || this.testShotgunReload)
		{
			this.ShotgunReloadRefactor();
		}
	}

	// Token: 0x06000307 RID: 775 RVA: 0x00012C7C File Offset: 0x00010E7C
	private void ShotgunReturnBolt(AmmoTypeManager.AmmoType ammoType)
	{
		this.animator.SetLayerWeight(this.animator.GetLayerIndex("SlideMovement"), 0f);
		this.status = WeaponController.WeaponStatus.Loaded;
		this.animator.Play("ReturnBolt");
		if (this.ammoTypeInLifter != ammoType)
		{
			ammoType = this.ammoTypeInLifter;
		}
		this.ShotgunLoadShell(ammoType);
		this.ammoTypeManager.AddRound(ammoType, true, 1);
		this.currentAmmo++;
		this.audioSource.PlayOneShot(this.audioSlideRelease);
		this.shotgunReloading = true;
	}

	// Token: 0x06000308 RID: 776 RVA: 0x00012D0C File Offset: 0x00010F0C
	private void ShotgunLoadShell(AmmoTypeManager.AmmoType type)
	{
		if (type == AmmoTypeManager.AmmoType.Default)
		{
			foreach (Renderer renderer in this.shellLoadRenderers)
			{
				Material[] materials = renderer.materials;
				materials[0] = this.defaultMaterial;
				materials[1] = renderer.materials[1];
				renderer.materials = materials;
			}
			return;
		}
		if (type == AmmoTypeManager.AmmoType.Alternative)
		{
			foreach (Renderer renderer2 in this.shellLoadRenderers)
			{
				Material[] materials2 = renderer2.materials;
				materials2[0] = this.altMaterial;
				materials2[1] = renderer2.materials[1];
				renderer2.materials = materials2;
			}
		}
	}

	// Token: 0x06000309 RID: 777 RVA: 0x00012DA0 File Offset: 0x00010FA0
	private void ApplyMaterial(GameObject round, AmmoTypeManager.AmmoType type)
	{
		if (type == AmmoTypeManager.AmmoType.Default)
		{
			foreach (Renderer renderer in this.lifterShellRenderers)
			{
				Material[] materials = renderer.materials;
				materials[0] = this.defaultMaterial;
				materials[1] = renderer.materials[1];
				renderer.materials = materials;
			}
			return;
		}
		if (type == AmmoTypeManager.AmmoType.Alternative)
		{
			foreach (Renderer renderer2 in this.lifterShellRenderers)
			{
				Material[] materials2 = renderer2.materials;
				materials2[0] = this.altMaterial;
				materials2[1] = renderer2.materials[1];
				renderer2.materials = materials2;
			}
		}
	}

	// Token: 0x0600030A RID: 778 RVA: 0x00012E34 File Offset: 0x00011034
	private void EjectMagazine()
	{
		if (this.weaponType == WeaponController.WeaponType.Revolver)
		{
			bool flag = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, this.controlManager.controller).x < -0.9f;
			if (!this.magazineEjectCoolDown && (OVRInput.GetDown(OVRInput.Button.One, this.controlManager.controller) || flag))
			{
				if (!this.cylinderOpened)
				{
					this.animator.SetTrigger("CylinderRelease");
					this.cylinderOpened = true;
					this.magazineEjectCoolDown = true;
					this.MagazineLoadCoolDown(0.2f);
					this.audioSource.PlayOneShot(this.audioMagazineEject);
					return;
				}
				this.animator.SetTrigger("CylinderReleaseEmpty");
			}
			return;
		}
		if (OVRInput.GetDown(OVRInput.Button.One, this.controlManager.controller) && this.hasMagazine)
		{
			if (this.weaponType == WeaponController.WeaponType.ShotgunField)
			{
				if (this.status == WeaponController.WeaponStatus.LoadedEmptyChamber && !this.shotgunRoundInLifter)
				{
					this.shotgunRoundInLifter = true;
					this.audioSource.PlayOneShot(this.audioMagazineInsert);
					this.hapticManager.VibrateStandard(0.8f, 0.4f, 0.05f, this.controlManager.controller);
					this.ApplyMaterial(this.lifterShell, this.ammoTypeManager.PeekTubeRoundType());
					this.animator.Play("ReleaseRoundToLifter");
					return;
				}
				return;
			}
			else
			{
				MonoBehaviour.print("Mag released, current mag in queue " + this.magazineQueue.Count);
				this.EjectRigidbody();
				this.magazineToBeDisabled.SetActive(false);
				this.audioSource.PlayOneShot(this.audioMagazineEject);
				this.hasMagazine = false;
				if (this.currentAmmo > 0)
				{
					this.currentAmmo = 1;
					if (this.status == WeaponController.WeaponStatus.LoadedSlideLockedBack)
					{
						this.status = WeaponController.WeaponStatus.EmptySlideLockedBack;
						this.currentAmmo = 0;
					}
					else
					{
						this.status = WeaponController.WeaponStatus.EmptyRoundInChamber;
					}
				}
				else if (this.status == WeaponController.WeaponStatus.LoadedEmptyChamber || this.status == WeaponController.WeaponStatus.EmptySlideForwardEmptyMag)
				{
					this.status = WeaponController.WeaponStatus.Empty;
				}
				else if (this.status == WeaponController.WeaponStatus.SlideLockedBack || this.status == WeaponController.WeaponStatus.LoadedSlideLockedBack)
				{
					this.status = WeaponController.WeaponStatus.EmptySlideLockedBack;
				}
				this.ShowRound(1);
			}
		}
	}

	// Token: 0x0600030B RID: 779 RVA: 0x00013033 File Offset: 0x00011233
	private void EnableMagazineCollider()
	{
		this.magazineCollider.enabled = true;
	}

	// Token: 0x0600030C RID: 780 RVA: 0x00013044 File Offset: 0x00011244
	private void EjectRigidbody()
	{
		GameObject gameObject;
		if (this.magazineQueue.Count < this.maxMagazine)
		{
			gameObject = Object.Instantiate<GameObject>(this.magazineToBeEjected, this.magazineToBeDisabled.transform.position, this.magazineToBeDisabled.transform.rotation);
			if (this.ejectMagScaler != 0f)
			{
				gameObject.transform.localScale = new Vector3(this.ejectMagScaler, this.ejectMagScaler, this.ejectMagScaler);
			}
			this.magazineCollider = gameObject.AddComponent<BoxCollider>();
			gameObject.layer = LayerMask.NameToLayer("GrabColliders");
			gameObject.AddComponent<Rigidbody>();
			gameObject.GetComponent<Rigidbody>().collisionDetectionMode = CollisionDetectionMode.Continuous;
			gameObject.GetComponent<Rigidbody>().AddForce(this.magazineEjectionDirection.forward * 2f, ForceMode.Impulse);
			this.magazineQueue.Enqueue(gameObject);
		}
		else
		{
			gameObject = this.magazineQueue.Dequeue();
			if (gameObject == null)
			{
				this.ClearMagazines();
				this.EjectMagazine();
				return;
			}
			gameObject.transform.position = this.magazineToBeDisabled.transform.position;
			gameObject.transform.rotation = this.magazineToBeDisabled.transform.rotation;
			gameObject.GetComponent<Rigidbody>().velocity = Vector3.zero;
			gameObject.GetComponent<Rigidbody>().AddForce(this.magazineEjectionDirection.forward * 2f, ForceMode.Impulse);
			this.magazineQueue.Enqueue(gameObject);
			this.magazineEjectCoolDown = true;
			this.MagazineLoadCoolDown(0.2f);
		}
		if (gameObject.GetComponent<MagazineRoundDisplay>())
		{
			if (this.hasAltAmmo)
			{
				gameObject.GetComponent<MagazineRoundDisplay>().SetMaterial(base.GetComponent<AmmoTypeManager>().GetChamberRoundMaterial());
			}
			gameObject.GetComponent<MagazineRoundDisplay>().SetCount(this.currentAmmo);
		}
	}

	// Token: 0x0600030D RID: 781 RVA: 0x00013206 File Offset: 0x00011406
	public void MagazineLoadCoolDown(float coolDownTime)
	{
		this.magazineEjectCoolDown = true;
		base.Invoke("MagazineEjectReset", coolDownTime);
	}

	// Token: 0x0600030E RID: 782 RVA: 0x0001321B File Offset: 0x0001141B
	private void MagazineEjectReset()
	{
		this.magazineEjectCoolDown = false;
		this.lastPos = base.transform.position;
	}

	// Token: 0x0600030F RID: 783 RVA: 0x00013235 File Offset: 0x00011435
	public void AnimationReload()
	{
		this.currentAmmo = this.magazineCapacity;
	}

	// Token: 0x06000310 RID: 784 RVA: 0x00013244 File Offset: 0x00011444
	private void TapDetection()
	{
		if (this.weaponType == WeaponController.WeaponType.ShotgunField)
		{
			return;
		}
		if (this.magazineEjectCoolDown)
		{
			return;
		}
		float num = Vector3.Distance(base.transform.position, this.lastPos);
		float num2 = this.detectionThreshold * this.playerData.reloadMultiplier;
		if (num2 == 0f)
		{
			num2 = this.detectionThreshold;
		}
		MonoBehaviour.print("DETECTION THRESHOLD: " + num2);
		bool flag = num > num2;
		bool flag2 = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, this.controlManager.controller).x > 0.8f;
		if (this.weaponType == WeaponController.WeaponType.Revolver && this.cylinderOpened)
		{
			if (flag2)
			{
				this.animator.SetTrigger("CylinderClose");
				this.audioSource.PlayOneShot(this.audioSlideRelease);
				this.cylinderOpened = false;
			}
			if (!this.cylinderEmpty && base.transform.eulerAngles.x > 280f && base.transform.eulerAngles.x < 320f)
			{
				this.revolverInEjectRotation = true;
				bool flag3 = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, this.controlManager.controller).y < -0.9f;
				if (flag || OVRInput.GetDown(OVRInput.Button.PrimaryIndexTrigger, this.controlManager.controller) || flag3)
				{
					this.animator.SetTrigger("CylinderEject");
					this.magazineToBeEjected = this.clipToBeEjected;
					this.audioSource.PlayOneShot(this.audioRevolverEject);
					this.EjectRigidbody();
					this.status = WeaponController.WeaponStatus.Empty;
					this.moonClip.SetActive(false);
					this.currentAmmo = 0;
					this.cylinderEmpty = true;
				}
			}
			else if (!this.magazineEjectCoolDown && this.cylinderEmpty && base.transform.eulerAngles.x > 40f && base.transform.eulerAngles.x < 80f)
			{
				if (this.timePointedDown == 0f)
				{
					this.timePointedDown = Time.time;
				}
				else if (Time.time > this.timePointedDown + this.timeRequiredToReload && (num > num2 / 2f || OVRInput.GetDown(OVRInput.Button.One, this.controlManager.controller)))
				{
					GameObject[] array = this.revolverRounds;
					for (int i = 0; i < array.Length; i++)
					{
						array[i].SetActive(true);
					}
					this.timePointedDown = 0f;
					this.moonClip.SetActive(true);
					this.animator.SetTrigger("CylinderReload");
					this.status = WeaponController.WeaponStatus.Loaded;
					this.audioSource.PlayOneShot(this.audioMagazineInsert);
					this.cylinderEmpty = false;
				}
			}
			else if (!this.magazineEjectCoolDown)
			{
				if ((this.currentAmmo == this.magazineCapacity && flag) || (flag && this.currentAmmo != this.magazineCapacity && flag && OVRInput.Get(OVRInput.Touch.One, this.controlManager.controller)))
				{
					this.animator.SetTrigger("CylinderClose");
					this.audioSource.PlayOneShot(this.audioSlideRelease);
					this.cylinderOpened = false;
				}
				this.revolverInEjectRotation = false;
			}
			else
			{
				this.revolverInEjectRotation = false;
			}
			this.lastPos = base.transform.position;
			MonoBehaviour.print("rotation POS " + base.transform.eulerAngles.x);
			return;
		}
		if (num > num2 && !this.hasMagazine && !this.ignoreReload)
		{
			this.ShowRound(2);
			this.magazineToBeDisabled.SetActive(true);
			if (this.magazineToBeDisabled.GetComponent<MagazineRoundDisplay>())
			{
				this.magazineToBeDisabled.GetComponent<MagazineRoundDisplay>().Reset();
			}
			if (this.currentAmmo >= 1)
			{
				this.currentAmmo = this.magazineCapacity + 1;
				this.status = WeaponController.WeaponStatus.Loaded;
			}
			else
			{
				this.currentAmmo = this.magazineCapacity;
				if (this.status == WeaponController.WeaponStatus.EmptySlideLockedBack)
				{
					this.status = WeaponController.WeaponStatus.LoadedSlideLockedBack;
				}
				else
				{
					this.status = WeaponController.WeaponStatus.LoadedEmptyChamber;
					this.canShoot = false;
				}
			}
			if (this.hasAltAmmo)
			{
				if (OVRInput.Get(OVRInput.Button.One, this.controlManager.controller))
				{
					this.ammoTypeManager.MagReload(this.magazineCapacity, AmmoTypeManager.AmmoType.Alternative);
					if (this.magazineToBeDisabled.GetComponent<MagazineRoundDisplay>())
					{
						this.magazineToBeDisabled.GetComponent<MagazineRoundDisplay>().SetMaterial(this.altMaterial);
					}
				}
				else
				{
					this.ammoTypeManager.MagReload(this.magazineCapacity, AmmoTypeManager.AmmoType.Default);
					if (this.magazineToBeDisabled.GetComponent<MagazineRoundDisplay>())
					{
						this.magazineToBeDisabled.GetComponent<MagazineRoundDisplay>().SetMaterial(this.defaultMaterial);
					}
				}
			}
			GameEvents.current.MagazineLoad();
			this.audioSource.PlayOneShot(this.audioMagazineInsert);
			this.hasMagazine = true;
		}
		this.lastPos = base.transform.position;
	}

	// Token: 0x06000311 RID: 785 RVA: 0x00003297 File Offset: 0x00001497
	public void AnimationDoubleActionHammerDrop()
	{
	}

	// Token: 0x06000312 RID: 786 RVA: 0x00013726 File Offset: 0x00011926
	private void DoubleActionCoolDown()
	{
		this.doubleActionCoolDown = false;
	}

	// Token: 0x06000313 RID: 787 RVA: 0x00013730 File Offset: 0x00011930
	private void TriggerControl()
	{
		float num = OVRInput.Get(OVRInput.Axis1D.PrimaryIndexTrigger, this.controlManager.controller);
		if (this.weaponType == WeaponController.WeaponType.Revolver)
		{
			if (this.revolverInEjectRotation)
			{
				if (OVRInput.GetUp(OVRInput.Button.PrimaryIndexTrigger, this.controlManager.controller))
				{
					this.revolverInEjectRotation = false;
				}
				return;
			}
			if (!this.triggerReset)
			{
				this.doubleActionReset = false;
			}
			if (num == 0f && !this.doubleActionReset)
			{
				if (this.currentAmmo < this.magazineCapacity)
				{
					this.revolverRoundMidSpin[0].SetActive(true);
					this.revolverRounds[Mathf.Clamp(this.magazineCapacity - this.currentAmmo - 1, 0, this.revolverRounds.Length - 1)].SetActive(false);
				}
				this.doubleActionReset = true;
			}
			if ((this.TriggerStatus(num) == WeaponController.CurrentTriggerStatus.Pulled && this.triggerReset) || this.doubleActionReset)
			{
				this.animator.SetFloat("Analogue-Hammer", num);
				if (!this.cylinderOpened)
				{
					this.animator.SetFloat("Analogue-CylinderSpin", num);
				}
			}
			this.animator.SetFloat("Analogue-TriggerPull", num);
			if (num >= this.triggerWallPositionTemp && this.triggerReset)
			{
				this.animator.SetFloat("Analogue-Hammer", 1f);
				this.HammerDrop();
				this.triggerReset = false;
			}
			if (num <= this.triggerResetPositionTemp && !this.triggerReset)
			{
				this.triggerReset = true;
				this.audioSource.PlayOneShot(this.audioTriggerReset);
				this.hapticManager.VibrateStandard(0.8f, 0.4f, 0.05f, this.controlManager.controller);
				return;
			}
		}
		else
		{
			this.animator.SetFloat("TriggerPull", num);
			if (this.triggerText != null)
			{
				this.triggerText.text = string.Concat(new object[]
				{
					"Wall: ",
					this.triggerWallPositionTemp.ToString(),
					" Reset:",
					this.triggerResetPositionTemp,
					"\n",
					num.ToString("F2"),
					"\n",
					this.triggerReset.ToString()
				});
			}
			if ((this.isDoubleAction && !this.IsCocked() && !this.doubleActionCoolDown && (this.status == WeaponController.WeaponStatus.Empty || this.status == WeaponController.WeaponStatus.Loaded || this.status == WeaponController.WeaponStatus.LoadedEmptyChamber)) || this.status == WeaponController.WeaponStatus.EmptySlideForwardEmptyMag)
			{
				if (this.TriggerStatus(num) == WeaponController.CurrentTriggerStatus.Pulled || (num < 0.9f && this.doubleActionReset && this.triggerReset))
				{
					this.animator.SetFloat("DoubleActionHammer", num);
					if (num > 0.8f && this.doubleActionReset)
					{
						this.doubleActionReset = false;
						this.HammerDrop();
						this.triggerReset = false;
					}
					else if (num < 0.1f && !this.doubleActionReset)
					{
						this.doubleActionReset = true;
					}
				}
			}
			else if (this.CanShoot() && num >= this.triggerWallPositionTemp && this.triggerReset)
			{
				this.HammerDrop();
				this.triggerReset = false;
			}
			if (num <= this.triggerResetPositionTemp && !this.triggerReset)
			{
				this.triggerReset = true;
				if (this.CanShoot())
				{
					this.audioSource.PlayOneShot(this.audioTriggerReset);
					this.hapticManager.VibrateStandard(0.8f, 0.4f, 0.05f, this.controlManager.controller);
				}
			}
		}
	}

	// Token: 0x06000314 RID: 788 RVA: 0x00013A88 File Offset: 0x00011C88
	private void Cock(bool isCock)
	{
		if (isCock)
		{
			this.cocked = true;
			this.animator.SetFloat("DoubleActionHammer", 0.7f);
			this.animator.SetFloat("HammerDown", 0f);
			return;
		}
		this.cocked = false;
		this.animator.SetFloat("HammerDown", 1f);
		this.animator.SetFloat("DoubleActionHammer", 0f);
	}

	// Token: 0x06000315 RID: 789 RVA: 0x00013AFC File Offset: 0x00011CFC
	private void HammerDrop()
	{
		if (this.weaponType != WeaponController.WeaponType.Revolver)
		{
			if (this.cocked || this.isDoubleAction)
			{
				if (this.status == WeaponController.WeaponStatus.SlideLockedBack)
				{
					return;
				}
				if (this.status == WeaponController.WeaponStatus.EmptyRoundInChamber && this.weaponType == WeaponController.WeaponType.ShotgunField)
				{
					return;
				}
				if (this.currentAmmo <= 0 || this.status == WeaponController.WeaponStatus.LoadedEmptyChamber)
				{
					this.audioSource.PlayOneShot(this.audioFireEmpty);
					this.Cock(false);
					this.animator.SetLayerWeight(this.animator.GetLayerIndex("DoubleAction"), 1f);
					if (this.currentAmmo <= 0)
					{
						GameEvents.current.GunEmpty();
						return;
					}
				}
				else if (this.currentAmmo > 0)
				{
					this.animator.SetLayerWeight(this.animator.GetLayerIndex("DoubleAction"), 0f);
					this.Cock(true);
					this.Fire();
					if (this.currentAmmo == 1 && this.hasMagazine)
					{
						this.animator.ResetTrigger("SlideRelease");
						this.animator.SetTrigger("FireLast");
						this.animator.SetFloat("SlideLock", 1f);
						this.status = WeaponController.WeaponStatus.SlideLockedBack;
						this.DoubleActionCoolDownInitiate(0.1f);
						if (this.weaponType == WeaponController.WeaponType.ShotgunField)
						{
							this.shotgunRoundInLifter = false;
						}
					}
					else if (this.currentAmmo == 1 && !this.hasMagazine)
					{
						this.animator.SetTrigger("Fire");
						this.status = WeaponController.WeaponStatus.Empty;
						this.ShowRound(0);
						this.doubleActionCoolDown = true;
						this.DoubleActionCoolDownInitiate(0.1f);
					}
					else
					{
						this.animator.SetTrigger("Fire");
					}
					this.currentAmmo--;
					this.ShowRound(1);
				}
			}
			return;
		}
		if (this.currentAmmo <= 0 || this.cylinderOpened)
		{
			this.audioSource.PlayOneShot(this.audioFireEmpty);
			return;
		}
		this.animator.SetTrigger("Fire");
		this.Fire();
		this.revolverRoundMidSpin[0].SetActive(false);
		this.currentAmmo--;
	}

	// Token: 0x06000316 RID: 790 RVA: 0x00013D04 File Offset: 0x00011F04
	private void DoubleActionCoolDownInitiate(float time = 0.1f)
	{
		this.doubleActionCoolDown = true;
		base.Invoke("DoubleActionCoolDown", time);
	}

	// Token: 0x06000317 RID: 791 RVA: 0x00013D1C File Offset: 0x00011F1C
	private void Fire()
	{
		this.animator.SetLayerWeight(this.animator.GetLayerIndex("SlideMovement"), 0f);
		this.animator.SetLayerWeight(this.animator.GetLayerIndex("DoubleAction"), 0f);
		if (this.weaponType != WeaponController.WeaponType.Revolver)
		{
			this.EjectionEffect(this.shellEjection);
		}
		GameObject gameObject;
		if (!this.hasAltAmmo)
		{
			gameObject = Object.Instantiate<GameObject>(this.projectilePrefab, this.muzzlePosition.position, this.muzzlePosition.rotation);
		}
		else
		{
			gameObject = Object.Instantiate<GameObject>(this.ammoTypeManager.UseRoundInChamber(), this.muzzlePosition.position, this.muzzlePosition.rotation);
		}
		if (gameObject.GetComponent<Projectile>().type == Projectile.ProjectileType.Pallets && this.chokeSpread != 0f)
		{
			gameObject.GetComponent<Projectile>().ModifySpread(this.chokeSpread);
		}
		this.hapticManager.VibrateStandard(0.1f, 0.8f, 0.12f, this.controlManager.controller);
		ParticleSystem particleSystem = Object.Instantiate<ParticleSystem>(this.muzzleFlash, this.muzzlePosition.position, this.muzzlePosition.rotation);
		if (this.gameManager.GetSceneSettings().isNight)
		{
			particleSystem.lights.light.gameObject.SetActive(true);
		}
		AudioSource.PlayClipAtPoint(this.audioFire, this.muzzlePosition.position);
		GameEvents.current.ShotFired();
	}

	// Token: 0x06000318 RID: 792 RVA: 0x00013E8F File Offset: 0x0001208F
	private void DisableIgnoreReload()
	{
		this.ignoreReload = false;
	}

	// Token: 0x06000319 RID: 793 RVA: 0x00013E98 File Offset: 0x00012098
	public void Holster()
	{
		this.isEquipped = false;
		this.holstered = true;
	}

	// Token: 0x0600031A RID: 794 RVA: 0x00013EA8 File Offset: 0x000120A8
	public void Unholster()
	{
		this.MagazineLoadCoolDown(0.2f);
		this.holstered = false;
		this.isEquipped = true;
		if (this.ignoreReload)
		{
			base.Invoke("DisableIgnoreReload", 0.5f);
		}
	}

	// Token: 0x0600031B RID: 795 RVA: 0x00013EDB File Offset: 0x000120DB
	public string WeaponID()
	{
		return this.weaponID;
	}

	// Token: 0x0600031C RID: 796 RVA: 0x00013EE3 File Offset: 0x000120E3
	public WeaponController.WeaponStatus CheckCondition()
	{
		return this.status;
	}

	// Token: 0x0600031D RID: 797 RVA: 0x00013EEC File Offset: 0x000120EC
	public void CycleAttachments(AccessoryManager.AccessoryType type)
	{
		switch (type)
		{
		case AccessoryManager.AccessoryType.Optic:
			this.CycleNext(this.optics);
			return;
		case AccessoryManager.AccessoryType.Magazine:
			if (this.magazines.Length > 1)
			{
				GameObject gameObject = this.CycleNext(this.magazines);
				this.magazineToBeDisabled = gameObject;
				this.magazineToBeEjected = gameObject;
				this.magazineToBeInstantiated = gameObject;
				this.magazineCapacity = gameObject.GetComponent<AccessoryManager>().roundCount;
				this.currentAmmo = this.magazineCapacity + 1;
				this.currentMagazineMax = this.magazineCapacity;
			}
			else
			{
				if (this.soundManager == null)
				{
					this.soundManager = Object.FindObjectOfType<SoundManager>();
				}
				this.soundManager.Play(this.soundManager.UIerror);
			}
			if (base.GetComponent<AmmoTypeManager>())
			{
				base.GetComponent<AmmoTypeManager>().InitiateRounds(this);
			}
			GameEvents.current.WeaponModified();
			return;
		case AccessoryManager.AccessoryType.BackupOptic:
			break;
		case AccessoryManager.AccessoryType.Choke:
		{
			GameObject gameObject2 = this.CycleNext(this.chokes);
			this.chokeSpread = gameObject2.GetComponent<AccessoryManager>().spread;
			break;
		}
		default:
			return;
		}
	}

	// Token: 0x0600031E RID: 798 RVA: 0x00013FEC File Offset: 0x000121EC
	private GameObject CycleNext(GameObject[] objects)
	{
		if (objects.Length > 1)
		{
			for (int i = 0; i < objects.Length; i++)
			{
				if (objects[i].activeSelf)
				{
					objects[i].SetActive(false);
					GameObject result;
					if (i + 1 >= objects.Length)
					{
						objects[0].SetActive(true);
						result = objects[0];
					}
					else
					{
						objects[i + 1].SetActive(true);
						result = objects[i + 1];
					}
					return result;
				}
			}
		}
		return null;
	}

	// Token: 0x0600031F RID: 799 RVA: 0x0001404C File Offset: 0x0001224C
	public void EmptyGun()
	{
		if (this.weaponType == WeaponController.WeaponType.Revolver)
		{
			this.moonClip.SetActive(false);
			this.currentAmmo = 0;
			this.cylinderEmpty = true;
			this.status = WeaponController.WeaponStatus.Empty;
			return;
		}
		if (!this.holstered && this.holsterControl != null)
		{
			this.holsterControl.Holster(base.gameObject);
			GameEvents.current.Holster();
		}
		if (this.status == WeaponController.WeaponStatus.EmptySlideLockedBack || this.status == WeaponController.WeaponStatus.SlideLockedBack || this.status == WeaponController.WeaponStatus.ManualSlideLocked || this.status == WeaponController.WeaponStatus.LoadedSlideLockedBack)
		{
			this.SlideRelease();
		}
		this.Cock(false);
		this.SafetyToggle(false);
		this.hasMagazine = false;
		if (this.weaponType != WeaponController.WeaponType.ShotgunField)
		{
			this.magazineToBeDisabled.SetActive(false);
		}
		this.currentAmmo = 0;
		if (this.hasAltAmmo)
		{
			this.ammoTypeManager.Clear();
		}
		this.ignoreReload = true;
		this.status = WeaponController.WeaponStatus.Empty;
		this.ShowRound(0);
		this.ShowRound(1);
	}

	// Token: 0x06000320 RID: 800 RVA: 0x0001413F File Offset: 0x0001233F
	private void OnDestroy()
	{
		GameEvents.current.onHolsterDraw -= this.OnHolsterDraw;
	}

	// Token: 0x04000334 RID: 820
	[Header("Weapon Info")]
	[SerializeField]
	public string weaponID;

	// Token: 0x04000335 RID: 821
	[SerializeField]
	public WeaponController.WeaponType weaponType;

	// Token: 0x04000336 RID: 822
	[Header("Weapon States")]
	[SerializeField]
	private WeaponController.WeaponStatus spawnStatus = WeaponController.WeaponStatus.Loaded;

	// Token: 0x04000337 RID: 823
	[SerializeField]
	public WeaponController.WeaponStatus status;

	// Token: 0x04000338 RID: 824
	[SerializeField]
	private Animator animator;

	// Token: 0x04000339 RID: 825
	[Header("Ammunition Related")]
	[SerializeField]
	private GameObject projectilePrefab;

	// Token: 0x0400033A RID: 826
	[SerializeField]
	private ParticleSystem shellEjection;

	// Token: 0x0400033B RID: 827
	[SerializeField]
	private ParticleSystem roundEjection;

	// Token: 0x0400033C RID: 828
	[SerializeField]
	private ParticleSystem muzzleFlash;

	// Token: 0x0400033D RID: 829
	[SerializeField]
	private Renderer pressCheckRound;

	// Token: 0x0400033E RID: 830
	[SerializeField]
	private Renderer[] pressCheckRoundInMag;

	// Token: 0x0400033F RID: 831
	[SerializeField]
	private int maxMagazine = 3;

	// Token: 0x04000340 RID: 832
	[SerializeField]
	public int magazineCapacity;

	// Token: 0x04000341 RID: 833
	public int currentMagazineMax;

	// Token: 0x04000342 RID: 834
	[SerializeField]
	public int currentAmmo;

	// Token: 0x04000343 RID: 835
	[SerializeField]
	private float timeToDeleteOldMagazine = 5f;

	// Token: 0x04000344 RID: 836
	[SerializeField]
	private Transform shellEjectPosition;

	// Token: 0x04000345 RID: 837
	[SerializeField]
	private Transform muzzlePosition;

	// Token: 0x04000346 RID: 838
	[Header("Revolver Related")]
	[SerializeField]
	private GameObject[] revolverRounds;

	// Token: 0x04000347 RID: 839
	[SerializeField]
	private GameObject[] revolverRoundMidSpin;

	// Token: 0x04000348 RID: 840
	[SerializeField]
	private GameObject clipToBeEjected;

	// Token: 0x04000349 RID: 841
	[SerializeField]
	private GameObject moonClip;

	// Token: 0x0400034A RID: 842
	[SerializeField]
	private float pointOfNoReturn = 0.4f;

	// Token: 0x0400034B RID: 843
	[SerializeField]
	private float timeRequiredToReload = 0.2f;

	// Token: 0x0400034C RID: 844
	[SerializeField]
	private float timeToBreak90 = 0.1f;

	// Token: 0x0400034D RID: 845
	[SerializeField]
	private float ejectMagScaler;

	// Token: 0x0400034E RID: 846
	[SerializeField]
	private AudioClip audioRevolverEject;

	// Token: 0x0400034F RID: 847
	private int triggerStatus;

	// Token: 0x04000350 RID: 848
	private float lastTriggerValue;

	// Token: 0x04000351 RID: 849
	private float timePointedDown;

	// Token: 0x04000352 RID: 850
	private float timeSinceBreaking90;

	// Token: 0x04000353 RID: 851
	private bool doubleActionReset;

	// Token: 0x04000354 RID: 852
	private bool cylinderOpened;

	// Token: 0x04000355 RID: 853
	private bool cylinderEmpty;

	// Token: 0x04000356 RID: 854
	private bool revolverInEjectRotation;

	// Token: 0x04000357 RID: 855
	private Quaternion lastRot;

	// Token: 0x04000358 RID: 856
	private Vector3 lastLocalPos;

	// Token: 0x04000359 RID: 857
	[Header("Shotgun Ammo Related")]
	[SerializeField]
	private Renderer[] shellLoadRenderers;

	// Token: 0x0400035A RID: 858
	public Material defaultMaterial;

	// Token: 0x0400035B RID: 859
	public Material altMaterial;

	// Token: 0x0400035C RID: 860
	[SerializeField]
	private Renderer[] lifterShellRenderers;

	// Token: 0x0400035D RID: 861
	[SerializeField]
	private GameObject lifterShell;

	// Token: 0x0400035E RID: 862
	public float chokeSpread;

	// Token: 0x0400035F RID: 863
	[Header("Magazine Transforms")]
	[SerializeField]
	private GameObject magazineToBeEjected;

	// Token: 0x04000360 RID: 864
	[SerializeField]
	public GameObject magazineToBeDisabled;

	// Token: 0x04000361 RID: 865
	[SerializeField]
	private GameObject magazineToBeInstantiated;

	// Token: 0x04000362 RID: 866
	[SerializeField]
	private Transform magazineEjectionDirection;

	// Token: 0x04000363 RID: 867
	private BoxCollider magazineCollider;

	// Token: 0x04000364 RID: 868
	[Header("Sounds")]
	[SerializeField]
	private AudioClip audioFire;

	// Token: 0x04000365 RID: 869
	[SerializeField]
	private AudioClip audioFireEmpty;

	// Token: 0x04000366 RID: 870
	[SerializeField]
	private AudioClip audioTriggerReset;

	// Token: 0x04000367 RID: 871
	[SerializeField]
	private AudioClip audioMagazineEject;

	// Token: 0x04000368 RID: 872
	[SerializeField]
	private AudioClip audioMagazineInsert;

	// Token: 0x04000369 RID: 873
	[SerializeField]
	private AudioClip audioSlideRelease;

	// Token: 0x0400036A RID: 874
	[Header("Controls")]
	[SerializeField]
	private float detectionThreshold;

	// Token: 0x0400036B RID: 875
	[SerializeField]
	private bool hasSafety;

	// Token: 0x0400036C RID: 876
	[SerializeField]
	private bool isDoubleAction;

	// Token: 0x0400036D RID: 877
	[SerializeField]
	private float triggerResetPosition;

	// Token: 0x0400036E RID: 878
	[SerializeField]
	private float triggerWallPosition;

	// Token: 0x0400036F RID: 879
	[SerializeField]
	private float slideLockPosition = 0.8f;

	// Token: 0x04000370 RID: 880
	[SerializeField]
	public Transform adjustmentArrowsTransform;

	// Token: 0x04000371 RID: 881
	[Header("Customisation")]
	[SerializeField]
	public float opticRecoil = 1.5f;

	// Token: 0x04000372 RID: 882
	[SerializeField]
	public GameObject[] magazines;

	// Token: 0x04000373 RID: 883
	[SerializeField]
	public GameObject[] optics;

	// Token: 0x04000374 RID: 884
	[SerializeField]
	public GameObject[] chokes;

	// Token: 0x04000375 RID: 885
	[SerializeField]
	public MaterialAssigner holsterMaterialAssigner;

	// Token: 0x04000376 RID: 886
	[Header("Misc")]
	[SerializeField]
	private TMP_Text testPro;

	// Token: 0x04000377 RID: 887
	[SerializeField]
	private bool conditionTest;

	// Token: 0x04000378 RID: 888
	[SerializeField]
	public TMP_Text adjustmentText;

	// Token: 0x04000379 RID: 889
	[SerializeField]
	public TMP_Text triggerText;

	// Token: 0x0400037A RID: 890
	[Header("Presets")]
	[SerializeField]
	public string startPreset;

	// Token: 0x0400037B RID: 891
	[SerializeField]
	public WeaponController.Preset[] presets;

	// Token: 0x0400037C RID: 892
	[SerializeField]
	public WeaponController.Preset currentPreset;

	// Token: 0x0400037D RID: 893
	[SerializeField]
	public WeaponController.Preset previousPreset;

	// Token: 0x0400037E RID: 894
	public bool testMode;

	// Token: 0x0400037F RID: 895
	public bool testFire;

	// Token: 0x04000380 RID: 896
	public bool testBoltRelease;

	// Token: 0x04000381 RID: 897
	public bool testShotgunReload;

	// Token: 0x04000382 RID: 898
	public bool doubleActionHammerDrop;

	// Token: 0x04000383 RID: 899
	public bool doubleActionCoolDown;

	// Token: 0x04000384 RID: 900
	public Vector2 testStick;

	// Token: 0x04000385 RID: 901
	public bool isEquipped;

	// Token: 0x04000386 RID: 902
	private bool hasAltAmmo;

	// Token: 0x04000387 RID: 903
	private bool shotgunReloading;

	// Token: 0x04000388 RID: 904
	private bool shotgunRoundInLifter;

	// Token: 0x04000389 RID: 905
	private bool disableControls;

	// Token: 0x0400038A RID: 906
	private bool hasMagazine;

	// Token: 0x0400038B RID: 907
	private bool canShoot;

	// Token: 0x0400038C RID: 908
	private bool triggerReset;

	// Token: 0x0400038D RID: 909
	private bool holstered;

	// Token: 0x0400038E RID: 910
	private bool ignoreReload;

	// Token: 0x0400038F RID: 911
	private bool cocked;

	// Token: 0x04000390 RID: 912
	private bool safetyOn;

	// Token: 0x04000391 RID: 913
	private bool slideActionInProgress;

	// Token: 0x04000392 RID: 914
	private bool slideBack;

	// Token: 0x04000393 RID: 915
	private bool joystickEngaged;

	// Token: 0x04000394 RID: 916
	private bool magazineEjectCoolDown;

	// Token: 0x04000395 RID: 917
	private Vector3 lastPos;

	// Token: 0x04000396 RID: 918
	private int currentOpticIndex;

	// Token: 0x04000397 RID: 919
	private int currentMagazineIndex;

	// Token: 0x04000398 RID: 920
	private float slideEjectThreshold = 0.7f;

	// Token: 0x04000399 RID: 921
	private float triggerWallPositionTemp;

	// Token: 0x0400039A RID: 922
	private float triggerResetPositionTemp;

	// Token: 0x0400039B RID: 923
	private ControlManager controlManager;

	// Token: 0x0400039C RID: 924
	private OVRInput.Controller controller;

	// Token: 0x0400039D RID: 925
	private ObjectManager objectManager;

	// Token: 0x0400039E RID: 926
	private GameManager gameManager;

	// Token: 0x0400039F RID: 927
	private PlayerData playerData;

	// Token: 0x040003A0 RID: 928
	private HapticManager hapticManager;

	// Token: 0x040003A1 RID: 929
	private HolsterControl holsterControl;

	// Token: 0x040003A2 RID: 930
	private AmmoTypeManager ammoTypeManager;

	// Token: 0x040003A3 RID: 931
	private SceneSettings sceneSettings;

	// Token: 0x040003A4 RID: 932
	private SettingsManager settingsManager;

	// Token: 0x040003A5 RID: 933
	private SoundManager soundManager;

	// Token: 0x040003A6 RID: 934
	private AudioSource audioSource;

	// Token: 0x040003A7 RID: 935
	private AmmoTypeManager.AmmoType ammoTypeInLifter;

	// Token: 0x040003A8 RID: 936
	private Queue<GameObject> magazineQueue = new Queue<GameObject>();

	// Token: 0x020001CC RID: 460
	public enum WeaponStatus
	{
		// Token: 0x04000DA3 RID: 3491
		Empty,
		// Token: 0x04000DA4 RID: 3492
		LoadedEmptyChamber,
		// Token: 0x04000DA5 RID: 3493
		LoadedSlideLockedBack,
		// Token: 0x04000DA6 RID: 3494
		EmptyRoundInChamber,
		// Token: 0x04000DA7 RID: 3495
		EmptySlideLockedBack,
		// Token: 0x04000DA8 RID: 3496
		SlideLockedBack,
		// Token: 0x04000DA9 RID: 3497
		Loaded,
		// Token: 0x04000DAA RID: 3498
		EmptySlideForwardEmptyMag,
		// Token: 0x04000DAB RID: 3499
		ManualSlideLocked
	}

	// Token: 0x020001CD RID: 461
	public enum WeaponType
	{
		// Token: 0x04000DAD RID: 3501
		Pistol,
		// Token: 0x04000DAE RID: 3502
		Rifle,
		// Token: 0x04000DAF RID: 3503
		Shotgun,
		// Token: 0x04000DB0 RID: 3504
		ShotgunField,
		// Token: 0x04000DB1 RID: 3505
		RifleField,
		// Token: 0x04000DB2 RID: 3506
		Revolver
	}

	// Token: 0x020001CE RID: 462
	public enum CurrentTriggerStatus
	{
		// Token: 0x04000DB4 RID: 3508
		Stationary,
		// Token: 0x04000DB5 RID: 3509
		Pulled,
		// Token: 0x04000DB6 RID: 3510
		Released
	}

	// Token: 0x020001CF RID: 463
	[Serializable]
	public class Preset
	{
		// Token: 0x04000DB7 RID: 3511
		public string presetName;

		// Token: 0x04000DB8 RID: 3512
		public bool unlocked;

		// Token: 0x04000DB9 RID: 3513
		public GameObject[] presetParts;
	}
}
