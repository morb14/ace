﻿using System;
using UnityEngine;

// Token: 0x02000039 RID: 57
public class DisqualifyQuad : MonoBehaviour
{
	// Token: 0x060001F2 RID: 498 RVA: 0x0000ADE2 File Offset: 0x00008FE2
	private void Start()
	{
		GameEvents.current.onDisqualify += this.Flash;
		this.renderer.enabled = false;
	}

	// Token: 0x060001F3 RID: 499 RVA: 0x0000AE06 File Offset: 0x00009006
	private void Update()
	{
		if (this.activate && Time.time > this.startTime + this.duration)
		{
			this.renderer.enabled = false;
			this.activate = false;
		}
	}

	// Token: 0x060001F4 RID: 500 RVA: 0x0000AE37 File Offset: 0x00009037
	private void Flash()
	{
		this.activate = true;
		this.startTime = Time.time;
		this.renderer.enabled = true;
	}

	// Token: 0x060001F5 RID: 501 RVA: 0x0000AE57 File Offset: 0x00009057
	private void OnDestroy()
	{
		GameEvents.current.onDisqualify -= this.Flash;
	}

	// Token: 0x040001A9 RID: 425
	[SerializeField]
	private MeshRenderer renderer;

	// Token: 0x040001AA RID: 426
	[SerializeField]
	private float duration = 0.5f;

	// Token: 0x040001AB RID: 427
	private bool activate;

	// Token: 0x040001AC RID: 428
	private float startTime;
}
