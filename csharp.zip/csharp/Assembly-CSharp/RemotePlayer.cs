﻿using System;
using Oculus.Platform;
using UnityEngine;

// Token: 0x020000A4 RID: 164
public class RemotePlayer
{
	// Token: 0x0400067E RID: 1662
	public ulong remoteUserID;

	// Token: 0x0400067F RID: 1663
	public bool stillInRoom;

	// Token: 0x04000680 RID: 1664
	public PeerConnectionState p2pConnectionState;

	// Token: 0x04000681 RID: 1665
	public PeerConnectionState voipConnectionState;

	// Token: 0x04000682 RID: 1666
	public OvrAvatar RemoteAvatar;

	// Token: 0x04000683 RID: 1667
	public Vector3 receivedRootPosition;

	// Token: 0x04000684 RID: 1668
	public Vector3 receivedRootPositionPrior;

	// Token: 0x04000685 RID: 1669
	public Quaternion receivedRootRotation;

	// Token: 0x04000686 RID: 1670
	public Quaternion receivedRootRotationPrior;

	// Token: 0x04000687 RID: 1671
	public VoipAudioSourceHiLevel voipSource;
}
