﻿using System;
using System.Runtime.InteropServices;
using UnityEngine;

// Token: 0x02000109 RID: 265
public class OVRLipSync : MonoBehaviour
{
	// Token: 0x060006A2 RID: 1698
	[DllImport("OVRLipSync")]
	private static extern int ovrLipSyncDll_Initialize(int samplerate, int buffersize);

	// Token: 0x060006A3 RID: 1699
	[DllImport("OVRLipSync")]
	private static extern void ovrLipSyncDll_Shutdown();

	// Token: 0x060006A4 RID: 1700
	[DllImport("OVRLipSync")]
	private static extern IntPtr ovrLipSyncDll_GetVersion(ref int Major, ref int Minor, ref int Patch);

	// Token: 0x060006A5 RID: 1701
	[DllImport("OVRLipSync")]
	private static extern int ovrLipSyncDll_CreateContextEx(ref uint context, OVRLipSync.ContextProviders provider, int sampleRate, bool enableAcceleration);

	// Token: 0x060006A6 RID: 1702
	[DllImport("OVRLipSync")]
	private static extern int ovrLipSyncDll_CreateContextWithModelFile(ref uint context, OVRLipSync.ContextProviders provider, string modelPath, int sampleRate, bool enableAcceleration);

	// Token: 0x060006A7 RID: 1703
	[DllImport("OVRLipSync")]
	private static extern int ovrLipSyncDll_DestroyContext(uint context);

	// Token: 0x060006A8 RID: 1704
	[DllImport("OVRLipSync")]
	private static extern int ovrLipSyncDll_ResetContext(uint context);

	// Token: 0x060006A9 RID: 1705
	[DllImport("OVRLipSync")]
	private static extern int ovrLipSyncDll_SendSignal(uint context, OVRLipSync.Signals signal, int arg1, int arg2);

	// Token: 0x060006AA RID: 1706
	[DllImport("OVRLipSync")]
	private static extern int ovrLipSyncDll_ProcessFrameEx(uint context, IntPtr audioBuffer, uint bufferSize, OVRLipSync.AudioDataType dataType, ref int frameNumber, ref int frameDelay, float[] visemes, int visemeCount, ref float laughterScore, float[] laughterCategories, int laughterCategoriesLength);

	// Token: 0x060006AB RID: 1707 RVA: 0x0002B24C File Offset: 0x0002944C
	private void Awake()
	{
		if (OVRLipSync.sInstance == null)
		{
			OVRLipSync.sInstance = this;
			if (OVRLipSync.IsInitialized() != OVRLipSync.Result.Success)
			{
				OVRLipSync.sInitialized = OVRLipSync.Initialize();
				if (OVRLipSync.sInitialized != OVRLipSync.Result.Success)
				{
					Debug.LogWarning(string.Format("OvrLipSync Awake: Failed to init Speech Rec library", Array.Empty<object>()));
				}
			}
			OVRTouchpad.Create();
			return;
		}
		Debug.LogWarning(string.Format("OVRLipSync Awake: Only one instance of OVRPLipSync can exist in the scene.", Array.Empty<object>()));
	}

	// Token: 0x060006AC RID: 1708 RVA: 0x0002B2B4 File Offset: 0x000294B4
	private void OnDestroy()
	{
		if (OVRLipSync.sInstance != this)
		{
			Debug.LogWarning("OVRLipSync OnDestroy: This is not the correct OVRLipSync instance.");
			return;
		}
	}

	// Token: 0x060006AD RID: 1709 RVA: 0x0002B2D0 File Offset: 0x000294D0
	public static OVRLipSync.Result Initialize()
	{
		int outputSampleRate = AudioSettings.outputSampleRate;
		int num;
		int num2;
		AudioSettings.GetDSPBufferSize(out num, out num2);
		Debug.LogWarning(string.Format("OvrLipSync Awake: Queried SampleRate: {0:F0} BufferSize: {1:F0}", outputSampleRate, num));
		OVRLipSync.sInitialized = (OVRLipSync.Result)OVRLipSync.ovrLipSyncDll_Initialize(outputSampleRate, num);
		return OVRLipSync.sInitialized;
	}

	// Token: 0x060006AE RID: 1710 RVA: 0x0002B318 File Offset: 0x00029518
	public static OVRLipSync.Result Initialize(int sampleRate, int bufferSize)
	{
		Debug.LogWarning(string.Format("OvrLipSync Awake: Queried SampleRate: {0:F0} BufferSize: {1:F0}", sampleRate, bufferSize));
		OVRLipSync.sInitialized = (OVRLipSync.Result)OVRLipSync.ovrLipSyncDll_Initialize(sampleRate, bufferSize);
		return OVRLipSync.sInitialized;
	}

	// Token: 0x060006AF RID: 1711 RVA: 0x0002B346 File Offset: 0x00029546
	public static void Shutdown()
	{
		OVRLipSync.ovrLipSyncDll_Shutdown();
		OVRLipSync.sInitialized = OVRLipSync.Result.Unknown;
	}

	// Token: 0x060006B0 RID: 1712 RVA: 0x0002B357 File Offset: 0x00029557
	public static OVRLipSync.Result IsInitialized()
	{
		return OVRLipSync.sInitialized;
	}

	// Token: 0x060006B1 RID: 1713 RVA: 0x0002B35E File Offset: 0x0002955E
	public static OVRLipSync.Result CreateContext(ref uint context, OVRLipSync.ContextProviders provider, int sampleRate = 0, bool enableAcceleration = false)
	{
		if (OVRLipSync.IsInitialized() != OVRLipSync.Result.Success && OVRLipSync.Initialize() != OVRLipSync.Result.Success)
		{
			return OVRLipSync.Result.CannotCreateContext;
		}
		return (OVRLipSync.Result)OVRLipSync.ovrLipSyncDll_CreateContextEx(ref context, provider, sampleRate, enableAcceleration);
	}

	// Token: 0x060006B2 RID: 1714 RVA: 0x0002B37D File Offset: 0x0002957D
	public static OVRLipSync.Result CreateContextWithModelFile(ref uint context, OVRLipSync.ContextProviders provider, string modelPath, int sampleRate = 0, bool enableAcceleration = false)
	{
		if (OVRLipSync.IsInitialized() != OVRLipSync.Result.Success && OVRLipSync.Initialize() != OVRLipSync.Result.Success)
		{
			return OVRLipSync.Result.CannotCreateContext;
		}
		return (OVRLipSync.Result)OVRLipSync.ovrLipSyncDll_CreateContextWithModelFile(ref context, provider, modelPath, sampleRate, enableAcceleration);
	}

	// Token: 0x060006B3 RID: 1715 RVA: 0x0002B39E File Offset: 0x0002959E
	public static OVRLipSync.Result DestroyContext(uint context)
	{
		if (OVRLipSync.IsInitialized() != OVRLipSync.Result.Success)
		{
			return OVRLipSync.Result.Unknown;
		}
		return (OVRLipSync.Result)OVRLipSync.ovrLipSyncDll_DestroyContext(context);
	}

	// Token: 0x060006B4 RID: 1716 RVA: 0x0002B3B3 File Offset: 0x000295B3
	public static OVRLipSync.Result ResetContext(uint context)
	{
		if (OVRLipSync.IsInitialized() != OVRLipSync.Result.Success)
		{
			return OVRLipSync.Result.Unknown;
		}
		return (OVRLipSync.Result)OVRLipSync.ovrLipSyncDll_ResetContext(context);
	}

	// Token: 0x060006B5 RID: 1717 RVA: 0x0002B3C8 File Offset: 0x000295C8
	public static OVRLipSync.Result SendSignal(uint context, OVRLipSync.Signals signal, int arg1, int arg2)
	{
		if (OVRLipSync.IsInitialized() != OVRLipSync.Result.Success)
		{
			return OVRLipSync.Result.Unknown;
		}
		return (OVRLipSync.Result)OVRLipSync.ovrLipSyncDll_SendSignal(context, signal, arg1, arg2);
	}

	// Token: 0x060006B6 RID: 1718 RVA: 0x0002B3E0 File Offset: 0x000295E0
	public static OVRLipSync.Result ProcessFrame(uint context, float[] audioBuffer, OVRLipSync.Frame frame, bool stereo = true)
	{
		if (OVRLipSync.IsInitialized() != OVRLipSync.Result.Success)
		{
			return OVRLipSync.Result.Unknown;
		}
		OVRLipSync.AudioDataType dataType = stereo ? OVRLipSync.AudioDataType.F32_Stereo : OVRLipSync.AudioDataType.F32_Mono;
		uint bufferSize = (uint)(stereo ? (audioBuffer.Length / 2) : audioBuffer.Length);
		GCHandle gchandle = GCHandle.Alloc(audioBuffer, GCHandleType.Pinned);
		OVRLipSync.Result result = (OVRLipSync.Result)OVRLipSync.ovrLipSyncDll_ProcessFrameEx(context, gchandle.AddrOfPinnedObject(), bufferSize, dataType, ref frame.frameNumber, ref frame.frameDelay, frame.Visemes, frame.Visemes.Length, ref frame.laughterScore, null, 0);
		gchandle.Free();
		return result;
	}

	// Token: 0x060006B7 RID: 1719 RVA: 0x0002B450 File Offset: 0x00029650
	public static OVRLipSync.Result ProcessFrame(uint context, short[] audioBuffer, OVRLipSync.Frame frame, bool stereo = true)
	{
		if (OVRLipSync.IsInitialized() != OVRLipSync.Result.Success)
		{
			return OVRLipSync.Result.Unknown;
		}
		OVRLipSync.AudioDataType dataType = stereo ? OVRLipSync.AudioDataType.S16_Stereo : OVRLipSync.AudioDataType.S16_Mono;
		uint bufferSize = (uint)(stereo ? (audioBuffer.Length / 2) : audioBuffer.Length);
		GCHandle gchandle = GCHandle.Alloc(audioBuffer, GCHandleType.Pinned);
		OVRLipSync.Result result = (OVRLipSync.Result)OVRLipSync.ovrLipSyncDll_ProcessFrameEx(context, gchandle.AddrOfPinnedObject(), bufferSize, dataType, ref frame.frameNumber, ref frame.frameDelay, frame.Visemes, frame.Visemes.Length, ref frame.laughterScore, null, 0);
		gchandle.Free();
		return result;
	}

	// Token: 0x040008E9 RID: 2281
	public static readonly int VisemeCount = Enum.GetNames(typeof(OVRLipSync.Viseme)).Length;

	// Token: 0x040008EA RID: 2282
	public static readonly int SignalCount = Enum.GetNames(typeof(OVRLipSync.Signals)).Length;

	// Token: 0x040008EB RID: 2283
	public const string strOVRLS = "OVRLipSync";

	// Token: 0x040008EC RID: 2284
	private static OVRLipSync.Result sInitialized = OVRLipSync.Result.Unknown;

	// Token: 0x040008ED RID: 2285
	public static OVRLipSync sInstance = null;

	// Token: 0x020001FC RID: 508
	public enum Result
	{
		// Token: 0x04000E96 RID: 3734
		Success,
		// Token: 0x04000E97 RID: 3735
		Unknown = -2200,
		// Token: 0x04000E98 RID: 3736
		CannotCreateContext = -2201,
		// Token: 0x04000E99 RID: 3737
		InvalidParam = -2202,
		// Token: 0x04000E9A RID: 3738
		BadSampleRate = -2203,
		// Token: 0x04000E9B RID: 3739
		MissingDLL = -2204,
		// Token: 0x04000E9C RID: 3740
		BadVersion = -2205,
		// Token: 0x04000E9D RID: 3741
		UndefinedFunction = -2206
	}

	// Token: 0x020001FD RID: 509
	public enum AudioDataType
	{
		// Token: 0x04000E9F RID: 3743
		S16_Mono,
		// Token: 0x04000EA0 RID: 3744
		S16_Stereo,
		// Token: 0x04000EA1 RID: 3745
		F32_Mono,
		// Token: 0x04000EA2 RID: 3746
		F32_Stereo
	}

	// Token: 0x020001FE RID: 510
	public enum Viseme
	{
		// Token: 0x04000EA4 RID: 3748
		sil,
		// Token: 0x04000EA5 RID: 3749
		PP,
		// Token: 0x04000EA6 RID: 3750
		FF,
		// Token: 0x04000EA7 RID: 3751
		TH,
		// Token: 0x04000EA8 RID: 3752
		DD,
		// Token: 0x04000EA9 RID: 3753
		kk,
		// Token: 0x04000EAA RID: 3754
		CH,
		// Token: 0x04000EAB RID: 3755
		SS,
		// Token: 0x04000EAC RID: 3756
		nn,
		// Token: 0x04000EAD RID: 3757
		RR,
		// Token: 0x04000EAE RID: 3758
		aa,
		// Token: 0x04000EAF RID: 3759
		E,
		// Token: 0x04000EB0 RID: 3760
		ih,
		// Token: 0x04000EB1 RID: 3761
		oh,
		// Token: 0x04000EB2 RID: 3762
		ou
	}

	// Token: 0x020001FF RID: 511
	public enum Signals
	{
		// Token: 0x04000EB4 RID: 3764
		VisemeOn,
		// Token: 0x04000EB5 RID: 3765
		VisemeOff,
		// Token: 0x04000EB6 RID: 3766
		VisemeAmount,
		// Token: 0x04000EB7 RID: 3767
		VisemeSmoothing,
		// Token: 0x04000EB8 RID: 3768
		LaughterAmount
	}

	// Token: 0x02000200 RID: 512
	public enum ContextProviders
	{
		// Token: 0x04000EBA RID: 3770
		Original,
		// Token: 0x04000EBB RID: 3771
		Enhanced,
		// Token: 0x04000EBC RID: 3772
		Enhanced_with_Laughter
	}

	// Token: 0x02000201 RID: 513
	[Serializable]
	public class Frame
	{
		// Token: 0x06000C4F RID: 3151 RVA: 0x000448F4 File Offset: 0x00042AF4
		public void CopyInput(OVRLipSync.Frame input)
		{
			this.frameNumber = input.frameNumber;
			this.frameDelay = input.frameDelay;
			input.Visemes.CopyTo(this.Visemes, 0);
			this.laughterScore = input.laughterScore;
		}

		// Token: 0x06000C50 RID: 3152 RVA: 0x0004492C File Offset: 0x00042B2C
		public void Reset()
		{
			this.frameNumber = 0;
			this.frameDelay = 0;
			Array.Clear(this.Visemes, 0, OVRLipSync.VisemeCount);
			this.laughterScore = 0f;
		}

		// Token: 0x04000EBD RID: 3773
		public int frameNumber;

		// Token: 0x04000EBE RID: 3774
		public int frameDelay;

		// Token: 0x04000EBF RID: 3775
		public float[] Visemes = new float[OVRLipSync.VisemeCount];

		// Token: 0x04000EC0 RID: 3776
		public float laughterScore;
	}
}
