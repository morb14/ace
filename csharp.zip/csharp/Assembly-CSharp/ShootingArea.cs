﻿using System;
using UnityEngine;

// Token: 0x02000055 RID: 85
public class ShootingArea : MonoBehaviour
{
	// Token: 0x06000334 RID: 820 RVA: 0x00014BB4 File Offset: 0x00012DB4
	private void Start()
	{
		if (this.areaType == ShootingArea.AreaType.Starting)
		{
			this.originalPos = base.transform.position;
			base.transform.position = new Vector3(100f, 100f, 100f);
			base.Invoke("Reposition", Time.deltaTime);
		}
		GameEvents.current.onShootingAreaCheck += this.OnShootingAreaCheck;
	}

	// Token: 0x06000335 RID: 821 RVA: 0x00014C20 File Offset: 0x00012E20
	private void Reposition()
	{
		base.transform.position = this.originalPos;
	}

	// Token: 0x06000336 RID: 822 RVA: 0x00014C33 File Offset: 0x00012E33
	private void OnTriggerEnter(Collider other)
	{
		if (this.areaType == ShootingArea.AreaType.Shooting)
		{
			GameEvents.current.ShootingAreaEnter();
		}
		if (this.areaType == ShootingArea.AreaType.Starting)
		{
			GameEvents.current.StartingAreaEnter();
		}
	}

	// Token: 0x06000337 RID: 823 RVA: 0x00014C5A File Offset: 0x00012E5A
	private void OnTriggerExit(Collider other)
	{
		if (this.areaType == ShootingArea.AreaType.Shooting)
		{
			GameEvents.current.ShootingAreaExit();
		}
		if (this.areaType == ShootingArea.AreaType.Starting)
		{
			GameEvents.current.StartingAreaExit();
		}
	}

	// Token: 0x06000338 RID: 824 RVA: 0x00014C84 File Offset: 0x00012E84
	private void OnShootingAreaCheck()
	{
		Vector3 position = base.transform.position;
		base.transform.position = Vector3.zero;
		base.transform.position = position;
	}

	// Token: 0x06000339 RID: 825 RVA: 0x00014CBC File Offset: 0x00012EBC
	private void OnDrawGizmos()
	{
		BoxCollider component = base.GetComponent<BoxCollider>();
		if (this.areaType == ShootingArea.AreaType.Shooting)
		{
			Gizmos.color = Color.green;
		}
		else
		{
			Gizmos.color = Color.yellow;
		}
		Vector3 vector = base.transform.TransformPoint(component.center + new Vector3(component.size.x, -component.size.y, component.size.z) * 0.5f);
		Vector3 vector2 = base.transform.TransformPoint(component.center + new Vector3(-component.size.x, -component.size.y, component.size.z) * 0.5f);
		Vector3 vector3 = base.transform.TransformPoint(component.center + new Vector3(-component.size.x, -component.size.y, -component.size.z) * 0.5f);
		Vector3 vector4 = base.transform.TransformPoint(component.center + new Vector3(component.size.x, -component.size.y, -component.size.z) * 0.5f);
		Gizmos.DrawLine(vector, vector2);
		Gizmos.DrawLine(vector2, vector3);
		Gizmos.DrawLine(vector3, vector4);
		Gizmos.DrawLine(vector4, vector);
	}

	// Token: 0x0600033A RID: 826 RVA: 0x00014E3F File Offset: 0x0001303F
	private void OnDestroy()
	{
		GameEvents.current.onShootingAreaCheck -= this.OnShootingAreaCheck;
	}

	// Token: 0x040003D2 RID: 978
	public Vector3[] vector3s;

	// Token: 0x040003D3 RID: 979
	[SerializeField]
	private ShootingArea.AreaType areaType;

	// Token: 0x040003D4 RID: 980
	private Vector3 originalPos;

	// Token: 0x020001D1 RID: 465
	public enum AreaType
	{
		// Token: 0x04000DC3 RID: 3523
		Shooting,
		// Token: 0x04000DC4 RID: 3524
		Starting
	}
}
