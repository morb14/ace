﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

// Token: 0x02000070 RID: 112
public class TutorialManager : MonoBehaviour
{
	// Token: 0x06000422 RID: 1058 RVA: 0x0001C0C8 File Offset: 0x0001A2C8
	private void Start()
	{
		this.soundManager = Object.FindObjectOfType<SoundManager>();
		this.gameManager = Object.FindObjectOfType<GameManager>();
		this.controlManager = Object.FindObjectOfType<ControlManager>();
		this.tutorialStageIndex = 0;
		this.currentTutorialStage = TutorialManager.TutorialStage.SetDownController;
		this.StoveHolsteredObjects();
		this.DisableTargets();
		this.AssignEvents();
	}

	// Token: 0x06000423 RID: 1059 RVA: 0x0001C118 File Offset: 0x0001A318
	private void AssignEvents()
	{
		GameEvents.current.onGrabStart += this.OnGrabStart;
		GameEvents.current.onHolsterLock += this.OnHolsterLock;
		GameEvents.current.onMagazineLoad += this.OnMagazineLoad;
		GameEvents.current.onRoundChambered += this.OnRoundChambered;
		GameEvents.current.onSafetyOn += this.OnSafetyOn;
		GameEvents.current.onSafetyOff += this.OnSafetyOff;
		GameEvents.current.onSlideRelease += this.OnSlideRelease;
	}

	// Token: 0x06000424 RID: 1060 RVA: 0x0001C1BF File Offset: 0x0001A3BF
	private void DisableTargets()
	{
		this.target_shootAll.SetActive(false);
		this.target_freeRange.SetActive(false);
	}

	// Token: 0x06000425 RID: 1061 RVA: 0x0001C1DC File Offset: 0x0001A3DC
	private void StoveHolsteredObjects()
	{
		this.volume = Object.FindObjectOfType<HolsterVolume>();
		this.parentTransform = this.volume.transform;
		foreach (Transform transform in this.volume.GetComponentsInChildren<Transform>())
		{
			if (transform.parent == this.parentTransform)
			{
				GameObject gameObject = transform.gameObject;
				this.holsteredObjectList.Add(gameObject);
				this.holsteredObjectPosDic.Add(gameObject, gameObject.transform.localPosition);
				this.holsteredObjectRotDic.Add(gameObject, gameObject.transform.localRotation);
				transform.parent = null;
				transform.position = new Vector3(0f, -20f, 0f);
				transform.gameObject.SetActive(false);
			}
		}
		MonoBehaviour.print("HOLSTERED OBJECTS SAVED " + this.holsteredObjectList.Count);
	}

	// Token: 0x06000426 RID: 1062 RVA: 0x0001C2CC File Offset: 0x0001A4CC
	private void DestroyHolsteredObjects()
	{
		foreach (Transform transform in this.volume.GetComponentsInChildren<Transform>())
		{
			if (transform != this.volume.transform)
			{
				Object.Destroy(transform.gameObject);
			}
		}
	}

	// Token: 0x06000427 RID: 1063 RVA: 0x0001C315 File Offset: 0x0001A515
	private void Update()
	{
		this.UpdateTutorial();
		this.TextFadeUpdate();
		this.TestNextStage();
	}

	// Token: 0x06000428 RID: 1064 RVA: 0x0001C329 File Offset: 0x0001A529
	private void TestNextStage()
	{
		if (this.testNextStage)
		{
			this.NextStage();
			this.testNextStage = false;
		}
	}

	// Token: 0x06000429 RID: 1065 RVA: 0x0001C340 File Offset: 0x0001A540
	private void NextStage()
	{
		GameEvents.current.TutorialStageAdvanced();
		this.tutorialStageIndex++;
		this.textUpdated = false;
		this.targetSpawned = false;
		this.TextFade(false);
		this.eventConditionMet = false;
		this.soundManager.Play(this.soundManager.UIcorrect);
		switch (this.tutorialStageIndex)
		{
		case 0:
			this.currentTutorialStage = TutorialManager.TutorialStage.SetDownController;
			return;
		case 1:
			this.currentTutorialStage = TutorialManager.TutorialStage.PickUp;
			return;
		case 2:
			this.currentTutorialStage = TutorialManager.TutorialStage.PlaceInVolume;
			return;
		case 3:
			this.currentTutorialStage = TutorialManager.TutorialStage.HolsterLock;
			return;
		case 4:
			this.currentTutorialStage = TutorialManager.TutorialStage.LoadWeapon;
			return;
		case 5:
			this.currentTutorialStage = TutorialManager.TutorialStage.ChamberRound;
			return;
		case 6:
			this.currentTutorialStage = TutorialManager.TutorialStage.SafetyOn;
			return;
		case 7:
			this.currentTutorialStage = TutorialManager.TutorialStage.SafetyOff;
			return;
		case 8:
			this.currentTutorialStage = TutorialManager.TutorialStage.ShootAll;
			return;
		case 9:
			this.currentTutorialStage = TutorialManager.TutorialStage.ReleaseSlide;
			return;
		case 10:
			this.currentTutorialStage = TutorialManager.TutorialStage.Reholster;
			return;
		case 11:
			this.currentTutorialStage = TutorialManager.TutorialStage.RemoveHolster;
			return;
		default:
			return;
		}
	}

	// Token: 0x0600042A RID: 1066 RVA: 0x0001C438 File Offset: 0x0001A638
	private void UpdateTutorial()
	{
		switch (this.currentTutorialStage)
		{
		case TutorialManager.TutorialStage.SetDownController:
			this.TextFade(true);
			if (!this.textUpdated)
			{
				this.tutorialText.text = "- VRPS is a mostly single controller experience\n";
				TextMeshPro textMeshPro = this.tutorialText;
				textMeshPro.text += "- Please set down the non-dominant hand controller\n";
				TextMeshPro textMeshPro2 = this.tutorialText;
				textMeshPro2.text += "- Press [Trigger] when you have done so";
				this.textUpdated = true;
			}
			if (OVRInput.GetDown(OVRInput.Button.PrimaryIndexTrigger, OVRInput.Controller.RTouch))
			{
				this.activeController = OVRInput.Controller.RTouch;
				this.controlManager.ShowController(this.activeController);
				this.NextStage();
			}
			if (OVRInput.GetDown(OVRInput.Button.PrimaryIndexTrigger, OVRInput.Controller.LTouch))
			{
				this.activeController = OVRInput.Controller.LTouch;
				this.controlManager.ShowController(this.activeController);
				this.NextStage();
				return;
			}
			break;
		case TutorialManager.TutorialStage.PickUp:
			this.TextFade(true);
			if (!this.textUpdated && !this.textFading)
			{
				this.tutorialText.text = "- Distant grab the pistol\n";
				TextMeshPro textMeshPro3 = this.tutorialText;
				textMeshPro3.text += "- To distant grab, touch [Trigger] to aim at pistol\n";
				TextMeshPro textMeshPro4 = this.tutorialText;
				textMeshPro4.text += "- While line is connected to pistol, press down on [Grip]\n";
				this.textUpdated = true;
			}
			if (this.eventConditionMet)
			{
				this.NextStage();
				return;
			}
			break;
		case TutorialManager.TutorialStage.PlaceInVolume:
			this.TextFade(true);
			if (!this.textUpdated && !this.textFading)
			{
				this.tutorialText.text = "- Release [Grip] the pistol within the holster volume at your waist\n";
				TextMeshPro textMeshPro5 = this.tutorialText;
				textMeshPro5.text += "- Holster will turn yellow when it is ready to be released\n";
				this.textUpdated = true;
			}
			if (this.volume.GunInVolume())
			{
				this.NextStage();
				return;
			}
			break;
		case TutorialManager.TutorialStage.HolsterLock:
			this.TextFade(true);
			if (!this.textUpdated && !this.textFading)
			{
				this.tutorialText.text = "- Pull [Trigger] on the pistol to lock the holster\n";
				TextMeshPro textMeshPro6 = this.tutorialText;
				textMeshPro6.text += "- Holster will turn green when it is locked in position\n";
				this.textUpdated = true;
			}
			if (this.eventConditionMet)
			{
				this.NextStage();
				return;
			}
			break;
		case TutorialManager.TutorialStage.LoadWeapon:
			this.TextFade(true);
			if (!this.textUpdated && !this.textFading)
			{
				this.tutorialText.text = "- Press [Grip] to draw pistol from holster\n";
				TextMeshPro textMeshPro7 = this.tutorialText;
				textMeshPro7.text += "- Make sure your finger does not touch the [Trigger] when you draw\n";
				TextMeshPro textMeshPro8 = this.tutorialText;
				textMeshPro8.text += "- Tap the bottom of controller with other hand to initate a reload\n";
				this.textUpdated = true;
			}
			if (this.eventConditionMet)
			{
				this.NextStage();
				return;
			}
			break;
		case TutorialManager.TutorialStage.SafetyOn:
			this.TextFade(true);
			if (!this.textUpdated && !this.textFading)
			{
				this.tutorialText.text = "- Push [Joystick] right to engage safety\n";
				this.textUpdated = true;
			}
			if (this.eventConditionMet)
			{
				this.NextStage();
				return;
			}
			break;
		case TutorialManager.TutorialStage.SafetyOff:
			this.TextFade(true);
			if (!this.textUpdated && !this.textFading)
			{
				this.tutorialText.text = "- Push [Joystick] left to disengage safety\n";
				this.textUpdated = true;
			}
			if (this.eventConditionMet)
			{
				this.NextStage();
				return;
			}
			break;
		case TutorialManager.TutorialStage.ChamberRound:
			this.TextFade(true);
			if (!this.textUpdated && !this.textFading)
			{
				this.tutorialText.text = "- Push [Joystick] backwards with your support hand to chamber a round\n";
				this.textUpdated = true;
			}
			if (this.eventConditionMet)
			{
				this.NextStage();
				return;
			}
			break;
		case TutorialManager.TutorialStage.ShootAll:
			if (!this.targetSpawned)
			{
				this.SpawnTarget(this.currentTutorialStage);
			}
			this.TextFade(true);
			if (!this.textUpdated && !this.textFading)
			{
				this.tutorialText.text = "- Fire the gun until empty, preferably at the target\n";
				this.textUpdated = true;
			}
			if (this.tutorialWeapon.GetCurrentAmmo() <= 0)
			{
				this.NextStage();
				return;
			}
			break;
		case TutorialManager.TutorialStage.ReleaseSlide:
			this.TextFade(true);
			if (!this.textUpdated && !this.textFading)
			{
				string str;
				string str2;
				if (this.activeController == OVRInput.Controller.LTouch)
				{
					str = "Y";
					str2 = "X";
				}
				else
				{
					str = "B";
					str2 = "A";
				}
				this.tutorialText.text = "- Press [" + str2 + "] to release magazine\n";
				TextMeshPro textMeshPro9 = this.tutorialText;
				textMeshPro9.text += "- Tap to reload as before\n";
				TextMeshPro textMeshPro10 = this.tutorialText;
				textMeshPro10.text = textMeshPro10.text + "- Press [" + str + "] to release slide\n";
				this.textUpdated = true;
			}
			if (this.eventConditionMet)
			{
				this.NextStage();
				return;
			}
			break;
		case TutorialManager.TutorialStage.Reholster:
			if (!this.targetSpawned)
			{
				this.SpawnTarget(this.currentTutorialStage);
			}
			this.TextFade(true);
			if (!this.textUpdated && !this.textFading)
			{
				this.tutorialText.text = " - Familiarise yourselves with the controls, enjoy the targets\n";
				TextMeshPro textMeshPro11 = this.tutorialText;
				textMeshPro11.text += "- When ready, holster and return to the main menu behind you\n";
				this.textUpdated = true;
			}
			break;
		default:
			return;
		}
	}

	// Token: 0x0600042B RID: 1067 RVA: 0x0001C900 File Offset: 0x0001AB00
	private void SpawnTarget(TutorialManager.TutorialStage stage)
	{
		if (stage == TutorialManager.TutorialStage.ShootAll)
		{
			this.target_shootAll.SetActive(true);
			this.targetSpawned = true;
		}
		if (stage == TutorialManager.TutorialStage.Reholster)
		{
			this.target_freeRange.SetActive(true);
			this.targetSpawned = true;
		}
	}

	// Token: 0x0600042C RID: 1068 RVA: 0x0001C931 File Offset: 0x0001AB31
	private void OnSlideRelease()
	{
		if (this.currentTutorialStage == TutorialManager.TutorialStage.ReleaseSlide)
		{
			this.eventConditionMet = true;
		}
	}

	// Token: 0x0600042D RID: 1069 RVA: 0x0001C944 File Offset: 0x0001AB44
	private void OnRoundChambered()
	{
		if (this.currentTutorialStage == TutorialManager.TutorialStage.ChamberRound)
		{
			this.eventConditionMet = true;
		}
	}

	// Token: 0x0600042E RID: 1070 RVA: 0x0001C956 File Offset: 0x0001AB56
	private void OnSafetyOn()
	{
		if (this.currentTutorialStage == TutorialManager.TutorialStage.SafetyOn)
		{
			this.eventConditionMet = true;
		}
	}

	// Token: 0x0600042F RID: 1071 RVA: 0x0001C968 File Offset: 0x0001AB68
	private void OnSafetyOff()
	{
		if (this.currentTutorialStage == TutorialManager.TutorialStage.SafetyOff)
		{
			this.eventConditionMet = true;
		}
	}

	// Token: 0x06000430 RID: 1072 RVA: 0x0001C97A File Offset: 0x0001AB7A
	private void OnGrabStart()
	{
		if (this.currentTutorialStage == TutorialManager.TutorialStage.PickUp)
		{
			this.eventConditionMet = true;
		}
	}

	// Token: 0x06000431 RID: 1073 RVA: 0x0001C98C File Offset: 0x0001AB8C
	private void OnHolsterLock()
	{
		if (this.currentTutorialStage == TutorialManager.TutorialStage.HolsterLock)
		{
			this.eventConditionMet = true;
		}
	}

	// Token: 0x06000432 RID: 1074 RVA: 0x0001C99E File Offset: 0x0001AB9E
	private void OnMagazineLoad()
	{
		if (this.currentTutorialStage == TutorialManager.TutorialStage.LoadWeapon)
		{
			this.eventConditionMet = true;
		}
	}

	// Token: 0x06000433 RID: 1075 RVA: 0x0001C9B0 File Offset: 0x0001ABB0
	private void TextFade(bool on)
	{
		if (this.textFading)
		{
			return;
		}
		if (!this.textFadeOn && on)
		{
			this.TextFadeMethod(true, 0f);
			return;
		}
		if (this.textFadeOn && !on)
		{
			this.TextFadeMethod(false, 1f);
		}
	}

	// Token: 0x06000434 RID: 1076 RVA: 0x0001C9EC File Offset: 0x0001ABEC
	private void TextFadeMethod(bool fade, float alpha)
	{
		this.tutorialText.color = new Color(this.tutorialText.color.r, this.tutorialText.color.g, this.tutorialText.color.b, alpha);
		this.textFadeOn = fade;
	}

	// Token: 0x06000435 RID: 1077 RVA: 0x0001CA44 File Offset: 0x0001AC44
	private void TextFadeUpdate()
	{
		float num = this.tutorialText.alpha;
		if (this.textFadeOn)
		{
			if (num < 1f)
			{
				this.textFading = true;
				num += this.textFadeRate;
				MonoBehaviour.print("TEXT FADE " + num);
			}
			else
			{
				num = 1f;
				this.textFading = false;
			}
		}
		else if (num > 0f)
		{
			this.textFading = true;
			num -= this.textFadeRate;
		}
		else
		{
			num = 0f;
			this.textFading = false;
		}
		this.tutorialText.color = new Color(this.tutorialText.color.r, this.tutorialText.color.g, this.tutorialText.color.b, num);
	}

	// Token: 0x06000436 RID: 1078 RVA: 0x0001CB0B File Offset: 0x0001AD0B
	private void DelayedTextLine(string text, float time)
	{
		this.delayedTextLine = "\n" + text;
		base.Invoke("AddDelayedTextLine", time);
	}

	// Token: 0x06000437 RID: 1079 RVA: 0x0001CB2A File Offset: 0x0001AD2A
	private void AddDelayedTextLine()
	{
		TextMeshPro textMeshPro = this.tutorialText;
		textMeshPro.text += this.delayedTextLine;
	}

	// Token: 0x06000438 RID: 1080 RVA: 0x0001CB48 File Offset: 0x0001AD48
	private void OnDestroy()
	{
		this.DestroyHolsteredObjects();
		if (this.holsteredObjectList.Count < 1)
		{
			return;
		}
		foreach (GameObject gameObject in this.holsteredObjectList)
		{
			gameObject.SetActive(true);
			if (Object.FindObjectOfType<GameManager>() && gameObject.GetComponentInChildren<WeaponController>())
			{
				Object.FindObjectOfType<GameManager>().holsteredWeapon = gameObject;
			}
			Vector3 localPosition;
			this.holsteredObjectPosDic.TryGetValue(gameObject, out localPosition);
			Quaternion localRotation;
			this.holsteredObjectRotDic.TryGetValue(gameObject, out localRotation);
			gameObject.transform.parent = this.parentTransform;
			gameObject.transform.localPosition = localPosition;
			gameObject.transform.localRotation = localRotation;
		}
		GameEvents.current.onGrabStart -= this.OnGrabStart;
		GameEvents.current.onHolsterLock -= this.OnHolsterLock;
		GameEvents.current.onMagazineLoad -= this.OnMagazineLoad;
		GameEvents.current.onRoundChambered -= this.OnRoundChambered;
		GameEvents.current.onSafetyOn -= this.OnSafetyOn;
		GameEvents.current.onSafetyOff -= this.OnSafetyOff;
		GameEvents.current.onSlideRelease -= this.OnSlideRelease;
	}

	// Token: 0x04000546 RID: 1350
	private List<GameObject> holsteredObjectList = new List<GameObject>();

	// Token: 0x04000547 RID: 1351
	private Dictionary<GameObject, Quaternion> holsteredObjectRotDic = new Dictionary<GameObject, Quaternion>();

	// Token: 0x04000548 RID: 1352
	private Dictionary<GameObject, Vector3> holsteredObjectPosDic = new Dictionary<GameObject, Vector3>();

	// Token: 0x04000549 RID: 1353
	public TutorialManager.TutorialStage currentTutorialStage;

	// Token: 0x0400054A RID: 1354
	[SerializeField]
	private TextMeshPro tutorialText;

	// Token: 0x0400054B RID: 1355
	[SerializeField]
	private GameObject tutorialController;

	// Token: 0x0400054C RID: 1356
	[SerializeField]
	private WeaponController tutorialWeapon;

	// Token: 0x0400054D RID: 1357
	[SerializeField]
	private float textFadeRate = 0.005f;

	// Token: 0x0400054E RID: 1358
	[SerializeField]
	private GameObject target_shootAll;

	// Token: 0x0400054F RID: 1359
	[SerializeField]
	private GameObject target_freeRange;

	// Token: 0x04000550 RID: 1360
	[SerializeField]
	private bool testNextStage;

	// Token: 0x04000551 RID: 1361
	public GameObject leftHandObject;

	// Token: 0x04000552 RID: 1362
	public GameObject rightHandObject;

	// Token: 0x04000553 RID: 1363
	private Transform parentTransform;

	// Token: 0x04000554 RID: 1364
	private HolsterControl holsterControl;

	// Token: 0x04000555 RID: 1365
	private Quaternion holsteredObjectRotation;

	// Token: 0x04000556 RID: 1366
	private Vector3 holsteredObjectPosition;

	// Token: 0x04000557 RID: 1367
	private SoundManager soundManager;

	// Token: 0x04000558 RID: 1368
	private GameManager gameManager;

	// Token: 0x04000559 RID: 1369
	private ControlManager controlManager;

	// Token: 0x0400055A RID: 1370
	private HolsterVolume volume;

	// Token: 0x0400055B RID: 1371
	public OVRInput.Controller activeController;

	// Token: 0x0400055C RID: 1372
	private bool textUpdated;

	// Token: 0x0400055D RID: 1373
	private bool textFadeOn;

	// Token: 0x0400055E RID: 1374
	private bool textFading;

	// Token: 0x0400055F RID: 1375
	private bool safetyOffCheck;

	// Token: 0x04000560 RID: 1376
	private bool safetyOnCheck;

	// Token: 0x04000561 RID: 1377
	private bool safetyToggled;

	// Token: 0x04000562 RID: 1378
	private bool eventConditionMet;

	// Token: 0x04000563 RID: 1379
	private bool targetSpawned;

	// Token: 0x04000564 RID: 1380
	private string delayedTextLine;

	// Token: 0x04000565 RID: 1381
	public int tutorialStageIndex;

	// Token: 0x020001DB RID: 475
	public enum TutorialStage
	{
		// Token: 0x04000DFA RID: 3578
		SetDownController,
		// Token: 0x04000DFB RID: 3579
		PickUp,
		// Token: 0x04000DFC RID: 3580
		PlaceInVolume,
		// Token: 0x04000DFD RID: 3581
		HolsterLock,
		// Token: 0x04000DFE RID: 3582
		LoadWeapon,
		// Token: 0x04000DFF RID: 3583
		SafetyOn,
		// Token: 0x04000E00 RID: 3584
		SafetyOff,
		// Token: 0x04000E01 RID: 3585
		ChamberRound,
		// Token: 0x04000E02 RID: 3586
		ShootAll,
		// Token: 0x04000E03 RID: 3587
		ReleaseSlide,
		// Token: 0x04000E04 RID: 3588
		Reholster,
		// Token: 0x04000E05 RID: 3589
		RemoveHolster
	}
}
