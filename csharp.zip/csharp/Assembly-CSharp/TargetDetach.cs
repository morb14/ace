﻿using System;
using UnityEngine;

// Token: 0x02000064 RID: 100
public class TargetDetach : MonoBehaviour
{
	// Token: 0x060003B7 RID: 951 RVA: 0x00018BFE File Offset: 0x00016DFE
	private void Start()
	{
		this.rb = base.GetComponent<Rigidbody>();
		if (this.rb == null)
		{
			this.rb = base.gameObject.AddComponent<Rigidbody>();
		}
		this.fixedJoint = base.GetComponent<FixedJoint>();
	}

	// Token: 0x060003B8 RID: 952 RVA: 0x00018C37 File Offset: 0x00016E37
	public void Detach()
	{
		if (this.fixedJoint.connectedBody.isKinematic)
		{
			this.fixedJoint.connectedBody.isKinematic = false;
		}
		Object.Destroy(this.fixedJoint);
		base.transform.parent = null;
	}

	// Token: 0x04000491 RID: 1169
	private Rigidbody rb;

	// Token: 0x04000492 RID: 1170
	public FixedJoint fixedJoint;
}
