﻿using System;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x0200005C RID: 92
public class StartConditionQuad : MonoBehaviour
{
	// Token: 0x0600037B RID: 891 RVA: 0x000175A8 File Offset: 0x000157A8
	private void Start()
	{
		this.mRenderer.enabled = false;
		GameEvents.current.onStageConditionMet += this.OnConditionMet;
		GameEvents.current.onStageConditionUnmet += this.OnConditionUnmet;
		SceneManager.sceneLoaded += this.OnSceneLoaded;
	}

	// Token: 0x0600037C RID: 892 RVA: 0x000175FE File Offset: 0x000157FE
	private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
	{
		this.mRenderer.enabled = false;
	}

	// Token: 0x0600037D RID: 893 RVA: 0x0001760C File Offset: 0x0001580C
	private void OnConditionMet()
	{
		this.mRenderer.enabled = true;
	}

	// Token: 0x0600037E RID: 894 RVA: 0x000175FE File Offset: 0x000157FE
	private void OnConditionUnmet()
	{
		this.mRenderer.enabled = false;
	}

	// Token: 0x0600037F RID: 895 RVA: 0x0001761A File Offset: 0x0001581A
	private void OnDestroy()
	{
		GameEvents.current.onStageConditionMet -= this.OnConditionMet;
		GameEvents.current.onStageConditionUnmet -= this.OnConditionUnmet;
		SceneManager.sceneLoaded -= this.OnSceneLoaded;
	}

	// Token: 0x04000449 RID: 1097
	private int colliderCounts;

	// Token: 0x0400044A RID: 1098
	[SerializeField]
	private MeshRenderer mRenderer;
}
