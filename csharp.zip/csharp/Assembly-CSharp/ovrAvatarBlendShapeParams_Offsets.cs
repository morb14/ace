﻿using System;
using System.Runtime.InteropServices;

// Token: 0x020000E8 RID: 232
internal struct ovrAvatarBlendShapeParams_Offsets
{
	// Token: 0x0400086B RID: 2155
	public static int blendShapeParamCount = Marshal.OffsetOf(typeof(ovrAvatarBlendShapeParams), "blendShapeParamCount").ToInt32();

	// Token: 0x0400086C RID: 2156
	public static long blendShapeParams = (long)Marshal.SizeOf(typeof(uint));
}
