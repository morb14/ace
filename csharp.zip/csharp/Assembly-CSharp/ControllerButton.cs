﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

// Token: 0x02000029 RID: 41
public class ControllerButton : MonoBehaviour
{
	// Token: 0x060000C5 RID: 197 RVA: 0x000060E8 File Offset: 0x000042E8
	private void Start()
	{
		this.controlManager = Object.FindObjectOfType<ControlManager>();
		this.soundManager = Object.FindObjectOfType<SoundManager>();
		this.holsterVolume = Object.FindObjectOfType<HolsterVolume>();
		this.iconList.Add(this.oneHand);
		this.iconList.Add(this.twoHand);
		this.iconList.Add(this.controlAR);
		this.iconList.Add(this.controlARPro);
		this.iconList.Add(this.controlAR2);
		this.InitiateIcon();
		this.controllerModeIndex = 0;
		GameEvents.current.onControllerModeChange += this.OnModeChange;
		this.OnModeChange();
	}

	// Token: 0x060000C6 RID: 198 RVA: 0x00006194 File Offset: 0x00004394
	private void InitiateIcon()
	{
		this.CycleIcon(this.controllerModeIndex);
		this.text.text = this.IndexToModeText(this.controllerModeIndex);
	}

	// Token: 0x060000C7 RID: 199 RVA: 0x000061B9 File Offset: 0x000043B9
	private void Update()
	{
		if (this.testSelect)
		{
			this.testSelect = false;
			this.Select();
		}
	}

	// Token: 0x060000C8 RID: 200 RVA: 0x00003297 File Offset: 0x00001497
	public void Highlight()
	{
	}

	// Token: 0x060000C9 RID: 201 RVA: 0x000061D0 File Offset: 0x000043D0
	public void Select()
	{
		if (this.holsterVolume.GunInVolume())
		{
			this.soundManager.Play(this.soundManager.UIerror);
			GameEvents.current.BroadcastMessage("Ensure nothing is equipped before switching scheme", false);
			return;
		}
		this.controllerModeIndex++;
		if (this.controllerModeIndex >= this.iconList.Count)
		{
			this.controllerModeIndex = 0;
		}
		this.soundManager.Play(this.soundManager.UIclick);
		this.CycleIcon(this.controllerModeIndex);
		this.controlManager.ChangeControllerMode(this.IndexToMode(this.controllerModeIndex));
		this.text.text = this.IndexToModeText(this.controllerModeIndex);
	}

	// Token: 0x060000CA RID: 202 RVA: 0x00006289 File Offset: 0x00004489
	private void OnModeChange()
	{
		this.controllerModeIndex = this.ModeToIndex(this.controlManager.controllerMode);
		this.text.text = this.IndexToModeText(this.controllerModeIndex);
		this.CycleIcon(this.controllerModeIndex);
	}

	// Token: 0x060000CB RID: 203 RVA: 0x000062C8 File Offset: 0x000044C8
	private void CycleIcon(int index)
	{
		foreach (GameObject gameObject in this.iconList)
		{
			gameObject.SetActive(false);
			if (gameObject == this.iconList[index])
			{
				gameObject.SetActive(true);
			}
		}
	}

	// Token: 0x060000CC RID: 204 RVA: 0x00006338 File Offset: 0x00004538
	private int ModeToIndex(ControlManager.ControllerMode mode)
	{
		int result = 0;
		if (mode == ControlManager.ControllerMode.OneHand)
		{
			result = 0;
		}
		if (mode == ControlManager.ControllerMode.TwoHand)
		{
			result = 1;
		}
		if (mode == ControlManager.ControllerMode.ControlAR)
		{
			result = 2;
		}
		if (mode == ControlManager.ControllerMode.ControlARPro)
		{
			result = 3;
		}
		if (mode == ControlManager.ControllerMode.ControlAR2)
		{
			result = 4;
		}
		return result;
	}

	// Token: 0x060000CD RID: 205 RVA: 0x00006368 File Offset: 0x00004568
	private string IndexToModeText(int index)
	{
		string result = "";
		if (index == 0)
		{
			result = "One Handed";
		}
		else if (index == 1)
		{
			result = "Two Handed";
		}
		else if (index == 2)
		{
			result = "ControlAR";
		}
		else if (index == 3)
		{
			result = "ControlAR-Pro";
		}
		else if (index == 4)
		{
			result = "ControlAR-Straight";
		}
		return result;
	}

	// Token: 0x060000CE RID: 206 RVA: 0x000063B8 File Offset: 0x000045B8
	private ControlManager.ControllerMode IndexToMode(int index)
	{
		ControlManager.ControllerMode result;
		if (index == 0)
		{
			result = ControlManager.ControllerMode.OneHand;
		}
		else if (index == 1)
		{
			result = ControlManager.ControllerMode.TwoHand;
		}
		else if (index == 2)
		{
			result = ControlManager.ControllerMode.ControlAR;
		}
		else if (index == 3)
		{
			result = ControlManager.ControllerMode.ControlARPro;
		}
		else if (index == 4)
		{
			result = ControlManager.ControllerMode.ControlAR2;
		}
		else
		{
			result = ControlManager.ControllerMode.OneHand;
		}
		return result;
	}

	// Token: 0x060000CF RID: 207 RVA: 0x000063EF File Offset: 0x000045EF
	private void OnDestroy()
	{
		GameEvents.current.onControllerModeChange -= this.OnModeChange;
	}

	// Token: 0x040000C9 RID: 201
	[SerializeField]
	private float rotateSpeed = 0.2f;

	// Token: 0x040000CA RID: 202
	[SerializeField]
	private TMP_Text text;

	// Token: 0x040000CB RID: 203
	[SerializeField]
	private GameObject oneHand;

	// Token: 0x040000CC RID: 204
	[SerializeField]
	private GameObject twoHand;

	// Token: 0x040000CD RID: 205
	[SerializeField]
	private GameObject controlAR;

	// Token: 0x040000CE RID: 206
	[SerializeField]
	private GameObject controlARPro;

	// Token: 0x040000CF RID: 207
	[SerializeField]
	private GameObject controlAR2;

	// Token: 0x040000D0 RID: 208
	private Transform icon;

	// Token: 0x040000D1 RID: 209
	private ControlManager.ControllerMode controllerMode;

	// Token: 0x040000D2 RID: 210
	private HolsterVolume holsterVolume;

	// Token: 0x040000D3 RID: 211
	private int controllerModeIndex;

	// Token: 0x040000D4 RID: 212
	private float timeSelected;

	// Token: 0x040000D5 RID: 213
	private string modeText;

	// Token: 0x040000D6 RID: 214
	private Quaternion originalRotation;

	// Token: 0x040000D7 RID: 215
	public bool testSelect;

	// Token: 0x040000D8 RID: 216
	private List<GameObject> iconList = new List<GameObject>();

	// Token: 0x040000D9 RID: 217
	private SoundManager soundManager;

	// Token: 0x040000DA RID: 218
	private ControlManager controlManager;
}
