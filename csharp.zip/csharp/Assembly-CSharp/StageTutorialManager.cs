﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

// Token: 0x0200006E RID: 110
public class StageTutorialManager : MonoBehaviour
{
	// Token: 0x06000409 RID: 1033 RVA: 0x0001B368 File Offset: 0x00019568
	private void Start()
	{
		this.soundManager = Object.FindObjectOfType<SoundManager>();
		this.gameManager = Object.FindObjectOfType<GameManager>();
		this.controlManager = Object.FindObjectOfType<ControlManager>();
		this.sceneSettings = Object.FindObjectOfType<SceneSettings>();
		this.sceneSettings.enabled = false;
		this.tutorialStageIndex = 0;
		this.currentTutorialStage = StageTutorialManager.TutorialStage.LockWeapon;
		this.StoveHolsteredObjects();
		this.AssignEvents();
	}

	// Token: 0x0600040A RID: 1034 RVA: 0x0001B3C8 File Offset: 0x000195C8
	private void AssignEvents()
	{
		GameEvents.current.onHolster += this.OnHolster;
		GameEvents.current.onHolsterLock += this.OnHolsterLock;
		GameEvents.current.onStageStart += this.OnStageStart;
		GameEvents.current.onStageFinish += this.OnStageFinish;
	}

	// Token: 0x0600040B RID: 1035 RVA: 0x0001B430 File Offset: 0x00019630
	private void StoveHolsteredObjects()
	{
		this.volume = Object.FindObjectOfType<HolsterVolume>();
		this.parentTransform = this.volume.transform;
		foreach (Transform transform in this.volume.GetComponentsInChildren<Transform>())
		{
			if (transform.parent == this.parentTransform)
			{
				GameObject gameObject = transform.gameObject;
				this.holsteredObjectList.Add(gameObject);
				this.holsteredObjectPosDic.Add(gameObject, gameObject.transform.localPosition);
				this.holsteredObjectRotDic.Add(gameObject, gameObject.transform.localRotation);
				transform.parent = null;
				transform.position = new Vector3(0f, -20f, 0f);
				transform.gameObject.SetActive(false);
			}
		}
		MonoBehaviour.print("HOLSTERED OBJECTS SAVED " + this.holsteredObjectList.Count);
	}

	// Token: 0x0600040C RID: 1036 RVA: 0x0001B520 File Offset: 0x00019720
	private void DestroyHolsteredObjects()
	{
		foreach (Transform transform in this.volume.GetComponentsInChildren<Transform>())
		{
			if (transform != this.volume.transform)
			{
				Object.Destroy(transform.gameObject);
			}
		}
	}

	// Token: 0x0600040D RID: 1037 RVA: 0x0001B569 File Offset: 0x00019769
	private void Update()
	{
		this.UpdateTutorial();
		this.TextFadeUpdate();
		this.TestNextStage();
	}

	// Token: 0x0600040E RID: 1038 RVA: 0x0001B57D File Offset: 0x0001977D
	private void TestNextStage()
	{
		if (this.testNextStage)
		{
			this.NextStage();
			this.testNextStage = false;
		}
	}

	// Token: 0x0600040F RID: 1039 RVA: 0x0001B594 File Offset: 0x00019794
	private void NextStage()
	{
		GameEvents.current.TutorialStageAdvanced();
		this.freezeInput = true;
		this.tutorialStageIndex++;
		this.textUpdated = false;
		this.targetSpawned = false;
		this.TextFade(false);
		this.eventConditionMet = false;
		this.soundManager.Play(this.soundManager.UIcorrect);
		switch (this.tutorialStageIndex)
		{
		case 0:
			this.currentTutorialStage = StageTutorialManager.TutorialStage.LockWeapon;
			return;
		case 1:
			this.currentTutorialStage = StageTutorialManager.TutorialStage.IntroTargetA;
			return;
		case 2:
			this.currentTutorialStage = StageTutorialManager.TutorialStage.IntroTargetB;
			return;
		case 3:
			this.currentTutorialStage = StageTutorialManager.TutorialStage.IntroTargetC;
			return;
		case 4:
			this.currentTutorialStage = StageTutorialManager.TutorialStage.ExplainBreaking90;
			return;
		case 5:
			this.currentTutorialStage = StageTutorialManager.TutorialStage.BeginStage;
			return;
		case 6:
			this.currentTutorialStage = StageTutorialManager.TutorialStage.MidStage;
			return;
		case 7:
			this.currentTutorialStage = StageTutorialManager.TutorialStage.EndStage;
			return;
		case 8:
			this.currentTutorialStage = StageTutorialManager.TutorialStage.FinishTutorial;
			return;
		default:
			return;
		}
	}

	// Token: 0x06000410 RID: 1040 RVA: 0x0001B66C File Offset: 0x0001986C
	private void UpdateTutorial()
	{
		switch (this.currentTutorialStage)
		{
		case StageTutorialManager.TutorialStage.LockWeapon:
			this.TextFade(true);
			this.freezeInput = true;
			if (!this.textUpdated)
			{
				this.tutorialText.text = "- Place pistol within holster volume\n";
				TextMeshPro textMeshPro = this.tutorialText;
				textMeshPro.text += "- Make sure muzzle does not point backwards\n";
				TextMeshPro textMeshPro2 = this.tutorialText;
				textMeshPro2.text += "- Lock pistol in place\n";
				this.textUpdated = true;
			}
			if (this.eventConditionMet)
			{
				this.tutorialHolsterControl.enabled = false;
				this.tutorialMaterial.SwitchMaterial(false, null);
				this.NextStage();
				return;
			}
			break;
		case StageTutorialManager.TutorialStage.IntroTargetA:
			this.TextFade(true);
			this.paperTargetExample.SetActive(true);
			this.paperTargetExample.GetComponent<Animation>().Play();
			if (!this.textUpdated && !this.textFading)
			{
				this.tutorialText.text = "- This is a paper target\n";
				TextMeshPro textMeshPro3 = this.tutorialText;
				textMeshPro3.text += "- It must be shot twice\n";
				this.DelayedTextLine("anyButton", this.freezeInputTime);
				this.textUpdated = true;
			}
			if (OVRInput.GetDown(OVRInput.Button.Any, this.controlManager.controller) && !this.freezeInput)
			{
				this.NextStage();
				return;
			}
			break;
		case StageTutorialManager.TutorialStage.IntroTargetB:
			this.paperTargetExample.SetActive(false);
			this.TextFade(true);
			this.noShootTargetExample.SetActive(true);
			if (!this.textUpdated && !this.textFading)
			{
				this.tutorialText.text = "- This is a no-shoot target\n";
				TextMeshPro textMeshPro4 = this.tutorialText;
				textMeshPro4.text += "- A hit anywhere results in a penalty\n";
				this.DelayedTextLine("anyButton", this.freezeInputTime);
				this.textUpdated = true;
			}
			if (OVRInput.GetDown(OVRInput.Button.Any, this.controlManager.controller) && !this.freezeInput)
			{
				this.NextStage();
				return;
			}
			break;
		case StageTutorialManager.TutorialStage.IntroTargetC:
			this.TextFade(true);
			this.noShootTargetExample.SetActive(false);
			this.steelTargetExample.SetActive(true);
			if (!this.textUpdated && !this.textFading)
			{
				this.tutorialText.text = "- This is a steel target\n";
				TextMeshPro textMeshPro5 = this.tutorialText;
				textMeshPro5.text += "- Target must fall to score\n";
				TextMeshPro textMeshPro6 = this.tutorialText;
				textMeshPro6.text += "- Targets are calibrated to have sweet spots\n";
				this.DelayedTextLine("anyButton", this.freezeInputTime);
				this.textUpdated = true;
			}
			if (OVRInput.GetDown(OVRInput.Button.Any, this.controlManager.controller) && !this.freezeInput)
			{
				this.NextStage();
				return;
			}
			break;
		case StageTutorialManager.TutorialStage.ExplainBreaking90:
		{
			this.TextFade(true);
			this.steelTargetExample.SetActive(false);
			if (!this.textUpdated && !this.textFading)
			{
				this.tutorialText.text = "- Every stage has a safe angle of fire\n";
				TextMeshPro textMeshPro7 = this.tutorialText;
				textMeshPro7.text += "- See angle displayed on the training weapon\n";
				TextMeshPro textMeshPro8 = this.tutorialText;
				textMeshPro8.text += "- Breaking 90° results in disqualification\n";
				this.DelayedTextLine("anyButton", this.freezeInputTime);
				this.textUpdated = true;
			}
			Transform weaponTransform;
			if (this.controlManager.controller == OVRInput.Controller.LTouch)
			{
				weaponTransform = this.gameManager.handObjectLeft.GetComponentInChildren<WeaponEquiper>().weaponTransform;
			}
			else
			{
				weaponTransform = this.gameManager.handObjectRight.GetComponentInChildren<WeaponEquiper>().weaponTransform;
			}
			this.sampleGun.transform.parent = weaponTransform;
			this.sampleGun.transform.localPosition = Vector3.zero;
			this.sampleGun.transform.localRotation = Quaternion.identity;
			this.sampleGun.SetActive(true);
			this.controlManager.ShowController(OVRInput.Controller.None);
			if (OVRInput.GetDown(OVRInput.Button.Any, this.controlManager.controller) && !this.freezeInput)
			{
				this.NextStage();
				this.sampleGun.SetActive(false);
				this.controlManager.ShowController(this.controlManager.controller);
				return;
			}
			break;
		}
		case StageTutorialManager.TutorialStage.BeginStage:
			this.TextFade(true);
			if (!this.textUpdated && !this.textFading)
			{
				this.tutorialText.text = "- Load weapon, chamber round, put on safety and reholster\n";
				TextMeshPro textMeshPro9 = this.tutorialText;
				textMeshPro9.text += "- When weapon condition is met, you will notice green in your periphery\n";
				TextMeshPro textMeshPro10 = this.tutorialText;
				textMeshPro10.text += "- Stay still and wait for the start signal\n";
				this.textUpdated = true;
				if (!this.sceneSettings.isActiveAndEnabled)
				{
					this.tutorialHolsterControl.enabled = true;
					this.tutorialMaterial.SwitchMaterial(true, null);
					this.tutorialHolsterControl.Lock();
					this.sceneSettings.enabled = true;
					this.sceneSettings.StartComp();
					this.targetObject.SetActive(true);
					if (Object.FindObjectOfType<Results>())
					{
						Object.FindObjectOfType<Results>().GatherTargets();
					}
				}
			}
			if (this.eventConditionMet)
			{
				this.NextStage();
				return;
			}
			break;
		case StageTutorialManager.TutorialStage.MidStage:
			this.TextFade(true);
			if (!this.textUpdated && !this.textFading)
			{
				this.tutorialText.text = "- Shoot all the targets (twice on paper)\n";
				TextMeshPro textMeshPro11 = this.tutorialText;
				textMeshPro11.text += "- When finished, hold pistol still at chest level, pointed down range\n";
				this.textUpdated = true;
			}
			if (this.eventConditionMet)
			{
				this.NextStage();
				return;
			}
			break;
		case StageTutorialManager.TutorialStage.EndStage:
			this.TextFade(true);
			if (!this.textUpdated && !this.textFading)
			{
				this.tutorialText.text = "- If finished, unload magazine\n";
				TextMeshPro textMeshPro12 = this.tutorialText;
				textMeshPro12.text += "- Rack slide (Joystick back) to eject round\n";
				TextMeshPro textMeshPro13 = this.tutorialText;
				textMeshPro13.text += "- Drop hammer by firing once down range\n";
				TextMeshPro textMeshPro14 = this.tutorialText;
				textMeshPro14.text += "- Reholster to see results\n";
				this.textUpdated = true;
			}
			if (this.eventConditionMet)
			{
				this.NextStage();
				return;
			}
			break;
		case StageTutorialManager.TutorialStage.FinishTutorial:
			this.TextFade(true);
			if (!this.textUpdated && !this.textFading)
			{
				this.tutorialText.text = "- You have completed the competition tutorial\n";
				TextMeshPro textMeshPro15 = this.tutorialText;
				textMeshPro15.text += "- Return to the main menu behind you\n";
				TextMeshPro textMeshPro16 = this.tutorialText;
				textMeshPro16.text += "- Before proceeding to other environments, be sure\n";
				TextMeshPro textMeshPro17 = this.tutorialText;
				textMeshPro17.text += "  a firearm is picked and locked in your holster volume\n";
				this.textUpdated = true;
			}
			break;
		default:
			return;
		}
	}

	// Token: 0x06000411 RID: 1041 RVA: 0x0001BCD2 File Offset: 0x00019ED2
	private void OnHolsterLock()
	{
		if (this.currentTutorialStage == StageTutorialManager.TutorialStage.LockWeapon)
		{
			this.eventConditionMet = true;
		}
	}

	// Token: 0x06000412 RID: 1042 RVA: 0x0001BCE3 File Offset: 0x00019EE3
	private void TextFade(bool on)
	{
		if (this.textFading)
		{
			return;
		}
		if (!this.textFadeOn && on)
		{
			this.TextFadeMethod(true, 0f);
			return;
		}
		if (this.textFadeOn && !on)
		{
			this.TextFadeMethod(false, 1f);
		}
	}

	// Token: 0x06000413 RID: 1043 RVA: 0x00003297 File Offset: 0x00001497
	public void Break90()
	{
	}

	// Token: 0x06000414 RID: 1044 RVA: 0x0001BD1F File Offset: 0x00019F1F
	private void EventConditionMet()
	{
		this.eventConditionMet = true;
	}

	// Token: 0x06000415 RID: 1045 RVA: 0x0001BD28 File Offset: 0x00019F28
	private void TextFadeMethod(bool fade, float alpha)
	{
		this.tutorialText.color = new Color(this.tutorialText.color.r, this.tutorialText.color.g, this.tutorialText.color.b, alpha);
		this.textFadeOn = fade;
	}

	// Token: 0x06000416 RID: 1046 RVA: 0x0001BD80 File Offset: 0x00019F80
	private void TextFadeUpdate()
	{
		float num = this.tutorialText.alpha;
		if (this.textFadeOn)
		{
			if (num < 1f)
			{
				this.textFading = true;
				num += this.textFadeRate;
				MonoBehaviour.print("TEXT FADE " + num);
			}
			else
			{
				num = 1f;
				this.textFading = false;
			}
		}
		else if (num > 0f)
		{
			this.textFading = true;
			num -= this.textFadeRate;
		}
		else
		{
			num = 0f;
			this.textFading = false;
		}
		this.tutorialText.color = new Color(this.tutorialText.color.r, this.tutorialText.color.g, this.tutorialText.color.b, num);
	}

	// Token: 0x06000417 RID: 1047 RVA: 0x0001BE47 File Offset: 0x0001A047
	private void DelayedTextLine(string text, float time)
	{
		if (text == "anyButton")
		{
			text = "- Press [Any Button] for the next slide";
		}
		this.delayedTextLine = "\n" + text;
		base.Invoke("AddDelayedTextLine", time);
	}

	// Token: 0x06000418 RID: 1048 RVA: 0x0001BE7A File Offset: 0x0001A07A
	private void AddDelayedTextLine()
	{
		this.freezeInput = false;
		TextMeshPro textMeshPro = this.tutorialText;
		textMeshPro.text += this.delayedTextLine;
	}

	// Token: 0x06000419 RID: 1049 RVA: 0x0001BEA0 File Offset: 0x0001A0A0
	private void OnDestroy()
	{
		this.DestroyHolsteredObjects();
		if (this.holsteredObjectList.Count < 1)
		{
			return;
		}
		foreach (GameObject gameObject in this.holsteredObjectList)
		{
			if (!(gameObject == null))
			{
				gameObject.SetActive(true);
				if (Object.FindObjectOfType<GameManager>() && gameObject.GetComponentInChildren<WeaponController>())
				{
					Object.FindObjectOfType<GameManager>().holsteredWeapon = gameObject;
				}
				Vector3 localPosition;
				this.holsteredObjectPosDic.TryGetValue(gameObject, out localPosition);
				Quaternion localRotation;
				this.holsteredObjectRotDic.TryGetValue(gameObject, out localRotation);
				gameObject.transform.parent = this.parentTransform;
				gameObject.transform.localPosition = localPosition;
				gameObject.transform.localRotation = localRotation;
			}
		}
		this.UnAssignEvents();
	}

	// Token: 0x0600041A RID: 1050 RVA: 0x0001BF88 File Offset: 0x0001A188
	private void UnAssignEvents()
	{
		GameEvents.current.onHolster -= this.OnHolster;
		GameEvents.current.onHolsterLock -= this.OnHolsterLock;
		GameEvents.current.onStageStart -= this.OnStageStart;
		GameEvents.current.onStageFinish -= this.OnStageFinish;
	}

	// Token: 0x0600041B RID: 1051 RVA: 0x0001BFED File Offset: 0x0001A1ED
	private void OnStageStart()
	{
		if (this.currentTutorialStage == StageTutorialManager.TutorialStage.BeginStage)
		{
			this.eventConditionMet = true;
		}
	}

	// Token: 0x0600041C RID: 1052 RVA: 0x0001BFFF File Offset: 0x0001A1FF
	private void OnStageFinish()
	{
		if (this.currentTutorialStage == StageTutorialManager.TutorialStage.MidStage)
		{
			this.eventConditionMet = true;
		}
	}

	// Token: 0x0600041D RID: 1053 RVA: 0x0001C011 File Offset: 0x0001A211
	private void OnHolster()
	{
		if (this.currentTutorialStage == StageTutorialManager.TutorialStage.EndStage)
		{
			this.eventConditionMet = true;
		}
	}

	// Token: 0x04000515 RID: 1301
	private List<GameObject> holsteredObjectList = new List<GameObject>();

	// Token: 0x04000516 RID: 1302
	private Dictionary<GameObject, Quaternion> holsteredObjectRotDic = new Dictionary<GameObject, Quaternion>();

	// Token: 0x04000517 RID: 1303
	private Dictionary<GameObject, Vector3> holsteredObjectPosDic = new Dictionary<GameObject, Vector3>();

	// Token: 0x04000518 RID: 1304
	public StageTutorialManager.TutorialStage currentTutorialStage;

	// Token: 0x04000519 RID: 1305
	[SerializeField]
	private TextMeshPro tutorialText;

	// Token: 0x0400051A RID: 1306
	[SerializeField]
	private GameObject tutorialController;

	// Token: 0x0400051B RID: 1307
	[SerializeField]
	private GameObject targetObject;

	// Token: 0x0400051C RID: 1308
	[SerializeField]
	private GameObject paperTargetExample;

	// Token: 0x0400051D RID: 1309
	[SerializeField]
	private GameObject noShootTargetExample;

	// Token: 0x0400051E RID: 1310
	[SerializeField]
	private GameObject steelTargetExample;

	// Token: 0x0400051F RID: 1311
	[SerializeField]
	private GameObject sampleGun;

	// Token: 0x04000520 RID: 1312
	[SerializeField]
	private float freezeInputTime = 2f;

	// Token: 0x04000521 RID: 1313
	[SerializeField]
	private WeaponController tutorialWeapon;

	// Token: 0x04000522 RID: 1314
	[SerializeField]
	private HolsterControl tutorialHolsterControl;

	// Token: 0x04000523 RID: 1315
	[SerializeField]
	private MaterialAssigner tutorialMaterial;

	// Token: 0x04000524 RID: 1316
	[SerializeField]
	private float textFadeRate = 0.005f;

	// Token: 0x04000525 RID: 1317
	[SerializeField]
	private SceneSettings sceneSettings;

	// Token: 0x04000526 RID: 1318
	[SerializeField]
	private bool testNextStage;

	// Token: 0x04000527 RID: 1319
	public GameObject leftHandObject;

	// Token: 0x04000528 RID: 1320
	public GameObject rightHandObject;

	// Token: 0x04000529 RID: 1321
	public bool tutorialReload;

	// Token: 0x0400052A RID: 1322
	private Transform parentTransform;

	// Token: 0x0400052B RID: 1323
	private HolsterControl holsterControl;

	// Token: 0x0400052C RID: 1324
	private Quaternion holsteredObjectRotation;

	// Token: 0x0400052D RID: 1325
	private Vector3 holsteredObjectPosition;

	// Token: 0x0400052E RID: 1326
	private SoundManager soundManager;

	// Token: 0x0400052F RID: 1327
	private GameManager gameManager;

	// Token: 0x04000530 RID: 1328
	private ControlManager controlManager;

	// Token: 0x04000531 RID: 1329
	private HolsterVolume volume;

	// Token: 0x04000532 RID: 1330
	public OVRInput.Controller activeController;

	// Token: 0x04000533 RID: 1331
	private bool textUpdated;

	// Token: 0x04000534 RID: 1332
	private bool textFadeOn;

	// Token: 0x04000535 RID: 1333
	private bool textFading;

	// Token: 0x04000536 RID: 1334
	private bool safetyOffCheck;

	// Token: 0x04000537 RID: 1335
	private bool safetyOnCheck;

	// Token: 0x04000538 RID: 1336
	private bool safetyToggled;

	// Token: 0x04000539 RID: 1337
	private bool eventConditionMet;

	// Token: 0x0400053A RID: 1338
	private bool targetSpawned;

	// Token: 0x0400053B RID: 1339
	private bool break90;

	// Token: 0x0400053C RID: 1340
	private string delayedTextLine;

	// Token: 0x0400053D RID: 1341
	public int tutorialStageIndex;

	// Token: 0x0400053E RID: 1342
	private bool freezeInput;

	// Token: 0x020001DA RID: 474
	public enum TutorialStage
	{
		// Token: 0x04000DF0 RID: 3568
		LockWeapon,
		// Token: 0x04000DF1 RID: 3569
		IntroTargetA,
		// Token: 0x04000DF2 RID: 3570
		IntroTargetB,
		// Token: 0x04000DF3 RID: 3571
		IntroTargetC,
		// Token: 0x04000DF4 RID: 3572
		ExplainBreaking90,
		// Token: 0x04000DF5 RID: 3573
		BeginStage,
		// Token: 0x04000DF6 RID: 3574
		MidStage,
		// Token: 0x04000DF7 RID: 3575
		EndStage,
		// Token: 0x04000DF8 RID: 3576
		FinishTutorial
	}
}
