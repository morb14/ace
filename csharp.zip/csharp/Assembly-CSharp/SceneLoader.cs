﻿using System;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x0200001F RID: 31
public class SceneLoader : MonoBehaviour
{
	// Token: 0x06000096 RID: 150 RVA: 0x00005670 File Offset: 0x00003870
	private void Start()
	{
		SceneManager.sceneLoaded += this.SpawnObjects;
	}

	// Token: 0x06000097 RID: 151 RVA: 0x00005684 File Offset: 0x00003884
	public void Populate(SaveManager.SaveObject loadObject, bool overRideSceneReload = false)
	{
		this.loading = true;
		this.saveObject = loadObject;
		if (!overRideSceneReload)
		{
			SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
			MonoBehaviour.print("POPULATE UNDER overRideSceneReload = false");
			return;
		}
		this.SpawnObjects(SceneManager.GetActiveScene(), LoadSceneMode.Single);
		MonoBehaviour.print("POPULATE UNDER spawnObjects");
	}

	// Token: 0x06000098 RID: 152 RVA: 0x000056D8 File Offset: 0x000038D8
	private void SpawnObjects(Scene scene, LoadSceneMode mode)
	{
		if (!this.loading)
		{
			return;
		}
		MonoBehaviour.print("Spawning " + this.saveObject.objectsToSave.Length + " objects");
		for (int i = 0; i < this.saveObject.objectsToSave.Length; i++)
		{
			GameObject gameObject = null;
			Vector3 position = Vector3.zero;
			Quaternion rotation = Quaternion.identity;
			foreach (GameObject gameObject2 in this.objectsToSpawn)
			{
				if (!(gameObject2 == null) && gameObject2.GetComponent<TargetInfo>() != null && !(this.saveObject.objectsToSave[i].targetID == "") && gameObject2.GetComponent<TargetInfo>().targetID == this.saveObject.objectsToSave[i].targetID)
				{
					gameObject = gameObject2;
					position = this.saveObject.objectsToSave[i].targetPosition;
					rotation = this.saveObject.objectsToSave[i].targetRotation;
				}
			}
			if (gameObject != null)
			{
				GameObject gameObject3 = Object.Instantiate<GameObject>(gameObject, position, rotation);
				gameObject3.GetComponent<TargetInfo>().linkID = this.saveObject.objectsToSave[i].linkID;
				gameObject3.GetComponent<TargetInfo>().instanceID = this.saveObject.objectsToSave[i].instanceID;
			}
		}
		this.loading = false;
		GameEvents.current.ScenePopulated();
	}

	// Token: 0x06000099 RID: 153 RVA: 0x00005848 File Offset: 0x00003A48
	private void OnDestroy()
	{
		SceneManager.sceneLoaded -= this.SpawnObjects;
	}

	// Token: 0x040000A3 RID: 163
	[SerializeField]
	private GameObject[] objectsToSpawn;

	// Token: 0x040000A4 RID: 164
	public SceneLoader.LoadMode loadMode;

	// Token: 0x040000A5 RID: 165
	private SaveManager.SaveObject saveObject;

	// Token: 0x040000A6 RID: 166
	private bool loading;

	// Token: 0x020001AC RID: 428
	public enum LoadMode
	{
		// Token: 0x04000CFF RID: 3327
		Default,
		// Token: 0x04000D00 RID: 3328
		FromMenu,
		// Token: 0x04000D01 RID: 3329
		Reset,
		// Token: 0x04000D02 RID: 3330
		Wipe
	}
}
