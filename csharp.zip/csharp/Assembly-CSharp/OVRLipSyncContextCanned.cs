﻿using System;
using UnityEngine;

// Token: 0x0200010C RID: 268
[RequireComponent(typeof(AudioSource))]
public class OVRLipSyncContextCanned : OVRLipSyncContextBase
{
	// Token: 0x060006D2 RID: 1746 RVA: 0x0002BC98 File Offset: 0x00029E98
	private void Update()
	{
		if (this.audioSource.isPlaying && this.currentSequence != null)
		{
			OVRLipSync.Frame frameAtTime = this.currentSequence.GetFrameAtTime(this.audioSource.time);
			base.Frame.CopyInput(frameAtTime);
		}
	}

	// Token: 0x04000900 RID: 2304
	[Tooltip("Pre-computed viseme sequence asset. Compute from audio in Unity with Tools -> Oculus -> Generate Lip Sync Assets.")]
	public OVRLipSyncSequence currentSequence;
}
