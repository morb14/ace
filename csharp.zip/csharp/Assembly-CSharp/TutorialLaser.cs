﻿using System;
using UnityEngine;

// Token: 0x02000093 RID: 147
public class TutorialLaser : MonoBehaviour
{
	// Token: 0x06000500 RID: 1280 RVA: 0x00020B36 File Offset: 0x0001ED36
	private void Start()
	{
		this.laserRenderer = base.GetComponent<LineRenderer>();
		this.laserRenderer.startColor = Color.red;
		this.laserRenderer.endColor = Color.red;
	}

	// Token: 0x06000501 RID: 1281 RVA: 0x00020B64 File Offset: 0x0001ED64
	private void Update()
	{
		this.laserRenderer.SetPosition(0, base.transform.position);
		this.laserRenderer.SetPosition(1, base.transform.forward * 5f);
	}

	// Token: 0x04000644 RID: 1604
	private LineRenderer laserRenderer;
}
