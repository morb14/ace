﻿using System;
using UnityEngine;

// Token: 0x02000057 RID: 87
public class StageManager : MonoBehaviour
{
	// Token: 0x0600034C RID: 844 RVA: 0x00015880 File Offset: 0x00013A80
	private void Start()
	{
		this.sceneSettings = Object.FindObjectOfType<SceneSettings>();
		if (Object.FindObjectsOfType<SceneSettings>().Length > 1)
		{
			MonoBehaviour.print("More than one SceneSettings, fix it");
		}
	}

	// Token: 0x0600034D RID: 845 RVA: 0x00003297 File Offset: 0x00001497
	private void Update()
	{
	}

	// Token: 0x040003FB RID: 1019
	private SceneSettings sceneSettings;
}
