﻿using System;
using System.Runtime.InteropServices;

// Token: 0x020000E9 RID: 233
public struct ovrAvatarVisemes
{
	// Token: 0x0400086D RID: 2157
	public uint visemeParamCount;

	// Token: 0x0400086E RID: 2158
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 32)]
	public float[] visemeParams;
}
