﻿using System;

// Token: 0x020000C6 RID: 198
public struct ovrAvatarTextureAssetData
{
	// Token: 0x040007AF RID: 1967
	public ovrAvatarTextureFormat format;

	// Token: 0x040007B0 RID: 1968
	public uint sizeX;

	// Token: 0x040007B1 RID: 1969
	public uint sizeY;

	// Token: 0x040007B2 RID: 1970
	public uint mipCount;

	// Token: 0x040007B3 RID: 1971
	public ulong textureDataSize;

	// Token: 0x040007B4 RID: 1972
	public IntPtr textureData;
}
