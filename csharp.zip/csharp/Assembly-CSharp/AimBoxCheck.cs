﻿using System;
using UnityEngine;

// Token: 0x02000021 RID: 33
public class AimBoxCheck : MonoBehaviour
{
	// Token: 0x0600009D RID: 157 RVA: 0x00003297 File Offset: 0x00001497
	private void Start()
	{
	}
}
