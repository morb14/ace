﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000100 RID: 256
public class OvrAvatarTextureCopyManager : MonoBehaviour
{
	// Token: 0x0600066F RID: 1647 RVA: 0x0002A5D4 File Offset: 0x000287D4
	public OvrAvatarTextureCopyManager()
	{
		this.texturesToCopy = new Queue<OvrAvatarTextureCopyManager.CopyTextureParams>(256);
		this.textureSets = new Dictionary<int, OvrAvatarTextureCopyManager.TextureSet>();
	}

	// Token: 0x06000670 RID: 1648 RVA: 0x0002A688 File Offset: 0x00028888
	public void Update()
	{
		if (this.texturesToCopy.Count == 0)
		{
			return;
		}
		Queue<OvrAvatarTextureCopyManager.CopyTextureParams> obj = this.texturesToCopy;
		lock (obj)
		{
			for (int i = 0; i < Mathf.Min(8, this.texturesToCopy.Count); i++)
			{
				this.CopyTexture(this.texturesToCopy.Dequeue());
			}
		}
	}

	// Token: 0x06000671 RID: 1649 RVA: 0x0002A700 File Offset: 0x00028900
	public int GetTextureCount()
	{
		return this.texturesToCopy.Count;
	}

	// Token: 0x06000672 RID: 1650 RVA: 0x0002A710 File Offset: 0x00028910
	public void CopyTexture(Texture src, Texture dst, int mipLevel, int mipSize, int dstElement, bool useQueue = true)
	{
		OvrAvatarTextureCopyManager.CopyTextureParams copyTextureParams = new OvrAvatarTextureCopyManager.CopyTextureParams(src, dst, mipLevel, mipSize, dstElement);
		if (useQueue)
		{
			Queue<OvrAvatarTextureCopyManager.CopyTextureParams> obj = this.texturesToCopy;
			lock (obj)
			{
				if (this.texturesToCopy.Count < 256)
				{
					this.texturesToCopy.Enqueue(copyTextureParams);
					return;
				}
				this.CopyTexture(copyTextureParams);
				return;
			}
		}
		this.CopyTexture(copyTextureParams);
	}

	// Token: 0x06000673 RID: 1651 RVA: 0x0002A78C File Offset: 0x0002898C
	private void CopyTexture(OvrAvatarTextureCopyManager.CopyTextureParams copyTextureParams)
	{
		Graphics.CopyTexture(copyTextureParams.Src, 0, copyTextureParams.Mip, copyTextureParams.Dst, copyTextureParams.DstElement, copyTextureParams.Mip);
	}

	// Token: 0x06000674 RID: 1652 RVA: 0x0002A7B4 File Offset: 0x000289B4
	public void AddTextureIDToTextureSet(int gameobjectID, ulong textureID, bool isSingleMesh)
	{
		if (!this.textureSets.ContainsKey(gameobjectID))
		{
			OvrAvatarTextureCopyManager.TextureSet textureSet = new OvrAvatarTextureCopyManager.TextureSet(new Dictionary<ulong, bool>(), false);
			textureSet.TextureIDSingleMeshPair.Add(textureID, isSingleMesh);
			this.textureSets.Add(gameobjectID, textureSet);
			return;
		}
		bool flag;
		if (this.textureSets[gameobjectID].TextureIDSingleMeshPair.TryGetValue(textureID, out flag))
		{
			if (!flag && isSingleMesh)
			{
				this.textureSets[gameobjectID].TextureIDSingleMeshPair[textureID] = true;
				return;
			}
		}
		else
		{
			this.textureSets[gameobjectID].TextureIDSingleMeshPair.Add(textureID, isSingleMesh);
		}
	}

	// Token: 0x06000675 RID: 1653 RVA: 0x0002A84C File Offset: 0x00028A4C
	public void DeleteTextureSet(int gameobjectID)
	{
		OvrAvatarTextureCopyManager.TextureSet textureSet;
		if (!this.textureSets.TryGetValue(gameobjectID, out textureSet))
		{
			return;
		}
		if (textureSet.IsProcessed)
		{
			return;
		}
		base.StartCoroutine(this.DeleteTextureSetCoroutine(textureSet, gameobjectID));
	}

	// Token: 0x06000676 RID: 1654 RVA: 0x0002A882 File Offset: 0x00028A82
	private IEnumerator DeleteTextureSetCoroutine(OvrAvatarTextureCopyManager.TextureSet textureSetToDelete, int gameobjectID)
	{
		yield return new WaitForSeconds(10f);
		while (OvrAvatarSDKManager.Instance.IsAvatarLoading())
		{
			yield return null;
		}
		foreach (KeyValuePair<ulong, bool> keyValuePair in textureSetToDelete.TextureIDSingleMeshPair)
		{
			bool flag = !keyValuePair.Value;
			if (flag)
			{
				foreach (KeyValuePair<int, OvrAvatarTextureCopyManager.TextureSet> keyValuePair2 in this.textureSets)
				{
					if (keyValuePair2.Key != gameobjectID)
					{
						foreach (KeyValuePair<ulong, bool> keyValuePair3 in keyValuePair2.Value.TextureIDSingleMeshPair)
						{
							if (keyValuePair3.Key == keyValuePair.Key && (!keyValuePair2.Value.IsProcessed || keyValuePair3.Value))
							{
								flag = false;
								break;
							}
						}
						if (!flag)
						{
							break;
						}
					}
				}
			}
			if (flag)
			{
				Texture2D loadedTexture = OvrAvatarComponent.GetLoadedTexture(keyValuePair.Key);
				if (loadedTexture != null)
				{
					OvrAvatarSDKManager.Instance.DeleteAssetFromCache(keyValuePair.Key);
					Object.Destroy(loadedTexture);
				}
			}
		}
		textureSetToDelete.IsProcessed = true;
		this.textureSets.Remove(gameobjectID);
		yield break;
	}

	// Token: 0x06000677 RID: 1655 RVA: 0x0002A89F File Offset: 0x00028A9F
	public void CheckFallbackTextureSet(ovrAvatarAssetLevelOfDetail lod)
	{
		if (this.FallbackTextureSets[(int)lod].Initialized)
		{
			return;
		}
		this.InitFallbackTextureSet(lod);
	}

	// Token: 0x06000678 RID: 1656 RVA: 0x0002A8BC File Offset: 0x00028ABC
	private void InitFallbackTextureSet(ovrAvatarAssetLevelOfDetail lod)
	{
		this.FallbackTextureSets[(int)lod].DiffuseRoughness = (this.FallbackTextureSets[(int)lod].DiffuseRoughness = Resources.Load<Texture2D>(this.FALLBACK_TEXTURE_PATHS_DIFFUSE_ROUGHNESS[(int)lod]));
		this.FallbackTextureSets[(int)lod].Normal = (this.FallbackTextureSets[(int)lod].Normal = Resources.Load<Texture2D>(this.FALLBACK_TEXTURE_PATHS_NORMAL[(int)lod]));
		this.FallbackTextureSets[(int)lod].Initialized = true;
	}

	// Token: 0x040008C4 RID: 2244
	public OvrAvatarTextureCopyManager.FallbackTextureSet[] FallbackTextureSets = new OvrAvatarTextureCopyManager.FallbackTextureSet[6];

	// Token: 0x040008C5 RID: 2245
	private Queue<OvrAvatarTextureCopyManager.CopyTextureParams> texturesToCopy;

	// Token: 0x040008C6 RID: 2246
	private Dictionary<int, OvrAvatarTextureCopyManager.TextureSet> textureSets;

	// Token: 0x040008C7 RID: 2247
	private const int TEXTURES_TO_COPY_QUEUE_CAPACITY = 256;

	// Token: 0x040008C8 RID: 2248
	private const int COPIES_PER_FRAME = 8;

	// Token: 0x040008C9 RID: 2249
	private readonly string[] FALLBACK_TEXTURE_PATHS_DIFFUSE_ROUGHNESS = new string[]
	{
		"null",
		"FallbackTextures/fallback_diffuse_roughness_256",
		"null",
		"FallbackTextures/fallback_diffuse_roughness_1024",
		"null",
		"FallbackTextures/fallback_diffuse_roughness_2048"
	};

	// Token: 0x040008CA RID: 2250
	private readonly string[] FALLBACK_TEXTURE_PATHS_NORMAL = new string[]
	{
		"null",
		"FallbackTextures/fallback_normal_256",
		"null",
		"FallbackTextures/fallback_normal_1024",
		"null",
		"FallbackTextures/fallback_normal_2048"
	};

	// Token: 0x040008CB RID: 2251
	private const string PATH_HIGHEST_DIFFUSE_ROUGHNESS = "FallbackTextures/fallback_diffuse_roughness_2048";

	// Token: 0x040008CC RID: 2252
	private const string PATH_MEDIUM_DIFFUSE_ROUGHNESS = "FallbackTextures/fallback_diffuse_roughness_1024";

	// Token: 0x040008CD RID: 2253
	private const string PATH_LOWEST_DIFFUSE_ROUGHNESS = "FallbackTextures/fallback_diffuse_roughness_256";

	// Token: 0x040008CE RID: 2254
	private const string PATH_HIGHEST_NORMAL = "FallbackTextures/fallback_normal_2048";

	// Token: 0x040008CF RID: 2255
	private const string PATH_MEDIUM_NORMAL = "FallbackTextures/fallback_normal_1024";

	// Token: 0x040008D0 RID: 2256
	private const string PATH_LOWEST_NORMAL = "FallbackTextures/fallback_normal_256";

	// Token: 0x040008D1 RID: 2257
	private const int GPU_TEXTURE_COPY_WAIT_TIME = 10;

	// Token: 0x020001F6 RID: 502
	[Serializable]
	public struct FallbackTextureSet
	{
		// Token: 0x04000E7F RID: 3711
		public bool Initialized;

		// Token: 0x04000E80 RID: 3712
		public Texture2D DiffuseRoughness;

		// Token: 0x04000E81 RID: 3713
		public Texture2D Normal;
	}

	// Token: 0x020001F7 RID: 503
	private struct CopyTextureParams
	{
		// Token: 0x06000C43 RID: 3139 RVA: 0x0004468E File Offset: 0x0004288E
		public CopyTextureParams(Texture src, Texture dst, int mip, int srcSize, int dstElement)
		{
			this.Src = src;
			this.Dst = dst;
			this.Mip = mip;
			this.SrcSize = srcSize;
			this.DstElement = dstElement;
		}

		// Token: 0x04000E82 RID: 3714
		public Texture Src;

		// Token: 0x04000E83 RID: 3715
		public Texture Dst;

		// Token: 0x04000E84 RID: 3716
		public int Mip;

		// Token: 0x04000E85 RID: 3717
		public int SrcSize;

		// Token: 0x04000E86 RID: 3718
		public int DstElement;
	}

	// Token: 0x020001F8 RID: 504
	public struct TextureSet
	{
		// Token: 0x06000C44 RID: 3140 RVA: 0x000446B5 File Offset: 0x000428B5
		public TextureSet(Dictionary<ulong, bool> textureIDSingleMeshPair, bool isProcessed)
		{
			this.TextureIDSingleMeshPair = textureIDSingleMeshPair;
			this.IsProcessed = isProcessed;
		}

		// Token: 0x04000E87 RID: 3719
		public Dictionary<ulong, bool> TextureIDSingleMeshPair;

		// Token: 0x04000E88 RID: 3720
		public bool IsProcessed;
	}
}
