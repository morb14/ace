﻿using System;
using Oculus.Avatar;
using UnityEngine;

// Token: 0x020000B3 RID: 179
public class OvrAvatarHand : OvrAvatarComponent
{
	// Token: 0x060005F5 RID: 1525 RVA: 0x00026EB8 File Offset: 0x000250B8
	private void Update()
	{
		if (this.owner == null)
		{
			return;
		}
		bool flag;
		if (this.isLeftHand)
		{
			flag = CAPI.ovrAvatarPose_GetLeftHandComponent(this.owner.sdkAvatar, ref this.component);
		}
		else
		{
			flag = CAPI.ovrAvatarPose_GetRightHandComponent(this.owner.sdkAvatar, ref this.component);
		}
		if (flag)
		{
			base.UpdateAvatar(this.component.renderComponent);
			return;
		}
		if (this.isLeftHand)
		{
			this.owner.HandLeft = null;
		}
		else
		{
			this.owner.HandRight = null;
		}
		Object.Destroy(this);
	}

	// Token: 0x04000728 RID: 1832
	public bool isLeftHand = true;

	// Token: 0x04000729 RID: 1833
	private ovrAvatarHandComponent component;
}
