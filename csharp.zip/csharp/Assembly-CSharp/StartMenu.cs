﻿using System;
using System.IO;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x0200013D RID: 317
public class StartMenu : MonoBehaviour
{
	// Token: 0x06000840 RID: 2112 RVA: 0x00033FD4 File Offset: 0x000321D4
	private void Start()
	{
		DebugUIBuilder.instance.AddLabel("Select Sample Scene", 0);
		int sceneCountInBuildSettings = SceneManager.sceneCountInBuildSettings;
		for (int i = 0; i < sceneCountInBuildSettings; i++)
		{
			string scenePathByBuildIndex = SceneUtility.GetScenePathByBuildIndex(i);
			int sceneIndex = i;
			DebugUIBuilder.instance.AddButton(Path.GetFileNameWithoutExtension(scenePathByBuildIndex), delegate
			{
				this.LoadScene(sceneIndex);
			}, 0);
		}
		DebugUIBuilder.instance.Show();
	}

	// Token: 0x06000841 RID: 2113 RVA: 0x00034047 File Offset: 0x00032247
	private void LoadScene(int idx)
	{
		DebugUIBuilder.instance.Hide();
		Debug.Log("Load scene: " + idx);
		SceneManager.LoadScene(idx);
	}

	// Token: 0x04000A49 RID: 2633
	public OVROverlay overlay;

	// Token: 0x04000A4A RID: 2634
	public OVROverlay text;

	// Token: 0x04000A4B RID: 2635
	public OVRCameraRig vrRig;
}
