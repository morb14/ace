﻿using System;

// Token: 0x020000F0 RID: 240
public enum ovrAvatarLightType
{
	// Token: 0x04000882 RID: 2178
	Point,
	// Token: 0x04000883 RID: 2179
	Direction,
	// Token: 0x04000884 RID: 2180
	Spot,
	// Token: 0x04000885 RID: 2181
	Count
}
