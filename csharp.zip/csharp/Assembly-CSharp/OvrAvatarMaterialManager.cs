﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

// Token: 0x020000B5 RID: 181
public class OvrAvatarMaterialManager : MonoBehaviour
{
	// Token: 0x060005FC RID: 1532 RVA: 0x0002727C File Offset: 0x0002547C
	public void CreateTextureArrays()
	{
		this.LocalAvatarConfig.ComponentMaterialProperties = new OvrAvatarMaterialManager.AvatarComponentMaterialProperties[5];
		this.LocalAvatarConfig.MaterialPropertyBlock.Colors = new Vector4[5];
		this.LocalAvatarConfig.MaterialPropertyBlock.DiffuseIntensities = new float[5];
		this.LocalAvatarConfig.MaterialPropertyBlock.RimIntensities = new float[5];
		this.LocalAvatarConfig.MaterialPropertyBlock.ReflectionIntensities = new float[5];
		for (int i = 0; i < this.LocalAvatarConfig.ComponentMaterialProperties.Length; i++)
		{
			this.LocalAvatarConfig.ComponentMaterialProperties[i].Textures = new Texture2D[3];
		}
		this.TextureArrays = new OvrAvatarMaterialManager.AvatarTextureArrayProperties[3];
	}

	// Token: 0x060005FD RID: 1533 RVA: 0x00027332 File Offset: 0x00025532
	public void SetRenderer(Renderer renderer)
	{
		this.TargetRenderer = renderer;
		this.TargetRenderer.GetClosestReflectionProbes(this.ReflectionProbes);
	}

	// Token: 0x060005FE RID: 1534 RVA: 0x0002734C File Offset: 0x0002554C
	public void OnCombinedMeshReady()
	{
		this.InitTextureArrays();
		this.SetMaterialPropertyBlock();
		base.StartCoroutine(this.RunLoadingAnimation(new Action(this.DeleteTextureSet)));
	}

	// Token: 0x060005FF RID: 1535 RVA: 0x00027373 File Offset: 0x00025573
	public void AddTextureIDToTextureManager(ulong assetID, bool isSingleComponent)
	{
		OvrAvatarSDKManager.Instance.GetTextureCopyManager().AddTextureIDToTextureSet(base.GetInstanceID(), assetID, isSingleComponent);
	}

	// Token: 0x06000600 RID: 1536 RVA: 0x0002738C File Offset: 0x0002558C
	private void DeleteTextureSet()
	{
		OvrAvatarSDKManager.Instance.GetTextureCopyManager().DeleteTextureSet(base.GetInstanceID());
	}

	// Token: 0x06000601 RID: 1537 RVA: 0x000273A4 File Offset: 0x000255A4
	public void InitTextureArrays()
	{
		OvrAvatarMaterialManager.AvatarComponentMaterialProperties avatarComponentMaterialProperties = this.LocalAvatarConfig.ComponentMaterialProperties[0];
		int num = 0;
		while (num < this.TextureArrays.Length && num < avatarComponentMaterialProperties.Textures.Length)
		{
			this.TextureArrays[num].TextureArray = new Texture2DArray(avatarComponentMaterialProperties.Textures[0].height, avatarComponentMaterialProperties.Textures[0].width, this.LocalAvatarConfig.ComponentMaterialProperties.Length, avatarComponentMaterialProperties.Textures[0].format, true, QualitySettings.activeColorSpace != ColorSpace.Gamma)
			{
				filterMode = FilterMode.Trilinear,
				anisoLevel = ((num == 2) ? 16 : 4)
			};
			this.TextureArrays[num].TextureArray.name = string.Format("Texture Array Type: {0}", (OvrAvatarMaterialManager.TextureType)num);
			this.TextureArrays[num].Textures = new Texture2D[this.LocalAvatarConfig.ComponentMaterialProperties.Length];
			for (int i = 0; i < this.LocalAvatarConfig.ComponentMaterialProperties.Length; i++)
			{
				this.TextureArrays[num].Textures[i] = this.LocalAvatarConfig.ComponentMaterialProperties[i].Textures[num];
				this.TextureArrays[num].Textures[i].name = string.Format("Texture Type: {0} Component: {1}", (OvrAvatarMaterialManager.TextureType)num, i);
			}
			this.ProcessTexturesWithMips(this.TextureArrays[num].Textures, avatarComponentMaterialProperties.Textures[num].height, this.TextureArrays[num].TextureArray);
			num++;
		}
	}

	// Token: 0x06000602 RID: 1538 RVA: 0x00027544 File Offset: 0x00025744
	private void ProcessTexturesWithMips(Texture2D[] textures, int texArrayResolution, Texture2DArray texArray)
	{
		for (int i = 0; i < textures.Length; i++)
		{
			int num = texArrayResolution;
			for (int j = textures[i].mipmapCount - 1; j >= 0; j--)
			{
				int mipSize = texArrayResolution / num;
				OvrAvatarSDKManager.Instance.GetTextureCopyManager().CopyTexture(textures[i], texArray, j, mipSize, i, false);
				num /= 2;
			}
		}
	}

	// Token: 0x06000603 RID: 1539 RVA: 0x00027598 File Offset: 0x00025798
	private void SetMaterialPropertyBlock()
	{
		if (this.TargetRenderer != null)
		{
			for (int i = 0; i < this.LocalAvatarConfig.ComponentMaterialProperties.Length; i++)
			{
				this.LocalAvatarConfig.MaterialPropertyBlock.Colors[i] = this.LocalAvatarConfig.ComponentMaterialProperties[i].Color;
				this.LocalAvatarConfig.MaterialPropertyBlock.DiffuseIntensities[i] = OvrAvatarMaterialManager.DiffuseIntensities[i];
				this.LocalAvatarConfig.MaterialPropertyBlock.RimIntensities[i] = OvrAvatarMaterialManager.RimIntensities[i];
				this.LocalAvatarConfig.MaterialPropertyBlock.ReflectionIntensities[i] = OvrAvatarMaterialManager.ReflectionIntensities[i];
			}
		}
	}

	// Token: 0x06000604 RID: 1540 RVA: 0x00027650 File Offset: 0x00025850
	private void ApplyMaterialPropertyBlock()
	{
		MaterialPropertyBlock materialPropertyBlock = new MaterialPropertyBlock();
		materialPropertyBlock.SetVectorArray(OvrAvatarMaterialManager.AVATAR_SHADER_COLOR, this.LocalAvatarConfig.MaterialPropertyBlock.Colors);
		materialPropertyBlock.SetFloatArray(OvrAvatarMaterialManager.AVATAR_SHADER_DIFFUSEINTENSITY, this.LocalAvatarConfig.MaterialPropertyBlock.DiffuseIntensities);
		materialPropertyBlock.SetFloatArray(OvrAvatarMaterialManager.AVATAR_SHADER_RIMINTENSITY, this.LocalAvatarConfig.MaterialPropertyBlock.RimIntensities);
		materialPropertyBlock.SetFloatArray(OvrAvatarMaterialManager.AVATAR_SHADER_REFLECTIONINTENSITY, this.LocalAvatarConfig.MaterialPropertyBlock.ReflectionIntensities);
		this.TargetRenderer.GetClosestReflectionProbes(this.ReflectionProbes);
		if (this.ReflectionProbes != null && this.ReflectionProbes.Count > 0 && this.ReflectionProbes[0].probe.texture != null)
		{
			materialPropertyBlock.SetTexture(OvrAvatarMaterialManager.AVATAR_SHADER_CUBEMAP, this.ReflectionProbes[0].probe.texture);
		}
		for (int i = 0; i < this.TextureArrays.Length; i++)
		{
			materialPropertyBlock.SetTexture(this.TextureTypeToShaderProperties[i], this.TextureArrays[i].TextureArray);
		}
		this.TargetRenderer.SetPropertyBlock(materialPropertyBlock);
	}

	// Token: 0x06000605 RID: 1541 RVA: 0x00027774 File Offset: 0x00025974
	public static ovrAvatarBodyPartType GetComponentType(string objectName)
	{
		if (objectName.Contains("0"))
		{
			return ovrAvatarBodyPartType.Body;
		}
		if (objectName.Contains("1"))
		{
			return ovrAvatarBodyPartType.Clothing;
		}
		if (objectName.Contains("2"))
		{
			return ovrAvatarBodyPartType.Eyewear;
		}
		if (objectName.Contains("3"))
		{
			return ovrAvatarBodyPartType.Hair;
		}
		if (objectName.Contains("4"))
		{
			return ovrAvatarBodyPartType.Beard;
		}
		return ovrAvatarBodyPartType.Count;
	}

	// Token: 0x06000606 RID: 1542 RVA: 0x000277CD File Offset: 0x000259CD
	private ulong GetTextureIDForType(ovrAvatarPBSMaterialState materialState, OvrAvatarMaterialManager.TextureType type)
	{
		if (type == OvrAvatarMaterialManager.TextureType.DiffuseTextures)
		{
			return materialState.albedoTextureID;
		}
		if (type == OvrAvatarMaterialManager.TextureType.NormalMaps)
		{
			return materialState.normalTextureID;
		}
		if (type == OvrAvatarMaterialManager.TextureType.RoughnessMaps)
		{
			return materialState.metallicnessTextureID;
		}
		return 0UL;
	}

	// Token: 0x06000607 RID: 1543 RVA: 0x000277F4 File Offset: 0x000259F4
	public void ValidateTextures(ovrAvatarPBSMaterialState[] materialStates)
	{
		OvrAvatarMaterialManager.AvatarComponentMaterialProperties[] componentMaterialProperties = this.LocalAvatarConfig.ComponentMaterialProperties;
		int[] array = new int[3];
		TextureFormat[] array2 = new TextureFormat[3];
		for (int i = 0; i < componentMaterialProperties.Length; i++)
		{
			for (int j = 0; j < componentMaterialProperties[i].Textures.Length; j++)
			{
				if (componentMaterialProperties[i].Textures[j] == null)
				{
					string str = componentMaterialProperties[i].TypeIndex.ToString();
					string str2 = "Invalid: ";
					OvrAvatarMaterialManager.TextureType textureType = (OvrAvatarMaterialManager.TextureType)j;
					throw new Exception(str + str2 + textureType.ToString());
				}
				array[j] = componentMaterialProperties[i].Textures[j].height;
				array2[j] = componentMaterialProperties[i].Textures[j].format;
			}
		}
		for (int k = 0; k < 3; k++)
		{
			for (int l = 1; l < componentMaterialProperties.Length; l++)
			{
				if (componentMaterialProperties[l - 1].Textures[k].height != componentMaterialProperties[l].Textures[k].height)
				{
					object[] array3 = new object[12];
					array3[0] = componentMaterialProperties[l].TypeIndex.ToString();
					array3[1] = " Mismatching Resolutions: ";
					int num = 2;
					OvrAvatarMaterialManager.TextureType textureType = (OvrAvatarMaterialManager.TextureType)k;
					array3[num] = textureType.ToString();
					array3[3] = " ";
					array3[4] = componentMaterialProperties[l - 1].Textures[k].height;
					array3[5] = " (ID: ";
					array3[6] = this.GetTextureIDForType(materialStates[l - 1], (OvrAvatarMaterialManager.TextureType)k);
					array3[7] = ") vs ";
					array3[8] = componentMaterialProperties[l].Textures[k].height;
					array3[9] = " (ID: ";
					array3[10] = this.GetTextureIDForType(materialStates[l], (OvrAvatarMaterialManager.TextureType)k);
					array3[11] = ") Ensure you are using ASTC texture compression on Android or turn off CombineMeshes";
					throw new Exception(string.Concat(array3));
				}
				if (componentMaterialProperties[l - 1].Textures[k].format != componentMaterialProperties[l].Textures[k].format)
				{
					object[] array4 = new object[12];
					array4[0] = componentMaterialProperties[l].TypeIndex.ToString();
					array4[1] = " Mismatching Formats: ";
					int num2 = 2;
					OvrAvatarMaterialManager.TextureType textureType = (OvrAvatarMaterialManager.TextureType)k;
					array4[num2] = textureType.ToString();
					array4[3] = " ";
					array4[4] = componentMaterialProperties[l - 1].Textures[k].format;
					array4[5] = " (ID: ";
					array4[6] = this.GetTextureIDForType(materialStates[l - 1], (OvrAvatarMaterialManager.TextureType)k);
					array4[7] = ") vs ";
					array4[8] = componentMaterialProperties[l].Textures[k].format;
					array4[9] = " (ID: ";
					array4[10] = this.GetTextureIDForType(materialStates[l], (OvrAvatarMaterialManager.TextureType)k);
					array4[11] = ") Ensure you are using ASTC texture compression on Android or turn off CombineMeshes";
					throw new Exception(string.Concat(array4));
				}
			}
		}
	}

	// Token: 0x06000608 RID: 1544 RVA: 0x00027B25 File Offset: 0x00025D25
	private IEnumerator RunLoadingAnimation(Action callBack)
	{
		this.CombinedShader = this.TargetRenderer.sharedMaterial.shader;
		int srcBlend = this.TargetRenderer.sharedMaterial.GetInt("_SrcBlend");
		int dstBlend = this.TargetRenderer.sharedMaterial.GetInt("_DstBlend");
		string lightModeTag = this.TargetRenderer.sharedMaterial.GetTag("LightMode", false);
		string renderTypeTag = this.TargetRenderer.sharedMaterial.GetTag("RenderType", false);
		string renderQueueTag = this.TargetRenderer.sharedMaterial.GetTag("Queue", false);
		string ignoreProjectorTag = this.TargetRenderer.sharedMaterial.GetTag("IgnoreProjector", false);
		int renderQueue = this.TargetRenderer.sharedMaterial.renderQueue;
		bool transparentQueue = this.TargetRenderer.sharedMaterial.IsKeywordEnabled("_ALPHATEST_ON");
		this.TargetRenderer.sharedMaterial.shader = Shader.Find(OvrAvatarMaterialManager.AVATAR_SHADER_LOADER);
		this.TargetRenderer.sharedMaterial.SetColor(OvrAvatarMaterialManager.AVATAR_SHADER_COLOR, Color.white);
		while (OvrAvatarSDKManager.Instance.GetTextureCopyManager().GetTextureCount() > 0)
		{
			float value = (0.5f * Mathf.Sin(Time.timeSinceLevelLoad / 0.35f) + 0.5f) * 0.25f + 0.3f;
			this.TargetRenderer.sharedMaterial.SetFloat(OvrAvatarMaterialManager.AVATAR_SHADER_LOADING_DIMMER, value);
			yield return null;
		}
		this.TargetRenderer.sharedMaterial.SetFloat(OvrAvatarMaterialManager.AVATAR_SHADER_LOADING_DIMMER, 1f);
		this.TargetRenderer.sharedMaterial.shader = this.CombinedShader;
		this.TargetRenderer.sharedMaterial.SetInt("_SrcBlend", srcBlend);
		this.TargetRenderer.sharedMaterial.SetInt("_DstBlend", dstBlend);
		this.TargetRenderer.sharedMaterial.SetOverrideTag("LightMode", lightModeTag);
		this.TargetRenderer.sharedMaterial.SetOverrideTag("RenderType", renderTypeTag);
		this.TargetRenderer.sharedMaterial.SetOverrideTag("Queue", renderQueueTag);
		this.TargetRenderer.sharedMaterial.SetOverrideTag("IgnoreProjector", ignoreProjectorTag);
		if (transparentQueue)
		{
			this.TargetRenderer.sharedMaterial.EnableKeyword("_ALPHATEST_ON");
			this.TargetRenderer.sharedMaterial.EnableKeyword("_ALPHABLEND_ON");
			this.TargetRenderer.sharedMaterial.EnableKeyword("_ALPHAPREMULTIPLY_ON");
		}
		else
		{
			this.TargetRenderer.sharedMaterial.DisableKeyword("_ALPHATEST_ON");
			this.TargetRenderer.sharedMaterial.DisableKeyword("_ALPHABLEND_ON");
			this.TargetRenderer.sharedMaterial.DisableKeyword("_ALPHAPREMULTIPLY_ON");
		}
		this.TargetRenderer.sharedMaterial.renderQueue = renderQueue;
		this.ApplyMaterialPropertyBlock();
		if (callBack != null)
		{
			callBack();
		}
		yield break;
	}

	// Token: 0x0600060A RID: 1546 RVA: 0x00027B8C File Offset: 0x00025D8C
	// Note: this type is marked as 'beforefieldinit'.
	static OvrAvatarMaterialManager()
	{
		float[] array = new float[5];
		array[1] = 0.3f;
		array[2] = 0.4f;
		OvrAvatarMaterialManager.ReflectionIntensities = array;
	}

	// Token: 0x0400072D RID: 1837
	private Renderer TargetRenderer;

	// Token: 0x0400072E RID: 1838
	private OvrAvatarMaterialManager.AvatarTextureArrayProperties[] TextureArrays;

	// Token: 0x0400072F RID: 1839
	private readonly string[] TextureTypeToShaderProperties = new string[]
	{
		"_MainTex",
		"_NormalMap",
		"_RoughnessMap"
	};

	// Token: 0x04000730 RID: 1840
	public OvrAvatarMaterialManager.AvatarMaterialConfig LocalAvatarConfig = new OvrAvatarMaterialManager.AvatarMaterialConfig();

	// Token: 0x04000731 RID: 1841
	public List<ReflectionProbeBlendInfo> ReflectionProbes = new List<ReflectionProbeBlendInfo>();

	// Token: 0x04000732 RID: 1842
	private Shader CombinedShader;

	// Token: 0x04000733 RID: 1843
	public static string AVATAR_SHADER_LOADER = "OvrAvatar/Avatar_Mobile_Loader";

	// Token: 0x04000734 RID: 1844
	public static string AVATAR_SHADER_MAINTEX = "_MainTex";

	// Token: 0x04000735 RID: 1845
	public static string AVATAR_SHADER_NORMALMAP = "_NormalMap";

	// Token: 0x04000736 RID: 1846
	public static string AVATAR_SHADER_ROUGHNESSMAP = "_RoughnessMap";

	// Token: 0x04000737 RID: 1847
	public static string AVATAR_SHADER_COLOR = "_BaseColor";

	// Token: 0x04000738 RID: 1848
	public static string AVATAR_SHADER_DIFFUSEINTENSITY = "_DiffuseIntensity";

	// Token: 0x04000739 RID: 1849
	public static string AVATAR_SHADER_RIMINTENSITY = "_RimIntensity";

	// Token: 0x0400073A RID: 1850
	public static string AVATAR_SHADER_REFLECTIONINTENSITY = "_ReflectionIntensity";

	// Token: 0x0400073B RID: 1851
	public static string AVATAR_SHADER_CUBEMAP = "_Cubemap";

	// Token: 0x0400073C RID: 1852
	public static string AVATAR_SHADER_ALPHA = "_Alpha";

	// Token: 0x0400073D RID: 1853
	public static string AVATAR_SHADER_LOADING_DIMMER = "_LoadingDimmer";

	// Token: 0x0400073E RID: 1854
	public static string AVATAR_SHADER_IRIS_COLOR = "_MaskColorIris";

	// Token: 0x0400073F RID: 1855
	public static string AVATAR_SHADER_LIP_COLOR = "_MaskColorLips";

	// Token: 0x04000740 RID: 1856
	public static string AVATAR_SHADER_BROW_COLOR = "_MaskColorBrows";

	// Token: 0x04000741 RID: 1857
	public static string AVATAR_SHADER_LASH_COLOR = "_MaskColorLashes";

	// Token: 0x04000742 RID: 1858
	public static string AVATAR_SHADER_SCLERA_COLOR = "_MaskColorSclera";

	// Token: 0x04000743 RID: 1859
	public static string AVATAR_SHADER_GUM_COLOR = "_MaskColorGums";

	// Token: 0x04000744 RID: 1860
	public static string AVATAR_SHADER_TEETH_COLOR = "_MaskColorTeeth";

	// Token: 0x04000745 RID: 1861
	public static string AVATAR_SHADER_LIP_SMOOTHNESS = "_LipSmoothness";

	// Token: 0x04000746 RID: 1862
	public static float[] DiffuseIntensities = new float[]
	{
		0.3f,
		0.1f,
		0f,
		0.15f,
		0.15f
	};

	// Token: 0x04000747 RID: 1863
	public static float[] RimIntensities = new float[]
	{
		5f,
		2f,
		2.84f,
		4f,
		4f
	};

	// Token: 0x04000748 RID: 1864
	public static float[] ReflectionIntensities;

	// Token: 0x04000749 RID: 1865
	private const float LOADING_ANIMATION_AMPLITUDE = 0.5f;

	// Token: 0x0400074A RID: 1866
	private const float LOADING_ANIMATION_PERIOD = 0.35f;

	// Token: 0x0400074B RID: 1867
	private const float LOADING_ANIMATION_CURVE_SCALE = 0.25f;

	// Token: 0x0400074C RID: 1868
	private const float LOADING_ANIMATION_DIMMER_MIN = 0.3f;

	// Token: 0x020001EF RID: 495
	public enum TextureType
	{
		// Token: 0x04000E59 RID: 3673
		DiffuseTextures,
		// Token: 0x04000E5A RID: 3674
		NormalMaps,
		// Token: 0x04000E5B RID: 3675
		RoughnessMaps,
		// Token: 0x04000E5C RID: 3676
		Count
	}

	// Token: 0x020001F0 RID: 496
	public struct AvatarComponentMaterialProperties
	{
		// Token: 0x04000E5D RID: 3677
		public ovrAvatarBodyPartType TypeIndex;

		// Token: 0x04000E5E RID: 3678
		public Color Color;

		// Token: 0x04000E5F RID: 3679
		public Texture2D[] Textures;

		// Token: 0x04000E60 RID: 3680
		public float DiffuseIntensity;

		// Token: 0x04000E61 RID: 3681
		public float RimIntensity;

		// Token: 0x04000E62 RID: 3682
		public float ReflectionIntensity;
	}

	// Token: 0x020001F1 RID: 497
	public struct AvatarTextureArrayProperties
	{
		// Token: 0x04000E63 RID: 3683
		public Texture2D[] Textures;

		// Token: 0x04000E64 RID: 3684
		public Texture2DArray TextureArray;
	}

	// Token: 0x020001F2 RID: 498
	public struct AvatarMaterialPropertyBlock
	{
		// Token: 0x04000E65 RID: 3685
		public Vector4[] Colors;

		// Token: 0x04000E66 RID: 3686
		public float[] DiffuseIntensities;

		// Token: 0x04000E67 RID: 3687
		public float[] RimIntensities;

		// Token: 0x04000E68 RID: 3688
		public float[] ReflectionIntensities;
	}

	// Token: 0x020001F3 RID: 499
	[Serializable]
	public class AvatarMaterialConfig
	{
		// Token: 0x04000E69 RID: 3689
		public OvrAvatarMaterialManager.AvatarComponentMaterialProperties[] ComponentMaterialProperties;

		// Token: 0x04000E6A RID: 3690
		public OvrAvatarMaterialManager.AvatarMaterialPropertyBlock MaterialPropertyBlock;
	}
}
