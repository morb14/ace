﻿using System;
using UnityEngine;

// Token: 0x02000062 RID: 98
public class PhysicsDisabler : MonoBehaviour
{
	// Token: 0x060003A6 RID: 934 RVA: 0x00018570 File Offset: 0x00016770
	private void Start()
	{
		this.AutoDisablePhysics();
	}

	// Token: 0x060003A7 RID: 935 RVA: 0x00018578 File Offset: 0x00016778
	public void AutoDisablePhysics()
	{
		base.Invoke("DisablePhysics", 2f);
	}

	// Token: 0x060003A8 RID: 936 RVA: 0x0001858A File Offset: 0x0001678A
	private void DisablePhysics()
	{
		if (base.GetComponent<Rigidbody>())
		{
			base.GetComponent<Rigidbody>().isKinematic = true;
		}
		if (base.GetComponent<Collider>())
		{
			base.GetComponent<Collider>().enabled = false;
		}
	}

	// Token: 0x060003A9 RID: 937 RVA: 0x000185BE File Offset: 0x000167BE
	public void EnablePhysics()
	{
		if (base.GetComponent<Rigidbody>())
		{
			base.GetComponent<Rigidbody>().isKinematic = false;
		}
		if (base.GetComponent<Collider>())
		{
			base.GetComponent<Collider>().enabled = true;
		}
	}
}
