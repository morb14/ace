﻿using System;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x02000004 RID: 4
public class ClearResults : MonoBehaviour
{
	// Token: 0x06000007 RID: 7 RVA: 0x000020A2 File Offset: 0x000002A2
	private void Start()
	{
		this.originalText = this.fieldText.text;
	}

	// Token: 0x06000008 RID: 8 RVA: 0x000020B5 File Offset: 0x000002B5
	private void FixedUpdate()
	{
		if (this.highlight != null && this.highlight.activeSelf)
		{
			this.highlight.SetActive(false);
		}
	}

	// Token: 0x06000009 RID: 9 RVA: 0x000020DE File Offset: 0x000002DE
	public void Highlight()
	{
		if (this.highlight != null && !this.highlight.activeSelf)
		{
			this.highlight.SetActive(true);
		}
	}

	// Token: 0x0600000A RID: 10 RVA: 0x00002108 File Offset: 0x00000308
	public void Select()
	{
		if (!this.clickedOnce)
		{
			this.fieldText.text = "DELETE RESULTS?";
			this.clickedOnce = true;
			base.Invoke("Reset", 2f);
			return;
		}
		this.DeleteResults();
		this.fieldText.text = "RESULTS DELETED";
		base.Invoke("Reset", 2f);
	}

	// Token: 0x0600000B RID: 11 RVA: 0x0000216C File Offset: 0x0000036C
	private void DeleteResults()
	{
		string text;
		if (Object.FindObjectOfType<StagePlanner>())
		{
			text = SceneManager.GetActiveScene().name;
			text = text + "_" + Object.FindObjectOfType<CustomStageMenu>().CurrentOpenedFile() + "_Results";
		}
		else
		{
			text = SceneManager.GetActiveScene().name + "_Results";
		}
		SaveSystem.DeleteFile(text);
		if (Object.FindObjectOfType<Results>())
		{
			Object.FindObjectOfType<Results>().ForceReset();
		}
		this.introPanel.ReloadResults();
	}

	// Token: 0x0600000C RID: 12 RVA: 0x000021EF File Offset: 0x000003EF
	private void Reset()
	{
		this.clickedOnce = false;
		this.fieldText.text = this.originalText;
	}

	// Token: 0x04000003 RID: 3
	[SerializeField]
	private GameObject highlight;

	// Token: 0x04000004 RID: 4
	[SerializeField]
	private TMP_Text fieldText;

	// Token: 0x04000005 RID: 5
	[SerializeField]
	private IntroPanel introPanel;

	// Token: 0x04000006 RID: 6
	private bool clickedOnce;

	// Token: 0x04000007 RID: 7
	private string originalText;
}
