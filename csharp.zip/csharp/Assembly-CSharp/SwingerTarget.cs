﻿using System;
using UnityEngine;

// Token: 0x0200005D RID: 93
public class SwingerTarget : MonoBehaviour
{
	// Token: 0x06000381 RID: 897 RVA: 0x00003297 File Offset: 0x00001497
	private void Start()
	{
	}

	// Token: 0x06000382 RID: 898 RVA: 0x00003297 File Offset: 0x00001497
	private void Update()
	{
	}
}
