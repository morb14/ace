﻿using System;
using UnityEngine;

// Token: 0x0200008B RID: 139
public class SpawnerSwitchDisplay : MonoBehaviour
{
	// Token: 0x060004E0 RID: 1248 RVA: 0x000205AC File Offset: 0x0001E7AC
	private void Start()
	{
		this.objectOne.SetActive(true);
		this.objectTwo.SetActive(false);
	}

	// Token: 0x060004E1 RID: 1249 RVA: 0x000205C8 File Offset: 0x0001E7C8
	private void Update()
	{
		if (this.objectOne != null && this.objectTwo != null && Time.time > this.startTime + this.switchRate)
		{
			this.objectOne.SetActive(this.objectTwo.activeSelf);
			this.objectTwo.SetActive(!this.objectTwo.activeSelf);
			this.startTime = Time.time;
		}
	}

	// Token: 0x0400062F RID: 1583
	[SerializeField]
	private float switchRate = 1f;

	// Token: 0x04000630 RID: 1584
	[SerializeField]
	private GameObject objectOne;

	// Token: 0x04000631 RID: 1585
	[SerializeField]
	private GameObject objectTwo;

	// Token: 0x04000632 RID: 1586
	private float startTime;
}
