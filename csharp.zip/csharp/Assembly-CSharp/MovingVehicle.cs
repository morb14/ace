﻿using System;
using UnityEngine;
using UnityEngine.SceneManagement;

// Token: 0x02000078 RID: 120
public class MovingVehicle : MonoBehaviour
{
	// Token: 0x06000461 RID: 1121 RVA: 0x0001D7FC File Offset: 0x0001B9FC
	private void Start()
	{
		this.controlManager = Object.FindObjectOfType<ControlManager>();
		this.gameManager = Object.FindObjectOfType<GameManager>();
		if (this.toPos != null)
		{
			this.toPos.transform.parent = null;
		}
		GameEvents.current.onExitVehicle += this.OnExitVehicle;
		SceneManager.sceneLoaded += this.OnSceneLoad;
	}

	// Token: 0x06000462 RID: 1122 RVA: 0x0001D868 File Offset: 0x0001BA68
	private void Update()
	{
		if (!this.paired)
		{
			return;
		}
		if (!this.beginMoving || this.reachedEnd)
		{
			if (OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick, this.controlManager.controller).y > 0.5f)
			{
				if (this.pushJoystickTime == 0f)
				{
					this.pushJoystickTime = Time.time;
					return;
				}
				if (Time.time > this.pushJoystickTime + 1f)
				{
					if (!this.beginMoving)
					{
						this.BeginMoving();
					}
					if (this.reachedEnd)
					{
						this.ReturnToStart();
					}
					this.pushJoystickTime = 0f;
					return;
				}
			}
			else if (this.pushJoystickTime != 0f)
			{
				this.pushJoystickTime = 0f;
			}
			return;
		}
		float num = Vector3.Distance(base.transform.position, this.toPos.position);
		if (num <= 0.1f)
		{
			this.EndRide();
			return;
		}
		if (num > 5f)
		{
			this.speed = (this.toPos.position - base.transform.position).normalized * Time.deltaTime;
			base.transform.Translate(this.speed * this.speedMultiplier, Space.World);
			return;
		}
		if (!this.stopTriggered)
		{
			this.stopTriggered = true;
			base.GetComponent<AudioSource>().clip = this.golfCartStop;
			base.GetComponent<AudioSource>().Stop();
			base.GetComponent<AudioSource>().Play();
			base.Invoke("EndRide", 3f);
		}
		this.speed *= 0.99f;
		base.transform.Translate(this.speed * this.speedMultiplier, Space.World);
	}

	// Token: 0x06000463 RID: 1123 RVA: 0x0001DA1E File Offset: 0x0001BC1E
	private void EndRide()
	{
		GameEvents.current.BroadcastMessage("Push and hold [Joystick] forward to return", false);
		this.reachedEnd = true;
		this.Unpair();
	}

	// Token: 0x06000464 RID: 1124 RVA: 0x0001DA40 File Offset: 0x0001BC40
	private void ReturnToStart()
	{
		GameEvents.current.ExitVehicle();
		this.destroyOnLoad = true;
		SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
	}

	// Token: 0x06000465 RID: 1125 RVA: 0x0001DA70 File Offset: 0x0001BC70
	private void DetermineHolsterTransform()
	{
		if (this.controlManager.controllerMode != ControlManager.ControllerMode.OneHand)
		{
			this.holsterTransform = this.holsterTransformRifle;
			return;
		}
		if (this.controlManager.handedness == ControlManager.Handedness.Left)
		{
			this.holsterTransform = this.holsterTransformLeft;
			return;
		}
		this.holsterTransform = this.holsterTransformRight;
	}

	// Token: 0x06000466 RID: 1126 RVA: 0x0001DAC0 File Offset: 0x0001BCC0
	public void Pair()
	{
		if (Object.FindObjectOfType<OVRPlayerController>())
		{
			this.DetermineHolsterTransform();
			this.pairObject = Object.FindObjectOfType<OVRPlayerController>().gameObject;
			this.characterController = this.pairObject.GetComponent<CharacterController>();
			this.ovrPlayerController = this.pairObject.GetComponent<OVRPlayerController>();
			this.holsterVolume = Object.FindObjectOfType<HolsterVolume>();
			this.characterController.enabled = false;
			this.ovrPlayerController.enabled = false;
			this.holsterVolume.gameObject.SetActive(false);
			Object.DontDestroyOnLoad(base.gameObject);
			this.pairObject.transform.parent = base.transform;
			GameEvents.current.BroadcastMessage("Push and hold [Joystick] forward to start", false);
			if (this.fromPos != null)
			{
				base.transform.position = this.fromPos.position;
			}
			this.paired = true;
			this.holsteredWeapon = this.gameManager.holsteredWeapon;
			this.holsteredWeaponPos = this.holsteredWeapon.transform.localPosition;
			this.holsteredWeaponRot = this.holsteredWeapon.transform.localEulerAngles;
			this.playerHolsterVolume = this.holsteredWeapon.transform.parent;
			this.holsteredWeapon.transform.parent = null;
			this.holsteredWeapon.transform.position = this.holsterTransform.position;
			this.holsteredWeapon.transform.rotation = this.holsterTransform.rotation;
			this.holsteredWeapon.transform.parent = this.holsterTransform;
			this.holsteredWeapon.GetComponent<HolsterControl>().drawOverRide = true;
			this.holsteredWeapon.GetComponent<HolsterControl>().Lock();
		}
	}

	// Token: 0x06000467 RID: 1127 RVA: 0x0001DC78 File Offset: 0x0001BE78
	private void OnSceneLoad(Scene scene, LoadSceneMode mode)
	{
		if (this.paired)
		{
			this.Unpair();
			Object.Destroy(base.gameObject);
		}
		if (this.destroyOnLoad)
		{
			Object.Destroy(base.gameObject);
		}
		if (scene.buildIndex == 0)
		{
			if (this.pairObject != null)
			{
				this.pairObject.transform.parent = null;
				Object.DontDestroyOnLoad(this.pairObject);
			}
			Object.Destroy(base.gameObject);
		}
	}

	// Token: 0x06000468 RID: 1128 RVA: 0x0001DCEF File Offset: 0x0001BEEF
	private void OnExitVehicle()
	{
		this.Unpair();
	}

	// Token: 0x06000469 RID: 1129 RVA: 0x0001DCF8 File Offset: 0x0001BEF8
	private void Unpair()
	{
		if (this.pairObject != null)
		{
			this.pairObject.transform.parent = null;
			Object.DontDestroyOnLoad(this.pairObject);
			SceneManager.MoveGameObjectToScene(base.gameObject, SceneManager.GetActiveScene());
		}
		if (this.characterController != null && this.ovrPlayerController != null)
		{
			this.characterController.enabled = true;
			this.ovrPlayerController.enabled = true;
			this.holsterVolume.gameObject.SetActive(true);
		}
		if (this.holsteredWeapon != null)
		{
			this.holsteredWeapon.transform.parent = this.playerHolsterVolume;
			this.holsteredWeapon.transform.localPosition = this.holsteredWeaponPos;
			this.holsteredWeapon.transform.localEulerAngles = this.holsteredWeaponRot;
			this.holsteredWeapon.GetComponent<HolsterControl>().drawOverRide = false;
		}
	}

	// Token: 0x0600046A RID: 1130 RVA: 0x0001DDE5 File Offset: 0x0001BFE5
	public void BeginMoving()
	{
		this.beginMoving = true;
		base.GetComponent<AudioSource>().clip = this.golfCartStart;
		base.GetComponent<AudioSource>().Play();
	}

	// Token: 0x0600046B RID: 1131 RVA: 0x0001DE0A File Offset: 0x0001C00A
	private void OnDestroy()
	{
		SceneManager.sceneLoaded -= this.OnSceneLoad;
		GameEvents.current.onExitVehicle -= this.OnExitVehicle;
	}

	// Token: 0x04000593 RID: 1427
	[SerializeField]
	private Transform fromPos;

	// Token: 0x04000594 RID: 1428
	[SerializeField]
	private Transform toPos;

	// Token: 0x04000595 RID: 1429
	[SerializeField]
	private float speedMultiplier = 0.2f;

	// Token: 0x04000596 RID: 1430
	private Transform holsterTransform;

	// Token: 0x04000597 RID: 1431
	[SerializeField]
	private Transform holsterTransformLeft;

	// Token: 0x04000598 RID: 1432
	[SerializeField]
	private Transform holsterTransformRight;

	// Token: 0x04000599 RID: 1433
	[SerializeField]
	private Transform holsterTransformRifle;

	// Token: 0x0400059A RID: 1434
	[Header("Audio")]
	[SerializeField]
	private AudioClip golfCartStart;

	// Token: 0x0400059B RID: 1435
	[SerializeField]
	private AudioClip golfCartStop;

	// Token: 0x0400059C RID: 1436
	private bool beginMoving;

	// Token: 0x0400059D RID: 1437
	private bool reachedEnd;

	// Token: 0x0400059E RID: 1438
	private bool destroyOnLoad;

	// Token: 0x0400059F RID: 1439
	private Vector3 originalPosition;

	// Token: 0x040005A0 RID: 1440
	private Quaternion originalRotation;

	// Token: 0x040005A1 RID: 1441
	private CharacterController characterController;

	// Token: 0x040005A2 RID: 1442
	private OVRPlayerController ovrPlayerController;

	// Token: 0x040005A3 RID: 1443
	private HolsterVolume holsterVolume;

	// Token: 0x040005A4 RID: 1444
	private float pushJoystickTime;

	// Token: 0x040005A5 RID: 1445
	private ControlManager controlManager;

	// Token: 0x040005A6 RID: 1446
	private bool paired;

	// Token: 0x040005A7 RID: 1447
	private bool stopTriggered;

	// Token: 0x040005A8 RID: 1448
	private GameObject pairObject;

	// Token: 0x040005A9 RID: 1449
	private GameObject holsteredWeapon;

	// Token: 0x040005AA RID: 1450
	private Vector3 holsteredWeaponPos;

	// Token: 0x040005AB RID: 1451
	private Vector3 holsteredWeaponRot;

	// Token: 0x040005AC RID: 1452
	private Vector3 speed;

	// Token: 0x040005AD RID: 1453
	private GameManager gameManager;

	// Token: 0x040005AE RID: 1454
	private Transform playerHolsterVolume;
}
