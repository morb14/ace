﻿using System;
using UnityEngine;

// Token: 0x0200010E RID: 270
public class OVRLipSyncContextTextureFlip : MonoBehaviour
{
	// Token: 0x060006DC RID: 1756 RVA: 0x0002BF98 File Offset: 0x0002A198
	private void Start()
	{
		this.lipsyncContext = base.GetComponent<OVRLipSyncContextBase>();
		if (this.lipsyncContext == null)
		{
			Debug.LogWarning("LipSyncContextTextureFlip.Start WARNING: No lip sync context component set to object");
		}
		else
		{
			this.lipsyncContext.Smoothing = this.smoothAmount;
		}
		if (this.material == null)
		{
			Debug.LogWarning("LipSyncContextTextureFlip.Start WARNING: Lip sync context texture flip has no material target to control!");
		}
	}

	// Token: 0x060006DD RID: 1757 RVA: 0x0002BFF4 File Offset: 0x0002A1F4
	private void Update()
	{
		if (this.lipsyncContext != null && this.material != null)
		{
			OVRLipSync.Frame currentPhonemeFrame = this.lipsyncContext.GetCurrentPhonemeFrame();
			if (currentPhonemeFrame != null)
			{
				if (this.lipsyncContext.provider == OVRLipSync.ContextProviders.Original)
				{
					for (int i = 0; i < currentPhonemeFrame.Visemes.Length; i++)
					{
						float num = (float)(this.smoothAmount - 1) / 100f;
						this.oldFrame.Visemes[i] = this.oldFrame.Visemes[i] * num + currentPhonemeFrame.Visemes[i] * (1f - num);
					}
				}
				else
				{
					this.oldFrame.Visemes = currentPhonemeFrame.Visemes;
				}
				this.SetVisemeToTexture();
			}
		}
		if (this.smoothAmount != this.lipsyncContext.Smoothing)
		{
			this.lipsyncContext.Smoothing = this.smoothAmount;
		}
	}

	// Token: 0x060006DE RID: 1758 RVA: 0x0002C0CC File Offset: 0x0002A2CC
	private void SetVisemeToTexture()
	{
		int num = -1;
		float num2 = 0f;
		for (int i = 0; i < this.oldFrame.Visemes.Length; i++)
		{
			if (this.oldFrame.Visemes[i] > num2)
			{
				num = i;
				num2 = this.oldFrame.Visemes[i];
			}
		}
		if (num != -1 && num < this.Textures.Length)
		{
			Texture texture = this.Textures[num];
			if (texture != null)
			{
				this.material.SetTexture("_MainTex", texture);
			}
		}
	}

	// Token: 0x0400090B RID: 2315
	public Material material;

	// Token: 0x0400090C RID: 2316
	[Tooltip("The texture used for each viseme.")]
	[OVRNamedArray(new string[]
	{
		"sil",
		"PP",
		"FF",
		"TH",
		"DD",
		"kk",
		"CH",
		"SS",
		"nn",
		"RR",
		"aa",
		"E",
		"ih",
		"oh",
		"ou"
	})]
	public Texture[] Textures = new Texture[OVRLipSync.VisemeCount];

	// Token: 0x0400090D RID: 2317
	[Range(1f, 100f)]
	[Tooltip("Smoothing of 1 will yield only the current predicted viseme,100 will yield an extremely smooth viseme response.")]
	public int smoothAmount = 70;

	// Token: 0x0400090E RID: 2318
	private OVRLipSyncContextBase lipsyncContext;

	// Token: 0x0400090F RID: 2319
	private OVRLipSync.Frame oldFrame = new OVRLipSync.Frame();
}
