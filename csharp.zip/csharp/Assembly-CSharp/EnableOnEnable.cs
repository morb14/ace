﻿using System;
using UnityEngine;

// Token: 0x0200000A RID: 10
public class EnableOnEnable : MonoBehaviour
{
	// Token: 0x06000035 RID: 53 RVA: 0x000031AC File Offset: 0x000013AC
	private void OnEnable()
	{
		if (this.objectsToEnable.Length != 0)
		{
			GameObject[] array = this.objectsToEnable;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].SetActive(true);
			}
		}
		if (this.objectsToDisable.Length != 0)
		{
			GameObject[] array = this.objectsToDisable;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].SetActive(false);
			}
		}
	}

	// Token: 0x06000036 RID: 54 RVA: 0x00003208 File Offset: 0x00001408
	private void OnDisable()
	{
		if (this.objectsToEnable.Length != 0)
		{
			GameObject[] array = this.objectsToEnable;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].SetActive(false);
			}
		}
		if (this.objectsToDisable.Length != 0)
		{
			GameObject[] array = this.objectsToDisable;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].SetActive(true);
			}
		}
	}

	// Token: 0x04000031 RID: 49
	[SerializeField]
	private GameObject[] objectsToEnable;

	// Token: 0x04000032 RID: 50
	[SerializeField]
	private GameObject[] objectsToDisable;
}
