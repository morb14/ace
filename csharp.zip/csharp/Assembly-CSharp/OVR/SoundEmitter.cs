﻿using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Audio;

namespace OVR
{
	// Token: 0x0200018D RID: 397
	public class SoundEmitter : MonoBehaviour
	{
		// Token: 0x1700008C RID: 140
		// (get) Token: 0x06000B23 RID: 2851 RVA: 0x00041DDD File Offset: 0x0003FFDD
		// (set) Token: 0x06000B24 RID: 2852 RVA: 0x00041DEA File Offset: 0x0003FFEA
		public float volume
		{
			get
			{
				return this.audioSource.volume;
			}
			set
			{
				this.audioSource.volume = value;
			}
		}

		// Token: 0x1700008D RID: 141
		// (get) Token: 0x06000B25 RID: 2853 RVA: 0x00041DF8 File Offset: 0x0003FFF8
		// (set) Token: 0x06000B26 RID: 2854 RVA: 0x00041E05 File Offset: 0x00040005
		public float pitch
		{
			get
			{
				return this.audioSource.pitch;
			}
			set
			{
				this.audioSource.pitch = value;
			}
		}

		// Token: 0x1700008E RID: 142
		// (get) Token: 0x06000B27 RID: 2855 RVA: 0x00041E13 File Offset: 0x00040013
		// (set) Token: 0x06000B28 RID: 2856 RVA: 0x00041E20 File Offset: 0x00040020
		public AudioClip clip
		{
			get
			{
				return this.audioSource.clip;
			}
			set
			{
				this.audioSource.clip = value;
			}
		}

		// Token: 0x1700008F RID: 143
		// (get) Token: 0x06000B29 RID: 2857 RVA: 0x00041E2E File Offset: 0x0004002E
		// (set) Token: 0x06000B2A RID: 2858 RVA: 0x00041E3B File Offset: 0x0004003B
		public float time
		{
			get
			{
				return this.audioSource.time;
			}
			set
			{
				this.audioSource.time = value;
			}
		}

		// Token: 0x17000090 RID: 144
		// (get) Token: 0x06000B2B RID: 2859 RVA: 0x00041E49 File Offset: 0x00040049
		public float length
		{
			get
			{
				if (!(this.audioSource.clip != null))
				{
					return 0f;
				}
				return this.audioSource.clip.length;
			}
		}

		// Token: 0x17000091 RID: 145
		// (get) Token: 0x06000B2C RID: 2860 RVA: 0x00041E74 File Offset: 0x00040074
		// (set) Token: 0x06000B2D RID: 2861 RVA: 0x00041E81 File Offset: 0x00040081
		public bool loop
		{
			get
			{
				return this.audioSource.loop;
			}
			set
			{
				this.audioSource.loop = value;
			}
		}

		// Token: 0x17000092 RID: 146
		// (get) Token: 0x06000B2E RID: 2862 RVA: 0x00041E8F File Offset: 0x0004008F
		// (set) Token: 0x06000B2F RID: 2863 RVA: 0x00041E9C File Offset: 0x0004009C
		public bool mute
		{
			get
			{
				return this.audioSource.mute;
			}
			set
			{
				this.audioSource.mute = value;
			}
		}

		// Token: 0x17000093 RID: 147
		// (get) Token: 0x06000B30 RID: 2864 RVA: 0x00041EAA File Offset: 0x000400AA
		// (set) Token: 0x06000B31 RID: 2865 RVA: 0x00041EB7 File Offset: 0x000400B7
		public AudioVelocityUpdateMode velocityUpdateMode
		{
			get
			{
				return this.audioSource.velocityUpdateMode;
			}
			set
			{
				this.audioSource.velocityUpdateMode = value;
			}
		}

		// Token: 0x17000094 RID: 148
		// (get) Token: 0x06000B32 RID: 2866 RVA: 0x00041EC5 File Offset: 0x000400C5
		public bool isPlaying
		{
			get
			{
				return this.audioSource.isPlaying;
			}
		}

		// Token: 0x06000B33 RID: 2867 RVA: 0x00041ED4 File Offset: 0x000400D4
		private void Awake()
		{
			this.audioSource = base.GetComponent<AudioSource>();
			if (this.audioSource == null)
			{
				this.audioSource = base.gameObject.AddComponent<AudioSource>();
			}
			if (AudioManager.enableSpatialization && !this.disableSpatialization)
			{
				this.osp = base.GetComponent<ONSPAudioSource>();
				if (this.osp == null)
				{
					this.osp = base.gameObject.AddComponent<ONSPAudioSource>();
				}
			}
			this.audioSource.playOnAwake = false;
			this.audioSource.Stop();
		}

		// Token: 0x06000B34 RID: 2868 RVA: 0x00041F5D File Offset: 0x0004015D
		public void SetPlayingSoundGroup(SoundGroup soundGroup)
		{
			this.playingSoundGroup = soundGroup;
			if (soundGroup != null)
			{
				soundGroup.IncrementPlayCount();
			}
		}

		// Token: 0x06000B35 RID: 2869 RVA: 0x00041F6F File Offset: 0x0004016F
		public void SetOnFinished(Action onFinished)
		{
			this.onFinished = onFinished;
		}

		// Token: 0x06000B36 RID: 2870 RVA: 0x00041F78 File Offset: 0x00040178
		public void SetOnFinished(Action<object> onFinished, object obj)
		{
			this.onFinishedObject = onFinished;
			this.onFinishedParam = obj;
		}

		// Token: 0x06000B37 RID: 2871 RVA: 0x00041F88 File Offset: 0x00040188
		public void SetChannel(int _channel)
		{
			this.channel = (EmitterChannel)_channel;
		}

		// Token: 0x06000B38 RID: 2872 RVA: 0x00041F91 File Offset: 0x00040191
		public void SetDefaultParent(Transform parent)
		{
			this.defaultParent = parent;
		}

		// Token: 0x06000B39 RID: 2873 RVA: 0x00041F9A File Offset: 0x0004019A
		public void SetAudioMixer(AudioMixerGroup _mixer)
		{
			if (this.audioSource != null)
			{
				this.audioSource.outputAudioMixerGroup = _mixer;
			}
		}

		// Token: 0x06000B3A RID: 2874 RVA: 0x00041FB6 File Offset: 0x000401B6
		public bool IsPlaying()
		{
			return (this.loop && this.audioSource.isPlaying) || this.endPlayTime > Time.time;
		}

		// Token: 0x06000B3B RID: 2875 RVA: 0x00041FDC File Offset: 0x000401DC
		public void Play()
		{
			this.state = SoundEmitter.FadeState.Null;
			this.endPlayTime = Time.time + this.length;
			base.StopAllCoroutines();
			this.audioSource.Play();
		}

		// Token: 0x06000B3C RID: 2876 RVA: 0x00042008 File Offset: 0x00040208
		public void Pause()
		{
			this.state = SoundEmitter.FadeState.Null;
			base.StopAllCoroutines();
			this.audioSource.Pause();
		}

		// Token: 0x06000B3D RID: 2877 RVA: 0x00042024 File Offset: 0x00040224
		public void Stop()
		{
			this.state = SoundEmitter.FadeState.Null;
			base.StopAllCoroutines();
			if (this.audioSource != null)
			{
				this.audioSource.Stop();
			}
			if (this.onFinished != null)
			{
				this.onFinished();
				this.onFinished = null;
			}
			if (this.onFinishedObject != null)
			{
				this.onFinishedObject(this.onFinishedParam);
				this.onFinishedObject = null;
			}
			if (this.playingSoundGroup != null)
			{
				this.playingSoundGroup.DecrementPlayCount();
				this.playingSoundGroup = null;
			}
		}

		// Token: 0x06000B3E RID: 2878 RVA: 0x000420AB File Offset: 0x000402AB
		private int GetSampleTime()
		{
			return this.audioSource.clip.samples - this.audioSource.timeSamples;
		}

		// Token: 0x06000B3F RID: 2879 RVA: 0x000420C9 File Offset: 0x000402C9
		public void ParentTo(Transform parent)
		{
			if (this.lastParentTransform != null)
			{
				Debug.LogError("[SoundEmitter] You must detach the sound emitter before parenting to another object!");
				return;
			}
			this.lastParentTransform = base.transform.parent;
			base.transform.parent = parent;
		}

		// Token: 0x06000B40 RID: 2880 RVA: 0x00042101 File Offset: 0x00040301
		public void DetachFromParent()
		{
			if (this.lastParentTransform == null)
			{
				base.transform.parent = this.defaultParent;
				return;
			}
			base.transform.parent = this.lastParentTransform;
			this.lastParentTransform = null;
		}

		// Token: 0x06000B41 RID: 2881 RVA: 0x0004213B File Offset: 0x0004033B
		public void ResetParent(Transform parent)
		{
			base.transform.parent = parent;
			this.lastParentTransform = null;
		}

		// Token: 0x06000B42 RID: 2882 RVA: 0x00042150 File Offset: 0x00040350
		public void SyncTo(SoundEmitter other, float fadeTime, float toVolume)
		{
			base.StartCoroutine(this.DelayedSyncTo(other, fadeTime, toVolume));
		}

		// Token: 0x06000B43 RID: 2883 RVA: 0x00042162 File Offset: 0x00040362
		private IEnumerator DelayedSyncTo(SoundEmitter other, float fadeTime, float toVolume)
		{
			yield return new WaitForEndOfFrame();
			this.audioSource.time = other.time;
			this.audioSource.Play();
			this.FadeTo(fadeTime, toVolume);
			yield break;
		}

		// Token: 0x06000B44 RID: 2884 RVA: 0x00042186 File Offset: 0x00040386
		public void FadeTo(float fadeTime, float toVolume)
		{
			if (this.state == SoundEmitter.FadeState.FadingOut)
			{
				return;
			}
			this.state = SoundEmitter.FadeState.Ducking;
			base.StopAllCoroutines();
			base.StartCoroutine(this.FadeSoundChannelTo(fadeTime, toVolume));
		}

		// Token: 0x06000B45 RID: 2885 RVA: 0x000421AE File Offset: 0x000403AE
		public void FadeIn(float fadeTime, float defaultVolume)
		{
			this.audioSource.volume = 0f;
			this.state = SoundEmitter.FadeState.FadingIn;
			base.StopAllCoroutines();
			base.StartCoroutine(this.FadeSoundChannel(0f, fadeTime, Fade.In, defaultVolume));
		}

		// Token: 0x06000B46 RID: 2886 RVA: 0x000421E2 File Offset: 0x000403E2
		public void FadeIn(float fadeTime)
		{
			this.audioSource.volume = 0f;
			this.state = SoundEmitter.FadeState.FadingIn;
			base.StopAllCoroutines();
			base.StartCoroutine(this.FadeSoundChannel(0f, fadeTime, Fade.In, this.defaultVolume));
		}

		// Token: 0x06000B47 RID: 2887 RVA: 0x0004221B File Offset: 0x0004041B
		public void FadeOut(float fadeTime)
		{
			if (!this.audioSource.isPlaying)
			{
				return;
			}
			this.state = SoundEmitter.FadeState.FadingOut;
			base.StopAllCoroutines();
			base.StartCoroutine(this.FadeSoundChannel(0f, fadeTime, Fade.Out, this.audioSource.volume));
		}

		// Token: 0x06000B48 RID: 2888 RVA: 0x00042257 File Offset: 0x00040457
		public void FadeOutDelayed(float delayedSecs, float fadeTime)
		{
			if (!this.audioSource.isPlaying)
			{
				return;
			}
			this.state = SoundEmitter.FadeState.FadingOut;
			base.StopAllCoroutines();
			base.StartCoroutine(this.FadeSoundChannel(delayedSecs, fadeTime, Fade.Out, this.audioSource.volume));
		}

		// Token: 0x06000B49 RID: 2889 RVA: 0x0004228F File Offset: 0x0004048F
		private IEnumerator FadeSoundChannelTo(float fadeTime, float toVolume)
		{
			float start = this.audioSource.volume;
			float startTime = Time.realtimeSinceStartup;
			float elapsedTime = 0f;
			while (elapsedTime < fadeTime)
			{
				elapsedTime = Time.realtimeSinceStartup - startTime;
				float t = elapsedTime / fadeTime;
				this.audioSource.volume = Mathf.Lerp(start, toVolume, t);
				yield return 0;
			}
			this.state = SoundEmitter.FadeState.Null;
			yield break;
		}

		// Token: 0x06000B4A RID: 2890 RVA: 0x000422AC File Offset: 0x000404AC
		private IEnumerator FadeSoundChannel(float delaySecs, float fadeTime, Fade fadeType, float defaultVolume)
		{
			if (delaySecs > 0f)
			{
				yield return new WaitForSeconds(delaySecs);
			}
			float start = (fadeType == Fade.In) ? 0f : defaultVolume;
			float end = (fadeType == Fade.In) ? defaultVolume : 0f;
			bool restartPlay = false;
			if (fadeType == Fade.In)
			{
				if (Time.time == 0f)
				{
					restartPlay = true;
				}
				this.audioSource.volume = 0f;
				this.audioSource.Play();
			}
			float startTime = Time.realtimeSinceStartup;
			float elapsedTime = 0f;
			while (elapsedTime < fadeTime)
			{
				elapsedTime = Time.realtimeSinceStartup - startTime;
				float t = elapsedTime / fadeTime;
				this.audioSource.volume = Mathf.Lerp(start, end, t);
				yield return 0;
				if (restartPlay && Time.time > 0f)
				{
					this.audioSource.Play();
					restartPlay = false;
				}
				if (!this.audioSource.isPlaying)
				{
					break;
				}
			}
			if (fadeType == Fade.Out)
			{
				this.Stop();
			}
			this.state = SoundEmitter.FadeState.Null;
			yield break;
		}

		// Token: 0x04000C67 RID: 3175
		public EmitterChannel channel;

		// Token: 0x04000C68 RID: 3176
		public bool disableSpatialization;

		// Token: 0x04000C69 RID: 3177
		private SoundEmitter.FadeState state;

		// Token: 0x04000C6A RID: 3178
		[HideInInspector]
		[NonSerialized]
		public AudioSource audioSource;

		// Token: 0x04000C6B RID: 3179
		[HideInInspector]
		[NonSerialized]
		public SoundPriority priority;

		// Token: 0x04000C6C RID: 3180
		[HideInInspector]
		[NonSerialized]
		public ONSPAudioSource osp;

		// Token: 0x04000C6D RID: 3181
		[HideInInspector]
		[NonSerialized]
		public float endPlayTime;

		// Token: 0x04000C6E RID: 3182
		private Transform lastParentTransform;

		// Token: 0x04000C6F RID: 3183
		[HideInInspector]
		[NonSerialized]
		public float defaultVolume = 1f;

		// Token: 0x04000C70 RID: 3184
		[HideInInspector]
		[NonSerialized]
		public Transform defaultParent;

		// Token: 0x04000C71 RID: 3185
		[HideInInspector]
		[NonSerialized]
		public int originalIdx = -1;

		// Token: 0x04000C72 RID: 3186
		[HideInInspector]
		[NonSerialized]
		public Action onFinished;

		// Token: 0x04000C73 RID: 3187
		[HideInInspector]
		[NonSerialized]
		public Action<object> onFinishedObject;

		// Token: 0x04000C74 RID: 3188
		[HideInInspector]
		[NonSerialized]
		public object onFinishedParam;

		// Token: 0x04000C75 RID: 3189
		[HideInInspector]
		[NonSerialized]
		public SoundGroup playingSoundGroup;

		// Token: 0x02000254 RID: 596
		public enum FadeState
		{
			// Token: 0x04001024 RID: 4132
			Null,
			// Token: 0x04001025 RID: 4133
			FadingIn,
			// Token: 0x04001026 RID: 4134
			FadingOut,
			// Token: 0x04001027 RID: 4135
			Ducking
		}
	}
}
