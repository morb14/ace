﻿using System;

namespace OVR
{
	// Token: 0x0200018E RID: 398
	public enum SoundFXNext
	{
		// Token: 0x04000C77 RID: 3191
		Random,
		// Token: 0x04000C78 RID: 3192
		Sequential
	}
}
