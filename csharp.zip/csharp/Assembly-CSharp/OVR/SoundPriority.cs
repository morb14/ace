﻿using System;

namespace OVR
{
	// Token: 0x02000190 RID: 400
	public enum SoundPriority
	{
		// Token: 0x04000C7E RID: 3198
		VeryLow = -2,
		// Token: 0x04000C7F RID: 3199
		Low,
		// Token: 0x04000C80 RID: 3200
		Default,
		// Token: 0x04000C81 RID: 3201
		High,
		// Token: 0x04000C82 RID: 3202
		VeryHigh
	}
}
