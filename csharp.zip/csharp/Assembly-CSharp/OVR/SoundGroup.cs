﻿using System;
using UnityEngine;
using UnityEngine.Audio;

namespace OVR
{
	// Token: 0x02000188 RID: 392
	[Serializable]
	public class SoundGroup
	{
		// Token: 0x06000AE9 RID: 2793 RVA: 0x0004055F File Offset: 0x0003E75F
		public SoundGroup(string name)
		{
			this.name = name;
		}

		// Token: 0x06000AEA RID: 2794 RVA: 0x00040590 File Offset: 0x0003E790
		public SoundGroup()
		{
			this.mixerGroup = null;
			this.maxPlayingSounds = 0;
			this.preloadAudio = PreloadSounds.Default;
			this.volumeOverride = 1f;
		}

		// Token: 0x06000AEB RID: 2795 RVA: 0x000405E8 File Offset: 0x0003E7E8
		public void IncrementPlayCount()
		{
			int value = this.playingSoundCount + 1;
			this.playingSoundCount = value;
			this.playingSoundCount = Mathf.Clamp(value, 0, this.maxPlayingSounds);
		}

		// Token: 0x06000AEC RID: 2796 RVA: 0x00040618 File Offset: 0x0003E818
		public void DecrementPlayCount()
		{
			int value = this.playingSoundCount - 1;
			this.playingSoundCount = value;
			this.playingSoundCount = Mathf.Clamp(value, 0, this.maxPlayingSounds);
		}

		// Token: 0x06000AED RID: 2797 RVA: 0x00040648 File Offset: 0x0003E848
		public bool CanPlaySound()
		{
			return this.maxPlayingSounds == 0 || this.playingSoundCount < this.maxPlayingSounds;
		}

		// Token: 0x04000C37 RID: 3127
		public string name = string.Empty;

		// Token: 0x04000C38 RID: 3128
		public SoundFX[] soundList = new SoundFX[0];

		// Token: 0x04000C39 RID: 3129
		public AudioMixerGroup mixerGroup;

		// Token: 0x04000C3A RID: 3130
		[Range(0f, 64f)]
		public int maxPlayingSounds;

		// Token: 0x04000C3B RID: 3131
		public PreloadSounds preloadAudio;

		// Token: 0x04000C3C RID: 3132
		public float volumeOverride = 1f;

		// Token: 0x04000C3D RID: 3133
		[HideInInspector]
		public int playingSoundCount;
	}
}
