﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

namespace OVR
{
	// Token: 0x02000189 RID: 393
	public class AudioManager : MonoBehaviour
	{
		// Token: 0x17000084 RID: 132
		// (get) Token: 0x06000AEE RID: 2798 RVA: 0x00040662 File Offset: 0x0003E862
		public static bool enableSpatialization
		{
			get
			{
				return AudioManager.theAudioManager != null && AudioManager.theAudioManager.enableSpatializedAudio;
			}
		}

		// Token: 0x17000085 RID: 133
		// (get) Token: 0x06000AEF RID: 2799 RVA: 0x0004067D File Offset: 0x0003E87D
		public static AudioManager Instance
		{
			get
			{
				return AudioManager.theAudioManager;
			}
		}

		// Token: 0x17000086 RID: 134
		// (get) Token: 0x06000AF0 RID: 2800 RVA: 0x00040684 File Offset: 0x0003E884
		public static float NearFallOff
		{
			get
			{
				return AudioManager.theAudioManager.audioMinFallOffDistance;
			}
		}

		// Token: 0x17000087 RID: 135
		// (get) Token: 0x06000AF1 RID: 2801 RVA: 0x00040690 File Offset: 0x0003E890
		public static float FarFallOff
		{
			get
			{
				return AudioManager.theAudioManager.audioMaxFallOffDistance;
			}
		}

		// Token: 0x17000088 RID: 136
		// (get) Token: 0x06000AF2 RID: 2802 RVA: 0x0004069C File Offset: 0x0003E89C
		public static AudioMixerGroup EmitterGroup
		{
			get
			{
				return AudioManager.theAudioManager.defaultMixerGroup;
			}
		}

		// Token: 0x17000089 RID: 137
		// (get) Token: 0x06000AF3 RID: 2803 RVA: 0x000406A8 File Offset: 0x0003E8A8
		public static AudioMixerGroup ReservedGroup
		{
			get
			{
				return AudioManager.theAudioManager.reservedMixerGroup;
			}
		}

		// Token: 0x1700008A RID: 138
		// (get) Token: 0x06000AF4 RID: 2804 RVA: 0x000406B4 File Offset: 0x0003E8B4
		public static AudioMixerGroup VoipGroup
		{
			get
			{
				return AudioManager.theAudioManager.voiceChatMixerGroup;
			}
		}

		// Token: 0x06000AF5 RID: 2805 RVA: 0x000406C0 File Offset: 0x0003E8C0
		private void Awake()
		{
			this.Init();
		}

		// Token: 0x06000AF6 RID: 2806 RVA: 0x000406C8 File Offset: 0x0003E8C8
		private void OnDestroy()
		{
			if (AudioManager.theAudioManager == this && AudioManager.soundEmitterParent != null)
			{
				Object.Destroy(AudioManager.soundEmitterParent);
			}
		}

		// Token: 0x06000AF7 RID: 2807 RVA: 0x000406F0 File Offset: 0x0003E8F0
		private void Init()
		{
			if (AudioManager.theAudioManager != null)
			{
				if (Application.isPlaying && AudioManager.theAudioManager != this)
				{
					base.enabled = false;
				}
				return;
			}
			AudioManager.theAudioManager = this;
			AudioManager.nullSound.name = "Default Sound";
			this.RebuildSoundFXCache();
			if (Application.isPlaying)
			{
				this.InitializeSoundSystem();
				if (this.makePersistent && base.transform.parent == null)
				{
					Object.DontDestroyOnLoad(base.gameObject);
				}
			}
		}

		// Token: 0x06000AF8 RID: 2808 RVA: 0x00040774 File Offset: 0x0003E974
		private void Update()
		{
			this.UpdateFreeEmitters();
		}

		// Token: 0x06000AF9 RID: 2809 RVA: 0x0004077C File Offset: 0x0003E97C
		private void RebuildSoundFXCache()
		{
			int num = 0;
			for (int i = 0; i < this.soundGroupings.Length; i++)
			{
				num += this.soundGroupings[i].soundList.Length;
			}
			this.soundFXCache = new Dictionary<string, SoundFX>(num + 1);
			this.soundFXCache.Add(AudioManager.nullSound.name, AudioManager.nullSound);
			for (int j = 0; j < this.soundGroupings.Length; j++)
			{
				for (int k = 0; k < this.soundGroupings[j].soundList.Length; k++)
				{
					if (this.soundFXCache.ContainsKey(this.soundGroupings[j].soundList[k].name))
					{
						Debug.LogError(string.Concat(new string[]
						{
							"ERROR: Duplicate Sound FX name in the audio manager: '",
							this.soundGroupings[j].name,
							"' > '",
							this.soundGroupings[j].soundList[k].name,
							"'"
						}));
					}
					else
					{
						this.soundGroupings[j].soundList[k].Group = this.soundGroupings[j];
						this.soundFXCache.Add(this.soundGroupings[j].soundList[k].name, this.soundGroupings[j].soundList[k]);
					}
				}
				this.soundGroupings[j].playingSoundCount = 0;
			}
		}

		// Token: 0x06000AFA RID: 2810 RVA: 0x000408DC File Offset: 0x0003EADC
		public static SoundFX FindSoundFX(string name, bool rebuildCache = false)
		{
			if (string.IsNullOrEmpty(name))
			{
				return AudioManager.nullSound;
			}
			if (rebuildCache)
			{
				AudioManager.theAudioManager.RebuildSoundFXCache();
			}
			if (!AudioManager.theAudioManager.soundFXCache.ContainsKey(name))
			{
				return AudioManager.nullSound;
			}
			return AudioManager.theAudioManager.soundFXCache[name];
		}

		// Token: 0x06000AFB RID: 2811 RVA: 0x0004092C File Offset: 0x0003EB2C
		private static bool FindAudioManager()
		{
			GameObject gameObject = GameObject.Find("AudioManager");
			if (gameObject == null || gameObject.GetComponent<AudioManager>() == null)
			{
				if (!AudioManager.hideWarnings)
				{
					Debug.LogError("[ERROR] AudioManager object missing from hierarchy!");
					AudioManager.hideWarnings = true;
				}
				return false;
			}
			gameObject.GetComponent<AudioManager>().Init();
			return true;
		}

		// Token: 0x06000AFC RID: 2812 RVA: 0x00040980 File Offset: 0x0003EB80
		public static GameObject GetGameObject()
		{
			if (AudioManager.theAudioManager == null && !AudioManager.FindAudioManager())
			{
				return null;
			}
			return AudioManager.theAudioManager.gameObject;
		}

		// Token: 0x06000AFD RID: 2813 RVA: 0x000409A2 File Offset: 0x0003EBA2
		public static string NameMinusGroup(string name)
		{
			if (name.IndexOf("/") > -1)
			{
				return name.Substring(name.IndexOf("/") + 1);
			}
			return name;
		}

		// Token: 0x06000AFE RID: 2814 RVA: 0x000409C8 File Offset: 0x0003EBC8
		public static string[] GetSoundFXNames(string currentValue, out int currentIdx)
		{
			currentIdx = 0;
			AudioManager.names.Clear();
			if (AudioManager.theAudioManager == null && !AudioManager.FindAudioManager())
			{
				return AudioManager.defaultSound;
			}
			AudioManager.names.Add(AudioManager.nullSound.name);
			for (int i = 0; i < AudioManager.theAudioManager.soundGroupings.Length; i++)
			{
				for (int j = 0; j < AudioManager.theAudioManager.soundGroupings[i].soundList.Length; j++)
				{
					if (string.Compare(currentValue, AudioManager.theAudioManager.soundGroupings[i].soundList[j].name, true) == 0)
					{
						currentIdx = AudioManager.names.Count;
					}
					AudioManager.names.Add(AudioManager.theAudioManager.soundGroupings[i].name + "/" + AudioManager.theAudioManager.soundGroupings[i].soundList[j].name);
				}
			}
			return AudioManager.names.ToArray();
		}

		// Token: 0x1700008B RID: 139
		// (get) Token: 0x06000AFF RID: 2815 RVA: 0x00040AC2 File Offset: 0x0003ECC2
		public static bool SoundEnabled
		{
			get
			{
				return AudioManager.soundEnabled;
			}
		}

		// Token: 0x06000B00 RID: 2816 RVA: 0x00040ACC File Offset: 0x0003ECCC
		private void InitializeSoundSystem()
		{
			int num = 960;
			int num2 = 4;
			AudioSettings.GetDSPBufferSize(out num, out num2);
			if (Application.isPlaying)
			{
				Debug.Log("[AudioManager] Audio Sample Rate: " + AudioSettings.outputSampleRate);
				Debug.Log(string.Concat(new object[]
				{
					"[AudioManager] Audio Buffer Length: ",
					num,
					" Size: ",
					num2
				}));
			}
			AudioListener audioListener = Object.FindObjectOfType<AudioListener>();
			if (audioListener == null)
			{
				Debug.LogError("[AudioManager] Missing AudioListener object!  Add one to the scene.");
			}
			else
			{
				AudioManager.staticListenerPosition = audioListener.transform;
			}
			this.soundEmitters = new SoundEmitter[this.maxSoundEmitters + 1];
			AudioManager.soundEmitterParent = GameObject.Find("__SoundEmitters__");
			if (AudioManager.soundEmitterParent != null)
			{
				Object.Destroy(AudioManager.soundEmitterParent);
			}
			AudioManager.soundEmitterParent = new GameObject("__SoundEmitters__");
			for (int i = 0; i < this.maxSoundEmitters + 1; i++)
			{
				GameObject gameObject = new GameObject("SoundEmitter_" + i);
				gameObject.transform.parent = AudioManager.soundEmitterParent.transform;
				gameObject.transform.position = Vector3.zero;
				gameObject.hideFlags = HideFlags.DontSaveInEditor;
				this.soundEmitters[i] = gameObject.AddComponent<SoundEmitter>();
				this.soundEmitters[i].SetDefaultParent(AudioManager.soundEmitterParent.transform);
				this.soundEmitters[i].SetChannel(i);
				this.soundEmitters[i].Stop();
				this.soundEmitters[i].originalIdx = i;
			}
			this.ResetFreeEmitters();
			AudioManager.soundEmitterParent.hideFlags = HideFlags.DontSaveInEditor;
			this.audioMaxFallOffDistanceSqr = this.audioMaxFallOffDistance * this.audioMaxFallOffDistance;
		}

		// Token: 0x06000B01 RID: 2817 RVA: 0x00040C7C File Offset: 0x0003EE7C
		private void UpdateFreeEmitters()
		{
			if (this.verboseLogging)
			{
				if (Input.GetKeyDown(KeyCode.A))
				{
					AudioManager.forceShowEmitterCount = !AudioManager.forceShowEmitterCount;
				}
				if (AudioManager.forceShowEmitterCount)
				{
					AudioManager.showPlayingEmitterCount = true;
				}
			}
			int num = 0;
			int num2 = 0;
			int num3 = 0;
			int num4 = 0;
			int num5 = 0;
			int num6 = 0;
			int i = 0;
			while (i < this.playingEmitters.size)
			{
				if (this.playingEmitters[i] == null)
				{
					Debug.LogError("[AudioManager] ERROR: playingEmitters list had a null emitter! Something nuked a sound emitter!!!");
					this.playingEmitters.RemoveAtFast(i);
					return;
				}
				if (!this.playingEmitters[i].IsPlaying())
				{
					if (this.verboseLogging && this.nextFreeEmitters.Contains(this.playingEmitters[i]))
					{
						Debug.LogError("[AudioManager] ERROR: playing sound emitter already in the free emitters list!");
					}
					this.playingEmitters[i].Stop();
					this.nextFreeEmitters.Add(this.playingEmitters[i]);
					this.playingEmitters.RemoveAtFast(i);
				}
				else
				{
					if (this.verboseLogging && AudioManager.showPlayingEmitterCount)
					{
						num++;
						switch (this.playingEmitters[i].priority)
						{
						case SoundPriority.VeryLow:
							num2++;
							break;
						case SoundPriority.Low:
							num3++;
							break;
						case SoundPriority.Default:
							num4++;
							break;
						case SoundPriority.High:
							num5++;
							break;
						case SoundPriority.VeryHigh:
							num6++;
							break;
						}
					}
					i++;
				}
			}
			if (this.verboseLogging && AudioManager.showPlayingEmitterCount)
			{
				Debug.LogWarning(string.Format("[AudioManager] Playing sounds: Total {0} | VeryLow {1} | Low {2} | Default {3} | High {4} | VeryHigh {5} | Free {6}", new object[]
				{
					this.Fmt(num),
					this.Fmt(num2),
					this.Fmt(num3),
					this.Fmt(num4),
					this.Fmt(num5),
					this.Fmt(num6),
					this.FmtFree(this.nextFreeEmitters.Count)
				}));
				AudioManager.showPlayingEmitterCount = false;
			}
		}

		// Token: 0x06000B02 RID: 2818 RVA: 0x00040E6C File Offset: 0x0003F06C
		private string Fmt(int count)
		{
			float num = (float)count / (float)AudioManager.theAudioManager.maxSoundEmitters;
			if (num < 0.5f)
			{
				return "<color=green>" + count.ToString() + "</color>";
			}
			if ((double)num < 0.7)
			{
				return "<color=yellow>" + count.ToString() + "</color>";
			}
			return "<color=red>" + count.ToString() + "</color>";
		}

		// Token: 0x06000B03 RID: 2819 RVA: 0x00040EE4 File Offset: 0x0003F0E4
		private string FmtFree(int count)
		{
			float num = (float)count / (float)AudioManager.theAudioManager.maxSoundEmitters;
			if (num < 0.2f)
			{
				return "<color=red>" + count.ToString() + "</color>";
			}
			if ((double)num < 0.3)
			{
				return "<color=yellow>" + count.ToString() + "</color>";
			}
			return "<color=green>" + count.ToString() + "</color>";
		}

		// Token: 0x06000B04 RID: 2820 RVA: 0x00040F5C File Offset: 0x0003F15C
		private void OnPreSceneLoad()
		{
			Debug.Log("[AudioManager] OnPreSceneLoad cleanup");
			for (int i = 0; i < this.soundEmitters.Length; i++)
			{
				this.soundEmitters[i].Stop();
				this.soundEmitters[i].ResetParent(AudioManager.soundEmitterParent.transform);
			}
			this.ResetFreeEmitters();
		}

		// Token: 0x06000B05 RID: 2821 RVA: 0x00040FB0 File Offset: 0x0003F1B0
		private void ResetFreeEmitters()
		{
			this.nextFreeEmitters.Clear();
			this.playingEmitters.Clear();
			for (int i = 1; i < this.soundEmitters.Length; i++)
			{
				this.nextFreeEmitters.Add(this.soundEmitters[i]);
			}
		}

		// Token: 0x06000B06 RID: 2822 RVA: 0x00040FF9 File Offset: 0x0003F1F9
		public static void FadeOutSoundChannel(int channel, float delaySecs, float fadeTime)
		{
			AudioManager.theAudioManager.soundEmitters[channel].FadeOutDelayed(delaySecs, fadeTime);
		}

		// Token: 0x06000B07 RID: 2823 RVA: 0x0004100E File Offset: 0x0003F20E
		public static bool StopSound(int idx, bool fadeOut = true, bool stopReserved = false)
		{
			if (!stopReserved && idx == 0)
			{
				return false;
			}
			if (!fadeOut)
			{
				AudioManager.theAudioManager.soundEmitters[idx].Stop();
			}
			else
			{
				AudioManager.theAudioManager.soundEmitters[idx].FadeOut(AudioManager.theAudioManager.soundFxFadeSecs);
			}
			return true;
		}

		// Token: 0x06000B08 RID: 2824 RVA: 0x0004104A File Offset: 0x0003F24A
		public static void FadeInSound(int idx, float fadeTime, float volume)
		{
			AudioManager.theAudioManager.soundEmitters[idx].FadeIn(fadeTime, volume);
		}

		// Token: 0x06000B09 RID: 2825 RVA: 0x0004105F File Offset: 0x0003F25F
		public static void FadeInSound(int idx, float fadeTime)
		{
			AudioManager.theAudioManager.soundEmitters[idx].FadeIn(fadeTime);
		}

		// Token: 0x06000B0A RID: 2826 RVA: 0x00041073 File Offset: 0x0003F273
		public static void FadeOutSound(int idx, float fadeTime)
		{
			AudioManager.theAudioManager.soundEmitters[idx].FadeOut(fadeTime);
		}

		// Token: 0x06000B0B RID: 2827 RVA: 0x00041088 File Offset: 0x0003F288
		public static void StopAllSounds(bool fadeOut, bool stopReserved = false)
		{
			for (int i = 0; i < AudioManager.theAudioManager.soundEmitters.Length; i++)
			{
				AudioManager.StopSound(i, fadeOut, stopReserved);
			}
		}

		// Token: 0x06000B0C RID: 2828 RVA: 0x000410B8 File Offset: 0x0003F2B8
		public void MuteAllSounds(bool mute, bool muteReserved = false)
		{
			for (int i = 0; i < this.soundEmitters.Length; i++)
			{
				if (muteReserved || i != 0)
				{
					this.soundEmitters[i].audioSource.mute = true;
				}
			}
		}

		// Token: 0x06000B0D RID: 2829 RVA: 0x000410F4 File Offset: 0x0003F2F4
		public void UnMuteAllSounds(bool unmute, bool unmuteReserved = false)
		{
			for (int i = 0; i < this.soundEmitters.Length; i++)
			{
				if ((unmuteReserved || i != 0) && this.soundEmitters[i].audioSource.isPlaying)
				{
					this.soundEmitters[i].audioSource.mute = false;
				}
			}
		}

		// Token: 0x06000B0E RID: 2830 RVA: 0x00041141 File Offset: 0x0003F341
		public static float GetEmitterEndTime(int idx)
		{
			return AudioManager.theAudioManager.soundEmitters[idx].endPlayTime;
		}

		// Token: 0x06000B0F RID: 2831 RVA: 0x00041154 File Offset: 0x0003F354
		public static float SetEmitterTime(int idx, float time)
		{
			AudioManager.theAudioManager.soundEmitters[idx].time = time;
			return time;
		}

		// Token: 0x06000B10 RID: 2832 RVA: 0x00041176 File Offset: 0x0003F376
		public static int PlaySound(AudioClip clip, float volume, EmitterChannel src = EmitterChannel.Any, float delay = 0f, float pitchVariance = 1f, bool loop = false)
		{
			if (!AudioManager.SoundEnabled)
			{
				return -1;
			}
			return AudioManager.PlaySoundAt((AudioManager.staticListenerPosition != null) ? AudioManager.staticListenerPosition.position : Vector3.zero, clip, volume, src, delay, pitchVariance, loop);
		}

		// Token: 0x06000B11 RID: 2833 RVA: 0x000411AC File Offset: 0x0003F3AC
		private static int FindFreeEmitter(EmitterChannel src, SoundPriority priority)
		{
			SoundEmitter soundEmitter = AudioManager.theAudioManager.soundEmitters[0];
			if (src == EmitterChannel.Any)
			{
				if (AudioManager.theAudioManager.nextFreeEmitters.size > 0)
				{
					soundEmitter = AudioManager.theAudioManager.nextFreeEmitters[0];
					AudioManager.theAudioManager.nextFreeEmitters.RemoveAtFast(0);
				}
				else
				{
					if (priority == SoundPriority.VeryLow)
					{
						return -1;
					}
					soundEmitter = AudioManager.theAudioManager.playingEmitters.Find((SoundEmitter item) => item != null && item.priority < priority);
					if (soundEmitter == null)
					{
						if (priority < SoundPriority.Default)
						{
							if (AudioManager.theAudioManager.verboseLogging)
							{
								Debug.LogWarning("[AudioManager] skipping sound " + priority);
							}
							return -1;
						}
						soundEmitter = AudioManager.theAudioManager.playingEmitters.Find((SoundEmitter item) => item != null && item.priority <= SoundPriority.Default);
					}
					if (soundEmitter != null)
					{
						if (AudioManager.theAudioManager.verboseLogging)
						{
							Debug.LogWarning(string.Concat(new object[]
							{
								"[AudioManager] cannabalizing ",
								soundEmitter.originalIdx,
								" Time: ",
								Time.time
							}));
						}
						soundEmitter.Stop();
						AudioManager.theAudioManager.playingEmitters.RemoveFast(soundEmitter);
					}
				}
			}
			if (soundEmitter == null)
			{
				Debug.LogError("[AudioManager] ERROR - absolutely couldn't find a free emitter! Priority = " + priority + " TOO MANY PlaySound* calls!");
				AudioManager.showPlayingEmitterCount = true;
				return -1;
			}
			return soundEmitter.originalIdx;
		}

		// Token: 0x06000B12 RID: 2834 RVA: 0x00041340 File Offset: 0x0003F540
		public static int PlaySound(SoundFX soundFX, EmitterChannel src = EmitterChannel.Any, float delay = 0f)
		{
			if (!AudioManager.SoundEnabled)
			{
				return -1;
			}
			return AudioManager.PlaySoundAt((AudioManager.staticListenerPosition != null) ? AudioManager.staticListenerPosition.position : Vector3.zero, soundFX, src, delay, 1f, 1f);
		}

		// Token: 0x06000B13 RID: 2835 RVA: 0x0004137C File Offset: 0x0003F57C
		public static int PlaySoundAt(Vector3 position, SoundFX soundFX, EmitterChannel src = EmitterChannel.Any, float delay = 0f, float volumeOverride = 1f, float pitchMultiplier = 1f)
		{
			if (!AudioManager.SoundEnabled)
			{
				return -1;
			}
			AudioClip clip = soundFX.GetClip();
			if (clip == null)
			{
				return -1;
			}
			if (AudioManager.staticListenerPosition != null)
			{
				float sqrMagnitude = (AudioManager.staticListenerPosition.position - position).sqrMagnitude;
				if (sqrMagnitude > AudioManager.theAudioManager.audioMaxFallOffDistanceSqr)
				{
					return -1;
				}
				if (sqrMagnitude > soundFX.MaxFalloffDistSquared)
				{
					return -1;
				}
			}
			if (soundFX.ReachedGroupPlayLimit())
			{
				if (AudioManager.theAudioManager.verboseLogging)
				{
					Debug.Log("[AudioManager] PlaySoundAt() with " + soundFX.name + " skipped due to group play limit");
				}
				return -1;
			}
			int num = AudioManager.FindFreeEmitter(src, soundFX.priority);
			if (num == -1)
			{
				return -1;
			}
			SoundEmitter soundEmitter = AudioManager.theAudioManager.soundEmitters[num];
			soundEmitter.ResetParent(AudioManager.soundEmitterParent.transform);
			soundEmitter.gameObject.SetActive(true);
			AudioSource audioSource = soundEmitter.audioSource;
			ONSPAudioSource osp = soundEmitter.osp;
			audioSource.enabled = true;
			audioSource.volume = Mathf.Clamp01(Mathf.Clamp01(AudioManager.theAudioManager.volumeSoundFX * soundFX.volume) * volumeOverride * soundFX.GroupVolumeOverride);
			audioSource.pitch = soundFX.GetPitch() * pitchMultiplier;
			audioSource.time = 0f;
			audioSource.spatialBlend = 1f;
			audioSource.rolloffMode = soundFX.falloffCurve;
			if (soundFX.falloffCurve == AudioRolloffMode.Custom)
			{
				audioSource.SetCustomCurve(AudioSourceCurveType.CustomRolloff, soundFX.volumeFalloffCurve);
			}
			audioSource.SetCustomCurve(AudioSourceCurveType.ReverbZoneMix, soundFX.reverbZoneMix);
			audioSource.dopplerLevel = 0f;
			audioSource.clip = clip;
			audioSource.spread = soundFX.spread;
			audioSource.loop = soundFX.looping;
			audioSource.mute = false;
			audioSource.minDistance = soundFX.falloffDistance.x;
			audioSource.maxDistance = soundFX.falloffDistance.y;
			audioSource.outputAudioMixerGroup = soundFX.GetMixerGroup(AudioManager.EmitterGroup);
			soundEmitter.endPlayTime = Time.time + clip.length + delay;
			soundEmitter.defaultVolume = audioSource.volume;
			soundEmitter.priority = soundFX.priority;
			soundEmitter.onFinished = null;
			soundEmitter.SetPlayingSoundGroup(soundFX.Group);
			if (src == EmitterChannel.Any)
			{
				AudioManager.theAudioManager.playingEmitters.AddUnique(soundEmitter);
			}
			if (osp != null)
			{
				osp.EnableSpatialization = soundFX.ospProps.enableSpatialization;
				osp.EnableRfl = (AudioManager.theAudioManager.enableSpatializedFastOverride || soundFX.ospProps.useFastOverride);
				osp.Gain = soundFX.ospProps.gain;
				osp.UseInvSqr = soundFX.ospProps.enableInvSquare;
				osp.Near = soundFX.ospProps.invSquareFalloff.x;
				osp.Far = soundFX.ospProps.invSquareFalloff.y;
				audioSource.spatialBlend = (soundFX.ospProps.enableSpatialization ? 1f : 0.8f);
				osp.SetParameters(ref audioSource);
			}
			audioSource.transform.position = position;
			if (AudioManager.theAudioManager.verboseLogging)
			{
				Debug.Log(string.Concat(new object[]
				{
					"[AudioManager] PlaySoundAt() channel = ",
					num,
					" soundFX = ",
					soundFX.name,
					" volume = ",
					soundEmitter.volume,
					" Delay = ",
					delay,
					" time = ",
					Time.time,
					"\n"
				}));
			}
			if (delay > 0f)
			{
				audioSource.PlayDelayed(delay);
			}
			else
			{
				audioSource.Play();
			}
			return num;
		}

		// Token: 0x06000B14 RID: 2836 RVA: 0x00041708 File Offset: 0x0003F908
		public static int PlayRandomSoundAt(Vector3 position, AudioClip[] clips, float volume, EmitterChannel src = EmitterChannel.Any, float delay = 0f, float pitch = 1f, bool loop = false)
		{
			if (clips == null || clips.Length == 0)
			{
				return -1;
			}
			int num = Random.Range(0, clips.Length);
			return AudioManager.PlaySoundAt(position, clips[num], volume, src, delay, pitch, loop);
		}

		// Token: 0x06000B15 RID: 2837 RVA: 0x0004173C File Offset: 0x0003F93C
		public static int PlaySoundAt(Vector3 position, AudioClip clip, float volume = 1f, EmitterChannel src = EmitterChannel.Any, float delay = 0f, float pitch = 1f, bool loop = false)
		{
			if (!AudioManager.SoundEnabled)
			{
				return -1;
			}
			if (clip == null)
			{
				return -1;
			}
			if (AudioManager.staticListenerPosition != null && (AudioManager.staticListenerPosition.position - position).sqrMagnitude > AudioManager.theAudioManager.audioMaxFallOffDistanceSqr)
			{
				return -1;
			}
			int num = AudioManager.FindFreeEmitter(src, SoundPriority.Default);
			if (num == -1)
			{
				return -1;
			}
			SoundEmitter soundEmitter = AudioManager.theAudioManager.soundEmitters[num];
			soundEmitter.ResetParent(AudioManager.soundEmitterParent.transform);
			soundEmitter.gameObject.SetActive(true);
			AudioSource audioSource = soundEmitter.audioSource;
			ONSPAudioSource osp = soundEmitter.osp;
			audioSource.enabled = true;
			audioSource.volume = Mathf.Clamp01(AudioManager.theAudioManager.volumeSoundFX * volume);
			audioSource.pitch = pitch;
			audioSource.spatialBlend = 0.8f;
			audioSource.rolloffMode = AudioRolloffMode.Linear;
			audioSource.SetCustomCurve(AudioSourceCurveType.ReverbZoneMix, AudioManager.defaultReverbZoneMix);
			audioSource.dopplerLevel = 0f;
			audioSource.clip = clip;
			audioSource.spread = 0f;
			audioSource.loop = loop;
			audioSource.mute = false;
			audioSource.minDistance = AudioManager.theAudioManager.audioMinFallOffDistance;
			audioSource.maxDistance = AudioManager.theAudioManager.audioMaxFallOffDistance;
			audioSource.outputAudioMixerGroup = AudioManager.EmitterGroup;
			soundEmitter.endPlayTime = Time.time + clip.length + delay;
			soundEmitter.defaultVolume = audioSource.volume;
			soundEmitter.priority = SoundPriority.Default;
			soundEmitter.onFinished = null;
			soundEmitter.SetPlayingSoundGroup(null);
			if (src == EmitterChannel.Any)
			{
				AudioManager.theAudioManager.playingEmitters.AddUnique(soundEmitter);
			}
			if (osp != null)
			{
				osp.EnableSpatialization = false;
			}
			audioSource.transform.position = position;
			if (AudioManager.theAudioManager.verboseLogging)
			{
				Debug.Log(string.Concat(new object[]
				{
					"[AudioManager] PlaySoundAt() channel = ",
					num,
					" clip = ",
					clip.name,
					" volume = ",
					soundEmitter.volume,
					" Delay = ",
					delay,
					" time = ",
					Time.time,
					"\n"
				}));
			}
			if (delay > 0f)
			{
				audioSource.PlayDelayed(delay);
			}
			else
			{
				audioSource.Play();
			}
			return num;
		}

		// Token: 0x06000B16 RID: 2838 RVA: 0x00041977 File Offset: 0x0003FB77
		public static void SetOnFinished(int emitterIdx, Action onFinished)
		{
			if (emitterIdx >= 0 && emitterIdx < AudioManager.theAudioManager.maxSoundEmitters)
			{
				AudioManager.theAudioManager.soundEmitters[emitterIdx].SetOnFinished(onFinished);
			}
		}

		// Token: 0x06000B17 RID: 2839 RVA: 0x0004199C File Offset: 0x0003FB9C
		public static void SetOnFinished(int emitterIdx, Action<object> onFinished, object obj)
		{
			if (emitterIdx >= 0 && emitterIdx < AudioManager.theAudioManager.maxSoundEmitters)
			{
				AudioManager.theAudioManager.soundEmitters[emitterIdx].SetOnFinished(onFinished, obj);
			}
		}

		// Token: 0x06000B18 RID: 2840 RVA: 0x000419C4 File Offset: 0x0003FBC4
		public static void AttachSoundToParent(int idx, Transform parent)
		{
			if (AudioManager.theAudioManager.verboseLogging)
			{
				string text = parent.name;
				if (parent.parent != null)
				{
					text = parent.parent.name + "/" + text;
				}
				Debug.Log(string.Concat(new object[]
				{
					"[AudioManager] ATTACHING INDEX ",
					idx,
					" to ",
					text
				}));
			}
			AudioManager.theAudioManager.soundEmitters[idx].ParentTo(parent);
		}

		// Token: 0x06000B19 RID: 2841 RVA: 0x00041A48 File Offset: 0x0003FC48
		public static void DetachSoundFromParent(int idx)
		{
			if (AudioManager.theAudioManager.verboseLogging)
			{
				Debug.Log("[AudioManager] DETACHING INDEX " + idx);
			}
			AudioManager.theAudioManager.soundEmitters[idx].DetachFromParent();
		}

		// Token: 0x06000B1A RID: 2842 RVA: 0x00041A7C File Offset: 0x0003FC7C
		public static void DetachSoundsFromParent(SoundEmitter[] emitters, bool stopSounds = true)
		{
			if (emitters == null)
			{
				return;
			}
			foreach (SoundEmitter soundEmitter in emitters)
			{
				if (soundEmitter.defaultParent != null)
				{
					if (stopSounds)
					{
						soundEmitter.Stop();
					}
					soundEmitter.DetachFromParent();
					soundEmitter.gameObject.SetActive(true);
				}
				else if (stopSounds)
				{
					soundEmitter.Stop();
				}
			}
		}

		// Token: 0x06000B1B RID: 2843 RVA: 0x00041AD5 File Offset: 0x0003FCD5
		public static void SetEmitterMixerGroup(int idx, AudioMixerGroup mixerGroup)
		{
			if (AudioManager.theAudioManager != null && idx > -1)
			{
				AudioManager.theAudioManager.soundEmitters[idx].SetAudioMixer(mixerGroup);
			}
		}

		// Token: 0x06000B1C RID: 2844 RVA: 0x00041AFA File Offset: 0x0003FCFA
		public static MixerSnapshot GetActiveSnapshot()
		{
			if (!(AudioManager.theAudioManager != null))
			{
				return null;
			}
			return AudioManager.theAudioManager.currentSnapshot;
		}

		// Token: 0x06000B1D RID: 2845 RVA: 0x00041B18 File Offset: 0x0003FD18
		public static void SetCurrentSnapshot(MixerSnapshot mixerSnapshot)
		{
			if (AudioManager.theAudioManager != null)
			{
				if (mixerSnapshot != null && mixerSnapshot.snapshot != null)
				{
					mixerSnapshot.snapshot.TransitionTo(mixerSnapshot.transitionTime);
				}
				else
				{
					mixerSnapshot = null;
				}
				AudioManager.theAudioManager.currentSnapshot = mixerSnapshot;
			}
		}

		// Token: 0x06000B1E RID: 2846 RVA: 0x00041B64 File Offset: 0x0003FD64
		public static void BlendWithCurrentSnapshot(MixerSnapshot blendSnapshot, float weight, float blendTime = 0f)
		{
			if (AudioManager.theAudioManager != null)
			{
				if (AudioManager.theAudioManager.audioMixer == null)
				{
					Debug.LogWarning("[AudioManager] can't call BlendWithCurrentSnapshot if the audio mixer is not set!");
					return;
				}
				if (blendTime == 0f)
				{
					blendTime = Time.deltaTime;
				}
				if (AudioManager.theAudioManager.currentSnapshot != null && AudioManager.theAudioManager.currentSnapshot.snapshot != null && blendSnapshot != null && blendSnapshot.snapshot != null)
				{
					weight = Mathf.Clamp01(weight);
					if (weight == 0f)
					{
						AudioManager.theAudioManager.currentSnapshot.snapshot.TransitionTo(blendTime);
						return;
					}
					AudioMixerSnapshot[] snapshots = new AudioMixerSnapshot[]
					{
						AudioManager.theAudioManager.currentSnapshot.snapshot,
						blendSnapshot.snapshot
					};
					float[] weights = new float[]
					{
						1f - weight,
						weight
					};
					AudioManager.theAudioManager.audioMixer.TransitionToSnapshots(snapshots, weights, blendTime);
				}
			}
		}

		// Token: 0x04000C3E RID: 3134
		[Tooltip("Make the audio manager persistent across all scene loads")]
		public bool makePersistent = true;

		// Token: 0x04000C3F RID: 3135
		[Tooltip("Enable the OSP audio plugin features")]
		public bool enableSpatializedAudio = true;

		// Token: 0x04000C40 RID: 3136
		[Tooltip("Always play spatialized sounds with no reflections (Default)")]
		public bool enableSpatializedFastOverride;

		// Token: 0x04000C41 RID: 3137
		[Tooltip("The audio mixer asset used for snapshot blends, etc.")]
		public AudioMixer audioMixer;

		// Token: 0x04000C42 RID: 3138
		[Tooltip("The audio mixer group used for the pooled emitters")]
		public AudioMixerGroup defaultMixerGroup;

		// Token: 0x04000C43 RID: 3139
		[Tooltip("The audio mixer group used for the reserved pool emitter")]
		public AudioMixerGroup reservedMixerGroup;

		// Token: 0x04000C44 RID: 3140
		[Tooltip("The audio mixer group used for voice chat")]
		public AudioMixerGroup voiceChatMixerGroup;

		// Token: 0x04000C45 RID: 3141
		[Tooltip("Log all PlaySound calls to the Unity console")]
		public bool verboseLogging;

		// Token: 0x04000C46 RID: 3142
		[Tooltip("Maximum sound emitters")]
		public int maxSoundEmitters = 32;

		// Token: 0x04000C47 RID: 3143
		[Tooltip("Default volume for all sounds modulated by individual sound FX volumes")]
		public float volumeSoundFX = 1f;

		// Token: 0x04000C48 RID: 3144
		[Tooltip("Sound FX fade time")]
		public float soundFxFadeSecs = 1f;

		// Token: 0x04000C49 RID: 3145
		public float audioMinFallOffDistance = 1f;

		// Token: 0x04000C4A RID: 3146
		public float audioMaxFallOffDistance = 25f;

		// Token: 0x04000C4B RID: 3147
		public SoundGroup[] soundGroupings = new SoundGroup[0];

		// Token: 0x04000C4C RID: 3148
		private Dictionary<string, SoundFX> soundFXCache;

		// Token: 0x04000C4D RID: 3149
		private static AudioManager theAudioManager = null;

		// Token: 0x04000C4E RID: 3150
		private static FastList<string> names = new FastList<string>();

		// Token: 0x04000C4F RID: 3151
		private static string[] defaultSound = new string[]
		{
			"Default Sound"
		};

		// Token: 0x04000C50 RID: 3152
		private static SoundFX nullSound = new SoundFX();

		// Token: 0x04000C51 RID: 3153
		private static bool hideWarnings = false;

		// Token: 0x04000C52 RID: 3154
		private float audioMaxFallOffDistanceSqr = 625f;

		// Token: 0x04000C53 RID: 3155
		private SoundEmitter[] soundEmitters;

		// Token: 0x04000C54 RID: 3156
		private FastList<SoundEmitter> playingEmitters = new FastList<SoundEmitter>();

		// Token: 0x04000C55 RID: 3157
		private FastList<SoundEmitter> nextFreeEmitters = new FastList<SoundEmitter>();

		// Token: 0x04000C56 RID: 3158
		private MixerSnapshot currentSnapshot;

		// Token: 0x04000C57 RID: 3159
		private static GameObject soundEmitterParent = null;

		// Token: 0x04000C58 RID: 3160
		private static Transform staticListenerPosition = null;

		// Token: 0x04000C59 RID: 3161
		private static bool showPlayingEmitterCount = false;

		// Token: 0x04000C5A RID: 3162
		private static bool forceShowEmitterCount = false;

		// Token: 0x04000C5B RID: 3163
		private static bool soundEnabled = true;

		// Token: 0x04000C5C RID: 3164
		private static readonly AnimationCurve defaultReverbZoneMix = new AnimationCurve(new Keyframe[]
		{
			new Keyframe(0f, 1f),
			new Keyframe(1f, 1f)
		});

		// Token: 0x02000251 RID: 593
		public enum Fade
		{
			// Token: 0x0400101E RID: 4126
			In,
			// Token: 0x0400101F RID: 4127
			Out
		}
	}
}
