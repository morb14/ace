﻿using System;
using UnityEngine;

namespace OVR
{
	// Token: 0x02000184 RID: 388
	public class TestScript : MonoBehaviour
	{
		// Token: 0x06000AE0 RID: 2784 RVA: 0x00003297 File Offset: 0x00001497
		private void Start()
		{
		}

		// Token: 0x06000AE1 RID: 2785 RVA: 0x000402AC File Offset: 0x0003E4AC
		private void Update()
		{
			if (Input.GetKeyDown(KeyCode.Alpha1))
			{
				this.testSound1.PlaySoundAt(base.transform.position, 0f, 1f, 1f);
			}
			if (Input.GetKeyDown(KeyCode.Alpha2))
			{
				this.testSound2.PlaySoundAt(new Vector3(5f, 0f, 0f), 0f, 1f, 1f);
			}
		}

		// Token: 0x04000C24 RID: 3108
		[InspectorNote("Sound Setup", "Press '1' to play testSound1 and '2' to play testSound2")]
		public SoundFXRef testSound1;

		// Token: 0x04000C25 RID: 3109
		public SoundFXRef testSound2;
	}
}
