﻿using System;

namespace OVR
{
	// Token: 0x02000186 RID: 390
	public enum PreloadSounds
	{
		// Token: 0x04000C31 RID: 3121
		Default,
		// Token: 0x04000C32 RID: 3122
		Preload,
		// Token: 0x04000C33 RID: 3123
		ManualPreload
	}
}
