﻿using System;

namespace OVR
{
	// Token: 0x0200018F RID: 399
	public enum FreqHint
	{
		// Token: 0x04000C7A RID: 3194
		None,
		// Token: 0x04000C7B RID: 3195
		Wide,
		// Token: 0x04000C7C RID: 3196
		Narrow
	}
}
