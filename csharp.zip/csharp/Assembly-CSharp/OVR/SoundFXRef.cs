﻿using System;
using UnityEngine;

namespace OVR
{
	// Token: 0x02000193 RID: 403
	[Serializable]
	public class SoundFXRef
	{
		// Token: 0x1700009A RID: 154
		// (get) Token: 0x06000B60 RID: 2912 RVA: 0x00042883 File Offset: 0x00040A83
		public SoundFX soundFX
		{
			get
			{
				if (!this.initialized)
				{
					this.Init();
				}
				return this.soundFXCached;
			}
		}

		// Token: 0x1700009B RID: 155
		// (get) Token: 0x06000B61 RID: 2913 RVA: 0x00042899 File Offset: 0x00040A99
		// (set) Token: 0x06000B62 RID: 2914 RVA: 0x000428A1 File Offset: 0x00040AA1
		public string name
		{
			get
			{
				return this.soundFXName;
			}
			set
			{
				this.soundFXName = value;
				this.Init();
			}
		}

		// Token: 0x06000B63 RID: 2915 RVA: 0x000428B0 File Offset: 0x00040AB0
		private void Init()
		{
			this.soundFXCached = AudioManager.FindSoundFX(this.soundFXName, false);
			if (this.soundFXCached == null)
			{
				this.soundFXCached = AudioManager.FindSoundFX(string.Empty, false);
			}
			this.initialized = true;
		}

		// Token: 0x1700009C RID: 156
		// (get) Token: 0x06000B64 RID: 2916 RVA: 0x000428E4 File Offset: 0x00040AE4
		public int Length
		{
			get
			{
				return this.soundFX.Length;
			}
		}

		// Token: 0x1700009D RID: 157
		// (get) Token: 0x06000B65 RID: 2917 RVA: 0x000428F1 File Offset: 0x00040AF1
		public bool IsValid
		{
			get
			{
				return this.soundFX.IsValid;
			}
		}

		// Token: 0x06000B66 RID: 2918 RVA: 0x000428FE File Offset: 0x00040AFE
		public AudioClip GetClip()
		{
			return this.soundFX.GetClip();
		}

		// Token: 0x06000B67 RID: 2919 RVA: 0x0004290B File Offset: 0x00040B0B
		public float GetClipLength(int idx)
		{
			return this.soundFX.GetClipLength(idx);
		}

		// Token: 0x06000B68 RID: 2920 RVA: 0x00042919 File Offset: 0x00040B19
		public int PlaySound(float delaySecs = 0f)
		{
			return this.soundFX.PlaySound(delaySecs);
		}

		// Token: 0x06000B69 RID: 2921 RVA: 0x00042927 File Offset: 0x00040B27
		public int PlaySoundAt(Vector3 pos, float delaySecs = 0f, float volume = 1f, float pitchMultiplier = 1f)
		{
			return this.soundFX.PlaySoundAt(pos, delaySecs, volume, pitchMultiplier);
		}

		// Token: 0x06000B6A RID: 2922 RVA: 0x00042939 File Offset: 0x00040B39
		public void SetOnFinished(Action onFinished)
		{
			this.soundFX.SetOnFinished(onFinished);
		}

		// Token: 0x06000B6B RID: 2923 RVA: 0x00042947 File Offset: 0x00040B47
		public void SetOnFinished(Action<object> onFinished, object obj)
		{
			this.soundFX.SetOnFinished(onFinished, obj);
		}

		// Token: 0x06000B6C RID: 2924 RVA: 0x00042956 File Offset: 0x00040B56
		public bool StopSound()
		{
			return this.soundFX.StopSound();
		}

		// Token: 0x06000B6D RID: 2925 RVA: 0x00042963 File Offset: 0x00040B63
		public void AttachToParent(Transform parent)
		{
			this.soundFX.AttachToParent(parent);
		}

		// Token: 0x06000B6E RID: 2926 RVA: 0x00042971 File Offset: 0x00040B71
		public void DetachFromParent()
		{
			this.soundFX.DetachFromParent();
		}

		// Token: 0x04000C9C RID: 3228
		public string soundFXName = string.Empty;

		// Token: 0x04000C9D RID: 3229
		private bool initialized;

		// Token: 0x04000C9E RID: 3230
		private SoundFX soundFXCached;
	}
}
