﻿using System;
using UnityEngine;
using UnityEngine.Audio;

namespace OVR
{
	// Token: 0x02000192 RID: 402
	[Serializable]
	public class SoundFX
	{
		// Token: 0x06000B4D RID: 2893 RVA: 0x0004235C File Offset: 0x0004055C
		public SoundFX()
		{
			this.playback = SoundFXNext.Random;
			this.volume = 1f;
			this.pitchVariance = Vector2.one;
			this.falloffDistance = new Vector2(1f, 25f);
			this.falloffCurve = AudioRolloffMode.Linear;
			this.volumeFalloffCurve = new AnimationCurve(new Keyframe[]
			{
				new Keyframe(0f, 1f),
				new Keyframe(1f, 1f)
			});
			this.reverbZoneMix = new AnimationCurve(new Keyframe[]
			{
				new Keyframe(0f, 1f),
				new Keyframe(1f, 1f)
			});
			this.spread = 0f;
			this.pctChanceToPlay = 1f;
			this.priority = SoundPriority.Default;
			this.delay = Vector2.zero;
			this.looping = false;
			this.ospProps = new OSPProps();
		}

		// Token: 0x17000095 RID: 149
		// (get) Token: 0x06000B4E RID: 2894 RVA: 0x0004254E File Offset: 0x0004074E
		public int Length
		{
			get
			{
				return this.soundClips.Length;
			}
		}

		// Token: 0x17000096 RID: 150
		// (get) Token: 0x06000B4F RID: 2895 RVA: 0x00042558 File Offset: 0x00040758
		public bool IsValid
		{
			get
			{
				return this.soundClips.Length != 0 && this.soundClips[0] != null;
			}
		}

		// Token: 0x17000097 RID: 151
		// (get) Token: 0x06000B50 RID: 2896 RVA: 0x00042573 File Offset: 0x00040773
		// (set) Token: 0x06000B51 RID: 2897 RVA: 0x0004257B File Offset: 0x0004077B
		public SoundGroup Group
		{
			get
			{
				return this.soundGroup;
			}
			set
			{
				this.soundGroup = value;
			}
		}

		// Token: 0x17000098 RID: 152
		// (get) Token: 0x06000B52 RID: 2898 RVA: 0x00042584 File Offset: 0x00040784
		public float MaxFalloffDistSquared
		{
			get
			{
				return this.falloffDistance.y * this.falloffDistance.y;
			}
		}

		// Token: 0x17000099 RID: 153
		// (get) Token: 0x06000B53 RID: 2899 RVA: 0x0004259D File Offset: 0x0004079D
		public float GroupVolumeOverride
		{
			get
			{
				if (this.soundGroup == null)
				{
					return 1f;
				}
				return this.soundGroup.volumeOverride;
			}
		}

		// Token: 0x06000B54 RID: 2900 RVA: 0x000425B8 File Offset: 0x000407B8
		public AudioClip GetClip()
		{
			if (this.soundClips.Length == 0)
			{
				return null;
			}
			if (this.soundClips.Length == 1)
			{
				return this.soundClips[0];
			}
			if (this.playback == SoundFXNext.Random)
			{
				int num;
				for (num = Random.Range(0, this.soundClips.Length); num == this.lastIdx; num = Random.Range(0, this.soundClips.Length))
				{
				}
				this.lastIdx = num;
				return this.soundClips[num];
			}
			int num2 = this.lastIdx + 1;
			this.lastIdx = num2;
			if (num2 >= this.soundClips.Length)
			{
				this.lastIdx = 0;
			}
			return this.soundClips[this.lastIdx];
		}

		// Token: 0x06000B55 RID: 2901 RVA: 0x00042654 File Offset: 0x00040854
		public AudioMixerGroup GetMixerGroup(AudioMixerGroup defaultMixerGroup)
		{
			if (this.soundGroup == null)
			{
				return defaultMixerGroup;
			}
			if (!(this.soundGroup.mixerGroup != null))
			{
				return defaultMixerGroup;
			}
			return this.soundGroup.mixerGroup;
		}

		// Token: 0x06000B56 RID: 2902 RVA: 0x00042680 File Offset: 0x00040880
		public bool ReachedGroupPlayLimit()
		{
			return this.soundGroup != null && !this.soundGroup.CanPlaySound();
		}

		// Token: 0x06000B57 RID: 2903 RVA: 0x0004269A File Offset: 0x0004089A
		public float GetClipLength(int idx)
		{
			if (idx == -1 || this.soundClips.Length == 0 || idx >= this.soundClips.Length || this.soundClips[idx] == null)
			{
				return 0f;
			}
			return this.soundClips[idx].length;
		}

		// Token: 0x06000B58 RID: 2904 RVA: 0x000426D7 File Offset: 0x000408D7
		public float GetPitch()
		{
			return Random.Range(this.pitchVariance.x, this.pitchVariance.y);
		}

		// Token: 0x06000B59 RID: 2905 RVA: 0x000426F4 File Offset: 0x000408F4
		public int PlaySound(float delaySecs = 0f)
		{
			this.playingIdx = -1;
			if (!this.IsValid)
			{
				return this.playingIdx;
			}
			if (this.pctChanceToPlay > 0.99f || Random.value < this.pctChanceToPlay)
			{
				if (this.delay.y > 0f)
				{
					delaySecs = Random.Range(this.delay.x, this.delay.y);
				}
				this.playingIdx = AudioManager.PlaySound(this, EmitterChannel.Any, delaySecs);
			}
			return this.playingIdx;
		}

		// Token: 0x06000B5A RID: 2906 RVA: 0x00042774 File Offset: 0x00040974
		public int PlaySoundAt(Vector3 pos, float delaySecs = 0f, float volumeOverride = 1f, float pitchMultiplier = 1f)
		{
			this.playingIdx = -1;
			if (!this.IsValid)
			{
				return this.playingIdx;
			}
			if (this.pctChanceToPlay > 0.99f || Random.value < this.pctChanceToPlay)
			{
				if (this.delay.y > 0f)
				{
					delaySecs = Random.Range(this.delay.x, this.delay.y);
				}
				this.playingIdx = AudioManager.PlaySoundAt(pos, this, EmitterChannel.Any, delaySecs, volumeOverride, pitchMultiplier);
			}
			return this.playingIdx;
		}

		// Token: 0x06000B5B RID: 2907 RVA: 0x000427F8 File Offset: 0x000409F8
		public void SetOnFinished(Action onFinished)
		{
			if (this.playingIdx > -1)
			{
				AudioManager.SetOnFinished(this.playingIdx, onFinished);
			}
		}

		// Token: 0x06000B5C RID: 2908 RVA: 0x0004280F File Offset: 0x00040A0F
		public void SetOnFinished(Action<object> onFinished, object obj)
		{
			if (this.playingIdx > -1)
			{
				AudioManager.SetOnFinished(this.playingIdx, onFinished, obj);
			}
		}

		// Token: 0x06000B5D RID: 2909 RVA: 0x00042828 File Offset: 0x00040A28
		public bool StopSound()
		{
			bool result = false;
			if (this.playingIdx > -1)
			{
				result = AudioManager.StopSound(this.playingIdx, true, false);
				this.playingIdx = -1;
			}
			return result;
		}

		// Token: 0x06000B5E RID: 2910 RVA: 0x00042856 File Offset: 0x00040A56
		public void AttachToParent(Transform parent)
		{
			if (this.playingIdx > -1)
			{
				AudioManager.AttachSoundToParent(this.playingIdx, parent);
			}
		}

		// Token: 0x06000B5F RID: 2911 RVA: 0x0004286D File Offset: 0x00040A6D
		public void DetachFromParent()
		{
			if (this.playingIdx > -1)
			{
				AudioManager.DetachSoundFromParent(this.playingIdx);
			}
		}

		// Token: 0x04000C89 RID: 3209
		[Tooltip("Each sound FX should have a unique name")]
		public string name = string.Empty;

		// Token: 0x04000C8A RID: 3210
		[Tooltip("Sound diversity playback option when multiple audio clips are defined, default = Random")]
		public SoundFXNext playback;

		// Token: 0x04000C8B RID: 3211
		[Tooltip("Default volume for this sound FX, default = 1.0")]
		[Range(0f, 1f)]
		public float volume = 1f;

		// Token: 0x04000C8C RID: 3212
		[Tooltip("Random pitch variance each time a sound FX is played, default = 1.0 (none)")]
		[MinMax(1f, 1f, 0f, 2f)]
		public Vector2 pitchVariance = Vector2.one;

		// Token: 0x04000C8D RID: 3213
		[Tooltip("Falloff distance for the sound FX, default = 1m min to 25m max")]
		[MinMax(1f, 25f, 0f, 250f)]
		public Vector2 falloffDistance = new Vector2(1f, 25f);

		// Token: 0x04000C8E RID: 3214
		[Tooltip("Volume falloff curve - sets how the sound FX attenuates over distance, default = Linear")]
		public AudioRolloffMode falloffCurve = AudioRolloffMode.Linear;

		// Token: 0x04000C8F RID: 3215
		[Tooltip("Defines the custom volume falloff curve")]
		public AnimationCurve volumeFalloffCurve = new AnimationCurve(new Keyframe[]
		{
			new Keyframe(0f, 1f),
			new Keyframe(1f, 1f)
		});

		// Token: 0x04000C90 RID: 3216
		[Tooltip("The amount by which the signal from the AudioSource will be mixed into the global reverb associated with the Reverb Zones | Valid range is 0.0 - 1.1, default = 1.0")]
		public AnimationCurve reverbZoneMix = new AnimationCurve(new Keyframe[]
		{
			new Keyframe(0f, 1f),
			new Keyframe(1f, 1f)
		});

		// Token: 0x04000C91 RID: 3217
		[Tooltip("Sets the spread angle (in degrees) of a 3d stereo or multichannel sound in speaker space, default = 0")]
		[Range(0f, 360f)]
		public float spread;

		// Token: 0x04000C92 RID: 3218
		[Tooltip("The percentage chance that this sound FX will play | 0.0 = none, 1.0 = 100%, default = 1.0")]
		[Range(0f, 1f)]
		public float pctChanceToPlay = 1f;

		// Token: 0x04000C93 RID: 3219
		[Tooltip("Sets the priority for this sound to play and/or to override a currently playing sound FX, default = Default")]
		public SoundPriority priority;

		// Token: 0x04000C94 RID: 3220
		[Tooltip("Specifies the default delay when this sound FX is played, default = 0.0 secs")]
		[MinMax(0f, 0f, 0f, 2f)]
		public Vector2 delay = Vector2.zero;

		// Token: 0x04000C95 RID: 3221
		[Tooltip("Set to true for the sound to loop continuously, default = false")]
		public bool looping;

		// Token: 0x04000C96 RID: 3222
		public OSPProps ospProps = new OSPProps();

		// Token: 0x04000C97 RID: 3223
		[Tooltip("List of the audio clips assigned to this sound FX")]
		public AudioClip[] soundClips = new AudioClip[1];

		// Token: 0x04000C98 RID: 3224
		public bool visibilityToggle;

		// Token: 0x04000C99 RID: 3225
		[NonSerialized]
		private SoundGroup soundGroup;

		// Token: 0x04000C9A RID: 3226
		private int lastIdx = -1;

		// Token: 0x04000C9B RID: 3227
		private int playingIdx = -1;
	}
}
