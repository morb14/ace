﻿using System;
using UnityEngine;

namespace OVR
{
	// Token: 0x02000191 RID: 401
	[Serializable]
	public class OSPProps
	{
		// Token: 0x06000B4C RID: 2892 RVA: 0x000422F4 File Offset: 0x000404F4
		public OSPProps()
		{
			this.enableSpatialization = false;
			this.useFastOverride = false;
			this.gain = 0f;
			this.enableInvSquare = false;
			this.volumetric = 0f;
			this.invSquareFalloff = new Vector2(1f, 25f);
		}

		// Token: 0x04000C83 RID: 3203
		[Tooltip("Set to true to play the sound FX spatialized with binaural HRTF, default = false")]
		public bool enableSpatialization;

		// Token: 0x04000C84 RID: 3204
		[Tooltip("Play the sound FX with reflections, default = false")]
		public bool useFastOverride;

		// Token: 0x04000C85 RID: 3205
		[Tooltip("Boost the gain on the spatialized sound FX, default = 0.0")]
		[Range(0f, 24f)]
		public float gain;

		// Token: 0x04000C86 RID: 3206
		[Tooltip("Enable Inverse Square attenuation curve, default = false")]
		public bool enableInvSquare;

		// Token: 0x04000C87 RID: 3207
		[Tooltip("Change the sound from point source (0.0f) to a spherical volume, default = 0.0")]
		[Range(0f, 1000f)]
		public float volumetric;

		// Token: 0x04000C88 RID: 3208
		[Tooltip("Set the near and far falloff value for the OSP attenuation curve, default = 1.0")]
		[MinMax(1f, 25f, 0f, 250f)]
		public Vector2 invSquareFalloff = new Vector2(1f, 25f);
	}
}
