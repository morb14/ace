﻿using System;
using UnityEngine.Audio;

namespace OVR
{
	// Token: 0x0200018B RID: 395
	[Serializable]
	public class MixerSnapshot
	{
		// Token: 0x04000C61 RID: 3169
		public AudioMixerSnapshot snapshot;

		// Token: 0x04000C62 RID: 3170
		public float transitionTime = 0.25f;
	}
}
