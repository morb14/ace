﻿using System;

namespace OVR
{
	// Token: 0x02000187 RID: 391
	public enum Fade
	{
		// Token: 0x04000C35 RID: 3125
		In,
		// Token: 0x04000C36 RID: 3126
		Out
	}
}
