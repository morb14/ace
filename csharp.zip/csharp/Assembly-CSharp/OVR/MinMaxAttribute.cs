﻿using System;
using UnityEngine;

namespace OVR
{
	// Token: 0x0200018C RID: 396
	public class MinMaxAttribute : PropertyAttribute
	{
		// Token: 0x06000B22 RID: 2850 RVA: 0x00041D8C File Offset: 0x0003FF8C
		public MinMaxAttribute(float minDefaultVal, float maxDefaultVal, float min, float max)
		{
			this.minDefaultVal = minDefaultVal;
			this.maxDefaultVal = maxDefaultVal;
			this.min = min;
			this.max = max;
		}

		// Token: 0x04000C63 RID: 3171
		public float minDefaultVal = 1f;

		// Token: 0x04000C64 RID: 3172
		public float maxDefaultVal = 1f;

		// Token: 0x04000C65 RID: 3173
		public float min;

		// Token: 0x04000C66 RID: 3174
		public float max = 1f;
	}
}
