﻿using System;

namespace OVR
{
	// Token: 0x0200018A RID: 394
	public enum EmitterChannel
	{
		// Token: 0x04000C5E RID: 3166
		None = -1,
		// Token: 0x04000C5F RID: 3167
		Reserved,
		// Token: 0x04000C60 RID: 3168
		Any
	}
}
