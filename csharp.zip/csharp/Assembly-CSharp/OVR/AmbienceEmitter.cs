﻿using System;
using UnityEngine;

namespace OVR
{
	// Token: 0x02000185 RID: 389
	public class AmbienceEmitter : MonoBehaviour
	{
		// Token: 0x06000AE3 RID: 2787 RVA: 0x00040320 File Offset: 0x0003E520
		private void Awake()
		{
			if (this.autoActivate)
			{
				this.activated = true;
				this.nextPlayTime = Time.time + Random.Range(this.randomRetriggerDelaySecs.x, this.randomRetriggerDelaySecs.y);
			}
			Transform[] array = this.playPositions;
			for (int i = 0; i < array.Length; i++)
			{
				if (array[i] == null)
				{
					Debug.LogWarning("[AmbienceEmitter] Invalid play positions in " + base.name);
					this.playPositions = new Transform[0];
					return;
				}
			}
		}

		// Token: 0x06000AE4 RID: 2788 RVA: 0x000403A5 File Offset: 0x0003E5A5
		private void Update()
		{
			if (this.activated && (this.playingIdx == -1 || this.autoRetrigger) && Time.time >= this.nextPlayTime)
			{
				this.Play();
				if (!this.autoRetrigger)
				{
					this.activated = false;
				}
			}
		}

		// Token: 0x06000AE5 RID: 2789 RVA: 0x000403E2 File Offset: 0x0003E5E2
		public void OnTriggerEnter(Collider col)
		{
			this.activated = !this.activated;
		}

		// Token: 0x06000AE6 RID: 2790 RVA: 0x000403F4 File Offset: 0x0003E5F4
		public void Play()
		{
			Transform transform = base.transform;
			if (this.playPositions.Length != 0)
			{
				int num = Random.Range(0, this.playPositions.Length);
				while (this.playPositions.Length > 1 && num == this.lastPosIdx)
				{
					num = Random.Range(0, this.playPositions.Length);
				}
				transform = this.playPositions[num];
				this.lastPosIdx = num;
			}
			this.playingIdx = this.ambientSounds[Random.Range(0, this.ambientSounds.Length)].PlaySoundAt(transform.position, 0f, 1f, 1f);
			if (this.playingIdx != -1)
			{
				AudioManager.FadeInSound(this.playingIdx, this.fadeTime);
				this.nextPlayTime = Time.time + Random.Range(this.randomRetriggerDelaySecs.x, this.randomRetriggerDelaySecs.y);
			}
		}

		// Token: 0x06000AE7 RID: 2791 RVA: 0x000404CB File Offset: 0x0003E6CB
		public void EnableEmitter(bool enable)
		{
			this.activated = enable;
			if (enable)
			{
				this.Play();
				return;
			}
			if (this.playingIdx != -1)
			{
				AudioManager.FadeOutSound(this.playingIdx, this.fadeTime);
			}
		}

		// Token: 0x04000C26 RID: 3110
		public SoundFXRef[] ambientSounds = new SoundFXRef[0];

		// Token: 0x04000C27 RID: 3111
		public bool autoActivate = true;

		// Token: 0x04000C28 RID: 3112
		[Tooltip("Automatically play the sound randomly again when checked.  Should be OFF for looping sounds")]
		public bool autoRetrigger = true;

		// Token: 0x04000C29 RID: 3113
		[MinMax(2f, 4f, 0.1f, 10f)]
		public Vector2 randomRetriggerDelaySecs = new Vector2(2f, 4f);

		// Token: 0x04000C2A RID: 3114
		[Tooltip("If defined, the sounds will randomly play from these transform positions, otherwise the sound will play from this transform")]
		public Transform[] playPositions = new Transform[0];

		// Token: 0x04000C2B RID: 3115
		private bool activated;

		// Token: 0x04000C2C RID: 3116
		private int playingIdx = -1;

		// Token: 0x04000C2D RID: 3117
		private float nextPlayTime;

		// Token: 0x04000C2E RID: 3118
		private float fadeTime = 0.25f;

		// Token: 0x04000C2F RID: 3119
		private int lastPosIdx = -1;
	}
}
