﻿using System;

// Token: 0x020000E3 RID: 227
public struct ovrAvatarRenderPart_ProjectorRender
{
	// Token: 0x04000854 RID: 2132
	public ovrAvatarTransform localTransform;

	// Token: 0x04000855 RID: 2133
	public uint componentIndex;

	// Token: 0x04000856 RID: 2134
	public uint renderPartIndex;

	// Token: 0x04000857 RID: 2135
	public ovrAvatarMaterialState materialState;
}
