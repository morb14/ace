﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

// Token: 0x0200007E RID: 126
[DisallowMultipleComponent]
public class Outline : MonoBehaviour
{
	// Token: 0x17000002 RID: 2
	// (get) Token: 0x06000486 RID: 1158 RVA: 0x0001E407 File Offset: 0x0001C607
	// (set) Token: 0x06000487 RID: 1159 RVA: 0x0001E40F File Offset: 0x0001C60F
	public Outline.Mode OutlineMode
	{
		get
		{
			return this.outlineMode;
		}
		set
		{
			this.outlineMode = value;
			this.needsUpdate = true;
		}
	}

	// Token: 0x17000003 RID: 3
	// (get) Token: 0x06000488 RID: 1160 RVA: 0x0001E41F File Offset: 0x0001C61F
	// (set) Token: 0x06000489 RID: 1161 RVA: 0x0001E427 File Offset: 0x0001C627
	public Color OutlineColor
	{
		get
		{
			return this.outlineColor;
		}
		set
		{
			this.outlineColor = value;
			this.needsUpdate = true;
		}
	}

	// Token: 0x17000004 RID: 4
	// (get) Token: 0x0600048A RID: 1162 RVA: 0x0001E437 File Offset: 0x0001C637
	// (set) Token: 0x0600048B RID: 1163 RVA: 0x0001E43F File Offset: 0x0001C63F
	public float OutlineWidth
	{
		get
		{
			return this.outlineWidth;
		}
		set
		{
			this.outlineWidth = value;
			this.needsUpdate = true;
		}
	}

	// Token: 0x0600048C RID: 1164 RVA: 0x0001E450 File Offset: 0x0001C650
	private void Awake()
	{
		this.renderers = base.GetComponentsInChildren<Renderer>();
		this.outlineMaskMaterial = Object.Instantiate<Material>(Resources.Load<Material>("Materials/OutlineMask"));
		this.outlineFillMaterial = Object.Instantiate<Material>(Resources.Load<Material>("Materials/OutlineFill"));
		this.outlineMaskMaterial.name = "OutlineMask (Instance)";
		this.outlineFillMaterial.name = "OutlineFill (Instance)";
		this.LoadSmoothNormals();
		this.needsUpdate = true;
	}

	// Token: 0x0600048D RID: 1165 RVA: 0x0001E4C0 File Offset: 0x0001C6C0
	private void OnEnable()
	{
		foreach (Renderer renderer in this.renderers)
		{
			List<Material> list = renderer.sharedMaterials.ToList<Material>();
			list.Add(this.outlineMaskMaterial);
			list.Add(this.outlineFillMaterial);
			renderer.materials = list.ToArray();
		}
	}

	// Token: 0x0600048E RID: 1166 RVA: 0x0001E514 File Offset: 0x0001C714
	private void OnValidate()
	{
		this.needsUpdate = true;
		if ((!this.precomputeOutline && this.bakeKeys.Count != 0) || this.bakeKeys.Count != this.bakeValues.Count)
		{
			this.bakeKeys.Clear();
			this.bakeValues.Clear();
		}
		if (this.precomputeOutline && this.bakeKeys.Count == 0)
		{
			this.Bake();
		}
	}

	// Token: 0x0600048F RID: 1167 RVA: 0x0001E586 File Offset: 0x0001C786
	private void Update()
	{
		if (this.needsUpdate)
		{
			this.needsUpdate = false;
			this.UpdateMaterialProperties();
		}
	}

	// Token: 0x06000490 RID: 1168 RVA: 0x0001E5A0 File Offset: 0x0001C7A0
	private void OnDisable()
	{
		foreach (Renderer renderer in this.renderers)
		{
			List<Material> list = renderer.sharedMaterials.ToList<Material>();
			list.Remove(this.outlineMaskMaterial);
			list.Remove(this.outlineFillMaterial);
			renderer.materials = list.ToArray();
		}
	}

	// Token: 0x06000491 RID: 1169 RVA: 0x0001E5F6 File Offset: 0x0001C7F6
	private void OnDestroy()
	{
		Object.Destroy(this.outlineMaskMaterial);
		Object.Destroy(this.outlineFillMaterial);
	}

	// Token: 0x06000492 RID: 1170 RVA: 0x0001E610 File Offset: 0x0001C810
	private void Bake()
	{
		HashSet<Mesh> hashSet = new HashSet<Mesh>();
		foreach (MeshFilter meshFilter in base.GetComponentsInChildren<MeshFilter>())
		{
			if (hashSet.Add(meshFilter.sharedMesh))
			{
				List<Vector3> data = this.SmoothNormals(meshFilter.sharedMesh);
				this.bakeKeys.Add(meshFilter.sharedMesh);
				this.bakeValues.Add(new Outline.ListVector3
				{
					data = data
				});
			}
		}
	}

	// Token: 0x06000493 RID: 1171 RVA: 0x0001E684 File Offset: 0x0001C884
	private void LoadSmoothNormals()
	{
		foreach (MeshFilter meshFilter in base.GetComponentsInChildren<MeshFilter>())
		{
			if (Outline.registeredMeshes.Add(meshFilter.sharedMesh))
			{
				int num = this.bakeKeys.IndexOf(meshFilter.sharedMesh);
				List<Vector3> uvs = (num >= 0) ? this.bakeValues[num].data : this.SmoothNormals(meshFilter.sharedMesh);
				meshFilter.sharedMesh.SetUVs(3, uvs);
			}
		}
		foreach (SkinnedMeshRenderer skinnedMeshRenderer in base.GetComponentsInChildren<SkinnedMeshRenderer>())
		{
			if (Outline.registeredMeshes.Add(skinnedMeshRenderer.sharedMesh))
			{
				skinnedMeshRenderer.sharedMesh.uv4 = new Vector2[skinnedMeshRenderer.sharedMesh.vertexCount];
			}
		}
	}

	// Token: 0x06000494 RID: 1172 RVA: 0x0001E750 File Offset: 0x0001C950
	private List<Vector3> SmoothNormals(Mesh mesh)
	{
		IEnumerable<IGrouping<Vector3, KeyValuePair<Vector3, int>>> enumerable = from pair in mesh.vertices.Select((Vector3 vertex, int index) => new KeyValuePair<Vector3, int>(vertex, index))
		group pair by pair.Key;
		List<Vector3> list = new List<Vector3>(mesh.normals);
		foreach (IGrouping<Vector3, KeyValuePair<Vector3, int>> grouping in enumerable)
		{
			if (grouping.Count<KeyValuePair<Vector3, int>>() != 1)
			{
				Vector3 vector = Vector3.zero;
				foreach (KeyValuePair<Vector3, int> keyValuePair in grouping)
				{
					vector += mesh.normals[keyValuePair.Value];
				}
				vector.Normalize();
				foreach (KeyValuePair<Vector3, int> keyValuePair2 in grouping)
				{
					list[keyValuePair2.Value] = vector;
				}
			}
		}
		return list;
	}

	// Token: 0x06000495 RID: 1173 RVA: 0x0001E8A0 File Offset: 0x0001CAA0
	private void UpdateMaterialProperties()
	{
		this.outlineFillMaterial.SetColor("_OutlineColor", this.outlineColor);
		switch (this.outlineMode)
		{
		case Outline.Mode.OutlineAll:
			this.outlineMaskMaterial.SetFloat("_ZTest", 8f);
			this.outlineFillMaterial.SetFloat("_ZTest", 8f);
			this.outlineFillMaterial.SetFloat("_OutlineWidth", this.outlineWidth);
			return;
		case Outline.Mode.OutlineVisible:
			this.outlineMaskMaterial.SetFloat("_ZTest", 8f);
			this.outlineFillMaterial.SetFloat("_ZTest", 4f);
			this.outlineFillMaterial.SetFloat("_OutlineWidth", this.outlineWidth);
			return;
		case Outline.Mode.OutlineHidden:
			this.outlineMaskMaterial.SetFloat("_ZTest", 8f);
			this.outlineFillMaterial.SetFloat("_ZTest", 5f);
			this.outlineFillMaterial.SetFloat("_OutlineWidth", this.outlineWidth);
			return;
		case Outline.Mode.OutlineAndSilhouette:
			this.outlineMaskMaterial.SetFloat("_ZTest", 4f);
			this.outlineFillMaterial.SetFloat("_ZTest", 8f);
			this.outlineFillMaterial.SetFloat("_OutlineWidth", this.outlineWidth);
			return;
		case Outline.Mode.SilhouetteOnly:
			this.outlineMaskMaterial.SetFloat("_ZTest", 4f);
			this.outlineFillMaterial.SetFloat("_ZTest", 5f);
			this.outlineFillMaterial.SetFloat("_OutlineWidth", 0f);
			return;
		default:
			return;
		}
	}

	// Token: 0x040005C8 RID: 1480
	private static HashSet<Mesh> registeredMeshes = new HashSet<Mesh>();

	// Token: 0x040005C9 RID: 1481
	[SerializeField]
	private Outline.Mode outlineMode;

	// Token: 0x040005CA RID: 1482
	[SerializeField]
	private Color outlineColor = Color.white;

	// Token: 0x040005CB RID: 1483
	[SerializeField]
	[Range(0f, 10f)]
	private float outlineWidth = 2f;

	// Token: 0x040005CC RID: 1484
	[Header("Optional")]
	[SerializeField]
	[Tooltip("Precompute enabled: Per-vertex calculations are performed in the editor and serialized with the object. Precompute disabled: Per-vertex calculations are performed at runtime in Awake(). This may cause a pause for large meshes.")]
	private bool precomputeOutline;

	// Token: 0x040005CD RID: 1485
	[SerializeField]
	[HideInInspector]
	private List<Mesh> bakeKeys = new List<Mesh>();

	// Token: 0x040005CE RID: 1486
	[SerializeField]
	[HideInInspector]
	private List<Outline.ListVector3> bakeValues = new List<Outline.ListVector3>();

	// Token: 0x040005CF RID: 1487
	private Renderer[] renderers;

	// Token: 0x040005D0 RID: 1488
	private Material outlineMaskMaterial;

	// Token: 0x040005D1 RID: 1489
	private Material outlineFillMaterial;

	// Token: 0x040005D2 RID: 1490
	private bool needsUpdate;

	// Token: 0x020001DC RID: 476
	public enum Mode
	{
		// Token: 0x04000E07 RID: 3591
		OutlineAll,
		// Token: 0x04000E08 RID: 3592
		OutlineVisible,
		// Token: 0x04000E09 RID: 3593
		OutlineHidden,
		// Token: 0x04000E0A RID: 3594
		OutlineAndSilhouette,
		// Token: 0x04000E0B RID: 3595
		SilhouetteOnly
	}

	// Token: 0x020001DD RID: 477
	[Serializable]
	private class ListVector3
	{
		// Token: 0x04000E0C RID: 3596
		public List<Vector3> data;
	}
}
