﻿using System;
using UnityEngine;

// Token: 0x02000013 RID: 19
public class CFX_Demo_RotateCamera : MonoBehaviour
{
	// Token: 0x06000052 RID: 82 RVA: 0x0000363E File Offset: 0x0000183E
	private void Update()
	{
		if (CFX_Demo_RotateCamera.rotating)
		{
			base.transform.RotateAround(this.rotationCenter.position, Vector3.up, this.speed * Time.deltaTime);
		}
	}

	// Token: 0x0400003F RID: 63
	public static bool rotating = true;

	// Token: 0x04000040 RID: 64
	public float speed = 30f;

	// Token: 0x04000041 RID: 65
	public Transform rotationCenter;
}
