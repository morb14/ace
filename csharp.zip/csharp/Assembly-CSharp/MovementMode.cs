﻿using System;

// Token: 0x02000085 RID: 133
public enum MovementMode
{
	// Token: 0x040005F1 RID: 1521
	Glide,
	// Token: 0x040005F2 RID: 1522
	Teleport
}
