﻿using System;
using System.Collections.Generic;
using Oculus.Avatar;
using UnityEngine;

// Token: 0x020000FB RID: 251
public class OvrAvatarSDKManager : MonoBehaviour
{
	// Token: 0x1700000D RID: 13
	// (get) Token: 0x06000649 RID: 1609 RVA: 0x000292A8 File Offset: 0x000274A8
	public static OvrAvatarSDKManager Instance
	{
		get
		{
			if (OvrAvatarSDKManager._instance == null)
			{
				OvrAvatarSDKManager._instance = Object.FindObjectOfType<OvrAvatarSDKManager>();
				if (OvrAvatarSDKManager._instance == null)
				{
					GameObject gameObject = new GameObject("OvrAvatarSDKManager");
					OvrAvatarSDKManager._instance = gameObject.AddComponent<OvrAvatarSDKManager>();
					OvrAvatarSDKManager._instance.textureCopyManager = gameObject.AddComponent<OvrAvatarTextureCopyManager>();
					OvrAvatarSDKManager._instance.initialized = OvrAvatarSDKManager._instance.Initialize();
				}
			}
			if (!OvrAvatarSDKManager._instance.initialized)
			{
				return null;
			}
			return OvrAvatarSDKManager._instance;
		}
	}

	// Token: 0x0600064A RID: 1610 RVA: 0x00029328 File Offset: 0x00027528
	private bool Initialize()
	{
		CAPI.Initialize();
		string text = this.GetAppId();
		if (text == "")
		{
			text = "0";
		}
		CAPI.ovrAvatar_InitializeAndroidUnity(text);
		this.specificationCallbacks = new Dictionary<ulong, HashSet<specificationCallback>>();
		this.assetLoadedCallbacks = new Dictionary<ulong, HashSet<assetLoadedCallback>>();
		this.combinedMeshLoadedCallbacks = new Dictionary<IntPtr, combinedMeshLoadedCallback>();
		this.assetCache = new Dictionary<ulong, OvrAvatarAsset>();
		this.avatarSpecificationQueue = new Queue<OvrAvatarSDKManager.AvatarSpecRequestParams>();
		this.loadingAvatars = new List<int>();
		CAPI.ovrAvatar_SetLoggingLevel(this.LoggingLevel);
		CAPI.ovrAvatar_RegisterLoggingCallback(new CAPI.LoggingDelegate(CAPI.LoggingCallback));
		return true;
	}

	// Token: 0x0600064B RID: 1611 RVA: 0x000293B9 File Offset: 0x000275B9
	private void OnDestroy()
	{
		CAPI.Shutdown();
		CAPI.ovrAvatar_RegisterLoggingCallback(null);
		CAPI.ovrAvatar_Shutdown();
	}

	// Token: 0x0600064C RID: 1612 RVA: 0x000293CC File Offset: 0x000275CC
	private void Update()
	{
		if (OvrAvatarSDKManager.Instance == null)
		{
			return;
		}
		if (this.avatarSpecificationQueue.Count > 0 && (this.avatarSpecRequestAvailable || Time.time - this.lastDispatchedAvatarSpecRequestTime >= 5f))
		{
			this.avatarSpecRequestAvailable = false;
			OvrAvatarSDKManager.AvatarSpecRequestParams avatarSpecRequest = this.avatarSpecificationQueue.Dequeue();
			this.DispatchAvatarSpecificationRequest(avatarSpecRequest);
			this.lastDispatchedAvatarSpecRequestTime = Time.time;
		}
		IntPtr intPtr = CAPI.ovrAvatarMessage_Pop();
		if (intPtr == IntPtr.Zero)
		{
			return;
		}
		ovrAvatarMessageType ovrAvatarMessageType = CAPI.ovrAvatarMessage_GetType(intPtr);
		if (ovrAvatarMessageType != ovrAvatarMessageType.AvatarSpecification)
		{
			if (ovrAvatarMessageType != ovrAvatarMessageType.AssetLoaded)
			{
				throw new NotImplementedException("Unhandled ovrAvatarMessageType: " + ovrAvatarMessageType);
			}
			ovrAvatarMessage_AssetLoaded ovrAvatarMessage_AssetLoaded = CAPI.ovrAvatarMessage_GetAssetLoaded(intPtr);
			IntPtr asset = ovrAvatarMessage_AssetLoaded.asset;
			ulong assetID = ovrAvatarMessage_AssetLoaded.assetID;
			ovrAvatarAssetType ovrAvatarAssetType = CAPI.ovrAvatarAsset_GetType(asset);
			OvrAvatarAsset ovrAvatarAsset = null;
			IntPtr key = IntPtr.Zero;
			switch (ovrAvatarAssetType)
			{
			case ovrAvatarAssetType.Mesh:
				ovrAvatarAsset = new OvrAvatarAssetMesh(assetID, asset, ovrAvatarAssetType.Mesh);
				goto IL_12F;
			case ovrAvatarAssetType.Texture:
				ovrAvatarAsset = new OvrAvatarAssetTexture(assetID, asset);
				goto IL_12F;
			case ovrAvatarAssetType.Material:
				ovrAvatarAsset = new OvrAvatarAssetMaterial(assetID, asset);
				goto IL_12F;
			case ovrAvatarAssetType.CombinedMesh:
				key = CAPI.ovrAvatarAsset_GetAvatar(asset);
				ovrAvatarAsset = new OvrAvatarAssetMesh(assetID, asset, ovrAvatarAssetType.CombinedMesh);
				goto IL_12F;
			case ovrAvatarAssetType.FailedLoad:
				goto IL_12F;
			}
			throw new NotImplementedException(string.Format("Unsupported asset type format {0}", ovrAvatarAssetType.ToString()));
			IL_12F:
			HashSet<assetLoadedCallback> hashSet;
			if (ovrAvatarAssetType == ovrAvatarAssetType.CombinedMesh)
			{
				if (!this.assetCache.ContainsKey(assetID))
				{
					this.assetCache.Add(assetID, ovrAvatarAsset);
				}
				combinedMeshLoadedCallback combinedMeshLoadedCallback;
				if (this.combinedMeshLoadedCallbacks.TryGetValue(key, out combinedMeshLoadedCallback))
				{
					combinedMeshLoadedCallback(asset);
					this.combinedMeshLoadedCallbacks.Remove(key);
				}
			}
			else if (ovrAvatarAsset != null && this.assetLoadedCallbacks.TryGetValue(ovrAvatarMessage_AssetLoaded.assetID, out hashSet))
			{
				this.assetCache.Add(assetID, ovrAvatarAsset);
				foreach (assetLoadedCallback assetLoadedCallback in hashSet)
				{
					assetLoadedCallback(ovrAvatarAsset);
				}
				this.assetLoadedCallbacks.Remove(ovrAvatarMessage_AssetLoaded.assetID);
			}
		}
		else
		{
			this.avatarSpecRequestAvailable = true;
			ovrAvatarMessage_AvatarSpecification ovrAvatarMessage_AvatarSpecification = CAPI.ovrAvatarMessage_GetAvatarSpecification(intPtr);
			HashSet<specificationCallback> hashSet2;
			if (this.specificationCallbacks.TryGetValue(ovrAvatarMessage_AvatarSpecification.oculusUserID, out hashSet2))
			{
				foreach (specificationCallback specificationCallback in hashSet2)
				{
					specificationCallback(ovrAvatarMessage_AvatarSpecification.avatarSpec);
				}
				this.specificationCallbacks.Remove(ovrAvatarMessage_AvatarSpecification.oculusUserID);
			}
		}
		CAPI.ovrAvatarMessage_Free(intPtr);
	}

	// Token: 0x0600064D RID: 1613 RVA: 0x0002967C File Offset: 0x0002787C
	public bool IsAvatarSpecWaiting()
	{
		return this.avatarSpecificationQueue.Count > 0;
	}

	// Token: 0x0600064E RID: 1614 RVA: 0x0002968C File Offset: 0x0002788C
	public bool IsAvatarLoading()
	{
		return this.loadingAvatars.Count > 0;
	}

	// Token: 0x0600064F RID: 1615 RVA: 0x0002969C File Offset: 0x0002789C
	public void AddLoadingAvatar(int gameobjectID)
	{
		this.loadingAvatars.Add(gameobjectID);
	}

	// Token: 0x06000650 RID: 1616 RVA: 0x000296AA File Offset: 0x000278AA
	public void RemoveLoadingAvatar(int gameobjectID)
	{
		this.loadingAvatars.Remove(gameobjectID);
	}

	// Token: 0x06000651 RID: 1617 RVA: 0x000296B9 File Offset: 0x000278B9
	public void RequestAvatarSpecification(OvrAvatarSDKManager.AvatarSpecRequestParams avatarSpecRequest)
	{
		this.avatarSpecificationQueue.Enqueue(avatarSpecRequest);
	}

	// Token: 0x06000652 RID: 1618 RVA: 0x000296C8 File Offset: 0x000278C8
	private void DispatchAvatarSpecificationRequest(OvrAvatarSDKManager.AvatarSpecRequestParams avatarSpecRequest)
	{
		this.textureCopyManager.CheckFallbackTextureSet(avatarSpecRequest._lod);
		CAPI.ovrAvatar_SetForceASTCTextures(avatarSpecRequest._forceMobileTextureFormat);
		HashSet<specificationCallback> hashSet;
		if (!this.specificationCallbacks.TryGetValue(avatarSpecRequest._userId, out hashSet))
		{
			hashSet = new HashSet<specificationCallback>();
			this.specificationCallbacks.Add(avatarSpecRequest._userId, hashSet);
			IntPtr specificationRequest = CAPI.ovrAvatarSpecificationRequest_Create(avatarSpecRequest._userId);
			CAPI.ovrAvatarSpecificationRequest_SetLookAndFeelVersion(specificationRequest, avatarSpecRequest._lookVersion);
			CAPI.ovrAvatarSpecificationRequest_SetFallbackLookAndFeelVersion(specificationRequest, avatarSpecRequest._fallbackVersion);
			CAPI.ovrAvatarSpecificationRequest_SetLevelOfDetail(specificationRequest, avatarSpecRequest._lod);
			CAPI.ovrAvatarSpecificationRequest_SetCombineMeshes(specificationRequest, avatarSpecRequest._useCombinedMesh);
			CAPI.ovrAvatarSpecificationRequest_SetExpressiveFlag(specificationRequest, avatarSpecRequest._enableExpressive);
			CAPI.ovrAvatar_RequestAvatarSpecificationFromSpecRequest(specificationRequest);
			CAPI.ovrAvatarSpecificationRequest_Destroy(specificationRequest);
		}
		hashSet.Add(avatarSpecRequest._callback);
	}

	// Token: 0x06000653 RID: 1619 RVA: 0x00029780 File Offset: 0x00027980
	public void BeginLoadingAsset(ulong assetId, ovrAvatarAssetLevelOfDetail lod, assetLoadedCallback callback)
	{
		HashSet<assetLoadedCallback> hashSet;
		if (!this.assetLoadedCallbacks.TryGetValue(assetId, out hashSet))
		{
			hashSet = new HashSet<assetLoadedCallback>();
			this.assetLoadedCallbacks.Add(assetId, hashSet);
		}
		CAPI.ovrAvatarAsset_BeginLoadingLOD(assetId, lod);
		hashSet.Add(callback);
	}

	// Token: 0x06000654 RID: 1620 RVA: 0x000297C0 File Offset: 0x000279C0
	public void RegisterCombinedMeshCallback(IntPtr sdkAvatar, combinedMeshLoadedCallback callback)
	{
		combinedMeshLoadedCallback combinedMeshLoadedCallback;
		if (!this.combinedMeshLoadedCallbacks.TryGetValue(sdkAvatar, out combinedMeshLoadedCallback))
		{
			this.combinedMeshLoadedCallbacks.Add(sdkAvatar, callback);
			return;
		}
		throw new Exception("Adding second combind mesh callback for same avatar");
	}

	// Token: 0x06000655 RID: 1621 RVA: 0x000297F8 File Offset: 0x000279F8
	public OvrAvatarAsset GetAsset(ulong assetId)
	{
		OvrAvatarAsset result;
		if (this.assetCache.TryGetValue(assetId, out result))
		{
			return result;
		}
		return null;
	}

	// Token: 0x06000656 RID: 1622 RVA: 0x00029818 File Offset: 0x00027A18
	public void DeleteAssetFromCache(ulong assetId)
	{
		if (this.assetCache.ContainsKey(assetId))
		{
			this.assetCache.Remove(assetId);
		}
	}

	// Token: 0x06000657 RID: 1623 RVA: 0x00029835 File Offset: 0x00027A35
	public string GetAppId()
	{
		if (Application.platform != RuntimePlatform.Android)
		{
			return OvrAvatarSettings.AppID;
		}
		return OvrAvatarSettings.MobileAppID;
	}

	// Token: 0x06000658 RID: 1624 RVA: 0x0002984B File Offset: 0x00027A4B
	public OvrAvatarTextureCopyManager GetTextureCopyManager()
	{
		if (this.textureCopyManager != null)
		{
			return this.textureCopyManager;
		}
		return null;
	}

	// Token: 0x040008A6 RID: 2214
	private static OvrAvatarSDKManager _instance;

	// Token: 0x040008A7 RID: 2215
	private bool initialized;

	// Token: 0x040008A8 RID: 2216
	private Dictionary<ulong, HashSet<specificationCallback>> specificationCallbacks;

	// Token: 0x040008A9 RID: 2217
	private Dictionary<ulong, HashSet<assetLoadedCallback>> assetLoadedCallbacks;

	// Token: 0x040008AA RID: 2218
	private Dictionary<IntPtr, combinedMeshLoadedCallback> combinedMeshLoadedCallbacks;

	// Token: 0x040008AB RID: 2219
	private Dictionary<ulong, OvrAvatarAsset> assetCache;

	// Token: 0x040008AC RID: 2220
	private OvrAvatarTextureCopyManager textureCopyManager;

	// Token: 0x040008AD RID: 2221
	public ovrAvatarLogLevel LoggingLevel = ovrAvatarLogLevel.Info;

	// Token: 0x040008AE RID: 2222
	private Queue<OvrAvatarSDKManager.AvatarSpecRequestParams> avatarSpecificationQueue;

	// Token: 0x040008AF RID: 2223
	private List<int> loadingAvatars;

	// Token: 0x040008B0 RID: 2224
	private bool avatarSpecRequestAvailable = true;

	// Token: 0x040008B1 RID: 2225
	private float lastDispatchedAvatarSpecRequestTime;

	// Token: 0x040008B2 RID: 2226
	private const float AVATAR_SPEC_REQUEST_TIMEOUT = 5f;

	// Token: 0x020001F5 RID: 501
	public struct AvatarSpecRequestParams
	{
		// Token: 0x06000C42 RID: 3138 RVA: 0x0004464F File Offset: 0x0004284F
		public AvatarSpecRequestParams(ulong userId, specificationCallback callback, bool useCombinedMesh, ovrAvatarAssetLevelOfDetail lod, bool forceMobileTextureFormat, ovrAvatarLookAndFeelVersion lookVersion, ovrAvatarLookAndFeelVersion fallbackVersion, bool enableExpressive)
		{
			this._userId = userId;
			this._callback = callback;
			this._useCombinedMesh = useCombinedMesh;
			this._lod = lod;
			this._forceMobileTextureFormat = forceMobileTextureFormat;
			this._lookVersion = lookVersion;
			this._fallbackVersion = fallbackVersion;
			this._enableExpressive = enableExpressive;
		}

		// Token: 0x04000E77 RID: 3703
		public ulong _userId;

		// Token: 0x04000E78 RID: 3704
		public specificationCallback _callback;

		// Token: 0x04000E79 RID: 3705
		public bool _useCombinedMesh;

		// Token: 0x04000E7A RID: 3706
		public ovrAvatarAssetLevelOfDetail _lod;

		// Token: 0x04000E7B RID: 3707
		public bool _forceMobileTextureFormat;

		// Token: 0x04000E7C RID: 3708
		public ovrAvatarLookAndFeelVersion _lookVersion;

		// Token: 0x04000E7D RID: 3709
		public ovrAvatarLookAndFeelVersion _fallbackVersion;

		// Token: 0x04000E7E RID: 3710
		public bool _enableExpressive;
	}
}
