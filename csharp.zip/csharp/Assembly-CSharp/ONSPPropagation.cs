﻿using System;
using System.Runtime.InteropServices;
using Oculus.Spatializer.Propagation;
using UnityEngine;

// Token: 0x02000143 RID: 323
internal class ONSPPropagation
{
	// Token: 0x17000035 RID: 53
	// (get) Token: 0x0600087D RID: 2173 RVA: 0x0003573E File Offset: 0x0003393E
	public static ONSPPropagation.PropagationInterface Interface
	{
		get
		{
			if (ONSPPropagation.CachedInterface == null)
			{
				ONSPPropagation.CachedInterface = ONSPPropagation.FindInterface();
			}
			return ONSPPropagation.CachedInterface;
		}
	}

	// Token: 0x0600087E RID: 2174 RVA: 0x00035758 File Offset: 0x00033958
	private static ONSPPropagation.PropagationInterface FindInterface()
	{
		try
		{
			IntPtr intPtr;
			ONSPPropagation.WwisePluginInterface.ovrAudio_GetPluginContext(out intPtr, 12U);
			Debug.Log("Propagation initialized with Wwise Oculus Spatializer plugin");
			return new ONSPPropagation.WwisePluginInterface();
		}
		catch (DllNotFoundException)
		{
		}
		try
		{
			IntPtr intPtr;
			ONSPPropagation.FMODPluginInterface.ovrAudio_GetPluginContext(out intPtr, 5U);
			Debug.Log("Propagation initialized with FMOD Oculus Spatializer plugin");
			return new ONSPPropagation.FMODPluginInterface();
		}
		catch (DllNotFoundException)
		{
		}
		Debug.Log("Propagation initialized with Unity Oculus Spatializer plugin");
		return new ONSPPropagation.UnityNativeInterface();
	}

	// Token: 0x04000A6F RID: 2671
	private static ONSPPropagation.PropagationInterface CachedInterface;

	// Token: 0x02000230 RID: 560
	public enum ovrAudioScalarType : uint
	{
		// Token: 0x04000F6F RID: 3951
		Int8,
		// Token: 0x04000F70 RID: 3952
		UInt8,
		// Token: 0x04000F71 RID: 3953
		Int16,
		// Token: 0x04000F72 RID: 3954
		UInt16,
		// Token: 0x04000F73 RID: 3955
		Int32,
		// Token: 0x04000F74 RID: 3956
		UInt32,
		// Token: 0x04000F75 RID: 3957
		Int64,
		// Token: 0x04000F76 RID: 3958
		UInt64,
		// Token: 0x04000F77 RID: 3959
		Float16,
		// Token: 0x04000F78 RID: 3960
		Float32,
		// Token: 0x04000F79 RID: 3961
		Float64
	}

	// Token: 0x02000231 RID: 561
	public class ClientType
	{
		// Token: 0x04000F7A RID: 3962
		public const uint OVRA_CLIENT_TYPE_NATIVE = 0U;

		// Token: 0x04000F7B RID: 3963
		public const uint OVRA_CLIENT_TYPE_WWISE_2016 = 1U;

		// Token: 0x04000F7C RID: 3964
		public const uint OVRA_CLIENT_TYPE_WWISE_2017_1 = 2U;

		// Token: 0x04000F7D RID: 3965
		public const uint OVRA_CLIENT_TYPE_WWISE_2017_2 = 3U;

		// Token: 0x04000F7E RID: 3966
		public const uint OVRA_CLIENT_TYPE_WWISE_2018_1 = 4U;

		// Token: 0x04000F7F RID: 3967
		public const uint OVRA_CLIENT_TYPE_FMOD = 5U;

		// Token: 0x04000F80 RID: 3968
		public const uint OVRA_CLIENT_TYPE_UNITY = 6U;

		// Token: 0x04000F81 RID: 3969
		public const uint OVRA_CLIENT_TYPE_UE4 = 7U;

		// Token: 0x04000F82 RID: 3970
		public const uint OVRA_CLIENT_TYPE_VST = 8U;

		// Token: 0x04000F83 RID: 3971
		public const uint OVRA_CLIENT_TYPE_AAX = 9U;

		// Token: 0x04000F84 RID: 3972
		public const uint OVRA_CLIENT_TYPE_TEST = 10U;

		// Token: 0x04000F85 RID: 3973
		public const uint OVRA_CLIENT_TYPE_OTHER = 11U;

		// Token: 0x04000F86 RID: 3974
		public const uint OVRA_CLIENT_TYPE_WWISE_UNKNOWN = 12U;

		// Token: 0x04000F87 RID: 3975
		public const uint OVRA_CLIENT_TYPE_WWISE_2019_1 = 13U;
	}

	// Token: 0x02000232 RID: 562
	public interface PropagationInterface
	{
		// Token: 0x06000CCF RID: 3279
		int SetPropagationQuality(float quality);

		// Token: 0x06000CD0 RID: 3280
		int SetPropagationThreadAffinity(ulong cpuMask);

		// Token: 0x06000CD1 RID: 3281
		int CreateAudioGeometry(out IntPtr geometry);

		// Token: 0x06000CD2 RID: 3282
		int DestroyAudioGeometry(IntPtr geometry);

		// Token: 0x06000CD3 RID: 3283
		int AudioGeometryUploadMeshArrays(IntPtr geometry, float[] vertices, int vertexCount, int[] indices, int indexCount, MeshGroup[] groups, int groupCount);

		// Token: 0x06000CD4 RID: 3284
		int AudioGeometrySetTransform(IntPtr geometry, float[] matrix4x4);

		// Token: 0x06000CD5 RID: 3285
		int AudioGeometryGetTransform(IntPtr geometry, out float[] matrix4x4);

		// Token: 0x06000CD6 RID: 3286
		int AudioGeometryWriteMeshFile(IntPtr geometry, string filePath);

		// Token: 0x06000CD7 RID: 3287
		int AudioGeometryReadMeshFile(IntPtr geometry, string filePath);

		// Token: 0x06000CD8 RID: 3288
		int AudioGeometryWriteMeshFileObj(IntPtr geometry, string filePath);

		// Token: 0x06000CD9 RID: 3289
		int AudioMaterialGetFrequency(IntPtr material, MaterialProperty property, float frequency, out float value);

		// Token: 0x06000CDA RID: 3290
		int CreateAudioMaterial(out IntPtr material);

		// Token: 0x06000CDB RID: 3291
		int DestroyAudioMaterial(IntPtr material);

		// Token: 0x06000CDC RID: 3292
		int AudioMaterialSetFrequency(IntPtr material, MaterialProperty property, float frequency, float value);

		// Token: 0x06000CDD RID: 3293
		int AudioMaterialReset(IntPtr material, MaterialProperty property);
	}

	// Token: 0x02000233 RID: 563
	public class UnityNativeInterface : ONSPPropagation.PropagationInterface
	{
		// Token: 0x170000EA RID: 234
		// (get) Token: 0x06000CDE RID: 3294 RVA: 0x000455BC File Offset: 0x000437BC
		private IntPtr context
		{
			get
			{
				if (this.context_ == IntPtr.Zero)
				{
					ONSPPropagation.UnityNativeInterface.ovrAudio_GetPluginContext(out this.context_, 6U);
				}
				return this.context_;
			}
		}

		// Token: 0x06000CDF RID: 3295
		[DllImport("AudioPluginOculusSpatializer")]
		public static extern int ovrAudio_GetPluginContext(out IntPtr context, uint clientType);

		// Token: 0x06000CE0 RID: 3296
		[DllImport("AudioPluginOculusSpatializer")]
		private static extern int ovrAudio_SetPropagationQuality(IntPtr context, float quality);

		// Token: 0x06000CE1 RID: 3297 RVA: 0x000455E3 File Offset: 0x000437E3
		public int SetPropagationQuality(float quality)
		{
			return ONSPPropagation.UnityNativeInterface.ovrAudio_SetPropagationQuality(this.context, quality);
		}

		// Token: 0x06000CE2 RID: 3298
		[DllImport("AudioPluginOculusSpatializer")]
		private static extern int ovrAudio_SetPropagationThreadAffinity(IntPtr context, ulong cpuMask);

		// Token: 0x06000CE3 RID: 3299 RVA: 0x000455F1 File Offset: 0x000437F1
		public int SetPropagationThreadAffinity(ulong cpuMask)
		{
			return ONSPPropagation.UnityNativeInterface.ovrAudio_SetPropagationThreadAffinity(this.context, cpuMask);
		}

		// Token: 0x06000CE4 RID: 3300
		[DllImport("AudioPluginOculusSpatializer")]
		private static extern int ovrAudio_CreateAudioGeometry(IntPtr context, out IntPtr geometry);

		// Token: 0x06000CE5 RID: 3301 RVA: 0x000455FF File Offset: 0x000437FF
		public int CreateAudioGeometry(out IntPtr geometry)
		{
			return ONSPPropagation.UnityNativeInterface.ovrAudio_CreateAudioGeometry(this.context, out geometry);
		}

		// Token: 0x06000CE6 RID: 3302
		[DllImport("AudioPluginOculusSpatializer")]
		private static extern int ovrAudio_DestroyAudioGeometry(IntPtr geometry);

		// Token: 0x06000CE7 RID: 3303 RVA: 0x0004560D File Offset: 0x0004380D
		public int DestroyAudioGeometry(IntPtr geometry)
		{
			return ONSPPropagation.UnityNativeInterface.ovrAudio_DestroyAudioGeometry(geometry);
		}

		// Token: 0x06000CE8 RID: 3304
		[DllImport("AudioPluginOculusSpatializer")]
		private static extern int ovrAudio_AudioGeometryUploadMeshArrays(IntPtr geometry, float[] vertices, UIntPtr verticesBytesOffset, UIntPtr vertexCount, UIntPtr vertexStride, ONSPPropagation.ovrAudioScalarType vertexType, int[] indices, UIntPtr indicesByteOffset, UIntPtr indexCount, ONSPPropagation.ovrAudioScalarType indexType, MeshGroup[] groups, UIntPtr groupCount);

		// Token: 0x06000CE9 RID: 3305 RVA: 0x00045618 File Offset: 0x00043818
		public int AudioGeometryUploadMeshArrays(IntPtr geometry, float[] vertices, int vertexCount, int[] indices, int indexCount, MeshGroup[] groups, int groupCount)
		{
			return ONSPPropagation.UnityNativeInterface.ovrAudio_AudioGeometryUploadMeshArrays(geometry, vertices, UIntPtr.Zero, (UIntPtr)((ulong)((long)vertexCount)), UIntPtr.Zero, ONSPPropagation.ovrAudioScalarType.Float32, indices, UIntPtr.Zero, (UIntPtr)((ulong)((long)indexCount)), ONSPPropagation.ovrAudioScalarType.UInt32, groups, (UIntPtr)((ulong)((long)groupCount)));
		}

		// Token: 0x06000CEA RID: 3306
		[DllImport("AudioPluginOculusSpatializer")]
		private static extern int ovrAudio_AudioGeometrySetTransform(IntPtr geometry, float[] matrix4x4);

		// Token: 0x06000CEB RID: 3307 RVA: 0x00045659 File Offset: 0x00043859
		public int AudioGeometrySetTransform(IntPtr geometry, float[] matrix4x4)
		{
			return ONSPPropagation.UnityNativeInterface.ovrAudio_AudioGeometrySetTransform(geometry, matrix4x4);
		}

		// Token: 0x06000CEC RID: 3308
		[DllImport("AudioPluginOculusSpatializer")]
		private static extern int ovrAudio_AudioGeometryGetTransform(IntPtr geometry, out float[] matrix4x4);

		// Token: 0x06000CED RID: 3309 RVA: 0x00045662 File Offset: 0x00043862
		public int AudioGeometryGetTransform(IntPtr geometry, out float[] matrix4x4)
		{
			return ONSPPropagation.UnityNativeInterface.ovrAudio_AudioGeometryGetTransform(geometry, out matrix4x4);
		}

		// Token: 0x06000CEE RID: 3310
		[DllImport("AudioPluginOculusSpatializer")]
		private static extern int ovrAudio_AudioGeometryWriteMeshFile(IntPtr geometry, string filePath);

		// Token: 0x06000CEF RID: 3311 RVA: 0x0004566B File Offset: 0x0004386B
		public int AudioGeometryWriteMeshFile(IntPtr geometry, string filePath)
		{
			return ONSPPropagation.UnityNativeInterface.ovrAudio_AudioGeometryWriteMeshFile(geometry, filePath);
		}

		// Token: 0x06000CF0 RID: 3312
		[DllImport("AudioPluginOculusSpatializer")]
		private static extern int ovrAudio_AudioGeometryReadMeshFile(IntPtr geometry, string filePath);

		// Token: 0x06000CF1 RID: 3313 RVA: 0x00045674 File Offset: 0x00043874
		public int AudioGeometryReadMeshFile(IntPtr geometry, string filePath)
		{
			return ONSPPropagation.UnityNativeInterface.ovrAudio_AudioGeometryReadMeshFile(geometry, filePath);
		}

		// Token: 0x06000CF2 RID: 3314
		[DllImport("AudioPluginOculusSpatializer")]
		private static extern int ovrAudio_AudioGeometryWriteMeshFileObj(IntPtr geometry, string filePath);

		// Token: 0x06000CF3 RID: 3315 RVA: 0x0004567D File Offset: 0x0004387D
		public int AudioGeometryWriteMeshFileObj(IntPtr geometry, string filePath)
		{
			return ONSPPropagation.UnityNativeInterface.ovrAudio_AudioGeometryWriteMeshFileObj(geometry, filePath);
		}

		// Token: 0x06000CF4 RID: 3316
		[DllImport("AudioPluginOculusSpatializer")]
		private static extern int ovrAudio_CreateAudioMaterial(IntPtr context, out IntPtr material);

		// Token: 0x06000CF5 RID: 3317 RVA: 0x00045686 File Offset: 0x00043886
		public int CreateAudioMaterial(out IntPtr material)
		{
			return ONSPPropagation.UnityNativeInterface.ovrAudio_CreateAudioMaterial(this.context, out material);
		}

		// Token: 0x06000CF6 RID: 3318
		[DllImport("AudioPluginOculusSpatializer")]
		private static extern int ovrAudio_DestroyAudioMaterial(IntPtr material);

		// Token: 0x06000CF7 RID: 3319 RVA: 0x00045694 File Offset: 0x00043894
		public int DestroyAudioMaterial(IntPtr material)
		{
			return ONSPPropagation.UnityNativeInterface.ovrAudio_DestroyAudioMaterial(material);
		}

		// Token: 0x06000CF8 RID: 3320
		[DllImport("AudioPluginOculusSpatializer")]
		private static extern int ovrAudio_AudioMaterialSetFrequency(IntPtr material, MaterialProperty property, float frequency, float value);

		// Token: 0x06000CF9 RID: 3321 RVA: 0x0004569C File Offset: 0x0004389C
		public int AudioMaterialSetFrequency(IntPtr material, MaterialProperty property, float frequency, float value)
		{
			return ONSPPropagation.UnityNativeInterface.ovrAudio_AudioMaterialSetFrequency(material, property, frequency, value);
		}

		// Token: 0x06000CFA RID: 3322
		[DllImport("AudioPluginOculusSpatializer")]
		private static extern int ovrAudio_AudioMaterialGetFrequency(IntPtr material, MaterialProperty property, float frequency, out float value);

		// Token: 0x06000CFB RID: 3323 RVA: 0x000456A8 File Offset: 0x000438A8
		public int AudioMaterialGetFrequency(IntPtr material, MaterialProperty property, float frequency, out float value)
		{
			return ONSPPropagation.UnityNativeInterface.ovrAudio_AudioMaterialGetFrequency(material, property, frequency, out value);
		}

		// Token: 0x06000CFC RID: 3324
		[DllImport("AudioPluginOculusSpatializer")]
		private static extern int ovrAudio_AudioMaterialReset(IntPtr material, MaterialProperty property);

		// Token: 0x06000CFD RID: 3325 RVA: 0x000456B4 File Offset: 0x000438B4
		public int AudioMaterialReset(IntPtr material, MaterialProperty property)
		{
			return ONSPPropagation.UnityNativeInterface.ovrAudio_AudioMaterialReset(material, property);
		}

		// Token: 0x04000F88 RID: 3976
		public const string strOSPS = "AudioPluginOculusSpatializer";

		// Token: 0x04000F89 RID: 3977
		private IntPtr context_ = IntPtr.Zero;
	}

	// Token: 0x02000234 RID: 564
	public class WwisePluginInterface : ONSPPropagation.PropagationInterface
	{
		// Token: 0x170000EB RID: 235
		// (get) Token: 0x06000CFF RID: 3327 RVA: 0x000456D0 File Offset: 0x000438D0
		private IntPtr context
		{
			get
			{
				if (this.context_ == IntPtr.Zero)
				{
					ONSPPropagation.WwisePluginInterface.ovrAudio_GetPluginContext(out this.context_, 12U);
				}
				return this.context_;
			}
		}

		// Token: 0x06000D00 RID: 3328
		[DllImport("OculusSpatializerWwise")]
		public static extern int ovrAudio_GetPluginContext(out IntPtr context, uint clientType);

		// Token: 0x06000D01 RID: 3329
		[DllImport("OculusSpatializerWwise")]
		private static extern int ovrAudio_SetPropagationQuality(IntPtr context, float quality);

		// Token: 0x06000D02 RID: 3330 RVA: 0x000456F8 File Offset: 0x000438F8
		public int SetPropagationQuality(float quality)
		{
			return ONSPPropagation.WwisePluginInterface.ovrAudio_SetPropagationQuality(this.context, quality);
		}

		// Token: 0x06000D03 RID: 3331
		[DllImport("OculusSpatializerWwise")]
		private static extern int ovrAudio_SetPropagationThreadAffinity(IntPtr context, ulong cpuMask);

		// Token: 0x06000D04 RID: 3332 RVA: 0x00045706 File Offset: 0x00043906
		public int SetPropagationThreadAffinity(ulong cpuMask)
		{
			return ONSPPropagation.WwisePluginInterface.ovrAudio_SetPropagationThreadAffinity(this.context, cpuMask);
		}

		// Token: 0x06000D05 RID: 3333
		[DllImport("OculusSpatializerWwise")]
		private static extern int ovrAudio_CreateAudioGeometry(IntPtr context, out IntPtr geometry);

		// Token: 0x06000D06 RID: 3334 RVA: 0x00045714 File Offset: 0x00043914
		public int CreateAudioGeometry(out IntPtr geometry)
		{
			return ONSPPropagation.WwisePluginInterface.ovrAudio_CreateAudioGeometry(this.context, out geometry);
		}

		// Token: 0x06000D07 RID: 3335
		[DllImport("OculusSpatializerWwise")]
		private static extern int ovrAudio_DestroyAudioGeometry(IntPtr geometry);

		// Token: 0x06000D08 RID: 3336 RVA: 0x00045722 File Offset: 0x00043922
		public int DestroyAudioGeometry(IntPtr geometry)
		{
			return ONSPPropagation.WwisePluginInterface.ovrAudio_DestroyAudioGeometry(geometry);
		}

		// Token: 0x06000D09 RID: 3337
		[DllImport("OculusSpatializerWwise")]
		private static extern int ovrAudio_AudioGeometryUploadMeshArrays(IntPtr geometry, float[] vertices, UIntPtr verticesBytesOffset, UIntPtr vertexCount, UIntPtr vertexStride, ONSPPropagation.ovrAudioScalarType vertexType, int[] indices, UIntPtr indicesByteOffset, UIntPtr indexCount, ONSPPropagation.ovrAudioScalarType indexType, MeshGroup[] groups, UIntPtr groupCount);

		// Token: 0x06000D0A RID: 3338 RVA: 0x0004572C File Offset: 0x0004392C
		public int AudioGeometryUploadMeshArrays(IntPtr geometry, float[] vertices, int vertexCount, int[] indices, int indexCount, MeshGroup[] groups, int groupCount)
		{
			return ONSPPropagation.WwisePluginInterface.ovrAudio_AudioGeometryUploadMeshArrays(geometry, vertices, UIntPtr.Zero, (UIntPtr)((ulong)((long)vertexCount)), UIntPtr.Zero, ONSPPropagation.ovrAudioScalarType.Float32, indices, UIntPtr.Zero, (UIntPtr)((ulong)((long)indexCount)), ONSPPropagation.ovrAudioScalarType.UInt32, groups, (UIntPtr)((ulong)((long)groupCount)));
		}

		// Token: 0x06000D0B RID: 3339
		[DllImport("OculusSpatializerWwise")]
		private static extern int ovrAudio_AudioGeometrySetTransform(IntPtr geometry, float[] matrix4x4);

		// Token: 0x06000D0C RID: 3340 RVA: 0x0004576D File Offset: 0x0004396D
		public int AudioGeometrySetTransform(IntPtr geometry, float[] matrix4x4)
		{
			return ONSPPropagation.WwisePluginInterface.ovrAudio_AudioGeometrySetTransform(geometry, matrix4x4);
		}

		// Token: 0x06000D0D RID: 3341
		[DllImport("OculusSpatializerWwise")]
		private static extern int ovrAudio_AudioGeometryGetTransform(IntPtr geometry, out float[] matrix4x4);

		// Token: 0x06000D0E RID: 3342 RVA: 0x00045776 File Offset: 0x00043976
		public int AudioGeometryGetTransform(IntPtr geometry, out float[] matrix4x4)
		{
			return ONSPPropagation.WwisePluginInterface.ovrAudio_AudioGeometryGetTransform(geometry, out matrix4x4);
		}

		// Token: 0x06000D0F RID: 3343
		[DllImport("OculusSpatializerWwise")]
		private static extern int ovrAudio_AudioGeometryWriteMeshFile(IntPtr geometry, string filePath);

		// Token: 0x06000D10 RID: 3344 RVA: 0x0004577F File Offset: 0x0004397F
		public int AudioGeometryWriteMeshFile(IntPtr geometry, string filePath)
		{
			return ONSPPropagation.WwisePluginInterface.ovrAudio_AudioGeometryWriteMeshFile(geometry, filePath);
		}

		// Token: 0x06000D11 RID: 3345
		[DllImport("OculusSpatializerWwise")]
		private static extern int ovrAudio_AudioGeometryReadMeshFile(IntPtr geometry, string filePath);

		// Token: 0x06000D12 RID: 3346 RVA: 0x00045788 File Offset: 0x00043988
		public int AudioGeometryReadMeshFile(IntPtr geometry, string filePath)
		{
			return ONSPPropagation.WwisePluginInterface.ovrAudio_AudioGeometryReadMeshFile(geometry, filePath);
		}

		// Token: 0x06000D13 RID: 3347
		[DllImport("OculusSpatializerWwise")]
		private static extern int ovrAudio_AudioGeometryWriteMeshFileObj(IntPtr geometry, string filePath);

		// Token: 0x06000D14 RID: 3348 RVA: 0x00045791 File Offset: 0x00043991
		public int AudioGeometryWriteMeshFileObj(IntPtr geometry, string filePath)
		{
			return ONSPPropagation.WwisePluginInterface.ovrAudio_AudioGeometryWriteMeshFileObj(geometry, filePath);
		}

		// Token: 0x06000D15 RID: 3349
		[DllImport("OculusSpatializerWwise")]
		private static extern int ovrAudio_CreateAudioMaterial(IntPtr context, out IntPtr material);

		// Token: 0x06000D16 RID: 3350 RVA: 0x0004579A File Offset: 0x0004399A
		public int CreateAudioMaterial(out IntPtr material)
		{
			return ONSPPropagation.WwisePluginInterface.ovrAudio_CreateAudioMaterial(this.context, out material);
		}

		// Token: 0x06000D17 RID: 3351
		[DllImport("OculusSpatializerWwise")]
		private static extern int ovrAudio_DestroyAudioMaterial(IntPtr material);

		// Token: 0x06000D18 RID: 3352 RVA: 0x000457A8 File Offset: 0x000439A8
		public int DestroyAudioMaterial(IntPtr material)
		{
			return ONSPPropagation.WwisePluginInterface.ovrAudio_DestroyAudioMaterial(material);
		}

		// Token: 0x06000D19 RID: 3353
		[DllImport("OculusSpatializerWwise")]
		private static extern int ovrAudio_AudioMaterialSetFrequency(IntPtr material, MaterialProperty property, float frequency, float value);

		// Token: 0x06000D1A RID: 3354 RVA: 0x000457B0 File Offset: 0x000439B0
		public int AudioMaterialSetFrequency(IntPtr material, MaterialProperty property, float frequency, float value)
		{
			return ONSPPropagation.WwisePluginInterface.ovrAudio_AudioMaterialSetFrequency(material, property, frequency, value);
		}

		// Token: 0x06000D1B RID: 3355
		[DllImport("OculusSpatializerWwise")]
		private static extern int ovrAudio_AudioMaterialGetFrequency(IntPtr material, MaterialProperty property, float frequency, out float value);

		// Token: 0x06000D1C RID: 3356 RVA: 0x000457BC File Offset: 0x000439BC
		public int AudioMaterialGetFrequency(IntPtr material, MaterialProperty property, float frequency, out float value)
		{
			return ONSPPropagation.WwisePluginInterface.ovrAudio_AudioMaterialGetFrequency(material, property, frequency, out value);
		}

		// Token: 0x06000D1D RID: 3357
		[DllImport("OculusSpatializerWwise")]
		private static extern int ovrAudio_AudioMaterialReset(IntPtr material, MaterialProperty property);

		// Token: 0x06000D1E RID: 3358 RVA: 0x000457C8 File Offset: 0x000439C8
		public int AudioMaterialReset(IntPtr material, MaterialProperty property)
		{
			return ONSPPropagation.WwisePluginInterface.ovrAudio_AudioMaterialReset(material, property);
		}

		// Token: 0x04000F8A RID: 3978
		public const string strOSPS = "OculusSpatializerWwise";

		// Token: 0x04000F8B RID: 3979
		private IntPtr context_ = IntPtr.Zero;
	}

	// Token: 0x02000235 RID: 565
	public class FMODPluginInterface : ONSPPropagation.PropagationInterface
	{
		// Token: 0x170000EC RID: 236
		// (get) Token: 0x06000D20 RID: 3360 RVA: 0x000457E4 File Offset: 0x000439E4
		private IntPtr context
		{
			get
			{
				if (this.context_ == IntPtr.Zero)
				{
					ONSPPropagation.FMODPluginInterface.ovrAudio_GetPluginContext(out this.context_, 5U);
				}
				return this.context_;
			}
		}

		// Token: 0x06000D21 RID: 3361
		[DllImport("OculusSpatializerFMOD")]
		public static extern int ovrAudio_GetPluginContext(out IntPtr context, uint clientType);

		// Token: 0x06000D22 RID: 3362
		[DllImport("OculusSpatializerFMOD")]
		private static extern int ovrAudio_SetPropagationQuality(IntPtr context, float quality);

		// Token: 0x06000D23 RID: 3363 RVA: 0x0004580B File Offset: 0x00043A0B
		public int SetPropagationQuality(float quality)
		{
			return ONSPPropagation.FMODPluginInterface.ovrAudio_SetPropagationQuality(this.context, quality);
		}

		// Token: 0x06000D24 RID: 3364
		[DllImport("OculusSpatializerFMOD")]
		private static extern int ovrAudio_SetPropagationThreadAffinity(IntPtr context, ulong cpuMask);

		// Token: 0x06000D25 RID: 3365 RVA: 0x00045819 File Offset: 0x00043A19
		public int SetPropagationThreadAffinity(ulong cpuMask)
		{
			return ONSPPropagation.FMODPluginInterface.ovrAudio_SetPropagationThreadAffinity(this.context, cpuMask);
		}

		// Token: 0x06000D26 RID: 3366
		[DllImport("OculusSpatializerFMOD")]
		private static extern int ovrAudio_CreateAudioGeometry(IntPtr context, out IntPtr geometry);

		// Token: 0x06000D27 RID: 3367 RVA: 0x00045827 File Offset: 0x00043A27
		public int CreateAudioGeometry(out IntPtr geometry)
		{
			return ONSPPropagation.FMODPluginInterface.ovrAudio_CreateAudioGeometry(this.context, out geometry);
		}

		// Token: 0x06000D28 RID: 3368
		[DllImport("OculusSpatializerFMOD")]
		private static extern int ovrAudio_DestroyAudioGeometry(IntPtr geometry);

		// Token: 0x06000D29 RID: 3369 RVA: 0x00045835 File Offset: 0x00043A35
		public int DestroyAudioGeometry(IntPtr geometry)
		{
			return ONSPPropagation.FMODPluginInterface.ovrAudio_DestroyAudioGeometry(geometry);
		}

		// Token: 0x06000D2A RID: 3370
		[DllImport("OculusSpatializerFMOD")]
		private static extern int ovrAudio_AudioGeometryUploadMeshArrays(IntPtr geometry, float[] vertices, UIntPtr verticesBytesOffset, UIntPtr vertexCount, UIntPtr vertexStride, ONSPPropagation.ovrAudioScalarType vertexType, int[] indices, UIntPtr indicesByteOffset, UIntPtr indexCount, ONSPPropagation.ovrAudioScalarType indexType, MeshGroup[] groups, UIntPtr groupCount);

		// Token: 0x06000D2B RID: 3371 RVA: 0x00045840 File Offset: 0x00043A40
		public int AudioGeometryUploadMeshArrays(IntPtr geometry, float[] vertices, int vertexCount, int[] indices, int indexCount, MeshGroup[] groups, int groupCount)
		{
			return ONSPPropagation.FMODPluginInterface.ovrAudio_AudioGeometryUploadMeshArrays(geometry, vertices, UIntPtr.Zero, (UIntPtr)((ulong)((long)vertexCount)), UIntPtr.Zero, ONSPPropagation.ovrAudioScalarType.Float32, indices, UIntPtr.Zero, (UIntPtr)((ulong)((long)indexCount)), ONSPPropagation.ovrAudioScalarType.UInt32, groups, (UIntPtr)((ulong)((long)groupCount)));
		}

		// Token: 0x06000D2C RID: 3372
		[DllImport("OculusSpatializerFMOD")]
		private static extern int ovrAudio_AudioGeometrySetTransform(IntPtr geometry, float[] matrix4x4);

		// Token: 0x06000D2D RID: 3373 RVA: 0x00045881 File Offset: 0x00043A81
		public int AudioGeometrySetTransform(IntPtr geometry, float[] matrix4x4)
		{
			return ONSPPropagation.FMODPluginInterface.ovrAudio_AudioGeometrySetTransform(geometry, matrix4x4);
		}

		// Token: 0x06000D2E RID: 3374
		[DllImport("OculusSpatializerFMOD")]
		private static extern int ovrAudio_AudioGeometryGetTransform(IntPtr geometry, out float[] matrix4x4);

		// Token: 0x06000D2F RID: 3375 RVA: 0x0004588A File Offset: 0x00043A8A
		public int AudioGeometryGetTransform(IntPtr geometry, out float[] matrix4x4)
		{
			return ONSPPropagation.FMODPluginInterface.ovrAudio_AudioGeometryGetTransform(geometry, out matrix4x4);
		}

		// Token: 0x06000D30 RID: 3376
		[DllImport("OculusSpatializerFMOD")]
		private static extern int ovrAudio_AudioGeometryWriteMeshFile(IntPtr geometry, string filePath);

		// Token: 0x06000D31 RID: 3377 RVA: 0x00045893 File Offset: 0x00043A93
		public int AudioGeometryWriteMeshFile(IntPtr geometry, string filePath)
		{
			return ONSPPropagation.FMODPluginInterface.ovrAudio_AudioGeometryWriteMeshFile(geometry, filePath);
		}

		// Token: 0x06000D32 RID: 3378
		[DllImport("OculusSpatializerFMOD")]
		private static extern int ovrAudio_AudioGeometryReadMeshFile(IntPtr geometry, string filePath);

		// Token: 0x06000D33 RID: 3379 RVA: 0x0004589C File Offset: 0x00043A9C
		public int AudioGeometryReadMeshFile(IntPtr geometry, string filePath)
		{
			return ONSPPropagation.FMODPluginInterface.ovrAudio_AudioGeometryReadMeshFile(geometry, filePath);
		}

		// Token: 0x06000D34 RID: 3380
		[DllImport("OculusSpatializerFMOD")]
		private static extern int ovrAudio_AudioGeometryWriteMeshFileObj(IntPtr geometry, string filePath);

		// Token: 0x06000D35 RID: 3381 RVA: 0x000458A5 File Offset: 0x00043AA5
		public int AudioGeometryWriteMeshFileObj(IntPtr geometry, string filePath)
		{
			return ONSPPropagation.FMODPluginInterface.ovrAudio_AudioGeometryWriteMeshFileObj(geometry, filePath);
		}

		// Token: 0x06000D36 RID: 3382
		[DllImport("OculusSpatializerFMOD")]
		private static extern int ovrAudio_CreateAudioMaterial(IntPtr context, out IntPtr material);

		// Token: 0x06000D37 RID: 3383 RVA: 0x000458AE File Offset: 0x00043AAE
		public int CreateAudioMaterial(out IntPtr material)
		{
			return ONSPPropagation.FMODPluginInterface.ovrAudio_CreateAudioMaterial(this.context, out material);
		}

		// Token: 0x06000D38 RID: 3384
		[DllImport("OculusSpatializerFMOD")]
		private static extern int ovrAudio_DestroyAudioMaterial(IntPtr material);

		// Token: 0x06000D39 RID: 3385 RVA: 0x000458BC File Offset: 0x00043ABC
		public int DestroyAudioMaterial(IntPtr material)
		{
			return ONSPPropagation.FMODPluginInterface.ovrAudio_DestroyAudioMaterial(material);
		}

		// Token: 0x06000D3A RID: 3386
		[DllImport("OculusSpatializerFMOD")]
		private static extern int ovrAudio_AudioMaterialSetFrequency(IntPtr material, MaterialProperty property, float frequency, float value);

		// Token: 0x06000D3B RID: 3387 RVA: 0x000458C4 File Offset: 0x00043AC4
		public int AudioMaterialSetFrequency(IntPtr material, MaterialProperty property, float frequency, float value)
		{
			return ONSPPropagation.FMODPluginInterface.ovrAudio_AudioMaterialSetFrequency(material, property, frequency, value);
		}

		// Token: 0x06000D3C RID: 3388
		[DllImport("OculusSpatializerFMOD")]
		private static extern int ovrAudio_AudioMaterialGetFrequency(IntPtr material, MaterialProperty property, float frequency, out float value);

		// Token: 0x06000D3D RID: 3389 RVA: 0x000458D0 File Offset: 0x00043AD0
		public int AudioMaterialGetFrequency(IntPtr material, MaterialProperty property, float frequency, out float value)
		{
			return ONSPPropagation.FMODPluginInterface.ovrAudio_AudioMaterialGetFrequency(material, property, frequency, out value);
		}

		// Token: 0x06000D3E RID: 3390
		[DllImport("OculusSpatializerFMOD")]
		private static extern int ovrAudio_AudioMaterialReset(IntPtr material, MaterialProperty property);

		// Token: 0x06000D3F RID: 3391 RVA: 0x000458DC File Offset: 0x00043ADC
		public int AudioMaterialReset(IntPtr material, MaterialProperty property)
		{
			return ONSPPropagation.FMODPluginInterface.ovrAudio_AudioMaterialReset(material, property);
		}

		// Token: 0x04000F8C RID: 3980
		public const string strOSPS = "OculusSpatializerFMOD";

		// Token: 0x04000F8D RID: 3981
		private IntPtr context_ = IntPtr.Zero;
	}
}
