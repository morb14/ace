﻿using System;
using System.Collections.Generic;
using UnityEngine;

// Token: 0x02000043 RID: 67
public class OpticAutoOn : MonoBehaviour
{
	// Token: 0x06000225 RID: 549 RVA: 0x0000C07C File Offset: 0x0000A27C
	private void Start()
	{
		GameEvents.current.onHolsterDraw += this.AutoOn;
		GameEvents.current.onHolster += this.AutoOff;
		GameEvents.current.onShotFired += this.RecoilEffect;
		if (this.forceRecoil)
		{
			this.opticRecoil = base.transform.root.GetComponentInChildren<WeaponController>().opticRecoil;
		}
		foreach (GameObject gameObject in this.toggleObjects)
		{
			if (!gameObject.GetComponent<Camera>())
			{
				this.recoilObjects.Add(gameObject);
			}
		}
		if (this.toggleObjects.Length == 0)
		{
			return;
		}
		GameObject[] array = this.toggleObjects;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetActive(false);
		}
		this.playerData = Object.FindObjectOfType<PlayerData>();
		this.settingsManager = Object.FindObjectOfType<SettingsManager>();
		this.dotColour = this.settingsManager.reflexColour;
	}

	// Token: 0x06000226 RID: 550 RVA: 0x0000C170 File Offset: 0x0000A370
	private void RecoilEffect()
	{
		if (!this.underRecoil && this.forceRecoil)
		{
			this.underRecoil = true;
			foreach (GameObject gameObject in this.recoilObjects)
			{
				gameObject.transform.Translate(Vector3.up * this.opticRecoil, Space.World);
			}
			base.Invoke("RecoilReturn", 0.02f);
		}
	}

	// Token: 0x06000227 RID: 551 RVA: 0x0000C200 File Offset: 0x0000A400
	private void RecoilReturn()
	{
		foreach (GameObject gameObject in this.recoilObjects)
		{
			gameObject.transform.Translate(Vector3.down * this.opticRecoil, Space.World);
		}
		this.underRecoil = false;
	}

	// Token: 0x06000228 RID: 552 RVA: 0x0000C270 File Offset: 0x0000A470
	private void AutoOn()
	{
		if (base.transform.root.gameObject.layer == LayerMask.NameToLayer("CharacterController"))
		{
			GameObject[] array = this.toggleObjects;
			for (int i = 0; i < array.Length; i++)
			{
				array[i].SetActive(true);
				MonoBehaviour.print("OPTIC TOGGLED ON");
				this.toggledOn = true;
			}
		}
		if (this.toggledOn)
		{
			this.dotColour = this.settingsManager.reflexColour;
			Renderer[] array2 = this.reticlesToChangeColour;
			for (int i = 0; i < array2.Length; i++)
			{
				array2[i].material = this.settingsManager.ReflexMaterial();
			}
			foreach (Renderer renderer in this.noneReflexToChangeColour)
			{
				if (this.uniqueNoneReflexMaterialAlt != null)
				{
					renderer.material = this.settingsManager.NoneReflexMaterial(this.uniqueNoneReflexMaterialOriginal, this.uniqueNoneReflexMaterialAlt);
				}
				else
				{
					renderer.material = this.settingsManager.NoneReflexMaterial(null, null);
				}
			}
			if (base.GetComponentInParent<OffsetSecondary>() && base.GetComponentInParent<OffsetSecondary>().isOffSetOptic)
			{
				GameObject[] array = this.reflexReticles;
				for (int i = 0; i < array.Length; i++)
				{
					array[i].layer = LayerMask.NameToLayer("ReflexReticle2");
				}
				this.reflexWindow.layer = LayerMask.NameToLayer("ReflexWindow2");
			}
			if (this.opacityLens != null)
			{
				Color color = this.opacityLens.material.GetColor("_BaseColor");
				this.opacityLens.material.SetColor("_BaseColor", new Color(color.r, color.g, color.b, this.playerData.opticOpacity));
			}
		}
	}

	// Token: 0x06000229 RID: 553 RVA: 0x0000C420 File Offset: 0x0000A620
	private void AutoOff()
	{
		GameObject[] array = this.toggleObjects;
		for (int i = 0; i < array.Length; i++)
		{
			array[i].SetActive(false);
			this.toggledOn = false;
		}
		MonoBehaviour.print("red dot event auto off");
	}

	// Token: 0x0600022A RID: 554 RVA: 0x0000C45C File Offset: 0x0000A65C
	private void OnDestroy()
	{
		if (this.toggleObjects.Length == 0)
		{
			return;
		}
		GameEvents.current.onHolsterDraw -= this.AutoOn;
		GameEvents.current.onHolster -= this.AutoOff;
		GameEvents.current.onShotFired -= this.RecoilEffect;
	}

	// Token: 0x040001F8 RID: 504
	[SerializeField]
	public GameObject[] toggleObjects;

	// Token: 0x040001F9 RID: 505
	[SerializeField]
	private bool forceRecoil;

	// Token: 0x040001FA RID: 506
	[SerializeField]
	private Material uniqueNoneReflexMaterialOriginal;

	// Token: 0x040001FB RID: 507
	[SerializeField]
	private Material uniqueNoneReflexMaterialAlt;

	// Token: 0x040001FC RID: 508
	[SerializeField]
	private Renderer[] reticlesToChangeColour;

	// Token: 0x040001FD RID: 509
	[SerializeField]
	private Renderer[] noneReflexToChangeColour;

	// Token: 0x040001FE RID: 510
	[SerializeField]
	private Renderer opacityLens;

	// Token: 0x040001FF RID: 511
	[Header("Stencil Buffer Objects")]
	[SerializeField]
	public GameObject[] reflexReticles;

	// Token: 0x04000200 RID: 512
	[SerializeField]
	public GameObject reflexWindow;

	// Token: 0x04000201 RID: 513
	private Vector3 startPos;

	// Token: 0x04000202 RID: 514
	private WeaponController controller;

	// Token: 0x04000203 RID: 515
	private float opticRecoil;

	// Token: 0x04000204 RID: 516
	private List<GameObject> recoilObjects = new List<GameObject>();

	// Token: 0x04000205 RID: 517
	private bool underRecoil;

	// Token: 0x04000206 RID: 518
	private bool toggledOn;

	// Token: 0x04000207 RID: 519
	private PlayerData playerData;

	// Token: 0x04000208 RID: 520
	private SettingsManager settingsManager;

	// Token: 0x04000209 RID: 521
	private SettingsManager.ReflexColour dotColour;
}
