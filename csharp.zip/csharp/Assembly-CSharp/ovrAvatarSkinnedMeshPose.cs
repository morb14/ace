﻿using System;
using System.Runtime.InteropServices;

// Token: 0x020000DF RID: 223
public struct ovrAvatarSkinnedMeshPose
{
	// Token: 0x04000841 RID: 2113
	public uint jointCount;

	// Token: 0x04000842 RID: 2114
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 64)]
	public ovrAvatarTransform[] jointTransform;

	// Token: 0x04000843 RID: 2115
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 64)]
	public int[] jointParents;

	// Token: 0x04000844 RID: 2116
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 64)]
	public IntPtr[] jointNames;
}
