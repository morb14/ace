﻿using System;
using UnityEngine;

// Token: 0x02000082 RID: 130
public class HandGrabbingBehaviour : OVRGrabber
{
	// Token: 0x060004B4 RID: 1204 RVA: 0x0001F0F9 File Offset: 0x0001D2F9
	protected override void Start()
	{
		base.Start();
		this.hand = base.GetComponent<OVRHand>();
	}

	// Token: 0x060004B5 RID: 1205 RVA: 0x0001F10D File Offset: 0x0001D30D
	public override void Update()
	{
		base.Update();
		this.CheckIndexPinch();
	}

	// Token: 0x060004B6 RID: 1206 RVA: 0x0001F11C File Offset: 0x0001D31C
	private void CheckIndexPinch()
	{
		bool flag = this.hand.GetFingerPinchStrength(OVRHand.HandFinger.Index) > this.pinchThreshold;
		if (flag)
		{
			MonoBehaviour.print("IS PINCHING");
		}
		if (!this.m_grabbedObj && flag && this.m_grabCandidates.Count > 0)
		{
			this.GrabBegin();
			return;
		}
		if (this.m_grabbedObj && !flag)
		{
			this.GrabEnd();
		}
	}

	// Token: 0x060004B7 RID: 1207 RVA: 0x0001F188 File Offset: 0x0001D388
	protected override void GrabEnd()
	{
		if (this.m_grabbedObj)
		{
			Vector3 linearVelocity = (base.transform.parent.position - this.m_lastPos) / Time.fixedDeltaTime;
			Vector3 angularVelocity = (base.transform.parent.eulerAngles - this.m_lastRot.eulerAngles) / Time.fixedDeltaTime;
			base.GrabbableRelease(linearVelocity, angularVelocity);
		}
		this.GrabVolumeEnable(true);
	}

	// Token: 0x040005E8 RID: 1512
	private OVRHand hand;

	// Token: 0x040005E9 RID: 1513
	public float pinchThreshold = 0.7f;
}
