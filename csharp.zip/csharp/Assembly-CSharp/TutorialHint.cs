﻿using System;
using UnityEngine;

// Token: 0x02000092 RID: 146
public class TutorialHint : MonoBehaviour
{
	// Token: 0x060004F9 RID: 1273 RVA: 0x00020812 File Offset: 0x0001EA12
	private void Start()
	{
		this.gameManager = Object.FindObjectOfType<GameManager>();
		GameEvents.current.onTutorialStageAdvanced += this.OnTutorialStageAdvanced;
		this.TutorialStage();
	}

	// Token: 0x060004FA RID: 1274 RVA: 0x0002083B File Offset: 0x0001EA3B
	private void Update()
	{
		this.UpdateTutorialStage();
	}

	// Token: 0x060004FB RID: 1275 RVA: 0x00020844 File Offset: 0x0001EA44
	private void UpdateTutorialStage()
	{
		if (this.syncRotate && this.activeController != null)
		{
			float z;
			if (this.handednessScaled)
			{
				z = -90f;
			}
			else
			{
				z = 90f;
			}
			this.tutorialController.transform.rotation = this.activeController.rotation * Quaternion.Euler(0f, 0f, z);
		}
	}

	// Token: 0x060004FC RID: 1276 RVA: 0x000208B0 File Offset: 0x0001EAB0
	private void TutorialStage()
	{
		this.currentStage = this.tutorialManager.currentTutorialStage;
		switch (this.currentStage)
		{
		case TutorialManager.TutorialStage.SetDownController:
			this.tutorialController.triggerRenderer.material = this.tutorialController.green;
			this.animator.SetTrigger("Trigger");
			return;
		case TutorialManager.TutorialStage.PickUp:
			this.activeController = this.gameManager.ActiveHandObject().transform;
			if (this.tutorialManager.activeController == OVRInput.Controller.LTouch && !this.handednessScaled)
			{
				Vector3 localScale = this.tutorialController.transform.localScale;
				this.tutorialController.transform.localScale = new Vector3(-localScale.x, localScale.y, localScale.z);
				this.handednessScaled = true;
			}
			this.syncRotate = true;
			if (!this.syncRotate)
			{
				this.activeController = this.gameManager.ActiveHandObject().transform;
			}
			this.tutorialController.triggerRenderer.material = this.tutorialController.green;
			this.tutorialController.gripRenderer.material = this.tutorialController.green;
			this.animator.SetTrigger("GripButton");
			return;
		case TutorialManager.TutorialStage.PlaceInVolume:
			this.tutorialController.gripRenderer.material = this.tutorialController.green;
			this.animator.SetTrigger("GripButton");
			return;
		case TutorialManager.TutorialStage.HolsterLock:
			this.tutorialController.triggerRenderer.material = this.tutorialController.green;
			this.animator.SetTrigger("Trigger");
			return;
		case TutorialManager.TutorialStage.LoadWeapon:
			this.animator.SetTrigger("Grab&Load");
			return;
		case TutorialManager.TutorialStage.SafetyOn:
			this.animator.SetTrigger("JoyStickRight");
			return;
		case TutorialManager.TutorialStage.SafetyOff:
			this.animator.SetTrigger("JoyStickLeft");
			return;
		case TutorialManager.TutorialStage.ChamberRound:
			this.animator.SetTrigger("ChamberRound");
			return;
		case TutorialManager.TutorialStage.ShootAll:
			this.animator.SetTrigger("Trigger");
			this.tutorialController.triggerRenderer.material = this.tutorialController.green;
			return;
		case TutorialManager.TutorialStage.ReleaseSlide:
			this.animator.SetTrigger("Reload&Release");
			return;
		case TutorialManager.TutorialStage.Reholster:
			base.gameObject.SetActive(false);
			return;
		default:
			return;
		}
	}

	// Token: 0x060004FD RID: 1277 RVA: 0x00020AF1 File Offset: 0x0001ECF1
	private void OnTutorialStageAdvanced()
	{
		this.animator.SetTrigger("Next");
		this.tutorialController.ResetMaterial();
		base.Invoke("TutorialStage", 0.1f);
	}

	// Token: 0x060004FE RID: 1278 RVA: 0x00020B1E File Offset: 0x0001ED1E
	private void OnDestroy()
	{
		GameEvents.current.onTutorialStageAdvanced -= this.OnTutorialStageAdvanced;
	}

	// Token: 0x0400063B RID: 1595
	[SerializeField]
	private Transform controllerIcon;

	// Token: 0x0400063C RID: 1596
	[SerializeField]
	private TutorialManager tutorialManager;

	// Token: 0x0400063D RID: 1597
	[SerializeField]
	private TutorialController tutorialController;

	// Token: 0x0400063E RID: 1598
	[SerializeField]
	private Animator animator;

	// Token: 0x0400063F RID: 1599
	private TutorialManager.TutorialStage currentStage;

	// Token: 0x04000640 RID: 1600
	private GameManager gameManager;

	// Token: 0x04000641 RID: 1601
	private Transform activeController;

	// Token: 0x04000642 RID: 1602
	private bool handednessScaled;

	// Token: 0x04000643 RID: 1603
	private bool syncRotate;
}
