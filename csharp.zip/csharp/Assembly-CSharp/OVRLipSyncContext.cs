﻿using System;
using UnityEngine;

// Token: 0x0200010A RID: 266
[RequireComponent(typeof(AudioSource))]
public class OVRLipSyncContext : OVRLipSyncContextBase
{
	// Token: 0x060006BA RID: 1722 RVA: 0x0002B500 File Offset: 0x00029700
	private void Start()
	{
		if (this.enableTouchInput)
		{
			OVRTouchpad.AddListener(new OVRTouchpad.OVRTouchpadCallback<OVRTouchpad.TouchEvent>(this.LocalTouchEventCallback));
		}
		OVRLipSyncDebugConsole[] array = Object.FindObjectsOfType<OVRLipSyncDebugConsole>();
		if (array.Length != 0)
		{
			this.hasDebugConsole = array[0];
		}
	}

	// Token: 0x060006BB RID: 1723 RVA: 0x0002B540 File Offset: 0x00029740
	private void HandleKeyboard()
	{
		if (Input.GetKeyDown(this.loopbackKey))
		{
			this.ToggleAudioLoopback();
			return;
		}
		if (Input.GetKeyDown(this.debugVisemesKey))
		{
			this.showVisemes = !this.showVisemes;
			if (!this.showVisemes)
			{
				if (this.hasDebugConsole)
				{
					OVRLipSyncDebugConsole.Clear();
				}
				Debug.Log("DEBUG SHOW VISEMES: DISABLED");
				return;
			}
			if (this.hasDebugConsole)
			{
				Debug.Log("DEBUG SHOW VISEMES: ENABLED");
				return;
			}
			Debug.LogWarning("Warning: No OVRLipSyncDebugConsole in the scene!");
			this.showVisemes = false;
			return;
		}
		else
		{
			if (!Input.GetKeyDown(this.debugLaughterKey))
			{
				if (Input.GetKeyDown(KeyCode.LeftArrow))
				{
					this.gain -= 1f;
					if (this.gain < 1f)
					{
						this.gain = 1f;
					}
					string text = "LINEAR GAIN: ";
					text += this.gain;
					if (this.hasDebugConsole)
					{
						OVRLipSyncDebugConsole.Clear();
						OVRLipSyncDebugConsole.Log(text);
						OVRLipSyncDebugConsole.ClearTimeout(1.5f);
						return;
					}
				}
				else if (Input.GetKeyDown(KeyCode.RightArrow))
				{
					this.gain += 1f;
					if (this.gain > 15f)
					{
						this.gain = 15f;
					}
					string text2 = "LINEAR GAIN: ";
					text2 += this.gain;
					if (this.hasDebugConsole)
					{
						OVRLipSyncDebugConsole.Clear();
						OVRLipSyncDebugConsole.Log(text2);
						OVRLipSyncDebugConsole.ClearTimeout(1.5f);
					}
				}
				return;
			}
			this.showLaughter = !this.showLaughter;
			if (!this.showLaughter)
			{
				if (this.hasDebugConsole)
				{
					OVRLipSyncDebugConsole.Clear();
				}
				Debug.Log("DEBUG SHOW LAUGHTER: DISABLED");
				return;
			}
			if (this.hasDebugConsole)
			{
				Debug.Log("DEBUG SHOW LAUGHTER: ENABLED");
				return;
			}
			Debug.LogWarning("Warning: No OVRLipSyncDebugConsole in the scene!");
			this.showLaughter = false;
			return;
		}
	}

	// Token: 0x060006BC RID: 1724 RVA: 0x0002B6FD File Offset: 0x000298FD
	private void Update()
	{
		if (this.enableKeyboardInput)
		{
			this.HandleKeyboard();
		}
		this.laughterScore = base.Frame.laughterScore;
		this.DebugShowVisemesAndLaughter();
	}

	// Token: 0x060006BD RID: 1725 RVA: 0x0002B724 File Offset: 0x00029924
	public void PreprocessAudioSamples(float[] data, int channels)
	{
		for (int i = 0; i < data.Length; i++)
		{
			data[i] *= this.gain;
		}
	}

	// Token: 0x060006BE RID: 1726 RVA: 0x0002B74C File Offset: 0x0002994C
	public void PostprocessAudioSamples(float[] data, int channels)
	{
		if (!this.audioLoopback)
		{
			for (int i = 0; i < data.Length; i++)
			{
				data[i] *= 0f;
			}
		}
	}

	// Token: 0x060006BF RID: 1727 RVA: 0x0002B77C File Offset: 0x0002997C
	public void ProcessAudioSamplesRaw(float[] data, int channels)
	{
		lock (this)
		{
			if (base.Context != 0U && OVRLipSync.IsInitialized() == OVRLipSync.Result.Success)
			{
				OVRLipSync.Frame frame = base.Frame;
				OVRLipSync.ProcessFrame(base.Context, data, frame, channels == 2);
			}
		}
	}

	// Token: 0x060006C0 RID: 1728 RVA: 0x0002B7DC File Offset: 0x000299DC
	public void ProcessAudioSamplesRaw(short[] data, int channels)
	{
		lock (this)
		{
			if (base.Context != 0U && OVRLipSync.IsInitialized() == OVRLipSync.Result.Success)
			{
				OVRLipSync.Frame frame = base.Frame;
				OVRLipSync.ProcessFrame(base.Context, data, frame, channels == 2);
			}
		}
	}

	// Token: 0x060006C1 RID: 1729 RVA: 0x0002B83C File Offset: 0x00029A3C
	public void ProcessAudioSamples(float[] data, int channels)
	{
		if (OVRLipSync.IsInitialized() != OVRLipSync.Result.Success || this.audioSource == null)
		{
			return;
		}
		this.PreprocessAudioSamples(data, channels);
		this.ProcessAudioSamplesRaw(data, channels);
		this.PostprocessAudioSamples(data, channels);
	}

	// Token: 0x060006C2 RID: 1730 RVA: 0x0002B86C File Offset: 0x00029A6C
	private void OnAudioFilterRead(float[] data, int channels)
	{
		if (!this.skipAudioSource)
		{
			this.ProcessAudioSamples(data, channels);
		}
	}

	// Token: 0x060006C3 RID: 1731 RVA: 0x0002B880 File Offset: 0x00029A80
	private void DebugShowVisemesAndLaughter()
	{
		if (this.hasDebugConsole)
		{
			string text = "";
			if (this.showLaughter)
			{
				text += "Laughter:";
				int num = (int)(50f * base.Frame.laughterScore);
				for (int i = 0; i < num; i++)
				{
					text += "*";
				}
				text += "\n";
			}
			if (this.showVisemes)
			{
				for (int j = 0; j < base.Frame.Visemes.Length; j++)
				{
					string str = text;
					OVRLipSync.Viseme viseme = (OVRLipSync.Viseme)j;
					text = str + viseme.ToString();
					text += ":";
					int num2 = (int)(50f * base.Frame.Visemes[j]);
					for (int k = 0; k < num2; k++)
					{
						text += "*";
					}
					text += "\n";
				}
			}
			OVRLipSyncDebugConsole.Clear();
			if (text != "")
			{
				OVRLipSyncDebugConsole.Log(text);
			}
		}
	}

	// Token: 0x060006C4 RID: 1732 RVA: 0x0002B984 File Offset: 0x00029B84
	private void ToggleAudioLoopback()
	{
		this.audioLoopback = !this.audioLoopback;
		if (this.hasDebugConsole)
		{
			OVRLipSyncDebugConsole.Clear();
			OVRLipSyncDebugConsole.ClearTimeout(1.5f);
			if (this.audioLoopback)
			{
				OVRLipSyncDebugConsole.Log("LOOPBACK MODE: ENABLED");
				return;
			}
			OVRLipSyncDebugConsole.Log("LOOPBACK MODE: DISABLED");
		}
	}

	// Token: 0x060006C5 RID: 1733 RVA: 0x0002B9D4 File Offset: 0x00029BD4
	private void LocalTouchEventCallback(OVRTouchpad.TouchEvent touchEvent)
	{
		string text = "LINEAR GAIN: ";
		if (touchEvent != OVRTouchpad.TouchEvent.SingleTap)
		{
			if (touchEvent != OVRTouchpad.TouchEvent.Up)
			{
				if (touchEvent != OVRTouchpad.TouchEvent.Down)
				{
					return;
				}
				this.gain -= 1f;
				if (this.gain < 1f)
				{
					this.gain = 1f;
				}
				text += this.gain;
				if (this.hasDebugConsole)
				{
					OVRLipSyncDebugConsole.Clear();
					OVRLipSyncDebugConsole.Log(text);
					OVRLipSyncDebugConsole.ClearTimeout(1.5f);
				}
			}
			else
			{
				this.gain += 1f;
				if (this.gain > 15f)
				{
					this.gain = 15f;
				}
				text += this.gain;
				if (this.hasDebugConsole)
				{
					OVRLipSyncDebugConsole.Clear();
					OVRLipSyncDebugConsole.Log(text);
					OVRLipSyncDebugConsole.ClearTimeout(1.5f);
					return;
				}
			}
			return;
		}
		this.ToggleAudioLoopback();
	}

	// Token: 0x040008EE RID: 2286
	[Tooltip("Allow capturing of keyboard input to control operation.")]
	public bool enableKeyboardInput;

	// Token: 0x040008EF RID: 2287
	[Tooltip("Register a mouse/touch callback to control loopback and gain (requires script restart).")]
	public bool enableTouchInput;

	// Token: 0x040008F0 RID: 2288
	[Tooltip("Play input audio back through audio output.")]
	public bool audioLoopback;

	// Token: 0x040008F1 RID: 2289
	[Tooltip("Key to toggle audio loopback.")]
	public KeyCode loopbackKey = KeyCode.L;

	// Token: 0x040008F2 RID: 2290
	[Tooltip("Show viseme scores in an OVRLipSyncDebugConsole display.")]
	public bool showVisemes;

	// Token: 0x040008F3 RID: 2291
	[Tooltip("Key to toggle viseme score display.")]
	public KeyCode debugVisemesKey = KeyCode.D;

	// Token: 0x040008F4 RID: 2292
	[Tooltip("Skip data from the Audio Source. Use if you intend to pass audio data in manually.")]
	public bool skipAudioSource;

	// Token: 0x040008F5 RID: 2293
	[Tooltip("Adjust the linear audio gain multiplier before processing lipsync")]
	public float gain = 1f;

	// Token: 0x040008F6 RID: 2294
	private bool hasDebugConsole;

	// Token: 0x040008F7 RID: 2295
	public KeyCode debugLaughterKey = KeyCode.H;

	// Token: 0x040008F8 RID: 2296
	public bool showLaughter;

	// Token: 0x040008F9 RID: 2297
	public float laughterScore;
}
