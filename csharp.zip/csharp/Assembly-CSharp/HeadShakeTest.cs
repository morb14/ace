﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x0200000E RID: 14
public class HeadShakeTest : MonoBehaviour
{
	// Token: 0x06000044 RID: 68 RVA: 0x0000342F File Offset: 0x0000162F
	private void Start()
	{
		this.text.text = "0";
		this.headTurn = HeadShakeTest.HeadTurn.NotTurning;
	}

	// Token: 0x06000045 RID: 69 RVA: 0x00003448 File Offset: 0x00001648
	private void Update()
	{
		float y = Camera.main.transform.rotation.y;
		if (this.previousRotation == 0f)
		{
			this.previousRotation = y;
		}
		if (this.previousRotation > y + 0.01f)
		{
			if (this.headTurn == HeadShakeTest.HeadTurn.NotTurning || this.headTurn == HeadShakeTest.HeadTurn.TurningRight)
			{
				this.headTurn = HeadShakeTest.HeadTurn.TurningLeft;
				this.headTurnCount++;
			}
		}
		else if (this.previousRotation + 0.01f < y && (this.headTurn == HeadShakeTest.HeadTurn.NotTurning || this.headTurn == HeadShakeTest.HeadTurn.TurningLeft))
		{
			this.headTurn = HeadShakeTest.HeadTurn.TurningRight;
			this.headTurnCount++;
		}
		if (this.headTurnCount >= 4)
		{
			this.headShakeCount++;
			this.headTurnCount = 0;
		}
		this.previousRotation = y;
	}

	// Token: 0x04000036 RID: 54
	private HeadShakeTest.HeadTurn headTurn;

	// Token: 0x04000037 RID: 55
	private int headShakeCount;

	// Token: 0x04000038 RID: 56
	private int headTurnCount;

	// Token: 0x04000039 RID: 57
	private float previousRotation;

	// Token: 0x0400003A RID: 58
	[SerializeField]
	private TMP_Text text;

	// Token: 0x020001A6 RID: 422
	private enum HeadTurn
	{
		// Token: 0x04000CEC RID: 3308
		TurningLeft,
		// Token: 0x04000CED RID: 3309
		TurningRight,
		// Token: 0x04000CEE RID: 3310
		NotTurning
	}
}
