﻿using System;

// Token: 0x020000C8 RID: 200
public enum ovrAvatarLogLevel
{
	// Token: 0x040007BC RID: 1980
	Unknown,
	// Token: 0x040007BD RID: 1981
	Default,
	// Token: 0x040007BE RID: 1982
	Verbose,
	// Token: 0x040007BF RID: 1983
	Debug,
	// Token: 0x040007C0 RID: 1984
	Info,
	// Token: 0x040007C1 RID: 1985
	Warn,
	// Token: 0x040007C2 RID: 1986
	Error,
	// Token: 0x040007C3 RID: 1987
	Fatal,
	// Token: 0x040007C4 RID: 1988
	Silent
}
