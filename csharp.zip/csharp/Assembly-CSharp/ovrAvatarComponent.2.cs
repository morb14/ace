﻿using System;
using System.Runtime.InteropServices;

// Token: 0x020000CD RID: 205
public struct ovrAvatarComponent
{
	// Token: 0x040007DD RID: 2013
	public ovrAvatarTransform transform;

	// Token: 0x040007DE RID: 2014
	public uint renderPartCount;

	// Token: 0x040007DF RID: 2015
	public IntPtr renderParts;

	// Token: 0x040007E0 RID: 2016
	[MarshalAs(UnmanagedType.LPStr)]
	public string name;
}
