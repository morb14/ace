﻿using System;
using TMPro;
using UnityEngine;

// Token: 0x02000005 RID: 5
public class CompMenu : MonoBehaviour
{
	// Token: 0x0600000E RID: 14 RVA: 0x0000220C File Offset: 0x0000040C
	private void Start()
	{
		if (this.stageID != "" && base.GetComponent<MenuButton>().subMenuType == MenuButton.SubMenuType.CompMode && !base.GetComponent<Collider>().enabled)
		{
			this.text.text = "COMING SOON";
			this.text.fontSize = 24f;
		}
		if (base.GetComponent<MenuButton>().subMenuType != MenuButton.SubMenuType.CompMode)
		{
			base.enabled = false;
			return;
		}
		if (this.menuScoreManager == null)
		{
			this.menuScoreManager = Object.FindObjectOfType<MenuScoreManager>();
		}
		this.UpdateAchievementShields();
	}

	// Token: 0x0600000F RID: 15 RVA: 0x0000229C File Offset: 0x0000049C
	private void UpdateAchievementShields()
	{
		SaveManager.ResultList topScore = this.menuScoreManager.GetTopScore(this.stageID);
		if (topScore != null)
		{
			if (topScore.played)
			{
				this.ToggleShield(this.shieldOne, true, null);
			}
			if (topScore.virginiaCount)
			{
				this.ToggleShield(this.shieldTwo, true, null);
			}
			if (topScore.bronzeShield)
			{
				this.ToggleShield(this.ShieldThree, true, this.bronzeShield);
			}
			if (topScore.silverShield)
			{
				this.ToggleShield(this.ShieldThree, true, this.silverShield);
			}
			if (topScore.goldShield)
			{
				this.ToggleShield(this.ShieldThree, true, this.goldShield);
			}
		}
	}

	// Token: 0x06000010 RID: 16 RVA: 0x0000233B File Offset: 0x0000053B
	private void ToggleShield(MeshRenderer shield, bool toFill, Material passMaterial = null)
	{
		if (!toFill)
		{
			shield.material = this.emptyShield;
			return;
		}
		if (passMaterial != null)
		{
			shield.material = passMaterial;
			return;
		}
		shield.material = this.goldShield;
	}

	// Token: 0x04000008 RID: 8
	[SerializeField]
	private MeshRenderer shieldOne;

	// Token: 0x04000009 RID: 9
	[SerializeField]
	private MeshRenderer shieldTwo;

	// Token: 0x0400000A RID: 10
	[SerializeField]
	private MeshRenderer ShieldThree;

	// Token: 0x0400000B RID: 11
	[SerializeField]
	private Material emptyShield;

	// Token: 0x0400000C RID: 12
	[SerializeField]
	private Material bronzeShield;

	// Token: 0x0400000D RID: 13
	[SerializeField]
	private Material silverShield;

	// Token: 0x0400000E RID: 14
	[SerializeField]
	private Material goldShield;

	// Token: 0x0400000F RID: 15
	[SerializeField]
	private TMP_Text text;

	// Token: 0x04000010 RID: 16
	[SerializeField]
	public string stageID;

	// Token: 0x04000011 RID: 17
	[SerializeField]
	private MenuScoreManager menuScoreManager;
}
