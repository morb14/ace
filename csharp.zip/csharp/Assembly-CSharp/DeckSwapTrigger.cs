﻿using System;
using UnityEngine;

// Token: 0x02000037 RID: 55
public class DeckSwapTrigger : MonoBehaviour
{
	// Token: 0x060001ED RID: 493 RVA: 0x0000ADA7 File Offset: 0x00008FA7
	private void Start()
	{
		this.stagePlanner = Object.FindObjectOfType<StagePlanner>();
	}

	// Token: 0x060001EE RID: 494 RVA: 0x0000ADB4 File Offset: 0x00008FB4
	private void OnTriggerExit(Collider other)
	{
		if (other.GetComponentInChildren<ObjectSpawner>())
		{
			this.stagePlanner.BackSpawnnerHotSwap(other.GetComponentInChildren<ObjectSpawner>());
		}
	}

	// Token: 0x040001A8 RID: 424
	private StagePlanner stagePlanner;
}
