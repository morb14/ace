﻿using System;
using UnityEngine;

// Token: 0x0200013E RID: 318
[AddComponentMenu("Camera-Control/Mouse Look")]
public class MouseLook : MonoBehaviour
{
	// Token: 0x06000843 RID: 2115 RVA: 0x00034070 File Offset: 0x00032270
	private void Update()
	{
		if (this.axes == MouseLook.RotationAxes.MouseXAndY)
		{
			float y = base.transform.localEulerAngles.y + Input.GetAxis("Mouse X") * this.sensitivityX;
			this.rotationY += Input.GetAxis("Mouse Y") * this.sensitivityY;
			this.rotationY = Mathf.Clamp(this.rotationY, this.minimumY, this.maximumY);
			base.transform.localEulerAngles = new Vector3(-this.rotationY, y, 0f);
			return;
		}
		if (this.axes == MouseLook.RotationAxes.MouseX)
		{
			base.transform.Rotate(0f, Input.GetAxis("Mouse X") * this.sensitivityX, 0f);
			return;
		}
		this.rotationY += Input.GetAxis("Mouse Y") * this.sensitivityY;
		this.rotationY = Mathf.Clamp(this.rotationY, this.minimumY, this.maximumY);
		base.transform.localEulerAngles = new Vector3(-this.rotationY, base.transform.localEulerAngles.y, 0f);
	}

	// Token: 0x06000844 RID: 2116 RVA: 0x00034198 File Offset: 0x00032398
	private void Start()
	{
		if (base.GetComponent<Rigidbody>())
		{
			base.GetComponent<Rigidbody>().freezeRotation = true;
		}
	}

	// Token: 0x04000A4C RID: 2636
	public MouseLook.RotationAxes axes;

	// Token: 0x04000A4D RID: 2637
	public float sensitivityX = 15f;

	// Token: 0x04000A4E RID: 2638
	public float sensitivityY = 15f;

	// Token: 0x04000A4F RID: 2639
	public float minimumX = -360f;

	// Token: 0x04000A50 RID: 2640
	public float maximumX = 360f;

	// Token: 0x04000A51 RID: 2641
	public float minimumY = -60f;

	// Token: 0x04000A52 RID: 2642
	public float maximumY = 60f;

	// Token: 0x04000A53 RID: 2643
	private float rotationY;

	// Token: 0x0200022B RID: 555
	public enum RotationAxes
	{
		// Token: 0x04000F52 RID: 3922
		MouseXAndY,
		// Token: 0x04000F53 RID: 3923
		MouseX,
		// Token: 0x04000F54 RID: 3924
		MouseY
	}
}
