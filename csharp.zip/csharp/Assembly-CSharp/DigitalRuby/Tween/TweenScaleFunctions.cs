﻿using System;
using UnityEngine;

namespace DigitalRuby.Tween
{
	// Token: 0x020001A2 RID: 418
	public static class TweenScaleFunctions
	{
		// Token: 0x06000BCF RID: 3023 RVA: 0x00043519 File Offset: 0x00041719
		private static float LinearFunc(float progress)
		{
			return progress;
		}

		// Token: 0x06000BD0 RID: 3024 RVA: 0x0004351C File Offset: 0x0004171C
		private static float QuadraticEaseInFunc(float progress)
		{
			return TweenScaleFunctions.EaseInPower(progress, 2);
		}

		// Token: 0x06000BD1 RID: 3025 RVA: 0x00043525 File Offset: 0x00041725
		private static float QuadraticEaseOutFunc(float progress)
		{
			return TweenScaleFunctions.EaseOutPower(progress, 2);
		}

		// Token: 0x06000BD2 RID: 3026 RVA: 0x0004352E File Offset: 0x0004172E
		private static float QuadraticEaseInOutFunc(float progress)
		{
			return TweenScaleFunctions.EaseInOutPower(progress, 2);
		}

		// Token: 0x06000BD3 RID: 3027 RVA: 0x00043537 File Offset: 0x00041737
		private static float CubicEaseInFunc(float progress)
		{
			return TweenScaleFunctions.EaseInPower(progress, 3);
		}

		// Token: 0x06000BD4 RID: 3028 RVA: 0x00043540 File Offset: 0x00041740
		private static float CubicEaseOutFunc(float progress)
		{
			return TweenScaleFunctions.EaseOutPower(progress, 3);
		}

		// Token: 0x06000BD5 RID: 3029 RVA: 0x00043549 File Offset: 0x00041749
		private static float CubicEaseInOutFunc(float progress)
		{
			return TweenScaleFunctions.EaseInOutPower(progress, 3);
		}

		// Token: 0x06000BD6 RID: 3030 RVA: 0x00043552 File Offset: 0x00041752
		private static float QuarticEaseInFunc(float progress)
		{
			return TweenScaleFunctions.EaseInPower(progress, 4);
		}

		// Token: 0x06000BD7 RID: 3031 RVA: 0x0004355B File Offset: 0x0004175B
		private static float QuarticEaseOutFunc(float progress)
		{
			return TweenScaleFunctions.EaseOutPower(progress, 4);
		}

		// Token: 0x06000BD8 RID: 3032 RVA: 0x00043564 File Offset: 0x00041764
		private static float QuarticEaseInOutFunc(float progress)
		{
			return TweenScaleFunctions.EaseInOutPower(progress, 4);
		}

		// Token: 0x06000BD9 RID: 3033 RVA: 0x0004356D File Offset: 0x0004176D
		private static float QuinticEaseInFunc(float progress)
		{
			return TweenScaleFunctions.EaseInPower(progress, 5);
		}

		// Token: 0x06000BDA RID: 3034 RVA: 0x00043576 File Offset: 0x00041776
		private static float QuinticEaseOutFunc(float progress)
		{
			return TweenScaleFunctions.EaseOutPower(progress, 5);
		}

		// Token: 0x06000BDB RID: 3035 RVA: 0x0004357F File Offset: 0x0004177F
		private static float QuinticEaseInOutFunc(float progress)
		{
			return TweenScaleFunctions.EaseInOutPower(progress, 5);
		}

		// Token: 0x06000BDC RID: 3036 RVA: 0x00043588 File Offset: 0x00041788
		private static float SineEaseInFunc(float progress)
		{
			return Mathf.Sin(progress * 1.5707964f - 1.5707964f) + 1f;
		}

		// Token: 0x06000BDD RID: 3037 RVA: 0x000435A2 File Offset: 0x000417A2
		private static float SineEaseOutFunc(float progress)
		{
			return Mathf.Sin(progress * 1.5707964f);
		}

		// Token: 0x06000BDE RID: 3038 RVA: 0x000435B0 File Offset: 0x000417B0
		private static float SineEaseInOutFunc(float progress)
		{
			return (Mathf.Sin(progress * 3.1415927f - 1.5707964f) + 1f) / 2f;
		}

		// Token: 0x06000BDF RID: 3039 RVA: 0x000435D0 File Offset: 0x000417D0
		private static float EaseInPower(float progress, int power)
		{
			return Mathf.Pow(progress, (float)power);
		}

		// Token: 0x06000BE0 RID: 3040 RVA: 0x000435DC File Offset: 0x000417DC
		private static float EaseOutPower(float progress, int power)
		{
			int num = (power % 2 == 0) ? -1 : 1;
			return (float)num * (Mathf.Pow(progress - 1f, (float)power) + (float)num);
		}

		// Token: 0x06000BE1 RID: 3041 RVA: 0x00043608 File Offset: 0x00041808
		private static float EaseInOutPower(float progress, int power)
		{
			progress *= 2f;
			if (progress < 1f)
			{
				return Mathf.Pow(progress, (float)power) / 2f;
			}
			int num = (power % 2 == 0) ? -1 : 1;
			return (float)num / 2f * (Mathf.Pow(progress - 2f, (float)power) + (float)(num * 2));
		}

		// Token: 0x04000CC9 RID: 3273
		private const float halfPi = 1.5707964f;

		// Token: 0x04000CCA RID: 3274
		public static readonly Func<float, float> Linear = new Func<float, float>(TweenScaleFunctions.LinearFunc);

		// Token: 0x04000CCB RID: 3275
		public static readonly Func<float, float> QuadraticEaseIn = new Func<float, float>(TweenScaleFunctions.QuadraticEaseInFunc);

		// Token: 0x04000CCC RID: 3276
		public static readonly Func<float, float> QuadraticEaseOut = new Func<float, float>(TweenScaleFunctions.QuadraticEaseOutFunc);

		// Token: 0x04000CCD RID: 3277
		public static readonly Func<float, float> QuadraticEaseInOut = new Func<float, float>(TweenScaleFunctions.QuadraticEaseInOutFunc);

		// Token: 0x04000CCE RID: 3278
		public static readonly Func<float, float> CubicEaseIn = new Func<float, float>(TweenScaleFunctions.CubicEaseInFunc);

		// Token: 0x04000CCF RID: 3279
		public static readonly Func<float, float> CubicEaseOut = new Func<float, float>(TweenScaleFunctions.CubicEaseOutFunc);

		// Token: 0x04000CD0 RID: 3280
		public static readonly Func<float, float> CubicEaseInOut = new Func<float, float>(TweenScaleFunctions.CubicEaseInOutFunc);

		// Token: 0x04000CD1 RID: 3281
		public static readonly Func<float, float> QuarticEaseIn = new Func<float, float>(TweenScaleFunctions.QuarticEaseInFunc);

		// Token: 0x04000CD2 RID: 3282
		public static readonly Func<float, float> QuarticEaseOut = new Func<float, float>(TweenScaleFunctions.QuarticEaseOutFunc);

		// Token: 0x04000CD3 RID: 3283
		public static readonly Func<float, float> QuarticEaseInOut = new Func<float, float>(TweenScaleFunctions.QuarticEaseInOutFunc);

		// Token: 0x04000CD4 RID: 3284
		public static readonly Func<float, float> QuinticEaseIn = new Func<float, float>(TweenScaleFunctions.QuinticEaseInFunc);

		// Token: 0x04000CD5 RID: 3285
		public static readonly Func<float, float> QuinticEaseOut = new Func<float, float>(TweenScaleFunctions.QuinticEaseOutFunc);

		// Token: 0x04000CD6 RID: 3286
		public static readonly Func<float, float> QuinticEaseInOut = new Func<float, float>(TweenScaleFunctions.QuinticEaseInOutFunc);

		// Token: 0x04000CD7 RID: 3287
		public static readonly Func<float, float> SineEaseIn = new Func<float, float>(TweenScaleFunctions.SineEaseInFunc);

		// Token: 0x04000CD8 RID: 3288
		public static readonly Func<float, float> SineEaseOut = new Func<float, float>(TweenScaleFunctions.SineEaseOutFunc);

		// Token: 0x04000CD9 RID: 3289
		public static readonly Func<float, float> SineEaseInOut = new Func<float, float>(TweenScaleFunctions.SineEaseInOutFunc);
	}
}
