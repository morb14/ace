﻿using System;
using UnityEngine;

namespace DigitalRuby.Tween
{
	// Token: 0x0200019D RID: 413
	public class Vector2Tween : Tween<Vector2>
	{
		// Token: 0x06000BC0 RID: 3008 RVA: 0x00043447 File Offset: 0x00041647
		private static Vector2 LerpVector2(ITween<Vector2> t, Vector2 start, Vector2 end, float progress)
		{
			return Vector2.Lerp(start, end, progress);
		}

		// Token: 0x06000BC1 RID: 3009 RVA: 0x00043451 File Offset: 0x00041651
		public Vector2Tween() : base(Vector2Tween.LerpFunc)
		{
		}

		// Token: 0x04000CC4 RID: 3268
		private static readonly Func<ITween<Vector2>, Vector2, Vector2, float, Vector2> LerpFunc = new Func<ITween<Vector2>, Vector2, Vector2, float, Vector2>(Vector2Tween.LerpVector2);
	}
}
