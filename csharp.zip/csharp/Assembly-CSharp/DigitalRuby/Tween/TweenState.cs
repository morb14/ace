﻿using System;

namespace DigitalRuby.Tween
{
	// Token: 0x02000195 RID: 405
	public enum TweenState
	{
		// Token: 0x04000CA3 RID: 3235
		Running,
		// Token: 0x04000CA4 RID: 3236
		Paused,
		// Token: 0x04000CA5 RID: 3237
		Stopped
	}
}
