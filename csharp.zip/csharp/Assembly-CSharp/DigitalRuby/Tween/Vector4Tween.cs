﻿using System;
using UnityEngine;

namespace DigitalRuby.Tween
{
	// Token: 0x0200019F RID: 415
	public class Vector4Tween : Tween<Vector4>
	{
		// Token: 0x06000BC6 RID: 3014 RVA: 0x0004349B File Offset: 0x0004169B
		private static Vector4 LerpVector4(ITween<Vector4> t, Vector4 start, Vector4 end, float progress)
		{
			return Vector4.Lerp(start, end, progress);
		}

		// Token: 0x06000BC7 RID: 3015 RVA: 0x000434A5 File Offset: 0x000416A5
		public Vector4Tween() : base(Vector4Tween.LerpFunc)
		{
		}

		// Token: 0x04000CC6 RID: 3270
		private static readonly Func<ITween<Vector4>, Vector4, Vector4, float, Vector4> LerpFunc = new Func<ITween<Vector4>, Vector4, Vector4, float, Vector4>(Vector4Tween.LerpVector4);
	}
}
