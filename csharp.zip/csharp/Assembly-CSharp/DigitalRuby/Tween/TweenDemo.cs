﻿using System;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace DigitalRuby.Tween
{
	// Token: 0x02000194 RID: 404
	public class TweenDemo : MonoBehaviour
	{
		// Token: 0x06000B70 RID: 2928 RVA: 0x00042994 File Offset: 0x00040B94
		private void TweenMove()
		{
			Action<ITween<Vector3>> progress = delegate(ITween<Vector3> t)
			{
				this.Circle.gameObject.transform.position = t.CurrentValue;
			};
			Action<ITween<Vector3>> completion = delegate(ITween<Vector3> t)
			{
				Debug.Log("Circle move completed");
			};
			Vector3 position = this.Circle.transform.position;
			Vector3 vector = Camera.main.ViewportToWorldPoint(Vector3.zero);
			Vector3 vector2 = Camera.main.ViewportToWorldPoint(Vector3.one);
			Vector3 end = Camera.main.ViewportToWorldPoint(new Vector3(0.5f, 0.5f, 0.5f));
			position.z = (vector.z = (vector2.z = (end.z = 0f)));
			this.Circle.gameObject.Tween("MoveCircle", position, vector, 1.75f, TweenScaleFunctions.CubicEaseIn, progress, null).ContinueWith<Vector3>(new Vector3Tween().Setup(vector, vector2, 1.75f, TweenScaleFunctions.Linear, progress, null)).ContinueWith<Vector3>(new Vector3Tween().Setup(vector2, end, 1.75f, TweenScaleFunctions.CubicEaseOut, progress, completion));
		}

		// Token: 0x06000B71 RID: 2929 RVA: 0x00042AB4 File Offset: 0x00040CB4
		private void TweenColor()
		{
			Action<ITween<Color>> progress = delegate(ITween<Color> t)
			{
				this.spriteRenderer.color = t.CurrentValue;
			};
			Color end = Random.ColorHSV(0f, 1f, 0f, 1f, 0.5f, 1f, 1f, 1f);
			this.Circle.gameObject.Tween("ColorCircle", this.spriteRenderer.color, end, 1f, TweenScaleFunctions.QuadraticEaseOut, progress, null);
		}

		// Token: 0x06000B72 RID: 2930 RVA: 0x00042B2C File Offset: 0x00040D2C
		private void TweenRotate()
		{
			Action<ITween<float>> progress = delegate(ITween<float> t)
			{
				this.Circle.transform.rotation = Quaternion.identity;
				this.Circle.transform.Rotate(Camera.main.transform.forward, t.CurrentValue);
			};
			float z = this.Circle.transform.rotation.eulerAngles.z;
			float end = z + 720f;
			this.Circle.gameObject.Tween("RotateCircle", z, end, 2f, TweenScaleFunctions.CubicEaseInOut, progress, null);
		}

		// Token: 0x06000B73 RID: 2931 RVA: 0x00042B90 File Offset: 0x00040D90
		private void TweenReset()
		{
			SceneManager.LoadScene(0, LoadSceneMode.Single);
		}

		// Token: 0x06000B74 RID: 2932 RVA: 0x00042B99 File Offset: 0x00040D99
		private void Start()
		{
			TweenFactory.ClearTweensOnLevelLoad = true;
			this.spriteRenderer = this.Circle.GetComponent<SpriteRenderer>();
		}

		// Token: 0x06000B75 RID: 2933 RVA: 0x00042BB2 File Offset: 0x00040DB2
		private void Update()
		{
			if (Input.GetKeyDown(KeyCode.Alpha1))
			{
				this.TweenMove();
			}
			if (Input.GetKeyDown(KeyCode.Alpha2))
			{
				this.TweenColor();
			}
			if (Input.GetKeyDown(KeyCode.Alpha3))
			{
				this.TweenRotate();
			}
			if (Input.GetKeyDown(KeyCode.R))
			{
				this.TweenReset();
			}
		}

		// Token: 0x04000C9F RID: 3231
		public GameObject Circle;

		// Token: 0x04000CA0 RID: 3232
		public Light Light;

		// Token: 0x04000CA1 RID: 3233
		private SpriteRenderer spriteRenderer;
	}
}
