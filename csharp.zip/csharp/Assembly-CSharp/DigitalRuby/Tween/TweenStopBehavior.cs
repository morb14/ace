﻿using System;

namespace DigitalRuby.Tween
{
	// Token: 0x02000196 RID: 406
	public enum TweenStopBehavior
	{
		// Token: 0x04000CA7 RID: 3239
		DoNotModify,
		// Token: 0x04000CA8 RID: 3240
		Complete
	}
}
