﻿using System;
using UnityEngine;

namespace DigitalRuby.Tween
{
	// Token: 0x02000198 RID: 408
	public static class GameObjectTweenExtensions
	{
		// Token: 0x06000B8E RID: 2958 RVA: 0x00042FC4 File Offset: 0x000411C4
		public static FloatTween Tween(this GameObject obj, object key, float start, float end, float duration, Func<float, float> scaleFunc, Action<ITween<float>> progress, Action<ITween<float>> completion = null)
		{
			FloatTween floatTween = TweenFactory.Tween(key, start, end, duration, scaleFunc, progress, completion);
			floatTween.GameObject = obj;
			floatTween.Renderer = obj.GetComponent<Renderer>();
			return floatTween;
		}

		// Token: 0x06000B8F RID: 2959 RVA: 0x00042FE9 File Offset: 0x000411E9
		public static Vector2Tween Tween(this GameObject obj, object key, Vector2 start, Vector2 end, float duration, Func<float, float> scaleFunc, Action<ITween<Vector2>> progress, Action<ITween<Vector2>> completion = null)
		{
			Vector2Tween vector2Tween = TweenFactory.Tween(key, start, end, duration, scaleFunc, progress, completion);
			vector2Tween.GameObject = obj;
			vector2Tween.Renderer = obj.GetComponent<Renderer>();
			return vector2Tween;
		}

		// Token: 0x06000B90 RID: 2960 RVA: 0x0004300E File Offset: 0x0004120E
		public static Vector3Tween Tween(this GameObject obj, object key, Vector3 start, Vector3 end, float duration, Func<float, float> scaleFunc, Action<ITween<Vector3>> progress, Action<ITween<Vector3>> completion = null)
		{
			Vector3Tween vector3Tween = TweenFactory.Tween(key, start, end, duration, scaleFunc, progress, completion);
			vector3Tween.GameObject = obj;
			vector3Tween.Renderer = obj.GetComponent<Renderer>();
			return vector3Tween;
		}

		// Token: 0x06000B91 RID: 2961 RVA: 0x00043033 File Offset: 0x00041233
		public static Vector4Tween Tween(this GameObject obj, object key, Vector4 start, Vector4 end, float duration, Func<float, float> scaleFunc, Action<ITween<Vector4>> progress, Action<ITween<Vector4>> completion = null)
		{
			Vector4Tween vector4Tween = TweenFactory.Tween(key, start, end, duration, scaleFunc, progress, completion);
			vector4Tween.GameObject = obj;
			vector4Tween.Renderer = obj.GetComponent<Renderer>();
			return vector4Tween;
		}

		// Token: 0x06000B92 RID: 2962 RVA: 0x00043058 File Offset: 0x00041258
		public static ColorTween Tween(this GameObject obj, object key, Color start, Color end, float duration, Func<float, float> scaleFunc, Action<ITween<Color>> progress, Action<ITween<Color>> completion = null)
		{
			ColorTween colorTween = TweenFactory.Tween(key, start, end, duration, scaleFunc, progress, completion);
			colorTween.GameObject = obj;
			colorTween.Renderer = obj.GetComponent<Renderer>();
			return colorTween;
		}

		// Token: 0x06000B93 RID: 2963 RVA: 0x0004307D File Offset: 0x0004127D
		public static QuaternionTween Tween(this GameObject obj, object key, Quaternion start, Quaternion end, float duration, Func<float, float> scaleFunc, Action<ITween<Quaternion>> progress, Action<ITween<Quaternion>> completion = null)
		{
			QuaternionTween quaternionTween = TweenFactory.Tween(key, start, end, duration, scaleFunc, progress, completion);
			quaternionTween.GameObject = obj;
			quaternionTween.Renderer = obj.GetComponent<Renderer>();
			return quaternionTween;
		}
	}
}
