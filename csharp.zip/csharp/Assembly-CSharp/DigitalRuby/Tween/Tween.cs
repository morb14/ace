﻿using System;
using UnityEngine;

namespace DigitalRuby.Tween
{
	// Token: 0x0200019B RID: 411
	public class Tween<T> : ITween<T>, ITween where T : struct
	{
		// Token: 0x170000A4 RID: 164
		// (get) Token: 0x06000BA0 RID: 2976 RVA: 0x000430A2 File Offset: 0x000412A2
		// (set) Token: 0x06000BA1 RID: 2977 RVA: 0x000430AA File Offset: 0x000412AA
		public object Key { get; set; }

		// Token: 0x170000A5 RID: 165
		// (get) Token: 0x06000BA2 RID: 2978 RVA: 0x000430B3 File Offset: 0x000412B3
		public float CurrentTime
		{
			get
			{
				return this.currentTime;
			}
		}

		// Token: 0x170000A6 RID: 166
		// (get) Token: 0x06000BA3 RID: 2979 RVA: 0x000430BB File Offset: 0x000412BB
		public float Duration
		{
			get
			{
				return this.duration;
			}
		}

		// Token: 0x170000A7 RID: 167
		// (get) Token: 0x06000BA4 RID: 2980 RVA: 0x000430C3 File Offset: 0x000412C3
		// (set) Token: 0x06000BA5 RID: 2981 RVA: 0x000430CB File Offset: 0x000412CB
		public float Delay { get; set; }

		// Token: 0x170000A8 RID: 168
		// (get) Token: 0x06000BA6 RID: 2982 RVA: 0x000430D4 File Offset: 0x000412D4
		public TweenState State
		{
			get
			{
				return this.state;
			}
		}

		// Token: 0x170000A9 RID: 169
		// (get) Token: 0x06000BA7 RID: 2983 RVA: 0x000430DC File Offset: 0x000412DC
		public T StartValue
		{
			get
			{
				return this.start;
			}
		}

		// Token: 0x170000AA RID: 170
		// (get) Token: 0x06000BA8 RID: 2984 RVA: 0x000430E4 File Offset: 0x000412E4
		public T EndValue
		{
			get
			{
				return this.end;
			}
		}

		// Token: 0x170000AB RID: 171
		// (get) Token: 0x06000BA9 RID: 2985 RVA: 0x000430EC File Offset: 0x000412EC
		public T CurrentValue
		{
			get
			{
				return this.value;
			}
		}

		// Token: 0x170000AC RID: 172
		// (get) Token: 0x06000BAA RID: 2986 RVA: 0x000430F4 File Offset: 0x000412F4
		// (set) Token: 0x06000BAB RID: 2987 RVA: 0x000430FC File Offset: 0x000412FC
		public Func<float> TimeFunc { get; set; }

		// Token: 0x170000AD RID: 173
		// (get) Token: 0x06000BAC RID: 2988 RVA: 0x00043105 File Offset: 0x00041305
		// (set) Token: 0x06000BAD RID: 2989 RVA: 0x0004310D File Offset: 0x0004130D
		public GameObject GameObject { get; set; }

		// Token: 0x170000AE RID: 174
		// (get) Token: 0x06000BAE RID: 2990 RVA: 0x00043116 File Offset: 0x00041316
		// (set) Token: 0x06000BAF RID: 2991 RVA: 0x0004311E File Offset: 0x0004131E
		public Renderer Renderer { get; set; }

		// Token: 0x170000AF RID: 175
		// (get) Token: 0x06000BB0 RID: 2992 RVA: 0x00043127 File Offset: 0x00041327
		// (set) Token: 0x06000BB1 RID: 2993 RVA: 0x0004312F File Offset: 0x0004132F
		public bool ForceUpdate { get; set; }

		// Token: 0x170000B0 RID: 176
		// (get) Token: 0x06000BB2 RID: 2994 RVA: 0x00043138 File Offset: 0x00041338
		// (set) Token: 0x06000BB3 RID: 2995 RVA: 0x00043140 File Offset: 0x00041340
		public float CurrentProgress { get; private set; }

		// Token: 0x06000BB4 RID: 2996 RVA: 0x00043149 File Offset: 0x00041349
		public Tween(Func<ITween<T>, T, T, float, T> lerpFunc)
		{
			this.lerpFunc = lerpFunc;
			this.state = TweenState.Stopped;
			this.TimeFunc = TweenFactory.DefaultTimeFunc;
		}

		// Token: 0x06000BB5 RID: 2997 RVA: 0x0004316C File Offset: 0x0004136C
		public Tween<T> Setup(T start, T end, float duration, Func<float, float> scaleFunc, Action<ITween<T>> progress, Action<ITween<T>> completion = null)
		{
			scaleFunc = (scaleFunc ?? TweenScaleFunctions.Linear);
			this.currentTime = 0f;
			this.duration = duration;
			this.scaleFunc = scaleFunc;
			this.progressCallback = progress;
			this.completionCallback = completion;
			this.start = start;
			this.end = end;
			return this;
		}

		// Token: 0x06000BB6 RID: 2998 RVA: 0x000431C0 File Offset: 0x000413C0
		public void Start()
		{
			if (this.state != TweenState.Running)
			{
				if (this.duration <= 0f && this.Delay <= 0f)
				{
					this.value = this.end;
					if (this.progressCallback != null)
					{
						this.progressCallback(this);
					}
					if (this.completionCallback != null)
					{
						this.completionCallback(this);
					}
					return;
				}
				this.state = TweenState.Running;
				this.UpdateValue();
			}
		}

		// Token: 0x06000BB7 RID: 2999 RVA: 0x00043231 File Offset: 0x00041431
		public void Pause()
		{
			if (this.state == TweenState.Running)
			{
				this.state = TweenState.Paused;
			}
		}

		// Token: 0x06000BB8 RID: 3000 RVA: 0x00043242 File Offset: 0x00041442
		public void Resume()
		{
			if (this.state == TweenState.Paused)
			{
				this.state = TweenState.Running;
			}
		}

		// Token: 0x06000BB9 RID: 3001 RVA: 0x00043254 File Offset: 0x00041454
		public void Stop(TweenStopBehavior stopBehavior)
		{
			if (this.state != TweenState.Stopped)
			{
				this.state = TweenState.Stopped;
				if (stopBehavior == TweenStopBehavior.Complete)
				{
					this.currentTime = this.duration;
					this.UpdateValue();
					if (this.completionCallback != null)
					{
						this.completionCallback(this);
						this.completionCallback = null;
					}
					if (this.continueWith != null)
					{
						this.continueWith.Start();
						TweenFactory.AddTween(this.continueWith);
						this.continueWith = null;
					}
				}
			}
		}

		// Token: 0x06000BBA RID: 3002 RVA: 0x000432C8 File Offset: 0x000414C8
		public bool Update(float elapsedTime)
		{
			if (this.state != TweenState.Running)
			{
				return this.state == TweenState.Stopped;
			}
			if (this.Delay > 0f)
			{
				this.currentTime += elapsedTime;
				if (this.currentTime <= this.Delay)
				{
					return false;
				}
				this.currentTime -= this.Delay;
				this.Delay = 0f;
			}
			else
			{
				this.currentTime += elapsedTime;
			}
			if (this.currentTime >= this.duration)
			{
				this.Stop(TweenStopBehavior.Complete);
				return true;
			}
			this.UpdateValue();
			return false;
		}

		// Token: 0x06000BBB RID: 3003 RVA: 0x0004335E File Offset: 0x0004155E
		public Tween<TNewTween> ContinueWith<TNewTween>(Tween<TNewTween> tween) where TNewTween : struct
		{
			tween.Key = this.Key;
			tween.GameObject = this.GameObject;
			tween.Renderer = this.Renderer;
			tween.ForceUpdate = this.ForceUpdate;
			this.continueWith = tween;
			return tween;
		}

		// Token: 0x06000BBC RID: 3004 RVA: 0x00043398 File Offset: 0x00041598
		private void UpdateValue()
		{
			if (this.Renderer == null || this.Renderer.isVisible || this.ForceUpdate)
			{
				this.CurrentProgress = this.scaleFunc(this.currentTime / this.duration);
				this.value = this.lerpFunc(this, this.start, this.end, this.CurrentProgress);
				if (this.progressCallback != null)
				{
					this.progressCallback(this);
				}
			}
		}

		// Token: 0x04000CB1 RID: 3249
		private readonly Func<ITween<T>, T, T, float, T> lerpFunc;

		// Token: 0x04000CB2 RID: 3250
		private float currentTime;

		// Token: 0x04000CB3 RID: 3251
		private float duration;

		// Token: 0x04000CB4 RID: 3252
		private Func<float, float> scaleFunc;

		// Token: 0x04000CB5 RID: 3253
		private Action<ITween<T>> progressCallback;

		// Token: 0x04000CB6 RID: 3254
		private Action<ITween<T>> completionCallback;

		// Token: 0x04000CB7 RID: 3255
		private TweenState state;

		// Token: 0x04000CB8 RID: 3256
		private T start;

		// Token: 0x04000CB9 RID: 3257
		private T end;

		// Token: 0x04000CBA RID: 3258
		private T value;

		// Token: 0x04000CBB RID: 3259
		private ITween continueWith;
	}
}
