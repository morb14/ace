﻿using System;
using UnityEngine;

namespace DigitalRuby.Tween
{
	// Token: 0x020001A1 RID: 417
	public class QuaternionTween : Tween<Quaternion>
	{
		// Token: 0x06000BCC RID: 3020 RVA: 0x000434EF File Offset: 0x000416EF
		private static Quaternion LerpQuaternion(ITween<Quaternion> t, Quaternion start, Quaternion end, float progress)
		{
			return Quaternion.Lerp(start, end, progress);
		}

		// Token: 0x06000BCD RID: 3021 RVA: 0x000434F9 File Offset: 0x000416F9
		public QuaternionTween() : base(QuaternionTween.LerpFunc)
		{
		}

		// Token: 0x04000CC8 RID: 3272
		private static readonly Func<ITween<Quaternion>, Quaternion, Quaternion, float, Quaternion> LerpFunc = new Func<ITween<Quaternion>, Quaternion, Quaternion, float, Quaternion>(QuaternionTween.LerpQuaternion);
	}
}
