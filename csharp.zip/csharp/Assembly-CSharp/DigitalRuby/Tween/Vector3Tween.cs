﻿using System;
using UnityEngine;

namespace DigitalRuby.Tween
{
	// Token: 0x0200019E RID: 414
	public class Vector3Tween : Tween<Vector3>
	{
		// Token: 0x06000BC3 RID: 3011 RVA: 0x00043471 File Offset: 0x00041671
		private static Vector3 LerpVector3(ITween<Vector3> t, Vector3 start, Vector3 end, float progress)
		{
			return Vector3.Lerp(start, end, progress);
		}

		// Token: 0x06000BC4 RID: 3012 RVA: 0x0004347B File Offset: 0x0004167B
		public Vector3Tween() : base(Vector3Tween.LerpFunc)
		{
		}

		// Token: 0x04000CC5 RID: 3269
		private static readonly Func<ITween<Vector3>, Vector3, Vector3, float, Vector3> LerpFunc = new Func<ITween<Vector3>, Vector3, Vector3, float, Vector3>(Vector3Tween.LerpVector3);
	}
}
