﻿using System;

namespace DigitalRuby.Tween
{
	// Token: 0x0200019C RID: 412
	public class FloatTween : Tween<float>
	{
		// Token: 0x06000BBD RID: 3005 RVA: 0x0004341E File Offset: 0x0004161E
		private static float LerpFloat(ITween<float> t, float start, float end, float progress)
		{
			return start + (end - start) * progress;
		}

		// Token: 0x06000BBE RID: 3006 RVA: 0x00043427 File Offset: 0x00041627
		public FloatTween() : base(FloatTween.LerpFunc)
		{
		}

		// Token: 0x04000CC3 RID: 3267
		private static readonly Func<ITween<float>, float, float, float, float> LerpFunc = new Func<ITween<float>, float, float, float, float>(FloatTween.LerpFloat);
	}
}
