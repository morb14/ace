﻿using System;
using UnityEngine;

namespace DigitalRuby.Tween
{
	// Token: 0x020001A0 RID: 416
	public class ColorTween : Tween<Color>
	{
		// Token: 0x06000BC9 RID: 3017 RVA: 0x000434C5 File Offset: 0x000416C5
		private static Color LerpColor(ITween<Color> t, Color start, Color end, float progress)
		{
			return Color.Lerp(start, end, progress);
		}

		// Token: 0x06000BCA RID: 3018 RVA: 0x000434CF File Offset: 0x000416CF
		public ColorTween() : base(ColorTween.LerpFunc)
		{
		}

		// Token: 0x04000CC7 RID: 3271
		private static readonly Func<ITween<Color>, Color, Color, float, Color> LerpFunc = new Func<ITween<Color>, Color, Color, float, Color>(ColorTween.LerpColor);
	}
}
