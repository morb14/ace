﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace DigitalRuby.Tween
{
	// Token: 0x02000197 RID: 407
	public class TweenFactory : MonoBehaviour
	{
		// Token: 0x06000B7A RID: 2938 RVA: 0x00042C5C File Offset: 0x00040E5C
		private static void EnsureCreated()
		{
			if (TweenFactory.root == null && Application.isPlaying)
			{
				TweenFactory.root = GameObject.Find("DigitalRubyTween");
				if (TweenFactory.root == null || TweenFactory.root.GetComponent<TweenFactory>() == null)
				{
					if (TweenFactory.root != null)
					{
						TweenFactory.toDestroy = TweenFactory.root;
					}
					TweenFactory.root = new GameObject
					{
						name = "DigitalRubyTween",
						hideFlags = HideFlags.HideAndDontSave
					};
					TweenFactory.root.AddComponent<TweenFactory>().hideFlags = HideFlags.HideAndDontSave;
				}
				if (Application.isPlaying)
				{
					Object.DontDestroyOnLoad(TweenFactory.root);
				}
			}
		}

		// Token: 0x06000B7B RID: 2939 RVA: 0x00042D07 File Offset: 0x00040F07
		private void Start()
		{
			SceneManager.sceneLoaded += this.SceneManagerSceneLoaded;
			if (TweenFactory.toDestroy != null)
			{
				Object.Destroy(TweenFactory.toDestroy);
				TweenFactory.toDestroy = null;
			}
		}

		// Token: 0x06000B7C RID: 2940 RVA: 0x00042D37 File Offset: 0x00040F37
		private void SceneManagerSceneLoaded(Scene s, LoadSceneMode m)
		{
			if (TweenFactory.ClearTweensOnLevelLoad)
			{
				TweenFactory.tweens.Clear();
			}
		}

		// Token: 0x06000B7D RID: 2941 RVA: 0x00042D4C File Offset: 0x00040F4C
		private void Update()
		{
			for (int i = TweenFactory.tweens.Count - 1; i >= 0; i--)
			{
				ITween tween = TweenFactory.tweens[i];
				if (tween.Update(tween.TimeFunc()) && i < TweenFactory.tweens.Count && TweenFactory.tweens[i] == tween)
				{
					TweenFactory.tweens.RemoveAt(i);
				}
			}
		}

		// Token: 0x06000B7E RID: 2942 RVA: 0x00042DB5 File Offset: 0x00040FB5
		public static FloatTween Tween(object key, float start, float end, float duration, Func<float, float> scaleFunc, Action<ITween<float>> progress, Action<ITween<float>> completion = null)
		{
			FloatTween floatTween = new FloatTween();
			floatTween.Key = key;
			floatTween.Setup(start, end, duration, scaleFunc, progress, completion);
			floatTween.Start();
			TweenFactory.AddTween(floatTween);
			return floatTween;
		}

		// Token: 0x06000B7F RID: 2943 RVA: 0x00042DDF File Offset: 0x00040FDF
		public static Vector2Tween Tween(object key, Vector2 start, Vector2 end, float duration, Func<float, float> scaleFunc, Action<ITween<Vector2>> progress, Action<ITween<Vector2>> completion = null)
		{
			Vector2Tween vector2Tween = new Vector2Tween();
			vector2Tween.Key = key;
			vector2Tween.Setup(start, end, duration, scaleFunc, progress, completion);
			vector2Tween.Start();
			TweenFactory.AddTween(vector2Tween);
			return vector2Tween;
		}

		// Token: 0x06000B80 RID: 2944 RVA: 0x00042E09 File Offset: 0x00041009
		public static Vector3Tween Tween(object key, Vector3 start, Vector3 end, float duration, Func<float, float> scaleFunc, Action<ITween<Vector3>> progress, Action<ITween<Vector3>> completion = null)
		{
			Vector3Tween vector3Tween = new Vector3Tween();
			vector3Tween.Key = key;
			vector3Tween.Setup(start, end, duration, scaleFunc, progress, completion);
			vector3Tween.Start();
			TweenFactory.AddTween(vector3Tween);
			return vector3Tween;
		}

		// Token: 0x06000B81 RID: 2945 RVA: 0x00042E33 File Offset: 0x00041033
		public static Vector4Tween Tween(object key, Vector4 start, Vector4 end, float duration, Func<float, float> scaleFunc, Action<ITween<Vector4>> progress, Action<ITween<Vector4>> completion = null)
		{
			Vector4Tween vector4Tween = new Vector4Tween();
			vector4Tween.Key = key;
			vector4Tween.Setup(start, end, duration, scaleFunc, progress, completion);
			vector4Tween.Start();
			TweenFactory.AddTween(vector4Tween);
			return vector4Tween;
		}

		// Token: 0x06000B82 RID: 2946 RVA: 0x00042E5D File Offset: 0x0004105D
		public static ColorTween Tween(object key, Color start, Color end, float duration, Func<float, float> scaleFunc, Action<ITween<Color>> progress, Action<ITween<Color>> completion = null)
		{
			ColorTween colorTween = new ColorTween();
			colorTween.Key = key;
			colorTween.Setup(start, end, duration, scaleFunc, progress, completion);
			colorTween.Start();
			TweenFactory.AddTween(colorTween);
			return colorTween;
		}

		// Token: 0x06000B83 RID: 2947 RVA: 0x00042E87 File Offset: 0x00041087
		public static QuaternionTween Tween(object key, Quaternion start, Quaternion end, float duration, Func<float, float> scaleFunc, Action<ITween<Quaternion>> progress, Action<ITween<Quaternion>> completion = null)
		{
			QuaternionTween quaternionTween = new QuaternionTween();
			quaternionTween.Key = key;
			quaternionTween.Setup(start, end, duration, scaleFunc, progress, completion);
			quaternionTween.Start();
			TweenFactory.AddTween(quaternionTween);
			return quaternionTween;
		}

		// Token: 0x06000B84 RID: 2948 RVA: 0x00042EB1 File Offset: 0x000410B1
		public static void AddTween(ITween tween)
		{
			TweenFactory.EnsureCreated();
			if (tween.Key != null)
			{
				TweenFactory.RemoveTweenKey(tween.Key, TweenFactory.AddKeyStopBehavior);
			}
			TweenFactory.tweens.Add(tween);
		}

		// Token: 0x06000B85 RID: 2949 RVA: 0x00042EDC File Offset: 0x000410DC
		public static bool RemoveTween(ITween tween, TweenStopBehavior stopBehavior)
		{
			tween.Stop(stopBehavior);
			return TweenFactory.tweens.Remove(tween);
		}

		// Token: 0x06000B86 RID: 2950 RVA: 0x00042EF0 File Offset: 0x000410F0
		public static bool RemoveTweenKey(object key, TweenStopBehavior stopBehavior)
		{
			if (key == null)
			{
				return false;
			}
			bool result = false;
			for (int i = TweenFactory.tweens.Count - 1; i >= 0; i--)
			{
				ITween tween = TweenFactory.tweens[i];
				if (key.Equals(tween.Key))
				{
					tween.Stop(stopBehavior);
					TweenFactory.tweens.RemoveAt(i);
					result = true;
				}
			}
			return result;
		}

		// Token: 0x06000B87 RID: 2951 RVA: 0x00042F4A File Offset: 0x0004114A
		public static void Clear()
		{
			TweenFactory.tweens.Clear();
		}

		// Token: 0x1700009E RID: 158
		// (get) Token: 0x06000B88 RID: 2952 RVA: 0x00042F56 File Offset: 0x00041156
		// (set) Token: 0x06000B89 RID: 2953 RVA: 0x00042F5D File Offset: 0x0004115D
		public static bool ClearTweensOnLevelLoad { get; set; }

		// Token: 0x06000B8A RID: 2954 RVA: 0x00042F65 File Offset: 0x00041165
		private static float TimeFuncDeltaTime()
		{
			return Time.deltaTime;
		}

		// Token: 0x06000B8B RID: 2955 RVA: 0x00042F6C File Offset: 0x0004116C
		private static float TimeFuncUnscaledDeltaTime()
		{
			return Time.unscaledDeltaTime;
		}

		// Token: 0x04000CA9 RID: 3241
		private static GameObject root;

		// Token: 0x04000CAA RID: 3242
		private static readonly List<ITween> tweens = new List<ITween>();

		// Token: 0x04000CAB RID: 3243
		private static GameObject toDestroy;

		// Token: 0x04000CAC RID: 3244
		public static TweenStopBehavior AddKeyStopBehavior = TweenStopBehavior.DoNotModify;

		// Token: 0x04000CAE RID: 3246
		public static Func<float> DefaultTimeFunc = new Func<float>(TweenFactory.TimeFuncDeltaTime);

		// Token: 0x04000CAF RID: 3247
		public static readonly Func<float> TimeFuncDeltaTimeFunc = new Func<float>(TweenFactory.TimeFuncDeltaTime);

		// Token: 0x04000CB0 RID: 3248
		public static readonly Func<float> TimeFuncUnscaledDeltaTimeFunc = new Func<float>(TweenFactory.TimeFuncUnscaledDeltaTime);
	}
}
