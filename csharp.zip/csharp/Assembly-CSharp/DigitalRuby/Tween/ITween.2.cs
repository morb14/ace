﻿using System;

namespace DigitalRuby.Tween
{
	// Token: 0x0200019A RID: 410
	public interface ITween<T> : ITween where T : struct
	{
		// Token: 0x170000A2 RID: 162
		// (get) Token: 0x06000B9D RID: 2973
		T CurrentValue { get; }

		// Token: 0x170000A3 RID: 163
		// (get) Token: 0x06000B9E RID: 2974
		float CurrentProgress { get; }

		// Token: 0x06000B9F RID: 2975
		Tween<T> Setup(T start, T end, float duration, Func<float, float> scaleFunc, Action<ITween<T>> progress, Action<ITween<T>> completion = null);
	}
}
