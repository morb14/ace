﻿using System;

namespace DigitalRuby.Tween
{
	// Token: 0x02000199 RID: 409
	public interface ITween
	{
		// Token: 0x1700009F RID: 159
		// (get) Token: 0x06000B94 RID: 2964
		object Key { get; }

		// Token: 0x170000A0 RID: 160
		// (get) Token: 0x06000B95 RID: 2965
		TweenState State { get; }

		// Token: 0x170000A1 RID: 161
		// (get) Token: 0x06000B96 RID: 2966
		// (set) Token: 0x06000B97 RID: 2967
		Func<float> TimeFunc { get; set; }

		// Token: 0x06000B98 RID: 2968
		void Start();

		// Token: 0x06000B99 RID: 2969
		void Pause();

		// Token: 0x06000B9A RID: 2970
		void Resume();

		// Token: 0x06000B9B RID: 2971
		void Stop(TweenStopBehavior stopBehavior);

		// Token: 0x06000B9C RID: 2972
		bool Update(float elapsedTime);
	}
}
