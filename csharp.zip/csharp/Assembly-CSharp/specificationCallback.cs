﻿using System;

// Token: 0x020000F8 RID: 248
// (Invoke) Token: 0x0600063E RID: 1598
public delegate void specificationCallback(IntPtr specification);
