﻿using System;
using UnityEngine;

// Token: 0x02000003 RID: 3
public class AnimationWeaponController : MonoBehaviour
{
	// Token: 0x06000004 RID: 4 RVA: 0x00002080 File Offset: 0x00000280
	public void ReloadFinish()
	{
		this.weaponController.AnimationReload();
	}

	// Token: 0x06000005 RID: 5 RVA: 0x0000208D File Offset: 0x0000028D
	public void DoubleActionHammerDrop()
	{
		this.weaponController.AnimationDoubleActionHammerDrop();
	}

	// Token: 0x04000002 RID: 2
	[SerializeField]
	private WeaponController weaponController;
}
